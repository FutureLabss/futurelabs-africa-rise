<?php
/**
 * Snapshot of the current front-end request type.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Meta;

defined( 'ABSPATH' ) || exit;

/**
 * Describes what is being rendered so resolvers do not repeat conditional tag logic.
 */
final class Context {

	/**
	 * Kind: singular, front, home, term, author, date, post_type_archive, search, 404, other.
	 *
	 * @var string
	 */
	public string $kind;

	/**
	 * Queried object, when any.
	 *
	 * @var \WP_Post|\WP_Term|\WP_User|\WP_Post_Type|null
	 */
	public $object;

	/**
	 * Current page number (1-based).
	 *
	 * @var int
	 */
	public int $page;

	/**
	 * Constructor.
	 *
	 * @param string                                        $kind   Kind.
	 * @param \WP_Post|\WP_Term|\WP_User|\WP_Post_Type|null $object Object.
	 * @param int                                           $page   Page.
	 */
	public function __construct( string $kind, $object = null, int $page = 1 ) {
		$this->kind   = $kind;
		$this->object = $object;
		$this->page   = max( 1, $page );
	}

	/**
	 * Build from the main query.
	 */
	public static function current(): self {
		$page   = max( 1, (int) get_query_var( 'paged' ) );
		$object = get_queried_object();
		if ( is_404() ) {
			return new self( '404' );
		}
		if ( is_search() ) {
			return new self( 'search', null, $page );
		}
		if ( is_front_page() && ! is_home() && $object instanceof \WP_Post ) {
			return new self( 'front', $object, max( $page, (int) get_query_var( 'page' ) ) );
		}
		if ( is_front_page() || ( is_home() && ! $object ) ) {
			return new self( 'front', null, $page );
		}
		if ( is_home() ) {
			return new self( 'home', $object instanceof \WP_Post ? $object : null, $page );
		}
		if ( is_singular() && $object instanceof \WP_Post ) {
			return new self( 'singular', $object, max( 1, (int) get_query_var( 'page' ) ) );
		}
		if ( ( is_category() || is_tag() || is_tax() ) && $object instanceof \WP_Term ) {
			return new self( 'term', $object, $page );
		}
		if ( is_author() && $object instanceof \WP_User ) {
			return new self( 'author', $object, $page );
		}
		if ( is_post_type_archive() ) {
			$type = get_query_var( 'post_type' );
			$type = is_array( $type ) ? reset( $type ) : $type;
			return new self( 'post_type_archive', get_post_type_object( (string) $type ), $page );
		}
		if ( is_date() ) {
			return new self( 'date', null, $page );
		}
		return new self( 'other', null, $page );
	}

	/**
	 * Whether this is a page beyond the first of an archive listing.
	 */
	public function is_paged_archive(): bool {
		return $this->page > 1 && 'singular' !== $this->kind;
	}
}
