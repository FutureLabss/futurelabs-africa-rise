<?php
/**
 * News filter panel content: 2 featured posts, then the rest as small rows.
 * Also rendered by the REST route for lazily loaded tabs.
 *
 * @package NewsTheme
 *
 * @var array $args Block args with a `loop` WP_Query.
 */

defined( 'ABSPATH' ) || exit;

if ( ! $args['loop']->have_posts() ) {
	printf( '<p class="nt-empty">%s</p>', esc_html__( 'No posts yet.', 'newstheme' ) );
	return;
}
?>
<div class="nt-filter">
	<div class="nt-grid nt-grid--2 nt-filter__featured">
		<?php
		while ( $args['loop']->have_posts() && $args['loop']->current_post < 1 ) :
			$args['loop']->the_post();
			?>
			<article <?php post_class( 'nt-post nt-post--grid nt-post--featured' ); ?>>
				<?php newstheme_post_thumb( 'newstheme-medium', array( 'badge' => true ) ); ?>
				<?php
				newstheme_post_title( 'h3' );
				newstheme_post_meta( $args['meta'] );
				newstheme_post_excerpt( $args['excerpt'] );
				?>
			</article>
		<?php endwhile; ?>
	</div>
	<?php if ( $args['loop']->have_posts() ) : ?>
		<div class="nt-grid nt-grid--2 nt-filter__rest">
			<?php
			while ( $args['loop']->have_posts() ) :
				$args['loop']->the_post();
				?>
				<article <?php post_class( 'nt-post nt-post--row nt-post--small' ); ?>>
					<?php newstheme_post_thumb( 'newstheme-list', array( 'badge' => true ) ); ?>
					<div class="nt-post__body">
						<?php
						newstheme_post_title( 'h3' );
						newstheme_post_meta( $args['meta'] );
						?>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
	<?php endif; ?>
</div>
