<?php
/**
 * Per-term SEO fields for public taxonomies.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Meta;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Registers `_flseo_*` term meta and renders fields on term screens.
 */
class TermMeta implements Module {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Term fields and sanitizer kinds.
	 *
	 * @return array<string, string>
	 */
	public static function fields(): array {
		return array(
			'title'          => 'template',
			'description'    => 'template',
			'canonical'      => 'url',
			'og_title'       => 'template',
			'og_description' => 'template',
			'og_image'       => 'url',
			'noindex'        => 'flag',
		);
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'register_meta' ), 20 );
		add_action( 'created_term', array( $this, 'save' ), 10, 3 );
		add_action( 'edited_term', array( $this, 'save' ), 10, 3 );
	}

	/**
	 * Register meta and screen hooks for public taxonomies.
	 */
	public function register_meta(): void {
		foreach ( get_taxonomies( array( 'public' => true ), 'names' ) as $taxonomy ) {
			foreach ( self::fields() as $key => $kind ) {
				register_term_meta(
					$taxonomy,
					'_flseo_' . $key,
					array(
						'type'              => 'string',
						'single'            => true,
						'show_in_rest'      => 'noindex' !== $key,
						'sanitize_callback' => static function ( $value ) use ( $kind ) {
							return 'flag' === $kind ? ( in_array( $value, array( '1', 'index' ), true ) ? $value : '' ) : PostMeta::sanitize( $kind, $value );
						},
						'auth_callback'     => static function ( $allowed, $meta_key, $term_id ) {
							$term = get_term( (int) $term_id );
							if ( ! $term instanceof \WP_Term ) {
								return false;
							}
							$tax = get_taxonomy( $term->taxonomy );
							return $tax && current_user_can( $tax->cap->edit_terms );
						},
					)
				);
			}
			add_action( $taxonomy . '_edit_form_fields', array( $this, 'render_edit' ), 10, 1 );
			add_action( $taxonomy . '_add_form_fields', array( $this, 'render_add' ), 10, 0 );
		}
	}

	/**
	 * Field labels.
	 *
	 * @return array<string, string>
	 */
	private function labels(): array {
		return array(
			'title'          => __( 'SEO title template', 'futurelabs-ai-seo' ),
			'description'    => __( 'Meta description', 'futurelabs-ai-seo' ),
			'canonical'      => __( 'Canonical URL', 'futurelabs-ai-seo' ),
			'og_title'       => __( 'Social title', 'futurelabs-ai-seo' ),
			'og_description' => __( 'Social description', 'futurelabs-ai-seo' ),
			'og_image'       => __( 'Social image URL', 'futurelabs-ai-seo' ),
		);
	}

	/**
	 * Fields on the edit term screen.
	 *
	 * @param \WP_Term $term Term.
	 */
	public function render_edit( \WP_Term $term ): void {
		wp_nonce_field( 'flseo_save_term', 'flseo_term_nonce' );
		foreach ( $this->labels() as $key => $label ) {
			$value = (string) get_term_meta( $term->term_id, '_flseo_' . $key, true );
			printf(
				'<tr class="form-field"><th scope="row"><label for="flseo-term-%1$s">%2$s</label></th><td><input class="regular-text" id="flseo-term-%1$s" name="flseo_term_%1$s" value="%3$s" /></td></tr>',
				esc_attr( $key ),
				esc_html( $label ),
				esc_attr( $value )
			);
		}
		$noindex = '1' === (string) get_term_meta( $term->term_id, '_flseo_noindex', true );
		printf(
			'<tr class="form-field"><th scope="row">%1$s</th><td><label><input type="checkbox" name="flseo_term_noindex" value="1" %2$s /> %3$s</label></td></tr>',
			esc_html__( 'Robots', 'futurelabs-ai-seo' ),
			checked( $noindex, true, false ),
			esc_html__( 'Noindex this archive', 'futurelabs-ai-seo' )
		);
	}

	/**
	 * Fields on the add term form.
	 */
	public function render_add(): void {
		wp_nonce_field( 'flseo_save_term', 'flseo_term_nonce' );
		foreach ( array_intersect_key( $this->labels(), array_flip( array( 'title', 'description' ) ) ) as $key => $label ) {
			printf(
				'<div class="form-field"><label for="flseo-term-%1$s">%2$s</label><input id="flseo-term-%1$s" name="flseo_term_%1$s" value="" /></div>',
				esc_attr( $key ),
				esc_html( $label )
			);
		}
		printf( '<div class="form-field"><label><input type="checkbox" name="flseo_term_noindex" value="1" /> %s</label></div>', esc_html__( 'Noindex this archive', 'futurelabs-ai-seo' ) );
	}

	/**
	 * Save fields.
	 *
	 * @param int    $term_id  Term ID.
	 * @param int    $tt_id    Term taxonomy ID.
	 * @param string $taxonomy Taxonomy.
	 */
	public function save( int $term_id, int $tt_id, string $taxonomy ): void {
		if ( ! isset( $_POST['flseo_term_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['flseo_term_nonce'] ) ), 'flseo_save_term' ) ) {
			return;
		}
		$tax = get_taxonomy( $taxonomy );
		if ( ! $tax || ! current_user_can( $tax->cap->edit_terms ) ) {
			return;
		}
		foreach ( self::fields() as $key => $kind ) {
			if ( 'noindex' === $key ) {
				continue;
			}
			if ( ! isset( $_POST[ 'flseo_term_' . $key ] ) ) {
				continue;
			}
			$value = PostMeta::sanitize( $kind, wp_unslash( $_POST[ 'flseo_term_' . $key ] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized by kind.
			if ( '' === $value ) {
				delete_term_meta( $term_id, '_flseo_' . $key );
			} else {
				update_term_meta( $term_id, '_flseo_' . $key, $value );
			}
		}
		$old = (string) get_term_meta( $term_id, '_flseo_noindex', true );
		$new = isset( $_POST['flseo_term_noindex'] ) ? '1' : ( '1' === $old ? '' : $old );
		if ( $new === $old ) {
			return;
		}
		$audit = $this->c->get( \FutureLabs\AISEO\Bulk\AuditLog::class );
		$audit->write(
			$audit->new_batch(),
			'1' === $new ? 'noindex' : 'index',
			'term',
			$term_id,
			array(
				'kind'  => 'term_meta',
				'key'   => '_flseo_noindex',
				'value' => $old,
			),
			array(
				'kind'  => 'term_meta',
				'key'   => '_flseo_noindex',
				'value' => $new,
			)
		);
		if ( '' === $new ) {
			delete_term_meta( $term_id, '_flseo_noindex' );
		} else {
			update_term_meta( $term_id, '_flseo_noindex', $new );
		}
	}
}
