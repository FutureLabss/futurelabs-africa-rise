<?php
/**
 * NewsTheme bootstrap.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

define( 'NEWSTHEME_VERSION', '1.1.2' );
define( 'NEWSTHEME_DIR', trailingslashit( get_template_directory() ) );
define( 'NEWSTHEME_URI', trailingslashit( get_template_directory_uri() ) );

require NEWSTHEME_DIR . 'inc/helpers.php';
require NEWSTHEME_DIR . 'inc/setup.php';
require NEWSTHEME_DIR . 'inc/customizer/customizer.php';
require NEWSTHEME_DIR . 'inc/enqueue.php';
require NEWSTHEME_DIR . 'inc/icons.php';
require NEWSTHEME_DIR . 'inc/template-tags.php';
require NEWSTHEME_DIR . 'inc/menus.php';
require NEWSTHEME_DIR . 'inc/header.php';
require NEWSTHEME_DIR . 'inc/footer.php';
require NEWSTHEME_DIR . 'inc/features.php';
require NEWSTHEME_DIR . 'inc/blocks.php';
require NEWSTHEME_DIR . 'inc/homepage.php';
require NEWSTHEME_DIR . 'inc/inner.php';
require NEWSTHEME_DIR . 'inc/widgets/widgets.php';
require NEWSTHEME_DIR . 'inc/builder.php';
require NEWSTHEME_DIR . 'inc/extras.php';
require NEWSTHEME_DIR . 'inc/editor.php';
require NEWSTHEME_DIR . 'inc/demo-import.php';
require NEWSTHEME_DIR . 'inc/opportunities.php';
