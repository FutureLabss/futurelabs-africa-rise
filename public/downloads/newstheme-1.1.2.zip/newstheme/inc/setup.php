<?php
/**
 * Theme supports, menus, image sizes and widget areas.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register theme features.
 */
function newstheme_setup() {
	load_theme_textdomain( 'newstheme', NEWSTHEME_DIR . 'languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 120,
			'width'       => 460,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	register_nav_menus(
		array(
			'primary'   => esc_html__( 'Primary Menu', 'newstheme' ),
			'secondary' => esc_html__( 'Secondary (Top Bar) Menu', 'newstheme' ),
			'footer'    => esc_html__( 'Footer Menu', 'newstheme' ),
		)
	);

	add_image_size( 'newstheme-large', 1200, 800, true );
	add_image_size( 'newstheme-medium', 600, 400, true );
	add_image_size( 'newstheme-list', 300, 210, true );
	add_image_size( 'newstheme-thumb', 150, 150, true );
}
add_action( 'after_setup_theme', 'newstheme_setup' );

/**
 * Content width for embeds and images.
 */
function newstheme_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'newstheme_content_width', 800 ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
}
add_action( 'after_setup_theme', 'newstheme_content_width', 0 );

/**
 * Register widget areas.
 */
function newstheme_widgets_init() {
	$areas = array(
		'sidebar'           => esc_html__( 'Sidebar', 'newstheme' ),
		'left-sidebar'      => esc_html__( 'Left Sidebar', 'newstheme' ),
		'home-middle-right' => esc_html__( 'Frontpage - Middle Right Sidebar', 'newstheme' ),
		'home-middle-left'  => esc_html__( 'Frontpage - Middle Left Sidebar', 'newstheme' ),
		'offcanvas-sidebar' => esc_html__( 'Header Toggle Sidebar', 'newstheme' ),
		'header-builder'    => esc_html__( 'Header Builder - Widget Area', 'newstheme' ),
	);

	for ( $i = 1; $i <= 4; $i++ ) {
		/* translators: %d: footer column number. */
		$areas[ 'footer-' . $i ] = sprintf( esc_html__( 'Footer - Column %d', 'newstheme' ), $i );
	}

	foreach ( $areas as $id => $name ) {
		register_sidebar(
			array(
				'id'            => $id,
				'name'          => $name,
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title"><span>',
				'after_title'   => '</span></h2>',
			)
		);
	}
}
add_action( 'widgets_init', 'newstheme_widgets_init' );
