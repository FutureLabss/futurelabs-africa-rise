<?php
/**
 * ISO 3166-1 alpha-2 country list for eligibility fields.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Opportunity;

defined( 'ABSPATH' ) || exit;

/**
 * Country codes and names, plus region shortcuts that expand to codes.
 *
 * Eligibility is stored as codes so a reader's profile and an opportunity compare
 * exactly. `ALL` means open to every country.
 */
class Countries {

	/**
	 * Means "every country".
	 */
	public const ALL = 'ALL';

	/**
	 * African Union member states and other African countries and territories.
	 */
	public const AFRICA = array( 'DZ', 'AO', 'BJ', 'BW', 'BF', 'BI', 'CV', 'CM', 'CF', 'TD', 'KM', 'CG', 'CD', 'CI', 'DJ', 'EG', 'GQ', 'ER', 'SZ', 'ET', 'GA', 'GM', 'GH', 'GN', 'GW', 'KE', 'LS', 'LR', 'LY', 'MG', 'MW', 'ML', 'MR', 'MU', 'MA', 'MZ', 'NA', 'NE', 'NG', 'RW', 'ST', 'SN', 'SC', 'SL', 'SO', 'ZA', 'SS', 'SD', 'TZ', 'TG', 'TN', 'UG', 'EH', 'ZM', 'ZW' );

	/**
	 * Code => translated name.
	 *
	 * @return array<string, string>
	 */
	public static function all(): array {
		return array(
			'AF' => __( 'Afghanistan', 'futurelabs-ai-seo' ),
			'AX' => __( 'Åland Islands', 'futurelabs-ai-seo' ),
			'AL' => __( 'Albania', 'futurelabs-ai-seo' ),
			'DZ' => __( 'Algeria', 'futurelabs-ai-seo' ),
			'AS' => __( 'American Samoa', 'futurelabs-ai-seo' ),
			'AD' => __( 'Andorra', 'futurelabs-ai-seo' ),
			'AO' => __( 'Angola', 'futurelabs-ai-seo' ),
			'AI' => __( 'Anguilla', 'futurelabs-ai-seo' ),
			'AQ' => __( 'Antarctica', 'futurelabs-ai-seo' ),
			'AG' => __( 'Antigua and Barbuda', 'futurelabs-ai-seo' ),
			'AR' => __( 'Argentina', 'futurelabs-ai-seo' ),
			'AM' => __( 'Armenia', 'futurelabs-ai-seo' ),
			'AW' => __( 'Aruba', 'futurelabs-ai-seo' ),
			'AU' => __( 'Australia', 'futurelabs-ai-seo' ),
			'AT' => __( 'Austria', 'futurelabs-ai-seo' ),
			'AZ' => __( 'Azerbaijan', 'futurelabs-ai-seo' ),
			'BS' => __( 'Bahamas', 'futurelabs-ai-seo' ),
			'BH' => __( 'Bahrain', 'futurelabs-ai-seo' ),
			'BD' => __( 'Bangladesh', 'futurelabs-ai-seo' ),
			'BB' => __( 'Barbados', 'futurelabs-ai-seo' ),
			'BY' => __( 'Belarus', 'futurelabs-ai-seo' ),
			'BE' => __( 'Belgium', 'futurelabs-ai-seo' ),
			'BZ' => __( 'Belize', 'futurelabs-ai-seo' ),
			'BJ' => __( 'Benin', 'futurelabs-ai-seo' ),
			'BM' => __( 'Bermuda', 'futurelabs-ai-seo' ),
			'BT' => __( 'Bhutan', 'futurelabs-ai-seo' ),
			'BO' => __( 'Bolivia', 'futurelabs-ai-seo' ),
			'BQ' => __( 'Bonaire, Sint Eustatius and Saba', 'futurelabs-ai-seo' ),
			'BA' => __( 'Bosnia and Herzegovina', 'futurelabs-ai-seo' ),
			'BW' => __( 'Botswana', 'futurelabs-ai-seo' ),
			'BV' => __( 'Bouvet Island', 'futurelabs-ai-seo' ),
			'BR' => __( 'Brazil', 'futurelabs-ai-seo' ),
			'IO' => __( 'British Indian Ocean Territory', 'futurelabs-ai-seo' ),
			'BN' => __( 'Brunei', 'futurelabs-ai-seo' ),
			'BG' => __( 'Bulgaria', 'futurelabs-ai-seo' ),
			'BF' => __( 'Burkina Faso', 'futurelabs-ai-seo' ),
			'BI' => __( 'Burundi', 'futurelabs-ai-seo' ),
			'CV' => __( 'Cabo Verde', 'futurelabs-ai-seo' ),
			'KH' => __( 'Cambodia', 'futurelabs-ai-seo' ),
			'CM' => __( 'Cameroon', 'futurelabs-ai-seo' ),
			'CA' => __( 'Canada', 'futurelabs-ai-seo' ),
			'KY' => __( 'Cayman Islands', 'futurelabs-ai-seo' ),
			'CF' => __( 'Central African Republic', 'futurelabs-ai-seo' ),
			'TD' => __( 'Chad', 'futurelabs-ai-seo' ),
			'CL' => __( 'Chile', 'futurelabs-ai-seo' ),
			'CN' => __( 'China', 'futurelabs-ai-seo' ),
			'CX' => __( 'Christmas Island', 'futurelabs-ai-seo' ),
			'CC' => __( 'Cocos (Keeling) Islands', 'futurelabs-ai-seo' ),
			'CO' => __( 'Colombia', 'futurelabs-ai-seo' ),
			'KM' => __( 'Comoros', 'futurelabs-ai-seo' ),
			'CG' => __( 'Congo', 'futurelabs-ai-seo' ),
			'CD' => __( 'Congo (DRC)', 'futurelabs-ai-seo' ),
			'CK' => __( 'Cook Islands', 'futurelabs-ai-seo' ),
			'CR' => __( 'Costa Rica', 'futurelabs-ai-seo' ),
			'CI' => __( 'Côte d\'Ivoire', 'futurelabs-ai-seo' ),
			'HR' => __( 'Croatia', 'futurelabs-ai-seo' ),
			'CU' => __( 'Cuba', 'futurelabs-ai-seo' ),
			'CW' => __( 'Curaçao', 'futurelabs-ai-seo' ),
			'CY' => __( 'Cyprus', 'futurelabs-ai-seo' ),
			'CZ' => __( 'Czechia', 'futurelabs-ai-seo' ),
			'DK' => __( 'Denmark', 'futurelabs-ai-seo' ),
			'DJ' => __( 'Djibouti', 'futurelabs-ai-seo' ),
			'DM' => __( 'Dominica', 'futurelabs-ai-seo' ),
			'DO' => __( 'Dominican Republic', 'futurelabs-ai-seo' ),
			'EC' => __( 'Ecuador', 'futurelabs-ai-seo' ),
			'EG' => __( 'Egypt', 'futurelabs-ai-seo' ),
			'SV' => __( 'El Salvador', 'futurelabs-ai-seo' ),
			'GQ' => __( 'Equatorial Guinea', 'futurelabs-ai-seo' ),
			'ER' => __( 'Eritrea', 'futurelabs-ai-seo' ),
			'EE' => __( 'Estonia', 'futurelabs-ai-seo' ),
			'SZ' => __( 'Eswatini', 'futurelabs-ai-seo' ),
			'ET' => __( 'Ethiopia', 'futurelabs-ai-seo' ),
			'FK' => __( 'Falkland Islands', 'futurelabs-ai-seo' ),
			'FO' => __( 'Faroe Islands', 'futurelabs-ai-seo' ),
			'FJ' => __( 'Fiji', 'futurelabs-ai-seo' ),
			'FI' => __( 'Finland', 'futurelabs-ai-seo' ),
			'FR' => __( 'France', 'futurelabs-ai-seo' ),
			'GF' => __( 'French Guiana', 'futurelabs-ai-seo' ),
			'PF' => __( 'French Polynesia', 'futurelabs-ai-seo' ),
			'TF' => __( 'French Southern Territories', 'futurelabs-ai-seo' ),
			'GA' => __( 'Gabon', 'futurelabs-ai-seo' ),
			'GM' => __( 'Gambia', 'futurelabs-ai-seo' ),
			'GE' => __( 'Georgia', 'futurelabs-ai-seo' ),
			'DE' => __( 'Germany', 'futurelabs-ai-seo' ),
			'GH' => __( 'Ghana', 'futurelabs-ai-seo' ),
			'GI' => __( 'Gibraltar', 'futurelabs-ai-seo' ),
			'GR' => __( 'Greece', 'futurelabs-ai-seo' ),
			'GL' => __( 'Greenland', 'futurelabs-ai-seo' ),
			'GD' => __( 'Grenada', 'futurelabs-ai-seo' ),
			'GP' => __( 'Guadeloupe', 'futurelabs-ai-seo' ),
			'GU' => __( 'Guam', 'futurelabs-ai-seo' ),
			'GT' => __( 'Guatemala', 'futurelabs-ai-seo' ),
			'GG' => __( 'Guernsey', 'futurelabs-ai-seo' ),
			'GN' => __( 'Guinea', 'futurelabs-ai-seo' ),
			'GW' => __( 'Guinea-Bissau', 'futurelabs-ai-seo' ),
			'GY' => __( 'Guyana', 'futurelabs-ai-seo' ),
			'HT' => __( 'Haiti', 'futurelabs-ai-seo' ),
			'HM' => __( 'Heard Island and McDonald Islands', 'futurelabs-ai-seo' ),
			'VA' => __( 'Holy See', 'futurelabs-ai-seo' ),
			'HN' => __( 'Honduras', 'futurelabs-ai-seo' ),
			'HK' => __( 'Hong Kong', 'futurelabs-ai-seo' ),
			'HU' => __( 'Hungary', 'futurelabs-ai-seo' ),
			'IS' => __( 'Iceland', 'futurelabs-ai-seo' ),
			'IN' => __( 'India', 'futurelabs-ai-seo' ),
			'ID' => __( 'Indonesia', 'futurelabs-ai-seo' ),
			'IR' => __( 'Iran', 'futurelabs-ai-seo' ),
			'IQ' => __( 'Iraq', 'futurelabs-ai-seo' ),
			'IE' => __( 'Ireland', 'futurelabs-ai-seo' ),
			'IM' => __( 'Isle of Man', 'futurelabs-ai-seo' ),
			'IL' => __( 'Israel', 'futurelabs-ai-seo' ),
			'IT' => __( 'Italy', 'futurelabs-ai-seo' ),
			'JM' => __( 'Jamaica', 'futurelabs-ai-seo' ),
			'JP' => __( 'Japan', 'futurelabs-ai-seo' ),
			'JE' => __( 'Jersey', 'futurelabs-ai-seo' ),
			'JO' => __( 'Jordan', 'futurelabs-ai-seo' ),
			'KZ' => __( 'Kazakhstan', 'futurelabs-ai-seo' ),
			'KE' => __( 'Kenya', 'futurelabs-ai-seo' ),
			'KI' => __( 'Kiribati', 'futurelabs-ai-seo' ),
			'KP' => __( 'North Korea', 'futurelabs-ai-seo' ),
			'KR' => __( 'South Korea', 'futurelabs-ai-seo' ),
			'XK' => __( 'Kosovo', 'futurelabs-ai-seo' ),
			'KW' => __( 'Kuwait', 'futurelabs-ai-seo' ),
			'KG' => __( 'Kyrgyzstan', 'futurelabs-ai-seo' ),
			'LA' => __( 'Laos', 'futurelabs-ai-seo' ),
			'LV' => __( 'Latvia', 'futurelabs-ai-seo' ),
			'LB' => __( 'Lebanon', 'futurelabs-ai-seo' ),
			'LS' => __( 'Lesotho', 'futurelabs-ai-seo' ),
			'LR' => __( 'Liberia', 'futurelabs-ai-seo' ),
			'LY' => __( 'Libya', 'futurelabs-ai-seo' ),
			'LI' => __( 'Liechtenstein', 'futurelabs-ai-seo' ),
			'LT' => __( 'Lithuania', 'futurelabs-ai-seo' ),
			'LU' => __( 'Luxembourg', 'futurelabs-ai-seo' ),
			'MO' => __( 'Macao', 'futurelabs-ai-seo' ),
			'MG' => __( 'Madagascar', 'futurelabs-ai-seo' ),
			'MW' => __( 'Malawi', 'futurelabs-ai-seo' ),
			'MY' => __( 'Malaysia', 'futurelabs-ai-seo' ),
			'MV' => __( 'Maldives', 'futurelabs-ai-seo' ),
			'ML' => __( 'Mali', 'futurelabs-ai-seo' ),
			'MT' => __( 'Malta', 'futurelabs-ai-seo' ),
			'MH' => __( 'Marshall Islands', 'futurelabs-ai-seo' ),
			'MQ' => __( 'Martinique', 'futurelabs-ai-seo' ),
			'MR' => __( 'Mauritania', 'futurelabs-ai-seo' ),
			'MU' => __( 'Mauritius', 'futurelabs-ai-seo' ),
			'YT' => __( 'Mayotte', 'futurelabs-ai-seo' ),
			'MX' => __( 'Mexico', 'futurelabs-ai-seo' ),
			'FM' => __( 'Micronesia', 'futurelabs-ai-seo' ),
			'MD' => __( 'Moldova', 'futurelabs-ai-seo' ),
			'MC' => __( 'Monaco', 'futurelabs-ai-seo' ),
			'MN' => __( 'Mongolia', 'futurelabs-ai-seo' ),
			'ME' => __( 'Montenegro', 'futurelabs-ai-seo' ),
			'MS' => __( 'Montserrat', 'futurelabs-ai-seo' ),
			'MA' => __( 'Morocco', 'futurelabs-ai-seo' ),
			'MZ' => __( 'Mozambique', 'futurelabs-ai-seo' ),
			'MM' => __( 'Myanmar', 'futurelabs-ai-seo' ),
			'NA' => __( 'Namibia', 'futurelabs-ai-seo' ),
			'NR' => __( 'Nauru', 'futurelabs-ai-seo' ),
			'NP' => __( 'Nepal', 'futurelabs-ai-seo' ),
			'NL' => __( 'Netherlands', 'futurelabs-ai-seo' ),
			'NC' => __( 'New Caledonia', 'futurelabs-ai-seo' ),
			'NZ' => __( 'New Zealand', 'futurelabs-ai-seo' ),
			'NI' => __( 'Nicaragua', 'futurelabs-ai-seo' ),
			'NE' => __( 'Niger', 'futurelabs-ai-seo' ),
			'NG' => __( 'Nigeria', 'futurelabs-ai-seo' ),
			'NU' => __( 'Niue', 'futurelabs-ai-seo' ),
			'NF' => __( 'Norfolk Island', 'futurelabs-ai-seo' ),
			'MK' => __( 'North Macedonia', 'futurelabs-ai-seo' ),
			'MP' => __( 'Northern Mariana Islands', 'futurelabs-ai-seo' ),
			'NO' => __( 'Norway', 'futurelabs-ai-seo' ),
			'OM' => __( 'Oman', 'futurelabs-ai-seo' ),
			'PK' => __( 'Pakistan', 'futurelabs-ai-seo' ),
			'PW' => __( 'Palau', 'futurelabs-ai-seo' ),
			'PS' => __( 'Palestine', 'futurelabs-ai-seo' ),
			'PA' => __( 'Panama', 'futurelabs-ai-seo' ),
			'PG' => __( 'Papua New Guinea', 'futurelabs-ai-seo' ),
			'PY' => __( 'Paraguay', 'futurelabs-ai-seo' ),
			'PE' => __( 'Peru', 'futurelabs-ai-seo' ),
			'PH' => __( 'Philippines', 'futurelabs-ai-seo' ),
			'PN' => __( 'Pitcairn', 'futurelabs-ai-seo' ),
			'PL' => __( 'Poland', 'futurelabs-ai-seo' ),
			'PT' => __( 'Portugal', 'futurelabs-ai-seo' ),
			'PR' => __( 'Puerto Rico', 'futurelabs-ai-seo' ),
			'QA' => __( 'Qatar', 'futurelabs-ai-seo' ),
			'RE' => __( 'Réunion', 'futurelabs-ai-seo' ),
			'RO' => __( 'Romania', 'futurelabs-ai-seo' ),
			'RU' => __( 'Russia', 'futurelabs-ai-seo' ),
			'RW' => __( 'Rwanda', 'futurelabs-ai-seo' ),
			'BL' => __( 'Saint Barthélemy', 'futurelabs-ai-seo' ),
			'SH' => __( 'Saint Helena', 'futurelabs-ai-seo' ),
			'KN' => __( 'Saint Kitts and Nevis', 'futurelabs-ai-seo' ),
			'LC' => __( 'Saint Lucia', 'futurelabs-ai-seo' ),
			'MF' => __( 'Saint Martin', 'futurelabs-ai-seo' ),
			'PM' => __( 'Saint Pierre and Miquelon', 'futurelabs-ai-seo' ),
			'VC' => __( 'Saint Vincent and the Grenadines', 'futurelabs-ai-seo' ),
			'WS' => __( 'Samoa', 'futurelabs-ai-seo' ),
			'SM' => __( 'San Marino', 'futurelabs-ai-seo' ),
			'ST' => __( 'São Tomé and Príncipe', 'futurelabs-ai-seo' ),
			'SA' => __( 'Saudi Arabia', 'futurelabs-ai-seo' ),
			'SN' => __( 'Senegal', 'futurelabs-ai-seo' ),
			'RS' => __( 'Serbia', 'futurelabs-ai-seo' ),
			'SC' => __( 'Seychelles', 'futurelabs-ai-seo' ),
			'SL' => __( 'Sierra Leone', 'futurelabs-ai-seo' ),
			'SG' => __( 'Singapore', 'futurelabs-ai-seo' ),
			'SX' => __( 'Sint Maarten', 'futurelabs-ai-seo' ),
			'SK' => __( 'Slovakia', 'futurelabs-ai-seo' ),
			'SI' => __( 'Slovenia', 'futurelabs-ai-seo' ),
			'SB' => __( 'Solomon Islands', 'futurelabs-ai-seo' ),
			'SO' => __( 'Somalia', 'futurelabs-ai-seo' ),
			'ZA' => __( 'South Africa', 'futurelabs-ai-seo' ),
			'GS' => __( 'South Georgia and the South Sandwich Islands', 'futurelabs-ai-seo' ),
			'SS' => __( 'South Sudan', 'futurelabs-ai-seo' ),
			'ES' => __( 'Spain', 'futurelabs-ai-seo' ),
			'LK' => __( 'Sri Lanka', 'futurelabs-ai-seo' ),
			'SD' => __( 'Sudan', 'futurelabs-ai-seo' ),
			'SR' => __( 'Suriname', 'futurelabs-ai-seo' ),
			'SJ' => __( 'Svalbard and Jan Mayen', 'futurelabs-ai-seo' ),
			'SE' => __( 'Sweden', 'futurelabs-ai-seo' ),
			'CH' => __( 'Switzerland', 'futurelabs-ai-seo' ),
			'SY' => __( 'Syria', 'futurelabs-ai-seo' ),
			'TW' => __( 'Taiwan', 'futurelabs-ai-seo' ),
			'TJ' => __( 'Tajikistan', 'futurelabs-ai-seo' ),
			'TZ' => __( 'Tanzania', 'futurelabs-ai-seo' ),
			'TH' => __( 'Thailand', 'futurelabs-ai-seo' ),
			'TL' => __( 'Timor-Leste', 'futurelabs-ai-seo' ),
			'TG' => __( 'Togo', 'futurelabs-ai-seo' ),
			'TK' => __( 'Tokelau', 'futurelabs-ai-seo' ),
			'TO' => __( 'Tonga', 'futurelabs-ai-seo' ),
			'TT' => __( 'Trinidad and Tobago', 'futurelabs-ai-seo' ),
			'TN' => __( 'Tunisia', 'futurelabs-ai-seo' ),
			'TR' => __( 'Türkiye', 'futurelabs-ai-seo' ),
			'TM' => __( 'Turkmenistan', 'futurelabs-ai-seo' ),
			'TC' => __( 'Turks and Caicos Islands', 'futurelabs-ai-seo' ),
			'TV' => __( 'Tuvalu', 'futurelabs-ai-seo' ),
			'UG' => __( 'Uganda', 'futurelabs-ai-seo' ),
			'UA' => __( 'Ukraine', 'futurelabs-ai-seo' ),
			'AE' => __( 'United Arab Emirates', 'futurelabs-ai-seo' ),
			'GB' => __( 'United Kingdom', 'futurelabs-ai-seo' ),
			'US' => __( 'United States', 'futurelabs-ai-seo' ),
			'UM' => __( 'United States Minor Outlying Islands', 'futurelabs-ai-seo' ),
			'UY' => __( 'Uruguay', 'futurelabs-ai-seo' ),
			'UZ' => __( 'Uzbekistan', 'futurelabs-ai-seo' ),
			'VU' => __( 'Vanuatu', 'futurelabs-ai-seo' ),
			'VE' => __( 'Venezuela', 'futurelabs-ai-seo' ),
			'VN' => __( 'Vietnam', 'futurelabs-ai-seo' ),
			'VG' => __( 'Virgin Islands (British)', 'futurelabs-ai-seo' ),
			'VI' => __( 'Virgin Islands (U.S.)', 'futurelabs-ai-seo' ),
			'WF' => __( 'Wallis and Futuna', 'futurelabs-ai-seo' ),
			'EH' => __( 'Western Sahara', 'futurelabs-ai-seo' ),
			'YE' => __( 'Yemen', 'futurelabs-ai-seo' ),
			'ZM' => __( 'Zambia', 'futurelabs-ai-seo' ),
			'ZW' => __( 'Zimbabwe', 'futurelabs-ai-seo' ),
		);
	}

	/**
	 * Region shortcuts (code => list of country codes) accepted when saving.
	 *
	 * @return array<string, array<int, string>>
	 */
	public static function regions(): array {
		/**
		 * Filters the region shortcuts that expand to country codes when eligibility is saved.
		 *
		 * @param array<string, array<int, string>> $regions Region => country codes.
		 */
		$regions = apply_filters( 'flseo_eligibility_regions', array( 'AFRICA' => self::AFRICA ) );
		return is_array( $regions ) ? $regions : array();
	}

	/**
	 * Normalize a comma-separated list of codes and region shortcuts.
	 *
	 * Unknown codes are dropped, regions expand to their countries, `ALL` wins over
	 * everything else, and the result is sorted and de-duplicated.
	 *
	 * @param mixed $value Raw value (string or array).
	 * @return string Comma-separated codes, `ALL`, or '' when nothing valid was given.
	 */
	public static function normalize( $value ): string {
		$parts = is_array( $value ) ? $value : explode( ',', is_scalar( $value ) ? (string) $value : '' );
		$known = self::all();
		$codes = array();
		foreach ( $parts as $part ) {
			$code = strtoupper( trim( (string) $part ) );
			if ( self::ALL === $code ) {
				return self::ALL;
			}
			$regions = self::regions();
			if ( isset( $regions[ $code ] ) ) {
				$codes = array_merge( $codes, array_map( 'strval', (array) $regions[ $code ] ) );
			} elseif ( isset( $known[ $code ] ) ) {
				$codes[] = $code;
			}
		}
		$codes = array_values( array_unique( array_intersect( $codes, array_keys( $known ) ) ) );
		sort( $codes );
		return implode( ',', $codes );
	}
}
