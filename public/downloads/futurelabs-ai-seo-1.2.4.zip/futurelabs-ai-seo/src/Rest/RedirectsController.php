<?php
/**
 * GET/POST/PUT/DELETE /redirects · POST /redirects/import · GET /redirects/export · suggestions.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Bulk\AuditLog;
use FutureLabs\AISEO\Redirects\Rules;
use FutureLabs\AISEO\Redirects\SlugWatcher;

defined( 'ABSPATH' ) || exit;

/**
 * Redirect management. Create, update and delete are audit-logged so they can be undone.
 */
class RedirectsController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/redirects', 'GET', array( $this, 'index' ) );
		$this->route( '/redirects', 'POST', array( $this, 'create' ) );
		$this->route( '/redirects/(?P<id>\d+)', array( 'PUT', 'PATCH' ), array( $this, 'update' ) );
		$this->route( '/redirects/(?P<id>\d+)', 'DELETE', array( $this, 'delete' ) );
		$this->route( '/redirects/import', 'POST', array( $this, 'import' ) );
		$this->route( '/redirects/export', 'GET', array( $this, 'export' ) );
		$this->route( '/redirects/suggestions', 'GET', array( $this, 'suggestions' ) );
		$this->route( '/redirects/suggestions/(?P<id>[a-f0-9\-]{36})', 'POST', array( $this, 'resolve_suggestion' ) );
	}

	/**
	 * List rules.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function index( \WP_REST_Request $request ): \WP_REST_Response {
		list( $page, $per_page ) = $this->paging( $request, 500 );
		$result                  = $this->c->get( Rules::class )->list(
			array(
				'page'     => $page,
				'per_page' => $per_page,
				'search'   => sanitize_text_field( (string) $request->get_param( 'search' ) ),
			)
		);
		$response                = rest_ensure_response( $result );
		$response->header( 'X-WP-Total', (string) $result['total'] );
		return $response;
	}

	/**
	 * Create a rule.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function create( \WP_REST_Request $request ) {
		$rules = $this->c->get( Rules::class );
		$id    = $rules->save( $this->body( $request ), 0, 'manual' );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$this->c->get( AuditLog::class )->write(
			$this->c->get( AuditLog::class )->new_batch(),
			'redirect_create',
			'redirect',
			$id,
			array(
				'kind' => 'redirect',
				'row'  => null,
			),
			array(
				'kind' => 'redirect',
				'row'  => $rules->get( $id ),
			)
		);
		return new \WP_REST_Response( $rules->get( $id ), 201 );
	}

	/**
	 * Update a rule.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update( \WP_REST_Request $request ) {
		$rules = $this->c->get( Rules::class );
		$id    = absint( $request['id'] );
		$old   = $rules->get( $id );
		if ( ! $old ) {
			return $this->error( 'not_found', __( 'Redirect not found.', 'futurelabs-ai-seo' ), 404 );
		}
		$data   = array_merge(
			array(
				'source'   => $old['source'],
				'target'   => $old['target'],
				'type'     => $old['type'],
				'is_regex' => (bool) $old['is_regex'],
			),
			$this->body( $request )
		);
		$result = $rules->save( $data, $id );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$this->c->get( AuditLog::class )->write(
			$this->c->get( AuditLog::class )->new_batch(),
			'redirect_update',
			'redirect',
			$id,
			array(
				'kind' => 'redirect',
				'row'  => $old,
			),
			array(
				'kind' => 'redirect',
				'row'  => $rules->get( $id ),
			)
		);
		return rest_ensure_response( $rules->get( $id ) );
	}

	/**
	 * Delete a rule.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function delete( \WP_REST_Request $request ) {
		$rules = $this->c->get( Rules::class );
		$id    = absint( $request['id'] );
		$old   = $rules->get( $id );
		if ( ! $old ) {
			return $this->error( 'not_found', __( 'Redirect not found.', 'futurelabs-ai-seo' ), 404 );
		}
		$rules->delete( $id );
		$batch = $this->c->get( AuditLog::class )->new_batch();
		$this->c->get( AuditLog::class )->write(
			$batch,
			'redirect_delete',
			'redirect',
			$id,
			array(
				'kind' => 'redirect',
				'row'  => $old,
			),
			array(
				'kind' => 'redirect',
				'row'  => null,
			)
		);
		return rest_ensure_response(
			array(
				'deleted'  => true,
				'batch_id' => $batch,
			)
		);
	}

	/**
	 * Import CSV (supports dry_run).
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function import( \WP_REST_Request $request ): \WP_REST_Response {
		$body = $this->body( $request );
		$csv  = (string) ( $body['csv'] ?? '' );
		$dry  = ! empty( $body['dry_run'] ) && 'false' !== $body['dry_run'];
		return rest_ensure_response( array_merge( array( 'dry_run' => $dry ), $this->c->get( Rules::class )->import_csv( $csv, $dry ) ) );
	}

	/**
	 * Export CSV.
	 */
	public function export(): \WP_REST_Response {
		return rest_ensure_response(
			array(
				'filename' => 'flseo-redirects-' . gmdate( 'Y-m-d' ) . '.csv',
				'csv'      => $this->c->get( Rules::class )->export_csv(),
			)
		);
	}

	/**
	 * Pending slug-change suggestions (suggest mode).
	 */
	public function suggestions(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( SlugWatcher::class )->suggestions() );
	}

	/**
	 * Accept or dismiss a suggestion.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function resolve_suggestion( \WP_REST_Request $request ) {
		$accept = ! empty( $this->body( $request )['accept'] );
		$result = $this->c->get( SlugWatcher::class )->resolve_suggestion( (string) $request['id'], $accept );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response(
			array(
				'created' => is_int( $result ),
				'id'      => $result,
			)
		);
	}
}
