<?php
/**
 * Footer rendering helpers and the dialogs printed at the end of the page.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Print the whole <footer> from the footer builder. Also the Customizer's
 * selective-refresh render callback for the footer.
 */
function newstheme_render_colophon() {
	echo '<footer id="nt-colophon" class="nt-footer">';
	newstheme_render_builder( 'footer', 'footer' );
	echo '</footer>';
}

/**
 * Copyright text with {year} and {site} replaced. Links are allowed.
 *
 * @return string Safe HTML.
 */
function newstheme_copyright_html() {
	$text = strtr(
		(string) newstheme_get_mod( 'copyright' ),
		array(
			'{year}' => wp_date( 'Y' ),
			'{site}' => get_bloginfo( 'name' ),
		)
	);
	return wp_kses(
		$text,
		array(
			'a'      => array(
				'href'   => true,
				'target' => true,
				'rel'    => true,
			),
			'strong' => array(),
			'em'     => array(),
		)
	);
}

/**
 * Newsletter popup.
 */
function newstheme_render_newsletter_dialog() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done      = true;
	$shortcode = trim( (string) newstheme_get_mod( 'newsletter_shortcode' ) );
	?>
	<dialog id="nt-newsletter" class="nt-modal" aria-labelledby="nt-newsletter-title">
		<button type="button" class="nt-icon-btn nt-dialog-close" data-nt-close aria-label="<?php esc_attr_e( 'Close', 'newstheme' ); ?>"><?php newstheme_icon( 'close' ); ?></button>
		<div class="nt-modal__body">
			<?php newstheme_icon( 'mail', 'nt-modal__icon' ); ?>
			<h2 id="nt-newsletter-title" class="nt-modal__title"><?php echo esc_html( newstheme_get_mod( 'newsletter_heading' ) ); ?></h2>
			<p class="nt-modal__text"><?php echo esc_html( newstheme_get_mod( 'newsletter_text' ) ); ?></p>
			<?php if ( $shortcode ) : ?>
				<div class="nt-modal__form"><?php echo do_shortcode( wp_kses_post( $shortcode ) ); ?></div>
			<?php elseif ( current_user_can( 'edit_theme_options' ) ) : ?>
				<p class="nt-modal__hint">
					<?php
					printf(
						/* translators: %s: Customizer path. */
						esc_html__( 'Only you can see this: add a form shortcode in %s.', 'newstheme' ),
						'<a href="' . esc_url( admin_url( 'customize.php?autofocus[section]=newstheme_header_newsletter' ) ) . '">' . esc_html__( 'Customizer → Header → Newsletter Button', 'newstheme' ) . '</a>'
					);
					?>
				</p>
			<?php endif; ?>
		</div>
	</dialog>
	<?php
}

/**
 * Off-canvas sidebar drawer.
 */
function newstheme_render_offcanvas_dialog() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	?>
	<dialog id="nt-offcanvas" class="nt-drawer" aria-label="<?php esc_attr_e( 'Sidebar', 'newstheme' ); ?>">
		<div class="nt-drawer__head">
			<button type="button" class="nt-icon-btn nt-dialog-close" data-nt-close aria-label="<?php esc_attr_e( 'Close sidebar', 'newstheme' ); ?>"><?php newstheme_icon( 'close' ); ?></button>
		</div>
		<div class="nt-drawer__body">
			<?php dynamic_sidebar( 'offcanvas-sidebar' ); ?>
		</div>
	</dialog>
	<?php
}
