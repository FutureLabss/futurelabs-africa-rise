<?php
/**
 * Redirect rule repository with loop and chain detection.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Redirects;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;

defined( 'ABSPATH' ) || exit;

/**
 * CRUD for `flseo_redirects`. Exact rules are matched by path hash; regex rules after exact matches.
 */
class Rules {

	public const TYPES     = array( 301, 302, 307, 410 );
	public const MAX_DEPTH = 5;
	public const MAX_REGEX = 200;
	public const MAX_PATH  = 512;

	/**
	 * The pcre.backtrack_limit applied while user regex rules run.
	 */
	public const BACKTRACK_LIMIT = 10000;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Regex rules cached per request.
	 *
	 * @var array<int, object>|null
	 */
	private ?array $regex_cache = null;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Table name.
	 */
	public static function table(): string {
		return Migrations::table( 'redirects' );
	}

	/**
	 * Normalize a URL or path to the stored form: leading slash, no trailing slash, no query.
	 *
	 * @param string $url URL or path.
	 */
	public static function normalize_path( string $url ): string {
		$url  = trim( $url );
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		if ( '' === $path && ! preg_match( '~^[a-z]+://~i', $url ) ) {
			$path = (string) strtok( $url, '?#' );
		}
		$path = '/' . ltrim( rawurldecode( $path ), '/' );
		$path = untrailingslashit( $path );
		return '' === $path ? '/' : $path;
	}

	/**
	 * Hash for a path.
	 *
	 * @param string $url URL or path.
	 */
	public static function hash( string $url ): string {
		return hash( 'sha256', self::normalize_path( $url ) );
	}

	/**
	 * Find the rule matching a request path.
	 *
	 * @param string $path Request path.
	 * @return object|null Rule row with an added `resolved_target` property.
	 */
	public function match( string $path ): ?object {
		global $wpdb;
		$table = self::table();
		$norm  = self::normalize_path( $path );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rule = $wpdb->get_row( $wpdb->prepare( "SELECT id, source, target, type, is_regex FROM {$table} WHERE source_hash=%s AND is_regex=0 LIMIT 1", hash( 'sha256', $norm ) ) );
		if ( $rule ) {
			$rule->resolved_target = (string) $rule->target;
			return $rule;
		}
		// Bound the work user patterns can do: over-long paths never reach regex rules
		// (truncating them could produce a false match).
		$regex = strlen( $norm ) > self::MAX_PATH ? array() : $this->regex_rules();
		if ( ! $regex ) {
			return null;
		}
		$subject = $norm;
		$limit   = self::lower_backtrack_limit();
		$found   = null;
		foreach ( $regex as $candidate ) {
			$pattern = self::regex_pattern( (string) $candidate->source );
			if ( null === $pattern ) {
				continue;
			}
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- invalid user patterns are skipped.
			if ( 1 === @preg_match( $pattern, $subject, $matches ) ) {
				$candidate->resolved_target = (string) preg_replace_callback(
					'/\$(\d+)/',
					static fn( $m ) => isset( $matches[ (int) $m[1] ] ) ? rawurlencode( $matches[ (int) $m[1] ] ) : '',
					(string) $candidate->target
				);
				$found = $candidate;
				break;
			}
		}
		self::restore_backtrack_limit( $limit );
		return $found;
	}

	/**
	 * Lower pcre.backtrack_limit; returns the previous value for restore_backtrack_limit().
	 *
	 * @return string|false
	 */
	private static function lower_backtrack_limit() {
		return ini_set( 'pcre.backtrack_limit', (string) self::BACKTRACK_LIMIT ); // phpcs:ignore WordPress.PHP.IniSet.Risky
	}

	/**
	 * Restore pcre.backtrack_limit.
	 *
	 * @param string|false $previous Previous value.
	 */
	private static function restore_backtrack_limit( $previous ): void {
		if ( false !== $previous ) {
			ini_set( 'pcre.backtrack_limit', $previous ); // phpcs:ignore WordPress.PHP.IniSet.Risky
		}
	}

	/**
	 * Whether a regex source risks catastrophic backtracking: a nested quantifier such as
	 * (a+)+, (a*)* or (.*)*, or a pattern that errors on an adversarial path.
	 *
	 * @param string $source Pattern without delimiters.
	 */
	public static function is_dangerous_regex( string $source ): bool {
		if ( preg_match( '~\((?:[^()\\\\]|\\\\.)*[+*}](?:[^()\\\\]|\\\\.)*\)(?:[+*]|\{\d+,\d*\})~', $source ) ) {
			return true;
		}
		$pattern = self::regex_pattern( $source );
		if ( null === $pattern ) {
			return false;
		}
		$limit = self::lower_backtrack_limit();
		$bad   = false;
		foreach ( array( str_repeat( 'a', 1999 ) . '!', '/' . str_repeat( 'a/', 999 ) . '!' ) as $subject ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			@preg_match( $pattern, $subject );
			if ( PREG_NO_ERROR !== preg_last_error() ) {
				$bad = true;
				break;
			}
		}
		self::restore_backtrack_limit( $limit );
		return $bad;
	}

	/**
	 * Regex rules (small set, cached per request).
	 *
	 * @return array<int, object>
	 */
	private function regex_rules(): array {
		if ( null === $this->regex_cache ) {
			global $wpdb;
			$table = self::table();
			$cache = wp_cache_get( 'regex_rules', 'futurelabs-ai-seo' );
			if ( is_array( $cache ) ) {
				$this->regex_cache = $cache;
			} else {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->regex_cache = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, source, target, type, is_regex FROM {$table} WHERE is_regex=1 ORDER BY id ASC LIMIT %d", self::MAX_REGEX ) );
				wp_cache_set( 'regex_rules', $this->regex_cache, 'futurelabs-ai-seo', 300 );
			}
		}
		return array_map( static fn( $r ) => clone $r, $this->regex_cache );
	}

	/**
	 * Wrap a stored regex source in delimiters; null when invalid or too long.
	 *
	 * @param string $source Pattern without delimiters, e.g. ^/old/(.*)$.
	 */
	public static function regex_pattern( string $source ): ?string {
		if ( '' === $source || strlen( $source ) > 250 ) {
			return null;
		}
		$pattern = '~' . str_replace( '~', '\~', $source ) . '~u';
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return false === @preg_match( $pattern, '' ) ? null : $pattern;
	}

	/**
	 * Validate and save a rule. Returns the rule id or WP_Error.
	 *
	 * @param array<string, mixed> $data   source, target, type, is_regex.
	 * @param int                  $id     Existing rule id for updates.
	 * @param string               $origin manual, slug, import, 404, bulk.
	 * @return int|\WP_Error
	 */
	public function save( array $data, int $id = 0, string $origin = 'manual' ) {
		global $wpdb;
		$is_regex = ! empty( $data['is_regex'] );
		$type     = absint( $data['type'] ?? 301 );
		$source   = $is_regex ? trim( (string) ( $data['source'] ?? '' ) ) : self::normalize_path( (string) ( $data['source'] ?? '' ) );
		$target   = trim( (string) ( $data['target'] ?? '' ) );
		if ( '' !== $target && str_starts_with( $target, '/' ) ) {
			$target = home_url( $target );
		}
		$target = esc_url_raw( $target );

		if ( ! in_array( $type, self::TYPES, true ) ) {
			return new \WP_Error( 'flseo_redirect_type', __( 'Choose 301, 302, 307 or 410.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( '' === $source || ( ! $is_regex && '/' === $source ) ) {
			return new \WP_Error( 'flseo_redirect_source', __( 'Enter a source path other than the home page.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( $is_regex && null === self::regex_pattern( $source ) ) {
			return new \WP_Error( 'flseo_redirect_regex', __( 'The regular expression is invalid or longer than 250 characters.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( $is_regex && self::is_dangerous_regex( $source ) ) {
			return new \WP_Error( 'flseo_redirect_regex_slow', __( 'The regular expression could be very slow (for example a repeated group such as (a+)+). Simplify it.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( $is_regex && ! $id && self::regex_count( hash( 'sha256', 'regex:' . $source ) ) >= self::MAX_REGEX ) {
			/* translators: %d: maximum number of regex redirects. */
			return new \WP_Error( 'flseo_redirect_regex_limit', sprintf( __( 'You can have at most %d regular expression redirects.', 'futurelabs-ai-seo' ), self::MAX_REGEX ), array( 'status' => 400 ) );
		}
		if ( 410 !== $type && ( '' === $target || ! \FutureLabs\AISEO\Core\Url::is_valid( $target ) ) ) {
			return new \WP_Error( 'flseo_redirect_target', __( 'Enter a valid target URL.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( 410 === $type ) {
			$target = '';
		}
		if ( ! $is_regex && '' !== $target ) {
			$loop = $this->check_chain( $source, $target, $id );
			if ( is_wp_error( $loop ) ) {
				return $loop;
			}
		}
		$row     = array(
			'source'      => $source,
			'source_hash' => $is_regex ? hash( 'sha256', 'regex:' . $source ) : hash( 'sha256', $source ),
			'target'      => $target,
			'type'        => $type,
			'is_regex'    => $is_regex ? 1 : 0,
		);
		$formats = array( '%s', '%s', '%s', '%d', '%d' );
		$table   = self::table();
		if ( $id ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$ok = $wpdb->update( $table, $row, array( 'id' => $id ), $formats, array( '%d' ) );
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE source_hash=%s", $row['source_hash'] ) );
			if ( $existing ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$ok = $wpdb->update( $table, $row, array( 'id' => $existing ), $formats, array( '%d' ) );
				$id = $existing;
			} else {
				$row['created_at'] = current_time( 'mysql', true );
				$row['created_by'] = get_current_user_id();
				$row['origin']     = sanitize_key( $origin );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$ok = $wpdb->insert( $table, $row, array_merge( $formats, array( '%s', '%d', '%s' ) ) );
				$id = (int) $wpdb->insert_id;
			}
		}
		if ( false === $ok ) {
			return new \WP_Error( 'flseo_redirect_db', __( 'The redirect could not be saved.', 'futurelabs-ai-seo' ), array( 'status' => 500 ) );
		}
		$this->changed();
		return $id;
	}

	/**
	 * Number of regex rules other than the one with this source hash.
	 *
	 * @param string $exclude_hash Source hash being saved (an update of it does not add a rule).
	 */
	private static function regex_count( string $exclude_hash ): int {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE is_regex=1 AND source_hash<>%s", $exclude_hash ) );
	}

	/**
	 * Detect loops and over-long chains starting at a target.
	 *
	 * @param string $source     Normalized source path.
	 * @param string $target     Target URL.
	 * @param int    $ignore_id  Rule being edited.
	 * @return true|\WP_Error
	 */
	public function check_chain( string $source, string $target, int $ignore_id = 0 ) {
		global $wpdb;
		$table   = self::table();
		$site    = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
		$cursor  = $target;
		$visited = array( $source => true );
		for ( $depth = 1; $depth <= self::MAX_DEPTH + 1; $depth++ ) {
			$host = strtolower( (string) wp_parse_url( $cursor, PHP_URL_HOST ) );
			if ( '' !== $host && $host !== $site ) {
				return true;
			}
			$path = self::normalize_path( $cursor );
			if ( isset( $visited[ $path ] ) ) {
				return new \WP_Error( 'flseo_redirect_loop', __( 'This redirect would create a loop.', 'futurelabs-ai-seo' ), array( 'status' => 409 ) );
			}
			if ( $depth > self::MAX_DEPTH ) {
				/* translators: %d: maximum chain length. */
				return new \WP_Error( 'flseo_redirect_chain', sprintf( __( 'This redirect would create a chain longer than %d hops. Point it at the final destination instead.', 'futurelabs-ai-seo' ), self::MAX_DEPTH ), array( 'status' => 409 ) );
			}
			$visited[ $path ] = true;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$next = $wpdb->get_var( $wpdb->prepare( "SELECT target FROM {$table} WHERE source_hash=%s AND is_regex=0 AND id<>%d AND type<>410 LIMIT 1", hash( 'sha256', $path ), $ignore_id ) );
			if ( ! $next ) {
				return true;
			}
			$cursor = (string) $next;
		}
		return true;
	}

	/**
	 * Get one rule.
	 *
	 * @param int $id Rule id.
	 * @return array<string, mixed>|null
	 */
	public function get( int $id ): ?array {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d", $id ), ARRAY_A );
		return $row ?: null;
	}

	/**
	 * Delete a rule.
	 *
	 * @param int $id Rule id.
	 */
	public function delete( int $id ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ok = (bool) $wpdb->delete( self::table(), array( 'id' => $id ), array( '%d' ) );
		$this->changed();
		return $ok;
	}

	/**
	 * Paginated list.
	 *
	 * @param array<string, mixed> $args search, page, per_page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function list( array $args = array() ): array {
		global $wpdb;
		$table    = self::table();
		$per_page = min( 500, max( 1, (int) ( $args['per_page'] ?? 50 ) ) );
		$offset   = ( max( 1, (int) ( $args['page'] ?? 1 ) ) - 1 ) * $per_page;
		$where    = '1=1';
		$params   = array();
		if ( ! empty( $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
			$where   .= ' AND (source LIKE %s OR target LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQL.NotPrepared -- $where only contains placeholders.
		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where}", $params ) ) : $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) );
		$items = $wpdb->get_results( $wpdb->prepare( "SELECT id, source, target, type, is_regex, hits, last_hit, origin, created_at FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $params, array( $per_page, $offset ) ) ), ARRAY_A );
		// phpcs:enable
		return array(
			'items' => (array) $items,
			'total' => $total,
		);
	}

	/**
	 * Record a hit.
	 *
	 * @param int $id Rule id.
	 */
	public function hit( int $id ): void {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET hits=hits+1, last_hit=%s WHERE id=%d", current_time( 'mysql', true ), $id ) );
	}

	/**
	 * Export all rules as CSV.
	 */
	public function export_csv(): string {
		global $wpdb;
		$table  = self::table();
		$lines  = array( self::csv_line( array( 'source', 'target', 'type', 'is_regex' ) ) );
		$offset = 0;
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT source, target, type, is_regex FROM {$table} ORDER BY id ASC LIMIT 1000 OFFSET %d", $offset ), ARRAY_A );
			foreach ( $rows as $row ) {
				$lines[] = self::csv_line( array( self::csv_safe( $row['source'] ), self::csv_safe( $row['target'] ), (string) $row['type'], (string) $row['is_regex'] ) );
			}
			$offset += 1000;
			$fetched = count( $rows );
		} while ( 1000 === $fetched );
		return implode( "\n", $lines ) . "\n";
	}

	/**
	 * Encode one CSV line (RFC 4180 quoting).
	 *
	 * @param array<int, string> $cells Cells.
	 */
	private static function csv_line( array $cells ): string {
		return implode(
			',',
			array_map(
				static function ( $cell ) {
					$cell = (string) $cell;
					return preg_match( '/[",\r\n]/', $cell ) ? '"' . str_replace( '"', '""', $cell ) . '"' : $cell;
				},
				$cells
			)
		);
	}

	/**
	 * Split CSV text into rows of cells, honouring quoted fields (which may contain commas and newlines).
	 *
	 * @param string $csv CSV text.
	 * @return array<int, array<int, string>>
	 */
	public static function parse_csv( string $csv ): array {
		$rows   = array();
		$row    = array();
		$cell   = '';
		$quoted = false;
		$length = strlen( $csv );
		for ( $i = 0; $i < $length; $i++ ) {
			$char = $csv[ $i ];
			if ( $quoted ) {
				if ( '"' === $char && isset( $csv[ $i + 1 ] ) && '"' === $csv[ $i + 1 ] ) {
					$cell .= '"';
					++$i;
				} elseif ( '"' === $char ) {
					$quoted = false;
				} else {
					$cell .= $char;
				}
				continue;
			}
			if ( '"' === $char ) {
				$quoted = true;
			} elseif ( ',' === $char ) {
				$row[] = $cell;
				$cell  = '';
			} elseif ( "\n" === $char || "\r" === $char ) {
				if ( "\r" === $char && isset( $csv[ $i + 1 ] ) && "\n" === $csv[ $i + 1 ] ) {
					++$i;
				}
				$row[]  = $cell;
				$rows[] = $row;
				$row    = array();
				$cell   = '';
			} else {
				$cell .= $char;
			}
		}
		if ( '' !== $cell || $row ) {
			$row[]  = $cell;
			$rows[] = $row;
		}
		return $rows;
	}

	/**
	 * Import CSV rows (source,target[,type[,is_regex]]).
	 *
	 * @param string $csv     CSV text.
	 * @param bool   $dry_run Validate only.
	 * @return array{valid: int, invalid: array<int, array{line: int, error: string}>, rows: array<int, array<string, mixed>>}
	 */
	public function import_csv( string $csv, bool $dry_run ): array {
		$rows   = self::parse_csv( ltrim( $csv, "\xEF\xBB\xBF" ) );
		$header = array_shift( $rows );
		$header = is_array( $header ) ? array_map( static fn( $h ) => strtolower( trim( (string) $h ) ), $header ) : array();
		if ( ! in_array( 'source', $header, true ) || ! in_array( 'target', $header, true ) ) {
			return array(
				'valid'   => 0,
				'invalid' => array(
					array(
						'line'  => 1,
						'error' => __( 'The CSV needs source and target columns.', 'futurelabs-ai-seo' ),
					),
				),
				'rows'    => array(),
			);
		}
		$valid   = array();
		$invalid = array();
		$line    = 1;
		foreach ( $rows as $cells ) {
			++$line;
			if ( array( '' ) === $cells || count( $cells ) !== count( $header ) ) {
				continue;
			}
			$row   = array_combine( $header, $cells );
			$data  = array(
				'source'   => (string) $row['source'],
				'target'   => (string) $row['target'],
				'type'     => absint( $row['type'] ?? 301 ) ?: 301,
				'is_regex' => ! empty( $row['is_regex'] ) && '0' !== $row['is_regex'],
			);
			$error = $this->validate_only( $data );
			if ( is_wp_error( $error ) ) {
				$invalid[] = array(
					'line'  => $line,
					'error' => $error->get_error_message(),
				);
				continue;
			}
			if ( ! $dry_run ) {
				$saved = $this->save( $data, 0, 'import' );
				if ( is_wp_error( $saved ) ) {
					$invalid[] = array(
						'line'  => $line,
						'error' => $saved->get_error_message(),
					);
					continue;
				}
			}
			$valid[] = $data;
		}
		return array(
			'valid'   => count( $valid ),
			'invalid' => $invalid,
			'rows'    => array_slice( $valid, 0, 200 ),
		);
	}

	/**
	 * Validate a rule without saving.
	 *
	 * @param array<string, mixed> $data Rule data.
	 * @return true|\WP_Error
	 */
	private function validate_only( array $data ) {
		$type = absint( $data['type'] );
		if ( ! in_array( $type, self::TYPES, true ) ) {
			return new \WP_Error( 'type', __( 'Invalid redirect type.', 'futurelabs-ai-seo' ) );
		}
		$source = $data['is_regex'] ? (string) $data['source'] : self::normalize_path( (string) $data['source'] );
		if ( '' === $source || '/' === $source || ( $data['is_regex'] && null === self::regex_pattern( $source ) ) ) {
			return new \WP_Error( 'source', __( 'Invalid source.', 'futurelabs-ai-seo' ) );
		}
		$target = (string) $data['target'];
		if ( 410 !== $type && ! \FutureLabs\AISEO\Core\Url::is_valid( str_starts_with( $target, '/' ) ? home_url( $target ) : $target ) ) {
			return new \WP_Error( 'target', __( 'Invalid target URL.', 'futurelabs-ai-seo' ) );
		}
		return $data['is_regex'] || 410 === $type ? true : $this->check_chain( $source, str_starts_with( $target, '/' ) ? home_url( $target ) : $target );
	}

	/**
	 * Prevent spreadsheet formula injection in exported cells.
	 *
	 * @param string $value Cell.
	 */
	private static function csv_safe( string $value ): string {
		return preg_match( '/^[=+\-@\t\r]/', $value ) ? "'" . $value : $value;
	}

	/**
	 * Forget cached regex rules (after direct table writes).
	 */
	public function flush(): void {
		$this->regex_cache = null;
		wp_cache_delete( 'regex_rules', 'futurelabs-ai-seo' );
	}

	/**
	 * Clear caches after a change.
	 */
	private function changed(): void {
		$this->regex_cache = null;
		wp_cache_delete( 'regex_rules', 'futurelabs-ai-seo' );
		do_action( 'flseo_redirects_changed' );
	}
}
