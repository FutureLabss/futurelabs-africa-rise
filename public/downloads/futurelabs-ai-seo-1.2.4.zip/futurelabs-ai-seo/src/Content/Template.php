<?php
/**
 * Template signatures, edition keys and the opportunity completeness checklist.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Content;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Links\Crawler;

defined( 'ABSPATH' ) || exit;

/**
 * Detects posts built from one template, the same programme across years (OL-3)
 * and missing opportunity sections (OL-4).
 */
class Template {

	/**
	 * Title keywords that mark a post as an opportunity listing.
	 */
	public const OPPORTUNITY_PATTERN = '/\b(scholarships?|fellowships?|grants?|internships?|bursar(?:y|ies)|competitions?|awards?|prizes?|programmes?|programs?|bootcamps?|residenc(?:y|ies)|call for (?:applications|proposals|papers)|apply|applications? (?:open|close)|traineeships?|apprenticeships?|accelerators?|incubators?|vacanc(?:y|ies)|recruitment|exchange)\b/i';

	/**
	 * Boilerplate phrases that template titles append.
	 */
	public const TITLE_BOILERPLATE = '/\b(eligibility and how to apply|eligibility|requirements|how to apply|apply now|application (?:form|portal|guide|process)|fully[- ]funded|partially[- ]funded|call for applications|applications? (?:are )?open|is open|for (?:african|nigerian|international) (?:youths?|students?)|deadline)\b/i';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Opportunity sections: key => [label, keywords searched in headings first, then body].
	 *
	 * @return array<string, array{0: string, 1: array<int, string>}>
	 */
	public static function sections(): array {
		return array(
			'deadline'      => array( __( 'Deadline', 'futurelabs-ai-seo' ), array( 'deadline', 'closing date', 'applications close', 'application closes', 'apply before', 'last date', 'due date', 'closes on' ) ),
			'eligibility'   => array( __( 'Eligibility', 'futurelabs-ai-seo' ), array( 'eligibility', 'eligible', 'who can apply', 'requirements', 'criteria', 'qualifications' ) ),
			'benefits'      => array( __( 'Benefits or funding', 'futurelabs-ai-seo' ), array( 'benefit', 'funding', 'funded', 'stipend', 'award', 'prize', 'allowance', 'tuition', 'grant amount', 'what you get', 'covers' ) ),
			'how_to_apply'  => array( __( 'How to apply', 'futurelabs-ai-seo' ), array( 'how to apply', 'application process', 'to apply', 'apply online', 'apply via', 'application procedure', 'steps to apply', 'submit your application' ) ),
			'official_link' => array( __( 'Official link', 'futurelabs-ai-seo' ), array( 'official website', 'official link', 'official page', 'official source', 'apply here', 'visit the website' ) ),
		);
	}

	/**
	 * Strip years, numbers and punctuation from a title.
	 *
	 * @param string $title Title.
	 */
	public static function strip_title( string $title ): string {
		$title = remove_accents( html_entity_decode( wp_strip_all_tags( $title ), ENT_QUOTES ) );
		$title = strtolower( $title );
		$title = (string) preg_replace( '/\b(19|20)\d{2}(\s*[\/-]\s*(19|20)?\d{2})?\b/', ' ', $title );
		$title = (string) preg_replace( '/\d+(st|nd|rd|th)?/', ' ', $title );
		$title = (string) preg_replace( '/[^\p{L}\s:|–—-]+/u', ' ', $title );
		return Crawler::squash( $title );
	}

	/**
	 * Title pattern used in the template signature: the text after the last separator
	 * (": Eligibility and How to Apply") when present, else the whole stripped title.
	 *
	 * @param string $title Title.
	 */
	public static function title_pattern( string $title ): string {
		$stripped = self::strip_title( $title );
		$parts    = preg_split( '/\s*[:|–—]\s*|\s+-\s+/u', $stripped );
		$parts    = array_values( array_filter( array_map( 'trim', (array) $parts ) ) );
		if ( count( $parts ) > 1 ) {
			$suffix = (string) end( $parts );
			if ( str_word_count( $suffix ) >= 2 ) {
				return $suffix;
			}
		}
		return trim( (string) preg_replace( '/[:|–—-]+/u', ' ', $stripped ) );
	}

	/**
	 * Structure fingerprint: block names in order, or heading outline for classic content.
	 *
	 * @param string                                      $raw      Raw post content.
	 * @param array<int, array{level: int, text: string}> $headings Rendered headings.
	 */
	public static function structure( string $raw, array $headings ): string {
		$parts = array();
		if ( has_blocks( $raw ) ) {
			foreach ( parse_blocks( $raw ) as $block ) {
				if ( empty( $block['blockName'] ) ) {
					continue;
				}
				$name = str_replace( 'core/', '', (string) $block['blockName'] );
				if ( end( $parts ) !== $name ) {
					$parts[] = $name;
				}
			}
		}
		foreach ( $headings as $heading ) {
			$parts[] = 'h' . $heading['level'] . ':' . self::strip_title( $heading['text'] );
		}
		return implode( '>', $parts );
	}

	/**
	 * Template signature (16 hex chars).
	 *
	 * @param string                                      $title    Title.
	 * @param string                                      $raw      Raw content.
	 * @param array<int, array{level: int, text: string}> $headings Headings.
	 */
	public static function signature( string $title, string $raw, array $headings ): string {
		return substr( md5( self::structure( $raw, $headings ) . '|' . self::title_pattern( $title ) ), 0, 16 );
	}

	/**
	 * Edition key and year (OL-3). Posts with the same key and different years are
	 * editions of one programme.
	 *
	 * @param string $title Title.
	 * @return array{key: string, year: int}
	 */
	public static function edition( string $title ): array {
		$year = 0;
		if ( preg_match( '/\b((?:19|20)\d{2})\b/', $title, $m ) ) {
			$year = (int) $m[1];
		}
		$name  = self::strip_title( $title );
		$name  = (string) preg_replace( self::TITLE_BOILERPLATE, ' ', $name );
		$name  = Crawler::squash( (string) preg_replace( '/[:|–—-]+/u', ' ', $name ) );
		$words = Crawler::tokens( $name );
		if ( count( $words ) < 2 ) {
			return array(
				'key'  => '',
				'year' => $year,
			);
		}
		return array(
			'key'  => substr( md5( implode( ' ', $words ) ), 0, 16 ),
			'year' => $year,
		);
	}

	/**
	 * Whether a title is generic: after removing years, numbers and template
	 * boilerplate, fewer than two distinctive words remain.
	 *
	 * @param string $title Title.
	 */
	public static function is_generic_title( string $title ): bool {
		$name = self::strip_title( $title );
		if ( '' === $name ) {
			return true;
		}
		$generic = array( 'untitled', 'hello world', 'home', 'new post', 'update', 'news', 'announcement', 'opportunity', 'opportunities', 'scholarship', 'scholarships', 'fellowship', 'grant', 'internship', 'apply now', 'auto draft', 'sample page', 'short update', 'latest update', 'post' );
		$bare    = trim( (string) preg_replace( '/[:|–—-]+/u', ' ', $name ) );
		if ( in_array( Crawler::squash( $bare ), $generic, true ) ) {
			return true;
		}
		$rest  = (string) preg_replace( self::TITLE_BOILERPLATE, ' ', $bare );
		$words = Crawler::tokens( $rest );
		return count( array_unique( $words ) ) < 2;
	}

	/**
	 * Whether a post is an opportunity listing: opportunity fields set, an
	 * opportunity keyword in the title, or an opportunity category plus
	 * application language in the body.
	 *
	 * @param \WP_Post             $post  Post.
	 * @param string               $text  Plain body text (may be empty).
	 * @param array<string, mixed> $meta  Meta overrides (unsaved values), keyed `_flseo_*`.
	 * @param array<int, int>|null $cats  Category IDs override.
	 */
	public static function is_opportunity( \WP_Post $post, string $text = '', array $meta = array(), ?array $cats = null ): bool {
		foreach ( array( '_flseo_opp_deadline', '_flseo_opp_source_url', '_flseo_opp_status' ) as $key ) {
			$value = array_key_exists( $key, $meta ) ? (string) $meta[ $key ] : ( $post->ID ? (string) get_post_meta( $post->ID, $key, true ) : '' );
			if ( '' !== $value ) {
				return true;
			}
		}
		if ( preg_match( self::OPPORTUNITY_PATTERN, (string) $post->post_title ) ) {
			return true;
		}
		$ids   = null !== $cats ? $cats : ( $post->ID ? self::category_ids( $post->ID ) : array() );
		$names = array();
		foreach ( (array) $ids as $id ) {
			$term = get_term( (int) $id, 'category' );
			if ( $term instanceof \WP_Term ) {
				$names[] = $term->name . ' ' . $term->slug;
			}
		}
		if ( $names && preg_match( self::OPPORTUNITY_PATTERN, implode( ' ', $names ) ) ) {
			return (bool) preg_match( '/\b(apply|applications?|applicants?|deadline|eligib\w*)\b/i', $text );
		}
		return false;
	}

	/**
	 * Category term IDs of a post.
	 *
	 * @param int $post_id Post ID.
	 * @return array<int, int>
	 */
	public static function category_ids( int $post_id ): array {
		$terms = wp_get_object_terms( $post_id, 'category', array( 'fields' => 'ids' ) );
		if ( ! is_array( $terms ) ) {
			return array();
		}
		return array_values( array_map( 'intval', $terms ) );
	}

	/**
	 * Completeness checklist for an opportunity post (OL-4). Not a score.
	 *
	 * @param \WP_Post                                        $post     Post.
	 * @param string                                          $text     Plain body text.
	 * @param array<int, array{level: int, text: string}>     $headings Headings.
	 * @param array<int, array{href: string, anchor: string}> $links  Links in the body.
	 * @param array<string, mixed>                            $meta     Meta overrides.
	 * @return array<int, array{key: string, label: string, ok: bool}>
	 */
	public static function completeness( \WP_Post $post, string $text, array $headings, array $links, array $meta = array() ): array {
		$haystack = strtolower( $text );
		$heads    = strtolower( implode( ' | ', array_column( $headings, 'text' ) ) );
		$get      = static function ( string $key ) use ( $post, $meta ): string {
			return array_key_exists( $key, $meta ) ? (string) $meta[ $key ] : ( $post->ID ? (string) get_post_meta( $post->ID, $key, true ) : '' );
		};
		$external = false;
		foreach ( $links as $link ) {
			if ( Crawler::is_external( $link['href'] ) ) {
				$external = true;
				break;
			}
		}
		$items = array();
		foreach ( self::sections() as $key => $section ) {
			$found = false;
			foreach ( $section[1] as $needle ) {
				if ( str_contains( $heads, $needle ) || str_contains( $haystack, $needle ) ) {
					$found = true;
					break;
				}
			}
			if ( 'deadline' === $key && '' !== $get( '_flseo_opp_deadline' ) ) {
				$found = true;
			}
			if ( 'official_link' === $key ) {
				$found = '' !== $get( '_flseo_opp_source_url' ) || ( $found && $external ) || ( $external && preg_match( '/\b(official|apply)\b/i', $text ) );
			}
			$items[] = array(
				'key'   => $key,
				'label' => $section[0],
				'ok'    => (bool) $found,
			);
		}
		return $items;
	}
}
