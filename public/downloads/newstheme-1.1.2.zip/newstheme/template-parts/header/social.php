<?php
/**
 * Header element: social profile links.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

get_template_part( 'template-parts/social-links', null, array( 'class' => 'nt-social--header' ) );
