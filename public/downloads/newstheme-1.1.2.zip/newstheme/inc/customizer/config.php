<?php
/**
 * Customizer configuration: panels, sections and settings.
 *
 * This is the single source of truth for every theme option. Each setting
 * declares its control, default, and (optionally) how it maps to CSS:
 *
 *   'css'        => [ 'var' => '--nt-accent' ]            color / number
 *   'css'        => [ 'var' => '--nt-gap', 'unit' => 'px' ] responsive / number
 *   'css'        => [ 'prefix' => '--nt-post-title' ]      typography
 *   'css'        => [ 'var' => '--nt-bg', 'scope' => 'dark' ] dark-mode token
 *   'body_class' => 'nt-site--%s'                          select / toggle
 *   'show_if'    => [ 'other_key', 'value' ]               conditional display
 *   'partial'    => 'partial-id'                           selective refresh
 *
 * Settings with `css` or `body_class` update live (postMessage); the rest refresh.
 * Setting keys are stored as theme mods prefixed with `newstheme_`.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Build a typography default value.
 *
 * @param string    $family     Font family slug.
 * @param int       $weight     Font weight.
 * @param int[]     $size       Font size [desktop, tablet, mobile] in px.
 * @param int[]     $lh         Line height [desktop, tablet, mobile] in px.
 * @param string    $transform  Text transform.
 * @param int|int[] $ls         Letter spacing in px (single value or per device).
 * @return array
 */
function newstheme_typo( $family, $weight, $size, $lh, $transform = 'none', $ls = 0 ) {
	$ls = is_array( $ls ) ? $ls : array( $ls, $ls, $ls );
	return array(
		'family'     => $family,
		'weight'     => $weight,
		'size'       => array_combine( array( 'desktop', 'tablet', 'mobile' ), $size ),
		'lineHeight' => array_combine( array( 'desktop', 'tablet', 'mobile' ), $lh ),
		'spacing'    => array_combine( array( 'desktop', 'tablet', 'mobile' ), $ls ),
		'transform'  => $transform,
		'decoration' => 'none',
	);
}

/**
 * Build a responsive default value.
 *
 * @param int|float $desktop Desktop value.
 * @param int|float $tablet  Tablet value (defaults to desktop).
 * @param int|float $mobile  Mobile value (defaults to tablet).
 * @return array
 */
function newstheme_responsive( $desktop, $tablet = null, $mobile = null ) {
	$tablet = null === $tablet ? $desktop : $tablet;
	return array(
		'desktop' => $desktop,
		'tablet'  => $tablet,
		'mobile'  => null === $mobile ? $tablet : $mobile,
	);
}

/**
 * Full Customizer configuration.
 *
 * @return array{panels: array, sections: array, settings: array}
 */
function newstheme_customizer_config() {
	static $config = null;
	if ( null !== $config ) {
		return $config;
	}

	$typography_roles = array(
		'site_title'     => array( __( 'Site Title', 'newstheme' ), '--nt-site-title', newstheme_typo( 'jost', 700, array( 50, 43, 40 ), array( 50, 42, 40 ), 'capitalize' ) ),
		'site_tagline'   => array( __( 'Site Tagline', 'newstheme' ), '--nt-tagline', newstheme_typo( 'roboto', 400, array( 16, 16, 16 ), array( 26, 26, 26 ), 'capitalize' ) ),
		'block_title'    => array( __( 'Block Title', 'newstheme' ), '--nt-block-title', newstheme_typo( 'roboto', 700, array( 26, 26, 25 ), array( 32, 32, 32 ), 'capitalize' ) ),
		'post_title'     => array( __( 'Post Title', 'newstheme' ), '--nt-post-title', newstheme_typo( 'roboto', 500, array( 22, 20, 19 ), array( 27, 27, 27 ), 'capitalize' ) ),
		'meta'           => array( __( 'Post Meta', 'newstheme' ), '--nt-meta', newstheme_typo( 'jost', 500, array( 14, 14, 14 ), array( 20, 20, 20 ), 'capitalize' ) ),
		'content'        => array( __( 'Content / Excerpt', 'newstheme' ), '--nt-content', newstheme_typo( 'inter', 400, array( 15, 15, 15 ), array( 24, 24, 24 ) ) ),
		'menu'           => array( __( 'Menu', 'newstheme' ), '--nt-menu', newstheme_typo( 'roboto', 500, array( 15, 16, 16 ), array( 24, 24, 24 ), 'uppercase' ) ),
		'submenu'        => array( __( 'Sub Menu', 'newstheme' ), '--nt-submenu', newstheme_typo( 'roboto', 500, array( 14, 15, 15 ), array( 22, 24, 24 ), 'capitalize', array( 1, 0, 0 ) ) ),
		'single_title'   => array( __( 'Single Post Title', 'newstheme' ), '--nt-single-title', newstheme_typo( 'roboto', 700, array( 34, 32, 30 ), array( 40, 40, 35 ), 'none' ) ),
		'single_meta'    => array( __( 'Single Post Meta', 'newstheme' ), '--nt-single-meta', newstheme_typo( 'jost', 500, array( 14, 14, 13 ), array( 22, 22, 22 ), 'capitalize' ) ),
		'single_content' => array( __( 'Single Post Content', 'newstheme' ), '--nt-single-content', newstheme_typo( 'inter', 400, array( 17, 16, 16 ), array( 27, 22, 22 ) ) ),
	);

	$panels = array(
		'newstheme_global'   => array(
			'title'    => __( 'Global Options', 'newstheme' ),
			'priority' => 21,
		),
		'newstheme_header'   => array(
			'title'    => __( 'Header', 'newstheme' ),
			'priority' => 22,
		),
		'newstheme_homepage' => array(
			'title'    => __( 'Homepage Sections', 'newstheme' ),
			'priority' => 23,
		),
	);

	$sections = array(
		'newstheme_colors'          => array(
			'title' => __( 'Colors', 'newstheme' ),
			'panel' => 'newstheme_global',
		),
		'newstheme_category_colors' => array(
			'title' => __( 'Category Colors', 'newstheme' ),
			'panel' => 'newstheme_global',
		),
		'newstheme_typography'      => array(
			'title' => __( 'Typography', 'newstheme' ),
			'panel' => 'newstheme_global',
		),
		'newstheme_layout'          => array(
			'title' => __( 'Layout', 'newstheme' ),
			'panel' => 'newstheme_global',
		),
		'newstheme_effects'         => array(
			'title' => __( 'Animations & Hover Effects', 'newstheme' ),
			'panel' => 'newstheme_global',
		),
		'newstheme_social'          => array(
			'title' => __( 'Social Links', 'newstheme' ),
			'panel' => 'newstheme_global',
		),
	);

	$settings = array(
		// Colors — light mode.
		'heading_colors_light' => array(
			'section' => 'newstheme_colors',
			'control' => 'heading',
			'label'   => __( 'Light Mode', 'newstheme' ),
		),
		'accent_color'         => array(
			'section' => 'newstheme_colors',
			'control' => 'color',
			'label'   => __( 'Theme / Accent Color', 'newstheme' ),
			'default' => '#1b8415',
			'css'     => array( 'var' => '--nt-accent' ),
		),
		'accent_text_color'    => array(
			'section'     => 'newstheme_colors',
			'control'     => 'color',
			'label'       => __( 'Accent Text & Link Hover', 'newstheme' ),
			'description' => __( 'Empty follows the accent color. Set a darker shade if your accent is light (aim for 4.5:1 contrast with the card background).', 'newstheme' ),
			'default'     => '',
			'css'         => array( 'var' => '--nt-accent-text' ),
		),
		'site_background'      => array(
			'section'  => 'newstheme_colors',
			'control'  => 'color',
			'label'    => __( 'Site Background', 'newstheme' ),
			'default'  => '#f0f1f2',
			'gradient' => true,
			'css'      => array( 'var' => '--nt-bg' ),
		),
		'surface_color'        => array(
			'section' => 'newstheme_colors',
			'control' => 'color',
			'label'   => __( 'Card / Block Background', 'newstheme' ),
			'default' => '#ffffff',
			'css'     => array( 'var' => '--nt-surface' ),
		),
		'text_color'           => array(
			'section' => 'newstheme_colors',
			'control' => 'color',
			'label'   => __( 'Text Color', 'newstheme' ),
			'default' => '#000000',
			'css'     => array( 'var' => '--nt-text' ),
		),
		'muted_color'          => array(
			'section' => 'newstheme_colors',
			'control' => 'color',
			'label'   => __( 'Meta / Muted Text', 'newstheme' ),
			'default' => '#525252',
			'css'     => array( 'var' => '--nt-text-muted' ),
		),
		'border_color'         => array(
			'section' => 'newstheme_colors',
			'control' => 'color',
			'label'   => __( 'Border Color', 'newstheme' ),
			'default' => '#eeeeee',
			'css'     => array( 'var' => '--nt-border' ),
		),

		// Colors — dark mode.
		'heading_colors_dark'  => array(
			'section' => 'newstheme_colors',
			'control' => 'heading',
			'label'   => __( 'Dark Mode', 'newstheme' ),
		),
		'dark_accent_text'     => array(
			'section'     => 'newstheme_colors',
			'control'     => 'color',
			'label'       => __( 'Accent Text & Link Hover', 'newstheme' ),
			'description' => __( 'Empty uses a lighter tint of the accent color.', 'newstheme' ),
			'default'     => '',
			'css'         => array(
				'var'   => '--nt-accent-text',
				'scope' => 'dark',
			),
		),
		'dark_background'      => array(
			'section'  => 'newstheme_colors',
			'control'  => 'color',
			'label'    => __( 'Site Background', 'newstheme' ),
			'default'  => '#121212',
			'gradient' => true,
			'css'      => array(
				'var'   => '--nt-bg',
				'scope' => 'dark',
			),
		),
		'dark_surface'         => array(
			'section' => 'newstheme_colors',
			'control' => 'color',
			'label'   => __( 'Card / Block Background', 'newstheme' ),
			'default' => '#1e1e1e',
			'css'     => array(
				'var'   => '--nt-surface',
				'scope' => 'dark',
			),
		),
		'dark_text'            => array(
			'section' => 'newstheme_colors',
			'control' => 'color',
			'label'   => __( 'Text Color', 'newstheme' ),
			'default' => '#ededed',
			'css'     => array(
				'var'   => '--nt-text',
				'scope' => 'dark',
			),
		),
		'dark_muted'           => array(
			'section' => 'newstheme_colors',
			'control' => 'color',
			'label'   => __( 'Meta / Muted Text', 'newstheme' ),
			'default' => '#a3a3a3',
			'css'     => array(
				'var'   => '--nt-text-muted',
				'scope' => 'dark',
			),
		),
		'dark_border'          => array(
			'section' => 'newstheme_colors',
			'control' => 'color',
			'label'   => __( 'Border Color', 'newstheme' ),
			'default' => '#2c2c2c',
			'css'     => array(
				'var'   => '--nt-border',
				'scope' => 'dark',
			),
		),

		// Preset palette (swatches in every color picker, and --nt-preset-N vars).
		'heading_presets'      => array(
			'section' => 'newstheme_colors',
			'control' => 'heading',
			'label'   => __( 'Preset Palette', 'newstheme' ),
		),
		'preset_colors'        => array(
			'section'     => 'newstheme_colors',
			'control'     => 'palette',
			'label'       => __( 'Preset Colors', 'newstheme' ),
			'description' => __( 'Shown as quick-pick swatches in every color control.', 'newstheme' ),
			'default'     => array( '#1b8415', '#0f5c0b', '#e8b500', '#d6312b', '#1e73be', '#7a3fd1', '#e45b9a', '#00a3a3', '#000000', '#525252', '#f0f1f2', '#ffffff' ),
			'css'         => array( 'var' => '--nt-preset-' ),
		),

		// Layout.
		'container_width'      => array(
			'section' => 'newstheme_layout',
			'control' => 'number',
			'label'   => __( 'Container Width (px)', 'newstheme' ),
			'default' => 1296,
			'min'     => 960,
			'max'     => 1800,
			'step'    => 2,
			'css'     => array(
				'var'  => '--nt-container',
				'unit' => 'px',
			),
		),
		'site_layout'          => array(
			'section'    => 'newstheme_layout',
			'control'    => 'buttons',
			'label'      => __( 'Website Layout', 'newstheme' ),
			'default'    => 'full',
			'choices'    => array(
				'full'  => __( 'Full Width', 'newstheme' ),
				'boxed' => __( 'Boxed', 'newstheme' ),
			),
			'body_class' => 'nt-site--%s',
		),
		'block_gap'            => array(
			'section' => 'newstheme_layout',
			'control' => 'responsive',
			'label'   => __( 'Gap Between Cards (px)', 'newstheme' ),
			'default' => newstheme_responsive( 30, 24, 20 ),
			'min'     => 0,
			'max'     => 80,
			'css'     => array(
				'var'  => '--nt-gap',
				'unit' => 'px',
			),
		),
		'section_spacing'      => array(
			'section' => 'newstheme_layout',
			'control' => 'responsive',
			'label'   => __( 'Section Vertical Spacing (px)', 'newstheme' ),
			'default' => newstheme_responsive( 40, 40, 30 ),
			'min'     => 0,
			'max'     => 160,
			'css'     => array(
				'var'  => '--nt-section-space',
				'unit' => 'px',
			),
		),
		'image_radius'         => array(
			'section' => 'newstheme_layout',
			'control' => 'responsive',
			'label'   => __( 'Image & Card Corner Radius (px)', 'newstheme' ),
			'default' => newstheme_responsive( 8 ),
			'min'     => 0,
			'max'     => 40,
			'css'     => array(
				'var'  => '--nt-radius',
				'unit' => 'px',
			),
		),

		// Effects.
		'animations'           => array(
			'section'    => 'newstheme_effects',
			'control'    => 'toggle',
			'label'      => __( 'Animate cards on scroll', 'newstheme' ),
			'default'    => true,
			'body_class' => 'nt-anim',
		),
		'image_hover'          => array(
			'section'    => 'newstheme_effects',
			'control'    => 'select',
			'label'      => __( 'Image Hover Effect', 'newstheme' ),
			'default'    => 'zoom',
			'choices'    => array(
				'none'    => __( 'None', 'newstheme' ),
				'zoom'    => __( 'Zoom', 'newstheme' ),
				'overlay' => __( 'Dark Overlay', 'newstheme' ),
			),
			'body_class' => 'nt-img-hover--%s',
		),
		'title_hover'          => array(
			'section'    => 'newstheme_effects',
			'control'    => 'select',
			'label'      => __( 'Post Title Hover Effect', 'newstheme' ),
			'default'    => 'color',
			'choices'    => array(
				'none'      => __( 'None', 'newstheme' ),
				'color'     => __( 'Accent Color', 'newstheme' ),
				'underline' => __( 'Animated Underline', 'newstheme' ),
			),
			'body_class' => 'nt-title-hover--%s',
		),

		// Social links.
		'social_links'         => array(
			'section'     => 'newstheme_social',
			'control'     => 'repeater',
			'label'       => __( 'Social Profiles', 'newstheme' ),
			'description' => __( 'Used by the header, footer and Social Icons widget.', 'newstheme' ),
			'item_label'  => __( 'Profile', 'newstheme' ),
			'fields'      => array(
				'network' => array(
					'type'    => 'select',
					'label'   => __( 'Network', 'newstheme' ),
					'default' => 'facebook',
					'choices' => newstheme_social_networks(),
				),
				'url'     => array(
					'type'    => 'url',
					'label'   => __( 'Profile URL', 'newstheme' ),
					'default' => '',
				),
				'enabled' => array(
					'type'    => 'toggle',
					'label'   => __( 'Show', 'newstheme' ),
					'default' => true,
				),
			),
			'default'     => array(
				array(
					'network' => 'facebook',
					'url'     => '#',
					'enabled' => true,
				),
				array(
					'network' => 'instagram',
					'url'     => '#',
					'enabled' => true,
				),
				array(
					'network' => 'x',
					'url'     => '#',
					'enabled' => true,
				),
				array(
					'network' => 'youtube',
					'url'     => '#',
					'enabled' => true,
				),
				array(
					'network' => 'tiktok',
					'url'     => '#',
					'enabled' => true,
				),
			),
		),
		'social_new_tab'       => array(
			'section' => 'newstheme_social',
			'control' => 'toggle',
			'label'   => __( 'Open links in a new tab', 'newstheme' ),
			'default' => true,
		),

	);

	// Typography roles.
	$settings['typography_fonts_note'] = array(
		'section'     => 'newstheme_typography',
		'control'     => 'heading',
		'label'       => __( 'More Fonts', 'newstheme' ),
		'description' => __( 'Install fonts in Appearance → Fonts (free Google Fonts, hosted on your own site). They then appear in every Font Family list below.', 'newstheme' ),
	);
	foreach ( $typography_roles as $key => list( $label, $prefix, $default ) ) {
		$settings[ 'typo_' . $key ] = array(
			'section' => 'newstheme_typography',
			'control' => 'typography',
			'label'   => $label,
			'default' => $default,
			'css'     => array( 'prefix' => $prefix ),
		);
	}

	// Area config files each return [ 'panels' => …, 'sections' => …, 'settings' => … ].
	$partials = array();
	foreach ( array( 'header', 'homepage', 'inner', 'footer', 'extras' ) as $area ) {
		$part     = require NEWSTHEME_DIR . "inc/customizer/config/{$area}.php";
		$panels   = array_merge( $panels, $part['panels'] ?? array() );
		$sections = array_merge( $sections, $part['sections'] ?? array() );
		$settings = array_merge( $settings, $part['settings'] ?? array() );
		$partials = array_merge( $partials, $part['partials'] ?? array() );
	}

	$config = apply_filters(
		'newstheme_customizer_config',
		array(
			'panels'   => $panels,
			'sections' => $sections,
			'settings' => $settings,
			'partials' => $partials,
		)
	);

	return $config;
}

/**
 * Category color settings, generated per category.
 *
 * Kept out of the cached config because categories change at runtime.
 *
 * @return array
 */
function newstheme_category_color_settings() {
	$settings   = array();
	$categories = get_categories(
		array(
			'hide_empty' => false,
			'number'     => 100,
		)
	);
	foreach ( $categories as $category ) {
		$settings[ 'category_color_' . $category->term_id ] = array(
			'section' => 'newstheme_category_colors',
			'control' => 'color',
			'label'   => $category->name,
			'default' => '',
			'css'     => array(
				'selector'     => '.nt-cat-' . (int) $category->term_id,
				'var'          => '--nt-cat-color',
				'contrast_var' => '--nt-cat-on',
			),
		);
	}
	return $settings;
}

/**
 * Supported social networks: slug => label.
 *
 * @return array<string, string>
 */
function newstheme_social_networks() {
	return array(
		'facebook'  => 'Facebook',
		'instagram' => 'Instagram',
		'x'         => 'X (Twitter)',
		'youtube'   => 'YouTube',
		'tiktok'    => 'TikTok',
		'linkedin'  => 'LinkedIn',
		'threads'   => 'Threads',
		'pinterest' => 'Pinterest',
		'whatsapp'  => 'WhatsApp',
		'telegram'  => 'Telegram',
		'rss'       => 'RSS',
	);
}
