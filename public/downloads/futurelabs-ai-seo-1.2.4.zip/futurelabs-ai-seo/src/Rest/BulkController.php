<?php
/**
 * POST /bulk · POST /bulk/undo.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Bulk\Actions;
use FutureLabs\AISEO\Bulk\Undo;
use FutureLabs\AISEO\Core\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Bulk actions and undo. Requires the editor capability; each post is checked with edit_post.
 */
class BulkController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/bulk', 'POST', array( $this, 'run' ), Capabilities::EDITOR );
		$this->route( '/bulk/undo', 'POST', array( $this, 'undo' ), Capabilities::EDITOR );
	}

	/**
	 * Run or preview a bulk action. Returns 409 with the phrase when confirmation is required.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function run( \WP_REST_Request $request ) {
		$result = $this->c->get( Actions::class )->run( $this->body( $request ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new \WP_REST_Response( $result, empty( $result['confirmation_required'] ) ? 200 : 409 );
	}

	/**
	 * Undo a batch.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function undo( \WP_REST_Request $request ) {
		$batch  = sanitize_text_field( (string) ( $this->body( $request )['batch_id'] ?? '' ) );
		$result = $this->c->get( Undo::class )->undo( $batch );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}
}
