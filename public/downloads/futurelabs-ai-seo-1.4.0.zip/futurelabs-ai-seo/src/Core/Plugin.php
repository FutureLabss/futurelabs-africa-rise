<?php
/**
 * Plugin bootstrap: builds the container and registers modules.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Owns the container and the module list.
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static ?Plugin $instance = null;

	/**
	 * Service container.
	 *
	 * @var Container
	 */
	private Container $container;

	/**
	 * Modules whose register() is called on boot, in order.
	 *
	 * @var array<int, class-string<Module>>
	 */
	public const MODULES = array(
		\FutureLabs\AISEO\Core\Capabilities::class,
		Cron::class,
		\FutureLabs\AISEO\Meta\PostMeta::class,
		\FutureLabs\AISEO\Meta\TermMeta::class,
		\FutureLabs\AISEO\Meta\Head::class,
		\FutureLabs\AISEO\Conflicts\Notices::class,
		\FutureLabs\AISEO\Sitemap\Router::class,
		\FutureLabs\AISEO\Sitemap\Validator::class,
		\FutureLabs\AISEO\Redirects\Router::class,
		\FutureLabs\AISEO\Redirects\Log404::class,
		\FutureLabs\AISEO\Redirects\SlugWatcher::class,
		\FutureLabs\AISEO\Gsc\OAuth::class,
		\FutureLabs\AISEO\Gsc\Inspector::class,
		\FutureLabs\AISEO\Gsc\Sitemaps::class,
		\FutureLabs\AISEO\Gsc\Analytics::class,
		\FutureLabs\AISEO\Content\Analyzer::class,
		\FutureLabs\AISEO\Links\Graph::class,
		\FutureLabs\AISEO\Opportunity\Lifecycle::class,
		\FutureLabs\AISEO\Opportunity\Velocity::class,
		\FutureLabs\AISEO\Opportunity\Checklist::class,
		\FutureLabs\AISEO\Bulk\AuditLog::class,
		\FutureLabs\AISEO\Schema\Graph::class,
		\FutureLabs\AISEO\Schema\Breadcrumbs::class,
		\FutureLabs\AISEO\Integrations\NewsDesk::class,
		\FutureLabs\AISEO\Indexing\IndexNow::class,
		\FutureLabs\AISEO\Ai\Approvals::class,
		\FutureLabs\AISEO\Reports\History::class,
		\FutureLabs\AISEO\Rest\Routes::class,
		\FutureLabs\AISEO\Admin\Menu::class,
		\FutureLabs\AISEO\Admin\EditorAssets::class,
		\FutureLabs\AISEO\Admin\CachePurge::class,
		\FutureLabs\AISEO\Admin\Updater::class,
		\FutureLabs\AISEO\Admin\Network::class,
	);

	/**
	 * Get the plugin instance.
	 */
	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self( new Container() );
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @param Container $container Container.
	 */
	private function __construct( Container $container ) {
		$this->container = $container;
		$this->container->instance( Container::class, $container );
	}

	/**
	 * The service container.
	 */
	public function container(): Container {
		return $this->container;
	}

	/**
	 * Register all modules. Called once on plugins_loaded.
	 */
	public function boot(): void {
		add_action( 'init', array( $this, 'maybe_migrate' ), 1 );
		add_action( 'init', array( $this, 'load_textdomain' ), 0 );
		// Settings are cached per request; switching sites must not leak one site's settings into another.
		add_action( 'switch_blog', array( $this, 'flush_site_caches' ) );
		foreach ( self::MODULES as $class ) {
			if ( ! class_exists( $class ) ) {
				continue;
			}
			$module = $this->container->get( $class );
			if ( $module instanceof Module ) {
				$module->register();
			}
		}
		/**
		 * Fires after FutureLabs AI SEO registered its modules.
		 *
		 * @param Container $container Service container.
		 */
		do_action( 'flseo_loaded', $this->container );
	}

	/**
	 * Run pending migrations (handles upgrades without reactivation).
	 */
	public function maybe_migrate(): void {
		$this->container->get( Migrations::class )->run();
	}

	/**
	 * Forget per-site cached state after switch_to_blog().
	 */
	public function flush_site_caches(): void {
		$this->container->get( Settings::class )->flush();
	}

	/**
	 * Load translations.
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain( 'futurelabs-ai-seo', false, dirname( plugin_basename( FLSEO_FILE ) ) . '/languages' );
	}

	/**
	 * Activation for one site.
	 */
	public static function activate_site(): void {
		$c = self::instance()->container();
		// Action Scheduler creates its tables lazily; a brand-new multisite site has none yet.
		if ( class_exists( '\ActionScheduler_StoreSchema' ) && class_exists( '\ActionScheduler_LoggerSchema' ) ) {
			( new \ActionScheduler_StoreSchema() )->register_tables( true );
			( new \ActionScheduler_LoggerSchema() )->register_tables( true );
		}
		$c->get( Migrations::class )->run();
		if ( false === get_option( Settings::OPTION ) ) {
			add_option( Settings::OPTION, Settings::defaults(), '', true );
		}
		$c->get( \FutureLabs\AISEO\Sitemap\Router::class )->add_rules();
		flush_rewrite_rules( false );
		do_action( 'flseo_activated' );
	}

	/**
	 * Activation hook (handles network activation).
	 *
	 * @param bool $network_wide Whether network-activated.
	 */
	public static function activate( bool $network_wide = false ): void {
		if ( is_multisite() && $network_wide ) {
			foreach ( get_sites(
				array(
					'fields' => 'ids',
					'number' => 0,
				)
			) as $site_id ) {
				switch_to_blog( (int) $site_id );
				self::activate_site();
				restore_current_blog();
			}
			return;
		}
		self::activate_site();
	}

	/**
	 * Deactivation hook.
	 *
	 * @param bool $network_wide Whether network-deactivated.
	 */
	public static function deactivate( bool $network_wide = false ): void {
		$run = static function (): void {
			$queue = self::instance()->container()->get( Queue::class );
			foreach ( self::scheduled_hooks() as $hook ) {
				$queue->cancel( $hook );
			}
			flush_rewrite_rules( false );
		};
		if ( is_multisite() && $network_wide ) {
			foreach ( get_sites(
				array(
					'fields' => 'ids',
					'number' => 0,
				)
			) as $site_id ) {
				switch_to_blog( (int) $site_id );
				$run();
				restore_current_blog();
			}
			return;
		}
		$run();
	}

	/**
	 * Every hook the plugin schedules.
	 *
	 * @return array<int, string>
	 */
	public static function scheduled_hooks(): array {
		return array(
			'flseo_daily',
			'flseo_expire_opportunities',
			'flseo_scan_batch',
			'flseo_scan_post',
			'flseo_graph_compute',
			'flseo_inspect_url',
			'flseo_inspection_queue',
			'flseo_submit_sitemap',
			'flseo_sync_analytics',
			'flseo_validate_sitemap',
			'flseo_purge_404',
			'flseo_history_snapshot',
			'flseo_embeddings_batch',
			'flseo_ai_alt_batch',
			'flseo_probe_frontend',
			'flseo_indexnow_submit',
			// 1.0.0 hooks.
			'flseo_daily_expiry',
			'flseo_scan_batch',
			'flseo_scan_enqueue_batch',
			'flseo_gsc_inspect_post',
			'flseo_gsc_submit_sitemap',
		);
	}
}
