<?php
/**
 * Reading theme options.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * All settings, including runtime-generated ones (category colors).
 *
 * @return array<string, array>
 */
function newstheme_all_settings() {
	$config = newstheme_customizer_config();
	return array_merge( $config['settings'], newstheme_category_color_settings() );
}

/**
 * Default value of a setting.
 *
 * @param string $key Setting key (without the `newstheme_` prefix).
 * @return mixed
 */
function newstheme_get_default( $key ) {
	$settings = newstheme_customizer_config()['settings'];
	if ( isset( $settings[ $key ]['default'] ) ) {
		return $settings[ $key ]['default'];
	}
	return str_starts_with( $key, 'category_color_' ) ? '' : null;
}

/**
 * Current value of a theme option, merged over its default.
 *
 * Keyed array values are merged over their defaults (see
 * newstheme_merge_defaults()) so options saved by older versions still get
 * newly added keys.
 *
 * @param string $key Setting key (without the `newstheme_` prefix).
 * @return mixed
 */
function newstheme_get_mod( $key ) {
	$default = newstheme_get_default( $key );
	// Defaults are applied here rather than passed to get_theme_mod(), which
	// runs string defaults through sprintf() and chokes on a literal "%".
	$value = get_theme_mod( 'newstheme_' . $key, null );
	if ( null === $value ) {
		$value = $default;
	}

	return newstheme_merge_defaults( $default, $value );
}

/**
 * Merge a saved value over its default: keyed arrays (typography, responsive,
 * builder rows) merge key by key so new keys get defaults; lists are values in
 * their own right and replace the default wholesale. (array_replace_recursive
 * would merge lists index by index, resurrecting items a user removed.)
 *
 * @param mixed $fallback Default value.
 * @param mixed $value    Saved value.
 * @return mixed
 */
function newstheme_merge_defaults( $fallback, $value ) {
	if ( ! is_array( $fallback ) || ! is_array( $value ) || ! newstheme_is_assoc( $fallback ) ) {
		return $value;
	}
	foreach ( $fallback as $key => $default_item ) {
		$value[ $key ] = array_key_exists( $key, $value )
			? newstheme_merge_defaults( $default_item, $value[ $key ] )
			: $default_item;
	}
	return $value;
}

/**
 * Whether an array is associative (vs a list).
 *
 * @param array $value Array to test.
 * @return bool
 */
function newstheme_is_assoc( $value ) {
	return array() !== $value && array_keys( $value ) !== range( 0, count( $value ) - 1 );
}
