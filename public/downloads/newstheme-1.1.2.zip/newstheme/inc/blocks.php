<?php
/**
 * Homepage blocks: grid, list, filter (tabs), carousel, banner and ad.
 *
 * A block is a type plus an args array. newstheme_render_block() sanitizes the
 * args, runs the query and loads template-parts/blocks/{type}-{layout}.php.
 * Phase 4 stores these args in the Customizer; any code can render a block:
 *
 *     newstheme_render_block( 'news-grid', array( 'title' => 'Trending', 'columns' => 3 ) );
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Block types: label, available layouts and default args.
 *
 * @return array<string, array{label: string, layouts: array, defaults: array}>
 */
function newstheme_block_types() {
	$query = array(
		'source'     => 'latest', // latest | categories | posts | closing.
		'categories' => array(),
		'posts'      => array(),
		'count'      => 3,
		'offset'     => 0,
		'orderby'    => 'date', // date | rand | comment_count | title.
	);
	$meta  = array( 'author', 'comments' );

	return apply_filters(
		'newstheme_block_types',
		array(
			'banner'        => array(
				'label'    => __( 'Main Banner', 'newstheme' ),
				'layouts'  => array(
					'one' => __( 'Slider + 2×2 Grid', 'newstheme' ),
					'two' => __( 'Wide Slider + Card Row', 'newstheme' ),
				),
				'defaults' => array(
					'layout'   => 'one',
					'query'    => array_merge( $query, array( 'count' => 4 ) ),
					'side'     => array_merge(
						$query,
						array(
							'count'  => 4,
							'offset' => 4,
						)
					),
					'autoplay' => 6,
				),
			),
			'news-grid'     => array(
				'label'    => __( 'News Grid', 'newstheme' ),
				'layouts'  => array(
					'one' => __( 'Cards', 'newstheme' ),
					'two' => __( 'Centered', 'newstheme' ),
				),
				'defaults' => array(
					'title'   => '',
					'layout'  => 'one',
					'columns' => 3,
					'query'   => $query,
					'meta'    => $meta,
				),
			),
			'news-list'     => array(
				'label'    => __( 'News List', 'newstheme' ),
				'layouts'  => array(
					'one' => __( 'Large Rows', 'newstheme' ),
					'two' => __( 'Compact', 'newstheme' ),
				),
				'defaults' => array(
					'title'     => '',
					'layout'    => 'one',
					'columns'   => 1,
					'query'     => $query,
					'meta'      => array( 'author', 'date', 'comments' ),
					'excerpt'   => 18,
					'read_more' => true,
				),
			),
			'news-filter'   => array(
				'label'    => __( 'News Filter (Tabs)', 'newstheme' ),
				'layouts'  => array(
					'one' => __( '2 Featured + 4 Small', 'newstheme' ),
					'two' => __( 'Card Grid', 'newstheme' ),
				),
				'defaults' => array(
					'title'   => '',
					'layout'  => 'one',
					'tabs'    => array(),
					'query'   => array_merge( $query, array( 'count' => 6 ) ),
					'meta'    => array( 'date', 'comments' ),
					'excerpt' => 12,
				),
			),
			'news-carousel' => array(
				'label'    => __( 'News Carousel', 'newstheme' ),
				'layouts'  => array(
					'one' => __( 'Overlapping Card', 'newstheme' ),
					'two' => __( 'Text Over Image', 'newstheme' ),
				),
				'defaults' => array(
					'title'    => '',
					'layout'   => 'one',
					'columns'  => 3,
					'query'    => array_merge( $query, array( 'count' => 6 ) ),
					'meta'     => array( 'author', 'date', 'comments' ),
					'autoplay' => 5,
					'arrows'   => true,
				),
			),
			'ad'            => array(
				'label'    => __( 'Advertisement', 'newstheme' ),
				'layouts'  => array( 'one' => __( 'Banner', 'newstheme' ) ),
				'defaults' => array(
					'layout' => 'one',
					'image'  => 0,
					'url'    => '',
					'html'   => '',
					'label'  => __( 'Advertisement', 'newstheme' ),
				),
			),
		)
	);
}

/**
 * Merge and sanitize block args against the type's defaults.
 *
 * @param string $type Block type.
 * @param array  $args Raw args.
 * @return array|null Null for unknown types.
 */
function newstheme_block_args( $type, array $args ) {
	$types = newstheme_block_types();
	if ( ! isset( $types[ $type ] ) ) {
		return null;
	}
	$defaults = $types[ $type ]['defaults'];
	$args     = array_merge( $defaults, array_intersect_key( $args, $defaults ) );

	if ( ! isset( $types[ $type ]['layouts'][ $args['layout'] ] ) ) {
		$args['layout'] = $defaults['layout'];
	}
	if ( isset( $args['title'] ) ) {
		$args['title'] = sanitize_text_field( $args['title'] );
	}
	if ( isset( $args['columns'] ) ) {
		$args['columns'] = max( 1, min( 4, (int) $args['columns'] ) );
	}
	foreach ( array( 'query', 'side' ) as $key ) {
		if ( isset( $args[ $key ] ) ) {
			$args[ $key ] = newstheme_sanitize_block_query( (array) $args[ $key ], $defaults[ $key ] );
		}
	}
	if ( isset( $args['meta'] ) ) {
		$args['meta'] = array_values( array_intersect( (array) $args['meta'], array( 'author', 'date', 'comments' ) ) );
	}
	if ( isset( $args['tabs'] ) ) {
		$args['tabs'] = newstheme_sanitize_id_list( $args['tabs'] );
	}
	foreach ( array( 'excerpt', 'autoplay', 'image' ) as $key ) {
		if ( isset( $args[ $key ] ) ) {
			$args[ $key ] = absint( $args[ $key ] );
		}
	}
	foreach ( array( 'read_more', 'arrows' ) as $key ) {
		if ( isset( $args[ $key ] ) ) {
			$args[ $key ] = (bool) $args[ $key ];
		}
	}
	if ( 'ad' === $type ) {
		$args['url']   = esc_url_raw( $args['url'] );
		$args['label'] = sanitize_text_field( $args['label'] );
		// Ad code is sanitized when saved (only users with `unfiltered_html` may
		// store scripts, as with the Custom HTML widget), so it's output as stored.
		// Never pass client input here: the REST route only accepts news-filter args.
		$args['html'] = (string) $args['html'];
	}

	return $args;
}

/**
 * Sanitize a block query.
 *
 * @param array $query    Raw query.
 * @param array $defaults Defaults.
 * @return array
 */
function newstheme_sanitize_block_query( array $query, array $defaults ) {
	$query = array_merge( $defaults, array_intersect_key( $query, $defaults ) );

	return array(
		'source'     => in_array( $query['source'], array( 'latest', 'categories', 'posts', 'closing' ), true ) ? $query['source'] : 'latest',
		'categories' => newstheme_sanitize_id_list( $query['categories'] ),
		'posts'      => newstheme_sanitize_id_list( $query['posts'] ),
		'count'      => max( 1, min( 24, (int) $query['count'] ) ),
		'offset'     => max( 0, min( 50, (int) $query['offset'] ) ),
		'orderby'    => in_array( $query['orderby'], array( 'date', 'rand', 'comment_count', 'title' ), true ) ? $query['orderby'] : 'date',
	);
}

/**
 * WP_Query args for a block query.
 *
 * @param array    $query       Sanitized block query.
 * @param int|null $category_id Force a category (filter tabs).
 * @return array
 */
function newstheme_block_wp_query_args( array $query, $category_id = null ) {
	$args = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => $query['count'],
		'offset'              => $query['offset'],
		'orderby'             => $query['orderby'],
		'order'               => 'title' === $query['orderby'] ? 'ASC' : 'DESC',
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);

	if ( $category_id ) {
		$args['cat'] = (int) $category_id;
	} elseif ( 'categories' === $query['source'] && $query['categories'] ) {
		$args['category__in'] = $query['categories'];
	} elseif ( 'posts' === $query['source'] ) {
		$args['post__in']       = $query['posts'] ? $query['posts'] : array( 0 );
		$args['orderby']        = 'post__in';
		$args['posts_per_page'] = count( $args['post__in'] );
		unset( $args['offset'] );
	} elseif ( 'closing' === $query['source'] ) {
		$args = newstheme_closing_soon_query_args( $args );
	}

	return apply_filters( 'newstheme_block_query_args', $args, $query );
}

/**
 * Render a block.
 *
 * @param string $type Block type.
 * @param array  $args Block args.
 */
function newstheme_render_block( $type, array $args = array() ) {
	$args = newstheme_block_args( $type, $args );
	if ( null === $args ) {
		return;
	}

	$args['type'] = $type;
	$args['id']   = wp_unique_id( 'nt-block-' );
	$args['loop'] = in_array( $type, array( 'ad', 'banner' ), true )
		? null
		: new WP_Query( newstheme_block_wp_query_args( $args['query'] ) );

	if ( $args['loop'] instanceof WP_Query && ! $args['loop']->have_posts() && 'news-filter' !== $type ) {
		return;
	}

	get_template_part( 'template-parts/blocks/' . $type, $args['layout'], $args );
	wp_reset_postdata();
}

/**
 * Print a block heading. Kept as a helper so every block's title is identical.
 *
 * @param string $title   Title text.
 * @param string $id      Heading ID (for aria-labelledby).
 * @param string $extra   Extra markup after the title (e.g. tabs).
 */
function newstheme_block_heading( $title, $id, $extra = '' ) {
	if ( '' === $title && '' === $extra ) {
		return;
	}
	echo '<div class="nt-block__head">';
	if ( '' !== $title ) {
		printf( '<h2 class="nt-block-title" id="%1$s-title"><span>%2$s</span></h2>', esc_attr( $id ), esc_html( $title ) );
	}
	echo $extra; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts by the caller.
	echo '</div>';
}

/**
 * Cache version for rendered block fragments; bumped whenever posts change.
 *
 * @return string
 */
function newstheme_block_cache_version() {
	return (string) get_option( 'newstheme_block_cache', '1' );
}

/**
 * Invalidate cached block fragments.
 */
function newstheme_bump_block_cache() {
	update_option( 'newstheme_block_cache', (string) time(), false );
}
add_action( 'save_post_post', 'newstheme_bump_block_cache' );
add_action( 'deleted_post', 'newstheme_bump_block_cache' );
add_action( 'edited_category', 'newstheme_bump_block_cache' );

/**
 * REST: one filter tab's posts, rendered.
 * GET /wp-json/newstheme/v1/filter-tab?args={json}&term={id}
 */
function newstheme_register_block_routes() {
	register_rest_route(
		'newstheme/v1',
		'/filter-tab',
		array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'args'                => array(
				'args' => array(
					'type'     => 'string',
					'required' => true,
				),
				'term' => array(
					'type'     => 'integer',
					'required' => true,
				),
			),
			'callback'            => 'newstheme_rest_filter_tab',
		)
	);
}
add_action( 'rest_api_init', 'newstheme_register_block_routes' );

/**
 * Render one filter tab.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response|WP_Error
 */
function newstheme_rest_filter_tab( $request ) {
	$raw  = json_decode( (string) $request->get_param( 'args' ), true );
	$args = newstheme_block_args( 'news-filter', is_array( $raw ) ? $raw : array() );
	$term = absint( $request->get_param( 'term' ) );
	if ( ! $term || ! term_exists( $term, 'category' ) ) {
		return new WP_Error( 'newstheme_bad_term', __( 'Unknown category.', 'newstheme' ), array( 'status' => 400 ) );
	}

	$key  = 'nt_tab_' . md5( wp_json_encode( array( $args, $term, newstheme_block_cache_version() ) ) );
	$html = get_transient( $key );
	if ( false === $html ) {
		$args['loop'] = new WP_Query( newstheme_block_wp_query_args( $args['query'], $term ) );
		ob_start();
		get_template_part( 'template-parts/blocks/news-filter', $args['layout'] . '-panel', $args );
		wp_reset_postdata();
		$html = ob_get_clean();
		set_transient( $key, $html, DAY_IN_SECONDS );
	}

	return rest_ensure_response( array( 'html' => $html ) );
}

/**
 * Editable fields for a block type, used by the Customizer's block list
 * control. `key` is a dot path into the block args; `show_if` is
 * [ key, value|values ] like setting configs.
 *
 * @param string $type Block type.
 * @return array[]
 */
function newstheme_block_fields( $type ) {
	$types = newstheme_block_types();
	if ( ! isset( $types[ $type ] ) ) {
		return array();
	}
	$defaults = $types[ $type ]['defaults'];
	$fields   = array();

	if ( array_key_exists( 'title', $defaults ) ) {
		$fields[] = array(
			'key'   => 'title',
			'type'  => 'text',
			'label' => __( 'Title', 'newstheme' ),
		);
	}
	if ( count( $types[ $type ]['layouts'] ) > 1 ) {
		$fields[] = array(
			'key'     => 'layout',
			'type'    => 'select',
			'label'   => __( 'Layout', 'newstheme' ),
			'choices' => $types[ $type ]['layouts'],
		);
	}
	if ( array_key_exists( 'columns', $defaults ) ) {
		$fields[] = array(
			'key'     => 'columns',
			'type'    => 'buttons',
			'label'   => __( 'Columns', 'newstheme' ),
			'choices' => array(
				'1' => '1',
				'2' => '2',
				'3' => '3',
				'4' => '4',
			),
		);
	}
	if ( 'banner' === $type ) {
		$fields = array_merge(
			$fields,
			newstheme_block_query_fields( 'query', __( 'Slider Posts', 'newstheme' ) ),
			newstheme_block_query_fields( 'side', __( 'Side Posts (2×2)', 'newstheme' ) )
		);
	} elseif ( array_key_exists( 'query', $defaults ) ) {
		$fields = array_merge( $fields, newstheme_block_query_fields( 'query', __( 'Posts', 'newstheme' ) ) );
	}
	if ( array_key_exists( 'tabs', $defaults ) ) {
		$fields[] = array(
			'key'         => 'tabs',
			'type'        => 'multiselect',
			'source'      => 'categories',
			'label'       => __( 'Category Tabs', 'newstheme' ),
			'description' => __( 'Shown next to an "All" tab.', 'newstheme' ),
		);
	}
	if ( array_key_exists( 'meta', $defaults ) ) {
		$fields[] = array(
			'key'     => 'meta',
			'type'    => 'checkboxes',
			'label'   => __( 'Show Meta', 'newstheme' ),
			'choices' => array(
				'author'   => __( 'Author', 'newstheme' ),
				'date'     => __( 'Date', 'newstheme' ),
				'comments' => __( 'Comments', 'newstheme' ),
			),
		);
	}
	if ( array_key_exists( 'excerpt', $defaults ) ) {
		$fields[] = array(
			'key'         => 'excerpt',
			'type'        => 'number',
			'label'       => __( 'Excerpt Length (words)', 'newstheme' ),
			'description' => __( '0 hides the excerpt.', 'newstheme' ),
			'min'         => 0,
			'max'         => 60,
		);
	}
	if ( array_key_exists( 'read_more', $defaults ) ) {
		$fields[] = array(
			'key'   => 'read_more',
			'type'  => 'toggle',
			'label' => __( 'Show "Read Full News" link', 'newstheme' ),
		);
	}
	if ( array_key_exists( 'autoplay', $defaults ) ) {
		$fields[] = array(
			'key'         => 'autoplay',
			'type'        => 'number',
			'label'       => __( 'Autoplay (seconds)', 'newstheme' ),
			'description' => __( '0 turns autoplay off.', 'newstheme' ),
			'min'         => 0,
			'max'         => 20,
		);
	}
	if ( array_key_exists( 'arrows', $defaults ) ) {
		$fields[] = array(
			'key'   => 'arrows',
			'type'  => 'toggle',
			'label' => __( 'Show arrows', 'newstheme' ),
		);
	}
	if ( 'ad' === $type ) {
		$fields[] = array(
			'key'   => 'image',
			'type'  => 'image',
			'label' => __( 'Ad Image', 'newstheme' ),
		);
		$fields[] = array(
			'key'   => 'url',
			'type'  => 'url',
			'label' => __( 'Link URL', 'newstheme' ),
		);
		$fields[] = array(
			'key'         => 'html',
			'type'        => 'textarea',
			'label'       => __( 'Or Ad Code', 'newstheme' ),
			'description' => __( 'Used when no image is set (e.g. AdSense). Scripts are only kept for administrators allowed to post unfiltered HTML.', 'newstheme' ),
		);
		$fields[] = array(
			'key'   => 'label',
			'type'  => 'text',
			'label' => __( 'Small Label Above Ad', 'newstheme' ),
		);
	}

	return apply_filters( 'newstheme_block_fields', $fields, $type );
}

/**
 * Query fields for a block (source, categories, posts, count, offset, order).
 *
 * @param string $prefix Args key holding the query ('query' or 'side').
 * @param string $label  Heading label.
 * @return array[]
 */
function newstheme_block_query_fields( $prefix, $label ) {
	$not_posts = array( "{$prefix}.source", array( 'latest', 'categories' ) );
	$counted   = array( "{$prefix}.source", array( 'latest', 'categories', 'closing' ) );
	return array(
		array(
			'key'         => "{$prefix}.source",
			'type'        => 'buttons',
			'label'       => $label,
			'description' => __( 'Closing soon: posts with an upcoming deadline (set in FutureLabs AI SEO), soonest first.', 'newstheme' ),
			'choices'     => array(
				'latest'     => __( 'Latest', 'newstheme' ),
				'categories' => __( 'Categories', 'newstheme' ),
				'posts'      => __( 'Hand-picked', 'newstheme' ),
				'closing'    => __( 'Closing soon', 'newstheme' ),
			),
		),
		array(
			'key'     => "{$prefix}.categories",
			'type'    => 'multiselect',
			'source'  => 'categories',
			'label'   => __( 'Categories', 'newstheme' ),
			'show_if' => array( "{$prefix}.source", 'categories' ),
		),
		array(
			'key'     => "{$prefix}.posts",
			'type'    => 'multiselect',
			'source'  => 'posts',
			'label'   => __( 'Posts', 'newstheme' ),
			'show_if' => array( "{$prefix}.source", 'posts' ),
		),
		array(
			'key'     => "{$prefix}.count",
			'type'    => 'number',
			'label'   => __( 'Number of Posts', 'newstheme' ),
			'min'     => 1,
			'max'     => 24,
			'show_if' => $counted,
		),
		array(
			'key'         => "{$prefix}.offset",
			'type'        => 'number',
			'label'       => __( 'Skip First N Posts', 'newstheme' ),
			'description' => __( 'Avoids repeating posts shown in an earlier block.', 'newstheme' ),
			'min'         => 0,
			'max'         => 50,
			'show_if'     => $not_posts,
		),
		array(
			'key'     => "{$prefix}.orderby",
			'type'    => 'select',
			'label'   => __( 'Order By', 'newstheme' ),
			'choices' => array(
				'date'          => __( 'Newest first', 'newstheme' ),
				'comment_count' => __( 'Most commented', 'newstheme' ),
				'rand'          => __( 'Random', 'newstheme' ),
				'title'         => __( 'Title (A–Z)', 'newstheme' ),
			),
			'show_if' => $not_posts,
		),
	);
}

/**
 * Sanitize a list of blocks for storage.
 *
 * @param mixed    $value   Raw value.
 * @param string[] $allowed Allowed block types.
 * @return array[]
 */
function newstheme_sanitize_blocks( $value, array $allowed ) {
	$clean = array();
	foreach ( array_slice( is_array( $value ) ? array_values( $value ) : array(), 0, 20 ) as $item ) {
		$type = is_array( $item ) ? ( $item['type'] ?? '' ) : '';
		if ( ! in_array( $type, $allowed, true ) ) {
			continue;
		}
		$args = newstheme_block_args( $type, $item );
		if ( 'ad' === $type && ! current_user_can( 'unfiltered_html' ) ) {
			$args['html'] = wp_kses_post( $args['html'] );
		}
		$clean[] = array( 'type' => $type ) + $args;
	}
	return $clean;
}
