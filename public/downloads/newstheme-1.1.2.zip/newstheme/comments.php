<?php
/**
 * Comments.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

if ( post_password_required() ) {
	return;
}
?>
<section id="comments" class="nt-card-box nt-comments">
	<?php if ( have_comments() ) : ?>
		<h2 class="nt-block-title nt-comments__title"><span>
			<?php
			$newstheme_count = (int) get_comments_number();
			/* translators: %d: number of comments. */
			echo esc_html( sprintf( _n( '%d Comment', '%d Comments', $newstheme_count, 'newstheme' ), $newstheme_count ) );
			?>
		</span></h2>
		<ol class="nt-comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 48,
				)
			);
			?>
		</ol>
		<?php the_comments_navigation(); ?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p class="nt-empty"><?php esc_html_e( 'Comments are closed.', 'newstheme' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'title_reply'        => esc_html__( 'Leave a Reply', 'newstheme' ),
			'title_reply_before' => '<h2 id="reply-title" class="nt-comments__reply-title">',
			'title_reply_after'  => '</h2>',
			'class_submit'       => 'nt-button',
		)
	);
	?>
</section>
