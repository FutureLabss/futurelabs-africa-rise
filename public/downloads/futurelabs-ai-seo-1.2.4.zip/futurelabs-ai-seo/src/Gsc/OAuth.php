<?php
/**
 * Google Search Console OAuth 2.0 connection.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Gsc;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Crypto;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;

defined( 'ABSPATH' ) || exit;

/**
 * Authorization, encrypted token storage, refresh and revocation.
 *
 * Tokens are stored only through Crypto in `flseo_gsc_token` and are never returned or logged.
 */
class OAuth implements Module {

	public const TOKEN_OPTION    = 'flseo_gsc_token';
	public const PROPERTY_OPTION = 'flseo_gsc_property';
	public const CLIENT_ID       = 'flseo_gsc_client_id';
	public const CLIENT_SECRET   = 'flseo_gsc_client_secret';

	public const AUTH_URL   = 'https://accounts.google.com/o/oauth2/v2/auth';
	public const TOKEN_URL  = 'https://oauth2.googleapis.com/token';
	public const REVOKE_URL = 'https://oauth2.googleapis.com/revoke';
	public const SCOPES     = 'https://www.googleapis.com/auth/webmasters.readonly https://www.googleapis.com/auth/webmasters';

	private const STATE_PREFIX = 'flseo_gsc_state_';
	private const STATE_TTL    = 10 * MINUTE_IN_SECONDS;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Decrypted token cache for this request.
	 *
	 * @var array<string, mixed>|null
	 */
	private ?array $token = null;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'admin_post_flseo_gsc_start', array( $this, 'start' ) );
		add_action( 'admin_post_flseo_gsc_callback', array( $this, 'callback' ) );
	}

	/**
	 * OAuth redirect URI registered in the Google Cloud console.
	 */
	public static function redirect_uri(): string {
		return admin_url( 'admin-post.php?action=flseo_gsc_callback' );
	}

	/**
	 * Whether a client id and secret are saved.
	 */
	public function has_client(): bool {
		$crypto = $this->c->get( Crypto::class );
		return $crypto->has_secret( self::CLIENT_ID ) && $crypto->has_secret( self::CLIENT_SECRET );
	}

	/**
	 * Build the Google consent URL with a state value bound to the current user.
	 *
	 * @return string|\WP_Error
	 */
	public function authorization_url() {
		if ( ! $this->has_client() ) {
			return new \WP_Error( 'flseo_gsc_no_client', __( 'Add a Google OAuth client ID and client secret in Settings first.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$state = wp_generate_password( 40, false, false );
		set_transient( self::STATE_PREFIX . hash( 'sha256', $state ), get_current_user_id(), self::STATE_TTL );
		return add_query_arg(
			array(
				'client_id'              => rawurlencode( $this->c->get( Crypto::class )->get_secret( self::CLIENT_ID ) ),
				'redirect_uri'           => rawurlencode( self::redirect_uri() ),
				'response_type'          => 'code',
				'scope'                  => rawurlencode( self::SCOPES ),
				'access_type'            => 'offline',
				'prompt'                 => 'consent',
				'include_granted_scopes' => 'true',
				'state'                  => $state,
			),
			self::AUTH_URL
		);
	}

	/**
	 * Handler for admin-post: send the administrator to Google.
	 */
	public function start(): void {
		if ( ! Capabilities::can( Capabilities::SETTINGS ) ) {
			wp_die( esc_html__( 'You do not have permission to connect Search Console.', 'futurelabs-ai-seo' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'flseo_gsc_start' );
		$url = $this->authorization_url();
		if ( is_wp_error( $url ) ) {
			wp_die( esc_html( $url->get_error_message() ) );
		}
		wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Google consent screen is external by design.
		exit;
	}

	/**
	 * Handler for admin-post: Google redirects back here with code and state.
	 */
	public function callback(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The OAuth state transient bound to the user replaces the nonce.
		$query  = wp_unslash( $_GET );
		$result = $this->handle_callback( is_array( $query ) ? $query : array() );
		$target = is_wp_error( $result )
			? 'admin.php?page=futurelabs-ai-seo#/settings?gsc=error&reason=' . rawurlencode( str_replace( 'flseo_gsc_', '', (string) $result->get_error_code() ) )
			: 'admin.php?page=futurelabs-ai-seo#/settings?gsc=connected';
		wp_safe_redirect( admin_url( $target ) );
		exit;
	}

	/**
	 * Validate state and exchange the authorization code for tokens.
	 *
	 * @param array<string, mixed> $query Callback query parameters.
	 * @return true|\WP_Error
	 */
	public function handle_callback( array $query ) {
		$state = sanitize_text_field( (string) ( $query['state'] ?? '' ) );
		$key   = self::STATE_PREFIX . hash( 'sha256', $state );
		$owner = '' === $state ? false : get_transient( $key );
		if ( '' !== $state ) {
			delete_transient( $key );
		}
		if ( false === $owner || ! is_user_logged_in() || get_current_user_id() !== (int) $owner || ! Capabilities::can( Capabilities::SETTINGS ) ) {
			return new \WP_Error( 'flseo_gsc_state', __( 'The Search Console authorization link expired or was started by another user. Please try connecting again.', 'futurelabs-ai-seo' ) );
		}
		if ( ! empty( $query['error'] ) ) {
			return new \WP_Error( 'flseo_gsc_denied', __( 'Google did not grant access to Search Console.', 'futurelabs-ai-seo' ) );
		}
		$code = sanitize_text_field( (string) ( $query['code'] ?? '' ) );
		if ( '' === $code ) {
			return new \WP_Error( 'flseo_gsc_no_code', __( 'Google did not return an authorization code.', 'futurelabs-ai-seo' ) );
		}
		$crypto = $this->c->get( Crypto::class );
		$token  = $this->token_request(
			array(
				'code'          => $code,
				'client_id'     => $crypto->get_secret( self::CLIENT_ID ),
				'client_secret' => $crypto->get_secret( self::CLIENT_SECRET ),
				'redirect_uri'  => self::redirect_uri(),
				'grant_type'    => 'authorization_code',
			)
		);
		if ( is_wp_error( $token ) ) {
			$this->c->get( Logger::class )->error( 'Search Console token exchange failed.', array( 'error' => $token->get_error_code() ) );
			return new \WP_Error( 'flseo_gsc_exchange', __( 'Google token exchange failed. Check the OAuth client ID, secret and redirect URI, then try again.', 'futurelabs-ai-seo' ) );
		}
		if ( empty( $token['refresh_token'] ) ) {
			// Google omits the refresh token on re-consent; keep the existing one.
			$token['refresh_token'] = (string) ( $this->token()['refresh_token'] ?? '' );
		}
		if ( ! $this->store_token( $token ) ) {
			return new \WP_Error( 'flseo_gsc_storage', __( 'The Search Console token could not be stored securely (libsodium is required).', 'futurelabs-ai-seo' ) );
		}
		$this->c->get( Logger::class )->info( 'Search Console connected.', array( 'user' => get_current_user_id() ) );
		/**
		 * Fires after Search Console was connected.
		 */
		do_action( 'flseo_gsc_connected' );
		return true;
	}

	/**
	 * Whether Search Console is connected (a refresh token is stored).
	 */
	public function is_connected(): bool {
		return '' !== (string) ( $this->token()['refresh_token'] ?? '' );
	}

	/**
	 * Selected Search Console property (`sc-domain:example.com` or a URL prefix).
	 */
	public function property(): string {
		return (string) get_option( self::PROPERTY_OPTION, '' );
	}

	/**
	 * Save the selected property.
	 *
	 * @param string $property Property identifier.
	 */
	public function set_property( string $property ): void {
		update_option( self::PROPERTY_OPTION, $property, false );
	}

	/**
	 * Whether the service is connected and a property is selected.
	 */
	public function ready(): bool {
		return $this->is_connected() && '' !== $this->property();
	}

	/**
	 * A valid access token, refreshing it when it expires within 60 seconds.
	 *
	 * @param bool $force Refresh even if the current token looks valid.
	 * @return string|\WP_Error
	 */
	public function access_token( bool $force = false ) {
		$token = $this->token();
		if ( empty( $token['refresh_token'] ) ) {
			return new \WP_Error( 'flseo_gsc_not_connected', __( 'Search Console is not connected.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( ! $force && ! empty( $token['access_token'] ) && (int) ( $token['expires_at'] ?? 0 ) > time() + 60 ) {
			return (string) $token['access_token'];
		}
		return $this->refresh();
	}

	/**
	 * Exchange the refresh token for a new access token.
	 *
	 * @return string|\WP_Error
	 */
	public function refresh() {
		$token  = $this->token();
		$crypto = $this->c->get( Crypto::class );
		$fresh  = $this->token_request(
			array(
				'client_id'     => $crypto->get_secret( self::CLIENT_ID ),
				'client_secret' => $crypto->get_secret( self::CLIENT_SECRET ),
				'refresh_token' => (string) ( $token['refresh_token'] ?? '' ),
				'grant_type'    => 'refresh_token',
			)
		);
		if ( is_wp_error( $fresh ) ) {
			if ( 'invalid_grant' === ( $fresh->get_error_data()['oauth_error'] ?? '' ) ) {
				// The grant was revoked or expired at Google; the stored token can never work again.
				$this->clear_local();
				$this->c->get( Logger::class )->warning( 'Search Console access was revoked at Google. Reconnect to continue.' );
				return new \WP_Error( 'flseo_gsc_not_connected', __( 'Search Console access was revoked. Please reconnect.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
			}
			$this->c->get( Logger::class )->warning( 'Search Console token refresh failed.', array( 'error' => $fresh->get_error_code() ) );
			return $fresh;
		}
		$this->store_token( array_merge( $token, $fresh ) );
		return (string) $fresh['access_token'];
	}

	/**
	 * Revoke the grant at Google (best effort) and always clear local credentials.
	 *
	 * @return array{disconnected: bool, revoked: bool}
	 */
	public function disconnect(): array {
		$token      = $this->token();
		$credential = (string) ( $token['refresh_token'] ?? ( $token['access_token'] ?? '' ) );
		$revoked    = false;
		if ( '' !== $credential ) {
			$response = wp_remote_post(
				self::REVOKE_URL,
				array(
					'timeout' => 10,
					'body'    => array( 'token' => $credential ),
				)
			);
			$revoked  = ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response );
		}
		$this->clear_local();
		delete_option( self::PROPERTY_OPTION );
		$queue = $this->c->get( Queue::class );
		foreach ( array( 'flseo_inspection_queue', 'flseo_inspect_url', 'flseo_submit_sitemap', 'flseo_sync_analytics' ) as $hook ) {
			$queue->cancel( $hook );
		}
		$this->c->get( Logger::class )->info( 'Search Console disconnected.', array( 'revoked_at_google' => $revoked ) );
		/**
		 * Fires after Search Console was disconnected.
		 */
		do_action( 'flseo_gsc_disconnected' );
		return array(
			'disconnected' => true,
			'revoked'      => $revoked,
		);
	}

	/**
	 * Expiry timestamp of the current access token (0 when none). Not a secret.
	 */
	public function expires_at(): int {
		return (int) ( $this->token()['expires_at'] ?? 0 );
	}

	/**
	 * Encrypt and store a token response.
	 *
	 * @param array<string, mixed> $token Token data from Google.
	 */
	public function store_token( array $token ): bool {
		$data        = array(
			'access_token'  => (string) ( $token['access_token'] ?? '' ),
			'refresh_token' => (string) ( $token['refresh_token'] ?? '' ),
			'expires_at'    => isset( $token['expires_in'] ) ? time() + (int) $token['expires_in'] : (int) ( $token['expires_at'] ?? 0 ),
			'scope'         => (string) ( $token['scope'] ?? '' ),
		);
		$this->token = null;
		return $this->c->get( Crypto::class )->set_secret( self::TOKEN_OPTION, (string) wp_json_encode( $data ) );
	}

	/**
	 * Remove stored tokens.
	 */
	private function clear_local(): void {
		delete_option( self::TOKEN_OPTION );
		$this->token = null;
	}

	/**
	 * Decrypted token data.
	 *
	 * @return array<string, mixed>
	 */
	private function token(): array {
		if ( null === $this->token ) {
			$data        = json_decode( $this->c->get( Crypto::class )->get_secret( self::TOKEN_OPTION ), true );
			$this->token = is_array( $data ) ? $data : array();
		}
		return $this->token;
	}

	/**
	 * POST to the token endpoint.
	 *
	 * @param array<string, string> $body Form body.
	 * @return array<string, mixed>|\WP_Error Token response.
	 */
	private function token_request( array $body ) {
		$response = wp_remote_post(
			self::TOKEN_URL,
			array(
				'timeout' => 20,
				'body'    => $body,
			)
		);
		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'flseo_gsc_http', __( 'Could not reach Google.', 'futurelabs-ai-seo' ), array( 'status' => 502 ) );
		}
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code || ! is_array( $data ) || empty( $data['access_token'] ) ) {
			return new \WP_Error(
				'flseo_gsc_token',
				__( 'Google rejected the token request.', 'futurelabs-ai-seo' ),
				array(
					'status'      => 502,
					'oauth_error' => is_array( $data ) ? sanitize_key( (string) ( $data['error'] ?? '' ) ) : '',
				)
			);
		}
		return $data;
	}
}
