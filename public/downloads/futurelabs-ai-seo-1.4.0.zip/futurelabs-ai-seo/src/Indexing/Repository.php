<?php
/**
 * Read queries for the indexing dashboard.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Indexing;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Gsc\Analytics;
use FutureLabs\AISEO\Meta\CanonicalResolver;
use FutureLabs\AISEO\Sitemap\Builder;

defined( 'ABSPATH' ) || exit;

/**
 * Joins flseo_index_status with posts, content scan and link stats.
 *
 * "Known" pages are published, non-password posts of the post types included in the sitemap.
 */
class Repository {

	/**
	 * Sortable columns mapped to SQL expressions.
	 */
	private const SORTS = array(
		'title'        => 'p.post_title',
		'date'         => 'p.post_date_gmt',
		'modified'     => 'p.post_modified_gmt',
		'inspected_at' => 's.inspected_at',
		'last_crawl'   => 's.last_crawl',
		'indexed_at'   => 's.indexed_at',
		'reason'       => 's.reason_code',
		'priority'     => 's.priority',
		'words'        => 'cs.word_count',
		'inbound'      => 'ls.inbound',
	);

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Post types counted as known URLs.
	 *
	 * @return array<int, string>
	 */
	public function post_types(): array {
		return $this->c->get( Builder::class )->post_types();
	}

	/**
	 * SQL fragment restricting posts to known URLs, already prepared.
	 *
	 * @param array<int, string>|null $types Override types.
	 */
	private function known_where( ?array $types = null ): string {
		global $wpdb;
		$types = $types ?? $this->post_types();
		if ( ! $types ) {
			return '1=0';
		}
		$in = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		return (string) $wpdb->prepare( "p.post_status='publish' AND p.post_password='' AND p.post_type IN ($in)", $types );
	}

	/**
	 * Whether a plugin table has any rows.
	 *
	 * @param string $suffix Table suffix.
	 */
	private function has_rows( string $suffix ): bool {
		global $wpdb;
		$table = Migrations::table( $suffix );
		return (bool) $wpdb->get_var( "SELECT 1 FROM {$table} LIMIT 1" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Dashboard summary cards.
	 *
	 * @return array<string, mixed>
	 */
	public function summary(): array {
		global $wpdb;
		$s     = Migrations::table( 'index_status' );
		$where = $this->known_where();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$known  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} p WHERE {$where}" );
		$rows   = (array) $wpdb->get_results( "SELECT s.reason_code, COUNT(*) n FROM {$s} s INNER JOIN {$wpdb->posts} p ON p.ID=s.post_id WHERE {$where} AND s.inspected_at IS NOT NULL GROUP BY s.reason_code", ARRAY_A );
		$queued = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$s} s INNER JOIN {$wpdb->posts} p ON p.ID=s.post_id WHERE {$where} AND s.queued_at IS NOT NULL" );
		$last   = $wpdb->get_var( "SELECT MAX(s.inspected_at) FROM {$s} s INNER JOIN {$wpdb->posts} p ON p.ID=s.post_id WHERE {$where}" );
		// phpcs:enable
		$inspected = 0;
		$counts    = array();
		foreach ( $rows as $row ) {
			$code            = '' !== (string) $row['reason_code'] ? (string) $row['reason_code'] : Reasons::OTHER;
			$counts[ $code ] = ( $counts[ $code ] ?? 0 ) + (int) $row['n'];
			$inspected      += (int) $row['n'];
		}
		$indexed = (int) ( $counts[ Reasons::INDEXED ] ?? 0 );
		$reasons = array();
		foreach ( $counts as $code => $count ) {
			$reasons[] = array(
				'code'       => $code,
				'label'      => Reasons::label( $code ),
				'count'      => $count,
				'actionable' => Reasons::actionable( $code ),
			);
		}
		if ( $known > $inspected ) {
			$reasons[] = array(
				'code'       => Reasons::NOT_INSPECTED,
				'label'      => Reasons::label( Reasons::NOT_INSPECTED ),
				'count'      => $known - $inspected,
				'actionable' => false,
			);
		}
		usort(
			$reasons,
			static function ( array $a, array $b ): int {
				return $b['count'] <=> $a['count'];
			}
		);
		return array(
			'known'                     => $known,
			'inspected'                 => $inspected,
			'not_inspected'             => max( 0, $known - $inspected ),
			'indexed'                   => $indexed,
			'not_indexed'               => $inspected - $indexed,
			'indexed_percent'           => $known > 0 ? round( $indexed / $known * 100, 1 ) : 0.0,
			'indexed_percent_inspected' => $inspected > 0 ? round( $indexed / $inspected * 100, 1 ) : 0.0,
			'queued'                    => $queued,
			'last_inspected_at'         => self::rfc( (string) $last ),
			'reasons'                   => $reasons,
		);
	}

	/**
	 * Filtered, paginated page list.
	 *
	 * @param array<string, mixed> $filters reason, post_type, in_sitemap, min_words, max_words, min_inbound, max_inbound, author, search, orderby, order, page, per_page.
	 * @return array{items: array<int, array<string, mixed>>, total: int, page: int, per_page: int, word_counts_available: bool}
	 */
	public function pages( array $filters ): array {
		global $wpdb;
		$s     = Migrations::table( 'index_status' );
		$cs    = Migrations::table( 'content_scan' );
		$ls    = Migrations::table( 'link_stats' );
		$words = $this->has_rows( 'content_scan' );
		$types = $this->post_types();
		if ( ! empty( $filters['post_type'] ) ) {
			$types = array_values( array_intersect( $types, array( sanitize_key( (string) $filters['post_type'] ) ) ) );
		}
		$where = array( $this->known_where( $types ) );

		$reason = sanitize_key( (string) ( $filters['reason'] ?? '' ) );
		if ( Reasons::NOT_INSPECTED === $reason ) {
			$where[] = 's.inspected_at IS NULL';
		} elseif ( 'not_indexed' === $reason ) {
			$where[] = $wpdb->prepare( 's.inspected_at IS NOT NULL AND s.reason_code<>%s', Reasons::INDEXED );
		} elseif ( '' !== $reason ) {
			$where[] = $wpdb->prepare( 's.inspected_at IS NOT NULL AND s.reason_code=%s', $reason );
		}
		if ( isset( $filters['in_sitemap'] ) && '' !== (string) $filters['in_sitemap'] ) {
			$where[] = Settings::to_bool( $filters['in_sitemap'] ) ? 's.in_sitemap=1' : '(s.in_sitemap IS NULL OR s.in_sitemap=0)';
		}
		if ( $words ) {
			if ( isset( $filters['min_words'] ) && '' !== (string) $filters['min_words'] ) {
				$where[] = $wpdb->prepare( 'cs.word_count>=%d', absint( $filters['min_words'] ) );
			}
			if ( isset( $filters['max_words'] ) && '' !== (string) $filters['max_words'] ) {
				$where[] = $wpdb->prepare( 'cs.word_count<=%d', absint( $filters['max_words'] ) );
			}
		}
		if ( isset( $filters['min_inbound'] ) && '' !== (string) $filters['min_inbound'] ) {
			$where[] = $wpdb->prepare( 'COALESCE(ls.inbound,0)>=%d', absint( $filters['min_inbound'] ) );
		}
		if ( isset( $filters['max_inbound'] ) && '' !== (string) $filters['max_inbound'] ) {
			$where[] = $wpdb->prepare( 'COALESCE(ls.inbound,0)<=%d', absint( $filters['max_inbound'] ) );
		}
		if ( ! empty( $filters['author'] ) ) {
			$where[] = $wpdb->prepare( 'p.post_author=%d', absint( $filters['author'] ) );
		}
		$search = trim( sanitize_text_field( (string) ( $filters['search'] ?? '' ) ) );
		if ( '' !== $search ) {
			$like    = '%' . $wpdb->esc_like( $search ) . '%';
			$where[] = $wpdb->prepare( '(p.post_title LIKE %s OR s.url LIKE %s OR p.post_name LIKE %s)', $like, $like, $like );
		}

		$orderby  = (string) ( $filters['orderby'] ?? 'date' );
		$sort     = self::SORTS[ $orderby ] ?? self::SORTS['date'];
		$order    = 'asc' === strtolower( (string) ( $filters['order'] ?? 'desc' ) ) ? 'ASC' : 'DESC';
		$page     = max( 1, absint( $filters['page'] ?? 1 ) );
		$per_page = min( 100, max( 1, absint( $filters['per_page'] ?? 50 ) ) );
		$offset   = ( $page - 1 ) * $per_page;

		$from = "{$wpdb->posts} p LEFT JOIN {$s} s ON s.post_id=p.ID LEFT JOIN {$cs} cs ON cs.post_id=p.ID LEFT JOIN {$ls} ls ON ls.post_id=p.ID";
		$sql  = implode( ' AND ', $where );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$from} WHERE {$sql}" );
		$rows  = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID, p.post_title, p.post_type, p.post_author, p.post_date_gmt, p.post_modified_gmt, s.url, s.verdict, s.reason_code, s.coverage_state, s.in_sitemap, s.inspected_at, s.last_crawl, s.indexed_at, s.published_at, s.queued_at, s.google_canonical, s.user_canonical, cs.word_count, ls.inbound
				FROM {$from} WHERE {$sql} ORDER BY {$sort} {$order}, p.ID DESC LIMIT %d OFFSET %d",
				$per_page,
				$offset
			),
			ARRAY_A
		);
		// phpcs:enable
		$items = array();
		foreach ( $rows as $row ) {
			$items[] = $this->format_row( $row, $words );
		}
		return array(
			'items'                 => $items,
			'total'                 => $total,
			'page'                  => $page,
			'per_page'              => $per_page,
			'word_counts_available' => $words,
		);
	}

	/**
	 * Shape one list row.
	 *
	 * @param array<string, mixed> $row   DB row.
	 * @param bool                 $words Whether word counts exist.
	 * @return array<string, mixed>
	 */
	private function format_row( array $row, bool $words ): array {
		$id        = (int) $row['ID'];
		$inspected = ! empty( $row['inspected_at'] );
		$reason    = $inspected ? ( (string) $row['reason_code'] ?: Reasons::OTHER ) : Reasons::NOT_INSPECTED;
		$author    = get_userdata( (int) $row['post_author'] );
		return array(
			'id'             => $id,
			'title'          => html_entity_decode( (string) $row['post_title'], ENT_QUOTES, 'UTF-8' ),
			'url'            => ! empty( $row['url'] ) ? (string) $row['url'] : (string) get_permalink( $id ),
			'post_type'      => (string) $row['post_type'],
			'author'         => array(
				'id'   => (int) $row['post_author'],
				'name' => $author ? $author->display_name : '',
			),
			'published_at'   => self::rfc( (string) ( $row['published_at'] ?: $row['post_date_gmt'] ) ),
			'modified_at'    => self::rfc( (string) $row['post_modified_gmt'] ),
			'verdict'        => $inspected ? (string) $row['verdict'] : null,
			'reason_code'    => $reason,
			'reason_label'   => Reasons::label( $reason ),
			'coverage_state' => (string) ( $row['coverage_state'] ?? '' ),
			'in_sitemap'     => null === $row['in_sitemap'] ? $this->live_in_sitemap( $id ) : (bool) $row['in_sitemap'],
			'inspected_at'   => self::rfc( (string) $row['inspected_at'] ),
			'last_crawl'     => self::rfc( (string) $row['last_crawl'] ),
			'indexed_at'     => self::rfc( (string) $row['indexed_at'] ),
			'days_to_index'  => self::days_between( (string) ( $row['published_at'] ?: $row['post_date_gmt'] ), (string) $row['indexed_at'] ),
			'queued'         => ! empty( $row['queued_at'] ),
			'word_count'     => $words && null !== $row['word_count'] ? (int) $row['word_count'] : null,
			'inbound'        => null !== $row['inbound'] ? (int) $row['inbound'] : null,
		);
	}

	/**
	 * Sitemap membership for a post that has no status row yet (not queued or inspected).
	 *
	 * @param int $post_id Post ID.
	 */
	private function live_in_sitemap( int $post_id ): ?bool {
		$post = get_post( $post_id );
		return $post instanceof \WP_Post ? $this->c->get( \FutureLabs\AISEO\Gsc\Inspector::class )->in_sitemap( $post ) : null;
	}

	/**
	 * Per-page detail including Google vs declared canonical.
	 *
	 * @param int $post_id Post id.
	 * @return array<string, mixed>|null
	 */
	public function detail( int $post_id ): ?array {
		global $wpdb;
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status ) {
			return null;
		}
		$s  = Migrations::table( 'index_status' );
		$cs = Migrations::table( 'content_scan' );
		$ls = Migrations::table( 'link_stats' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT p.ID, p.post_title, p.post_type, p.post_author, p.post_date_gmt, p.post_modified_gmt, s.url, s.verdict, s.reason_code, s.coverage_state, s.in_sitemap, s.inspected_at, s.last_crawl, s.indexed_at, s.published_at, s.queued_at, s.google_canonical, s.user_canonical, s.robots_state, s.page_fetch_state, cs.word_count, ls.inbound FROM {$wpdb->posts} p LEFT JOIN {$s} s ON s.post_id=p.ID LEFT JOIN {$cs} cs ON cs.post_id=p.ID LEFT JOIN {$ls} ls ON ls.post_id=p.ID WHERE p.ID=%d ORDER BY s.id DESC LIMIT 1", $post_id ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return null;
		}
		$item     = $this->format_row( $row, $this->has_rows( 'content_scan' ) );
		$declared = '';
		try {
			$declared = $this->c->get( CanonicalResolver::class )->for_post( $post );
		} catch ( \Throwable $e ) {
			$declared = (string) get_permalink( $post );
		}
		$google                   = (string) ( $row['google_canonical'] ?? '' );
		$item['fix']              = Reasons::fix( $item['reason_code'] );
		$item['robots_state']     = (string) ( $row['robots_state'] ?? '' );
		$item['page_fetch_state'] = (string) ( $row['page_fetch_state'] ?? '' );
		$item['canonical']        = array(
			'declared'            => $declared,
			'google'              => $google,
			'user_seen_by_google' => (string) ( $row['user_canonical'] ?? '' ),
			'matches'             => '' === $google ? null : CanonicalResolver::same_url( $declared, $google ),
		);
		$item['search_analytics'] = $this->analytics_for( $item['url'] );
		return $item;
	}

	/**
	 * Top queries for a URL from the latest synced current-28-day range.
	 *
	 * @param string $url URL.
	 * @return array{range: string, clicks: int, impressions: int, queries: array<int, array<string, mixed>>}|null
	 */
	private function analytics_for( string $url ): ?array {
		global $wpdb;
		$ranges = $this->c->get( Analytics::class )->latest_ranges();
		if ( empty( $ranges['current'] ) ) {
			return null;
		}
		$table = Migrations::table( 'gsc_queries' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows   = (array) $wpdb->get_results( $wpdb->prepare( "SELECT query, clicks, impressions, position FROM {$table} WHERE url_hash=%s AND date_range=%s ORDER BY impressions DESC LIMIT 200", hash( 'sha256', $url ), $ranges['current'] ), ARRAY_A );
		$clicks = 0;
		$impr   = 0;
		$top    = array();
		foreach ( $rows as $i => $row ) {
			$clicks += (int) $row['clicks'];
			$impr   += (int) $row['impressions'];
			if ( $i < 10 ) {
				$top[] = array(
					'query'       => (string) $row['query'],
					'clicks'      => (int) $row['clicks'],
					'impressions' => (int) $row['impressions'],
					'position'    => round( (float) $row['position'], 1 ),
				);
			}
		}
		return array(
			'range'       => (string) $ranges['current'],
			'clicks'      => $clicks,
			'impressions' => $impr,
			'queries'     => $top,
		);
	}

	/**
	 * OL-5: indexed rate per author.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function authors(): array {
		global $wpdb;
		$s     = Migrations::table( 'index_status' );
		$where = $this->known_where();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.post_author, COUNT(*) known, SUM(s.inspected_at IS NOT NULL) inspected, SUM(s.inspected_at IS NOT NULL AND s.reason_code=%s) indexed,
				AVG(CASE WHEN s.indexed_at IS NOT NULL THEN TIMESTAMPDIFF(HOUR, COALESCE(s.published_at, p.post_date_gmt), s.indexed_at) END) avg_hours
				FROM {$wpdb->posts} p LEFT JOIN {$s} s ON s.post_id=p.ID WHERE {$where} GROUP BY p.post_author ORDER BY known DESC",
				Reasons::INDEXED
			),
			ARRAY_A
		);
		// phpcs:enable
		$out = array();
		foreach ( $rows as $row ) {
			$user      = get_userdata( (int) $row['post_author'] );
			$inspected = (int) $row['inspected'];
			$indexed   = (int) $row['indexed'];
			$out[]     = array(
				'author_id'         => (int) $row['post_author'],
				'name'              => $user ? $user->display_name : __( 'Unknown author', 'futurelabs-ai-seo' ),
				'known'             => (int) $row['known'],
				'inspected'         => $inspected,
				'indexed'           => $indexed,
				'indexed_rate'      => $inspected > 0 ? round( $indexed / $inspected * 100, 1 ) : null,
				'avg_days_to_index' => null !== $row['avg_hours'] ? round( max( 0, (float) $row['avg_hours'] ) / 24, 1 ) : null,
			);
		}
		return $out;
	}

	/**
	 * OL-10: posts still not indexed N days after publishing, with reason and fix.
	 *
	 * @param int $min_days Days since publishing (default 7).
	 * @param int $max_days Ignore posts older than this (default 90).
	 * @param int $limit    Max items.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function unindexed_after( int $min_days = 7, int $max_days = 90, int $limit = 100 ): array {
		global $wpdb;
		$s      = Migrations::table( 'index_status' );
		$where  = $this->known_where();
		$newest = gmdate( 'Y-m-d H:i:s', time() - $min_days * DAY_IN_SECONDS );
		$oldest = gmdate( 'Y-m-d H:i:s', time() - $max_days * DAY_IN_SECONDS );
		$cond   = $wpdb->prepare( 'COALESCE(s.published_at, p.post_date_gmt)<=%s AND COALESCE(s.published_at, p.post_date_gmt)>=%s AND (s.reason_code IS NULL OR s.inspected_at IS NULL OR s.reason_code<>%s)', $newest, $oldest, Reasons::INDEXED );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} p LEFT JOIN {$s} s ON s.post_id=p.ID WHERE {$where} AND {$cond}" );
		$rows  = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID, p.post_title, p.post_type, p.post_author, p.post_date_gmt, s.url, s.reason_code, s.inspected_at, s.published_at, s.queued_at
				FROM {$wpdb->posts} p LEFT JOIN {$s} s ON s.post_id=p.ID WHERE {$where} AND {$cond} ORDER BY COALESCE(s.published_at, p.post_date_gmt) ASC LIMIT %d",
				max( 1, $limit )
			),
			ARRAY_A
		);
		// phpcs:enable
		$items = array();
		foreach ( $rows as $row ) {
			$reason    = ! empty( $row['inspected_at'] ) ? ( (string) $row['reason_code'] ?: Reasons::OTHER ) : Reasons::NOT_INSPECTED;
			$published = (string) ( $row['published_at'] ?: $row['post_date_gmt'] );
			$items[]   = array(
				'id'             => (int) $row['ID'],
				'title'          => html_entity_decode( (string) $row['post_title'], ENT_QUOTES, 'UTF-8' ),
				'url'            => ! empty( $row['url'] ) ? (string) $row['url'] : (string) get_permalink( (int) $row['ID'] ),
				'post_type'      => (string) $row['post_type'],
				'author_id'      => (int) $row['post_author'],
				'published_at'   => self::rfc( $published ),
				'days_published' => (int) floor( ( time() - (int) strtotime( $published . ' UTC' ) ) / DAY_IN_SECONDS ),
				'reason_code'    => $reason,
				'reason_label'   => Reasons::label( $reason ),
				'fix'            => Reasons::fix( $reason ),
				'inspected_at'   => self::rfc( (string) $row['inspected_at'] ),
				'queued'         => ! empty( $row['queued_at'] ),
			);
		}
		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Days from publish to first indexed verdict for one post, or null when not indexed yet.
	 *
	 * @param int $post_id Post id.
	 */
	public function days_to_index( int $post_id ): ?float {
		global $wpdb;
		$s = Migrations::table( 'index_status' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT COALESCE(s.published_at, p.post_date_gmt) published, s.indexed_at FROM {$wpdb->posts} p INNER JOIN {$s} s ON s.post_id=p.ID WHERE p.ID=%d ORDER BY s.id DESC LIMIT 1", $post_id ), ARRAY_A );
		return is_array( $row ) ? self::days_between( (string) $row['published'], (string) $row['indexed_at'] ) : null;
	}

	/**
	 * Days between two MySQL UTC datetimes, one decimal.
	 *
	 * @param string $from Start.
	 * @param string $to   End.
	 */
	private static function days_between( string $from, string $to ): ?float {
		if ( '' === $from || '' === $to || str_starts_with( $from, '0000' ) ) {
			return null;
		}
		$a = strtotime( $from . ' UTC' );
		$b = strtotime( $to . ' UTC' );
		return ( $a && $b ) ? round( max( 0, $b - $a ) / DAY_IN_SECONDS, 1 ) : null;
	}

	/**
	 * MySQL UTC datetime to RFC 3339, or null.
	 *
	 * @param string $mysql Datetime.
	 */
	private static function rfc( string $mysql ): ?string {
		if ( '' === $mysql || str_starts_with( $mysql, '0000' ) ) {
			return null;
		}
		return gmdate( 'c', (int) strtotime( $mysql . ' UTC' ) );
	}
}
