<?php
/**
 * Suggests redirect targets for missing URLs by slug distance and title similarity.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Redirects;

use FutureLabs\AISEO\Core\Container;

defined( 'ABSPATH' ) || exit;

/**
 * Nearest published page for a 404 path.
 */
class Suggester {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Suggest targets.
	 *
	 * @param string $url   Missing URL or path.
	 * @param int    $limit Max suggestions.
	 * @return array<int, array{post_id: int, title: string, url: string, score: float}>
	 */
	public function suggest( string $url, int $limit = 5 ): array {
		$slug = self::slug_from( $url );
		if ( '' === $slug ) {
			return array();
		}
		$candidates = $this->candidates( $slug );
		$scored     = array();
		foreach ( $candidates as $row ) {
			$score = self::score( $slug, (string) $row->post_name, (string) $row->post_title );
			if ( $score >= 0.35 ) {
				$scored[] = array(
					'post_id' => (int) $row->ID,
					'title'   => (string) $row->post_title,
					'url'     => (string) get_permalink( (int) $row->ID ),
					'score'   => round( $score, 3 ),
				);
			}
		}
		usort( $scored, static fn( $a, $b ) => $b['score'] <=> $a['score'] );
		return array_slice( $scored, 0, $limit );
	}

	/**
	 * Last meaningful path segment, lowercased.
	 *
	 * @param string $url URL or path.
	 */
	public static function slug_from( string $url ): string {
		$path     = Rules::normalize_path( $url );
		$segments = array_values( array_filter( explode( '/', $path ), static fn( $s ) => '' !== $s && ! ctype_digit( $s ) && 'page' !== $s ) );
		$slug     = $segments ? (string) end( $segments ) : '';
		$slug     = (string) preg_replace( '/\.(html?|php)$/i', '', $slug );
		return strtolower( sanitize_title( $slug ) );
	}

	/**
	 * Similarity score in [0,1] combining slug edit distance and title word overlap.
	 *
	 * @param string $slug      Missing slug.
	 * @param string $post_name Candidate slug.
	 * @param string $title     Candidate title.
	 */
	public static function score( string $slug, string $post_name, string $title ): float {
		$a        = substr( $slug, 0, 255 );
		$b        = substr( strtolower( rawurldecode( $post_name ) ), 0, 255 );
		$longest  = max( strlen( $a ), strlen( $b ), 1 );
		$slug_sim = 1 - ( levenshtein( $a, $b ) / $longest );

		$words_a = self::words( str_replace( '-', ' ', $slug ) );
		$words_b = self::words( $title . ' ' . str_replace( '-', ' ', $b ) );
		$overlap = $words_a ? count( array_intersect( $words_a, $words_b ) ) / count( $words_a ) : 0;
		return max( $slug_sim, 0.4 * $slug_sim + 0.6 * $overlap );
	}

	/**
	 * Significant words.
	 *
	 * @param string $text Text.
	 * @return array<int, string>
	 */
	private static function words( string $text ): array {
		preg_match_all( '/[\p{L}\p{N}]{3,}/u', strtolower( remove_accents( $text ) ), $m );
		$stop = array( 'the', 'and', 'for', 'with', 'how', 'apply', 'from', 'your', 'this', 'that' );
		return array_values( array_unique( array_diff( $m[0], $stop ) ) );
	}

	/**
	 * Candidate posts: slug token matches plus recent posts, bounded for large sites.
	 *
	 * @param string $slug Missing slug.
	 * @return array<int, object>
	 */
	private function candidates( string $slug ): array {
		global $wpdb;
		$types = array_values( array_diff( get_post_types( array( 'public' => true ), 'names' ), array( 'attachment' ) ) );
		if ( ! $types ) {
			return array();
		}
		$in     = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$tokens = array_slice( array_filter( explode( '-', $slug ), static fn( $t ) => strlen( $t ) >= 4 && ! ctype_digit( $t ) ), 0, 4 );
		$rows   = array();
		if ( $tokens ) {
			$likes  = implode( ' OR ', array_fill( 0, count( $tokens ), 'post_name LIKE %s' ) );
			$params = array_merge( $types, array_map( static fn( $t ) => '%' . $wpdb->esc_like( $t ) . '%', $tokens ) );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_name, post_title FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ($in) AND ($likes) ORDER BY post_date DESC LIMIT 400", $params ) );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$recent = (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_name, post_title FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ($in) ORDER BY post_date DESC LIMIT 200", $types ) );
		$merged = array();
		foreach ( array_merge( $rows, $recent ) as $row ) {
			$merged[ (int) $row->ID ] = $row;
		}
		return array_values( $merged );
	}
}
