<?php
/**
 * Public read-only feed of open opportunities and their eligibility (optional feature).
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Opportunity;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Features;

defined( 'ABSPATH' ) || exit;

/**
 * Lists published, open opportunities in a machine-readable form so another service (such
 * as a reader-matching portal) can filter them without a WordPress login.
 *
 * Only facts readers already see on the post are included: title, link, excerpt, image,
 * deadline, status and the opportunity and eligibility fields. SEO fields, expiry settings
 * and password-protected posts are left out. The feed exists only while the eligibility
 * feature is on (which also needs opportunities), and can be switched off with the
 * `flseo_opportunity_feed_enabled` filter.
 */
class Feed {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Whether the feed is available.
	 */
	public function enabled(): bool {
		/**
		 * Filters whether the public opportunity feed is available.
		 *
		 * @param bool $enabled Whether it is on (defaults to the eligibility feature).
		 */
		return (bool) apply_filters( 'flseo_opportunity_feed_enabled', $this->c->get( Features::class )->enabled( Features::ELIGIBILITY ) );
	}

	/**
	 * One page of open opportunities, most recently modified first.
	 *
	 * Open means not closed, and either a deadline today or later or a rolling status.
	 *
	 * @param int    $page           Page number.
	 * @param int    $per_page       Items per page.
	 * @param string $modified_after Only posts modified after this GMT time (Y-m-d H:i:s), or ''.
	 * @return array{items: array<int, array<string, mixed>>, total: int, total_pages: int}
	 */
	public function page( int $page, int $per_page, string $modified_after = '' ): array {
		$args = array(
			'post_type'              => array_values( get_post_types( array( 'public' => true ) ) ),
			'post_status'            => 'publish',
			'has_password'           => false,
			'posts_per_page'         => $per_page,
			'paged'                  => $page,
			'orderby'                => 'modified',
			'order'                  => 'DESC',
			'ignore_sticky_posts'    => true,
			'update_post_term_cache' => true,
			'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'relation' => 'AND',
				array(
					'relation' => 'OR',
					array(
						'key'     => '_flseo_opp_status',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => '_flseo_opp_status',
						'value'   => 'closed',
						'compare' => '!=',
					),
				),
				array(
					'relation' => 'OR',
					array(
						'key'     => '_flseo_opp_deadline',
						'value'   => current_time( 'Y-m-d' ),
						'compare' => '>=',
						'type'    => 'DATE',
					),
					array(
						'key'   => '_flseo_opp_status',
						'value' => 'rolling',
					),
				),
			),
		);
		if ( '' !== $modified_after ) {
			$args['date_query'] = array(
				array(
					'column' => 'post_modified_gmt',
					'after'  => $modified_after,
				),
			);
		}
		$query = new \WP_Query( $args );
		return array(
			'items'       => array_map( array( $this, 'item' ), $query->posts ),
			'total'       => (int) $query->found_posts,
			'total_pages' => (int) $query->max_num_pages,
		);
	}

	/**
	 * Feed entry for one post.
	 *
	 * @param \WP_Post $post Post.
	 * @return array<string, mixed>
	 */
	public function item( \WP_Post $post ): array {
		$meta  = static fn( string $key ): string => (string) get_post_meta( $post->ID, '_flseo_' . $key, true );
		$list  = static fn( string $key ): array => '' === $meta( $key ) ? array() : explode( ',', $meta( $key ) );
		$int   = static fn( string $key ): ?int => '' === $meta( $key ) ? null : (int) $meta( $key );
		$value = static fn( string $key ): ?string => '' === $meta( $key ) ? null : $meta( $key );
		$image = get_the_post_thumbnail_url( $post, 'large' );
		return array(
			'id'          => $post->ID,
			'title'       => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
			'link'        => get_permalink( $post ),
			'excerpt'     => html_entity_decode( wp_strip_all_tags( get_the_excerpt( $post ) ), ENT_QUOTES, 'UTF-8' ),
			'image'       => $image ? $image : null,
			'categories'  => array_values( wp_list_pluck( get_the_category( $post->ID ), 'name' ) ),
			'published'   => get_post_time( 'c', true, $post ),
			'modified'    => get_post_modified_time( 'c', true, $post ),
			'opportunity' => array(
				'deadline'     => $value( 'opp_deadline' ),
				'status'       => $value( 'opp_status' ),
				'type'         => $value( 'opp_type' ),
				'format'       => $value( 'opp_format' ),
				'funding_type' => $value( 'opp_funding_type' ),
				'funding'      => $value( 'opp_funding' ),
				'level'        => $value( 'opp_level' ),
				'region'       => $value( 'opp_region' ),
				'source_url'   => $value( 'opp_source_url' ),
			),
			'eligibility' => array(
				'countries'      => $list( 'elig_countries' ),
				'country_basis'  => $value( 'elig_country_basis' ),
				'age_min'        => $int( 'elig_age_min' ),
				'age_max'        => $int( 'elig_age_max' ),
				'gender'         => $value( 'elig_gender' ),
				'levels'         => $list( 'elig_levels' ),
				'fields'         => array_values( array_filter( array_map( 'trim', $list( 'elig_fields' ) ) ) ),
				'experience_min' => $int( 'elig_experience_min' ),
				'business_stage' => $list( 'elig_business_stage' ),
			),
		);
	}
}
