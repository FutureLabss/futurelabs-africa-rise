<?php
/**
 * Integration with the NewsDesk theme (formerly NewsTheme).
 *
 * The theme shows opportunity deadline badges, a "Closing soon" block source and
 * breadcrumbs, but since NewsDesk 2.0.0 it no longer reads this plugin's data
 * itself (WordPress.org themes must not depend on a plugin's private data).
 * Instead it asks through three filters, answered here. The filters only exist
 * in NewsDesk, so this is inert with any other theme.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Integrations;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Features;
use FutureLabs\AISEO\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * NewsDesk theme filters.
 */
class NewsDesk implements Module {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_filter( 'newsdesk_opportunity', array( $this, 'opportunity' ), 10, 2 );
		add_filter( 'newsdesk_closing_soon_query_args', array( $this, 'closing_soon_query_args' ), 10, 2 );
		add_filter( 'newsdesk_breadcrumbs_html', array( $this, 'breadcrumbs_html' ) );
	}

	/**
	 * Deadline facts for a post's badge.
	 *
	 * @param mixed    $data Value from earlier filters (null when none).
	 * @param \WP_Post $post Post.
	 * @return mixed array{deadline: string, status: string} when the post has a deadline or is rolling.
	 */
	public function opportunity( $data, $post ) {
		if ( is_array( $data ) || ! $post instanceof \WP_Post || ! $this->c->get( Features::class )->enabled( Features::OPPORTUNITIES ) ) {
			return $data;
		}
		$deadline = (string) get_post_meta( $post->ID, '_flseo_opp_deadline', true );
		$status   = sanitize_key( (string) get_post_meta( $post->ID, '_flseo_opp_status', true ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $deadline ) ) {
			$deadline = '';
		}
		if ( '' === $deadline && 'rolling' !== $status ) {
			return $data;
		}
		return array(
			'deadline' => $deadline,
			'status'   => $status,
		);
	}

	/**
	 * WP_Query arguments for "Closing soon": open deadlines from today, soonest first.
	 *
	 * @param mixed                $query Value from earlier filters (null when none).
	 * @param array<string, mixed> $args  The block's own query arguments.
	 * @return mixed
	 */
	public function closing_soon_query_args( $query, $args ) {
		if ( is_array( $query ) || ! is_array( $args ) || ! $this->c->get( Features::class )->enabled( Features::OPPORTUNITIES ) ) {
			return $query;
		}
		unset( $args['offset'] );
		$args['meta_key']   = '_flseo_opp_deadline'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- the list is defined by its deadline.
		$args['meta_type']  = 'DATE';
		$args['orderby']    = 'meta_value';
		$args['order']      = 'ASC';
		$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- as above.
			array(
				'key'     => '_flseo_opp_deadline',
				'value'   => wp_date( 'Y-m-d' ),
				'compare' => '>=',
				'type'    => 'DATE',
			),
		);
		return $args;
	}

	/**
	 * Breadcrumbs matching the BreadcrumbList structured data, in the theme's markup.
	 *
	 * @param mixed $html Value from earlier filters (null to let the theme decide).
	 * @return mixed
	 */
	public function breadcrumbs_html( $html ) {
		if ( is_string( $html ) || ! function_exists( 'flseo_get_breadcrumbs' ) ) {
			return $html;
		}
		$trail = flseo_get_breadcrumbs( array( 'class' => 'nt-breadcrumbs' ) );
		return '' === $trail ? $html : $trail;
	}
}
