<?php
/**
 * Near-duplicate detection with 64-bit simhash, LSH banding and union-find grouping.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Content;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Links\Crawler;

defined( 'ABSPATH' ) || exit;

/**
 * Computes simhashes, finds pairs at or above the similarity threshold and groups them.
 *
 * Groups are stored in `flseo_content_scan.dup_group_id` as the smallest post ID in the
 * group; `dup_similarity` holds the post's best similarity to another member.
 */
class Duplicate {

	/**
	 * Number of LSH bands (8 bands of 8 bits). Any pair within 7 differing bits is
	 * guaranteed to share a band; pairs up to the threshold usually do.
	 */
	public const BANDS = 8;

	/**
	 * Posts with fewer words than this get no simhash (too little text to compare).
	 */
	public const MIN_WORDS = 20;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * 64-bit simhash (16 hex chars) over word 2-shingles of content words.
	 *
	 * @param string $text Plain text.
	 */
	public static function simhash( string $text ): string {
		$tokens = Crawler::tokens( $text );
		$count  = count( $tokens );
		if ( $count < 2 ) {
			return '';
		}
		$features = array();
		for ( $i = 0; $i < $count - 1; $i++ ) {
			$key              = $tokens[ $i ] . ' ' . $tokens[ $i + 1 ];
			$features[ $key ] = ( $features[ $key ] ?? 0 ) + 1;
		}
		$weights = array_fill( 0, 64, 0 );
		foreach ( $features as $feature => $weight ) {
			$weight = min( 4, $weight );
			$hex    = substr( md5( (string) $feature ), 0, 16 );
			$hi     = (int) hexdec( substr( $hex, 0, 8 ) );
			$lo     = (int) hexdec( substr( $hex, 8, 8 ) );
			for ( $bit = 0; $bit < 32; $bit++ ) {
				$weights[ $bit ]      += ( ( $hi >> ( 31 - $bit ) ) & 1 ) ? $weight : -$weight;
				$weights[ $bit + 32 ] += ( ( $lo >> ( 31 - $bit ) ) & 1 ) ? $weight : -$weight;
			}
		}
		$out = '';
		for ( $nibble = 0; $nibble < 16; $nibble++ ) {
			$value = 0;
			for ( $j = 0; $j < 4; $j++ ) {
				$value = ( $value << 1 ) | ( $weights[ $nibble * 4 + $j ] > 0 ? 1 : 0 );
			}
			$out .= dechex( $value );
		}
		return $out;
	}

	/**
	 * Hamming distance between two simhashes (64 when either is invalid).
	 *
	 * @param string $a Hash.
	 * @param string $b Hash.
	 */
	public static function hamming( string $a, string $b ): int {
		if ( 16 !== strlen( $a ) || 16 !== strlen( $b ) || ! ctype_xdigit( $a . $b ) ) {
			return 64;
		}
		$x = ( (int) hexdec( substr( $a, 0, 8 ) ) ) ^ ( (int) hexdec( substr( $b, 0, 8 ) ) );
		$y = ( (int) hexdec( substr( $a, 8, 8 ) ) ) ^ ( (int) hexdec( substr( $b, 8, 8 ) ) );
		return self::popcount( $x ) + self::popcount( $y );
	}

	/**
	 * Set bits in a 32-bit value.
	 *
	 * @param int $v Value.
	 */
	private static function popcount( int $v ): int {
		$v = $v - ( ( $v >> 1 ) & 0x55555555 );
		$v = ( $v & 0x33333333 ) + ( ( $v >> 2 ) & 0x33333333 );
		$v = ( $v + ( $v >> 4 ) ) & 0x0F0F0F0F;
		return (int) ( ( ( $v * 0x01010101 ) & 0xFFFFFFFF ) >> 24 );
	}

	/**
	 * Similarity percentage between two simhashes.
	 *
	 * @param string $a Hash.
	 * @param string $b Hash.
	 */
	public static function similarity( string $a, string $b ): int {
		return (int) round( ( 64 - self::hamming( $a, $b ) ) * 100 / 64 );
	}

	/**
	 * Configured threshold in percent.
	 */
	public function threshold(): int {
		return max( 50, min( 100, (int) $this->c->get( Settings::class )->get( 'duplicate_threshold', 80 ) ) );
	}

	/**
	 * The published post most similar to some text, when it's a near copy.
	 *
	 * Used by the publish gate, so it only flags close copies: at least 90% similar,
	 * or the configured threshold when that's higher.
	 *
	 * @param string $text    Plain text.
	 * @param int    $exclude Post ID to ignore (the post being checked).
	 * @return array{post_id: int, similarity: int}|null
	 */
	public function closest( string $text, int $exclude = 0 ): ?array {
		global $wpdb;
		$hash = self::simhash( $text );
		if ( '' === $hash ) {
			return null;
		}
		$table = Migrations::table( 'content_scan' );
		$width = (int) ( 16 / self::BANDS );
		$where = array();
		$args  = array();
		foreach ( range( 0, self::BANDS - 1 ) as $i ) {
			$where[] = 'SUBSTRING(s.simhash, %d, %d) = %s';
			array_push( $args, $i * $width + 1, $width, substr( $hash, $i * $width, $width ) );
		}
		$args[] = $exclude;
		$args[] = self::MIN_WORDS;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders,WordPress.DB.PreparedSQL.NotPrepared
		$candidates = $wpdb->get_results( $wpdb->prepare( "SELECT s.post_id, s.simhash FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND (" . implode( ' OR ', $where ) . ') AND s.post_id <> %d AND s.word_count >= %d LIMIT 5000', $args ) );
		$floor      = max( 90, $this->threshold() );
		$best       = null;
		foreach ( (array) $candidates as $candidate ) {
			$sim = self::similarity( $hash, (string) $candidate->simhash );
			if ( $sim >= $floor && ( ! $best || $sim > $best['similarity'] ) ) {
				$best = array(
					'post_id'    => (int) $candidate->post_id,
					'similarity' => $sim,
				);
			}
		}
		return $best;
	}

	/**
	 * LSH band keys for a hash.
	 *
	 * @param string $hash Simhash.
	 * @return array<int, string>
	 */
	public static function bands( string $hash ): array {
		$width = (int) ( 16 / self::BANDS );
		$out   = array();
		for ( $i = 0; $i < self::BANDS; $i++ ) {
			$out[] = $i . ':' . substr( $hash, $i * $width, $width );
		}
		return $out;
	}

	/**
	 * Group every scanned published post. Memory is O(posts); comparisons only
	 * happen inside LSH buckets, so large sites avoid the O(n²) pair scan.
	 *
	 * @return array{groups: int, grouped: int}
	 */
	public function compute_groups(): array {
		global $wpdb;
		$table     = Migrations::table( 'content_scan' );
		$threshold = $this->threshold();
		$hashes    = array();
		$last      = 0;
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT s.post_id, s.simhash FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.simhash <> '' AND s.word_count >= %d AND s.post_id > %d ORDER BY s.post_id ASC LIMIT 2000", self::MIN_WORDS, $last ) );
			foreach ( (array) $rows as $row ) {
				$hashes[ (int) $row->post_id ] = (string) $row->simhash;
				$last                          = (int) $row->post_id;
			}
		} while ( is_array( $rows ) && 2000 === count( $rows ) ); // phpcs:ignore Squiz.PHP.DisallowSizeFunctionsInLoops.Found -- size of the batch just fetched.

		$buckets = array();
		foreach ( $hashes as $id => $hash ) {
			foreach ( self::bands( $hash ) as $band ) {
				$buckets[ $band ][] = $id;
			}
		}
		$tree = array();
		$best = array();
		foreach ( $buckets as $members ) {
			$n = count( $members );
			if ( $n < 2 ) {
				continue;
			}
			for ( $i = 0; $i < $n; $i++ ) {
				$a = $members[ $i ];
				for ( $j = $i + 1; $j < $n; $j++ ) {
					$b = $members[ $j ];
					if ( isset( $best[ $a ], $best[ $b ] ) && self::find( $tree, $a ) === self::find( $tree, $b ) ) {
						continue;
					}
					$sim = self::similarity( $hashes[ $a ], $hashes[ $b ] );
					if ( $sim < $threshold ) {
						continue;
					}
					$best[ $a ] = max( $best[ $a ] ?? 0, $sim );
					$best[ $b ] = max( $best[ $b ] ?? 0, $sim );
					self::union( $tree, $a, $b );
				}
			}
		}
		unset( $buckets, $hashes );

		$groups = array();
		foreach ( array_keys( $best ) as $id ) {
			$groups[ self::find( $tree, $id ) ][] = $id;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$wpdb->query( "UPDATE {$table} SET dup_group_id = 0, dup_similarity = 0 WHERE dup_group_id <> 0 OR dup_similarity <> 0" );
		$grouped = 0;
		foreach ( $groups as $members ) {
			$group_id = min( $members );
			$grouped += count( $members );
			foreach ( array_chunk( $members, 500 ) as $chunk ) {
				$this->set_group( $chunk, $group_id );
			}
		}
		$by_similarity = array();
		foreach ( $best as $id => $sim ) {
			$by_similarity[ $sim ][] = $id;
		}
		foreach ( $by_similarity as $sim => $ids ) {
			foreach ( array_chunk( $ids, 500 ) as $chunk ) {
				$in = implode( ',', array_map( 'absint', $chunk ) );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
				$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET dup_similarity = %d WHERE post_id IN ({$in})", (int) $sim ) );
			}
		}
		return array(
			'groups'  => count( $groups ),
			'grouped' => $grouped,
		);
	}

	/**
	 * Update one post's group after a rescan without recomputing the whole site.
	 *
	 * @param int $post_id Post ID.
	 * @return array<int, int> Post IDs whose group membership may have changed.
	 */
	public function update_for_post( int $post_id ): array {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT post_id, simhash, word_count, dup_group_id FROM {$table} WHERE post_id = %d", $post_id ) );
		if ( ! $row ) {
			return array();
		}
		$old_group = (int) $row->dup_group_id;
		$affected  = $old_group ? array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$table} WHERE dup_group_id = %d", $old_group ) ) ) : array(); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$hash      = (string) $row->simhash;
		$matches   = array();
		if ( '' !== $hash && (int) $row->word_count >= self::MIN_WORDS && 'publish' === get_post_status( $post_id ) ) {
			$where = array();
			$args  = array();
			$width = (int) ( 16 / self::BANDS );
			foreach ( range( 0, self::BANDS - 1 ) as $i ) {
				$where[] = 'SUBSTRING(s.simhash, %d, %d) = %s';
				array_push( $args, $i * $width + 1, $width, substr( $hash, $i * $width, $width ) );
			}
			$args[] = $post_id;
			$args[] = self::MIN_WORDS;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders,WordPress.DB.PreparedSQL.NotPrepared
			$candidates = $wpdb->get_results( $wpdb->prepare( "SELECT s.post_id, s.simhash, s.dup_group_id FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND (" . implode( ' OR ', $where ) . ') AND s.post_id <> %d AND s.word_count >= %d LIMIT 5000', $args ) );
			$threshold  = $this->threshold();
			foreach ( (array) $candidates as $candidate ) {
				$sim = self::similarity( $hash, (string) $candidate->simhash );
				if ( $sim >= $threshold ) {
					$matches[ (int) $candidate->post_id ] = array( $sim, (int) $candidate->dup_group_id );
				}
			}
		}
		if ( ! $matches ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update(
				$table,
				array(
					'dup_group_id'   => 0,
					'dup_similarity' => 0,
				),
				array( 'post_id' => $post_id ),
				array( '%d', '%d' ),
				array( '%d' )
			);
			if ( $old_group ) {
				$this->repair_group( $old_group );
			}
			return array_values( array_unique( array_merge( $affected, array( $post_id ) ) ) );
		}
		$members = array( $post_id );
		$groups  = array();
		foreach ( $matches as $id => $match ) {
			$members[] = $id;
			if ( $match[1] ) {
				$groups[] = $match[1];
			}
		}
		$groups = array_unique( $groups );
		foreach ( $groups as $group ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$members = array_merge( $members, array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$table} WHERE dup_group_id = %d", $group ) ) ) );
		}
		$members  = array_values( array_unique( $members ) );
		$group_id = min( $members );
		$this->set_group( $members, $group_id );
		$best = max( array_column( $matches, 0 ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update( $table, array( 'dup_similarity' => $best ), array( 'post_id' => $post_id ), array( '%d' ), array( '%d' ) );
		foreach ( $matches as $id => $match ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET dup_similarity = GREATEST(dup_similarity, %d) WHERE post_id = %d", $match[0], $id ) );
		}
		if ( $old_group && ! in_array( $old_group, $groups, true ) && $old_group !== $group_id ) {
			$this->repair_group( $old_group );
		}
		return array_values( array_unique( array_merge( $affected, $members ) ) );
	}

	/**
	 * Re-label or dissolve a group after a member left it.
	 *
	 * @param int $group_id Old group id.
	 */
	private function repair_group( int $group_id ): void {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$members = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$table} WHERE dup_group_id = %d", $group_id ) ) );
		if ( count( $members ) < 2 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET dup_group_id = 0, dup_similarity = 0 WHERE dup_group_id = %d", $group_id ) );
			return;
		}
		$this->set_group( $members, min( $members ) );
	}

	/**
	 * Assign a group id.
	 *
	 * @param array<int, int> $ids      Post IDs.
	 * @param int             $group_id Group id.
	 */
	private function set_group( array $ids, int $group_id ): void {
		global $wpdb;
		if ( ! $ids ) {
			return;
		}
		$table = Migrations::table( 'content_scan' );
		$in    = implode( ',', array_map( 'absint', $ids ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET dup_group_id = %d WHERE post_id IN ({$in})", $group_id ) );
	}

	/**
	 * Union-find: root with path compression.
	 *
	 * @param array<int, int> $tree   Parent map.
	 * @param int             $x      Node.
	 */
	private static function find( array &$tree, int $x ): int {
		$root = $x;
		while ( isset( $tree[ $root ] ) && $tree[ $root ] !== $root ) {
			$root = $tree[ $root ];
		}
		while ( isset( $tree[ $x ] ) && $tree[ $x ] !== $root ) {
			$next       = $tree[ $x ];
			$tree[ $x ] = $root;
			$x          = $next;
		}
		return $root;
	}

	/**
	 * Union-find: merge (smaller id becomes the root).
	 *
	 * @param array<int, int> $tree   Parent map.
	 * @param int             $a      Node.
	 * @param int             $b      Node.
	 */
	private static function union( array &$tree, int $a, int $b ): void {
		$ra = self::find( $tree, $a );
		$rb = self::find( $tree, $b );
		if ( $ra === $rb ) {
			return;
		}
		if ( $ra < $rb ) {
			$tree[ $rb ] = $ra;
			$tree[ $ra ] = $ra;
		} else {
			$tree[ $ra ] = $rb;
			$tree[ $rb ] = $rb;
		}
	}

	/**
	 * Duplicate groups, largest first.
	 *
	 * @param int $page     Page.
	 * @param int $per_page Per page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function groups( int $page = 1, int $per_page = 20 ): array {
		global $wpdb;
		$table  = Migrations::table( 'content_scan' );
		$offset = ( max( 1, $page ) - 1 ) * $per_page;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$total = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT s.dup_group_id) FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.dup_group_id > 0" );
		$heads = $wpdb->get_results( $wpdb->prepare( "SELECT s.dup_group_id, COUNT(*) size, MAX(s.dup_similarity) max_similarity FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.dup_group_id > 0 GROUP BY s.dup_group_id ORDER BY size DESC, s.dup_group_id ASC LIMIT %d OFFSET %d", $per_page, $offset ) );
		$items = array();
		foreach ( (array) $heads as $head ) {
			$rows    = $wpdb->get_results( $wpdb->prepare( "SELECT s.post_id, s.word_count, s.dup_similarity, s.recommendation FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.dup_group_id = %d ORDER BY s.word_count DESC, s.post_id ASC LIMIT 200", (int) $head->dup_group_id ) );
			$members = array();
			foreach ( (array) $rows as $row ) {
				$members[] = array(
					'id'             => (int) $row->post_id,
					'title'          => get_the_title( (int) $row->post_id ),
					'url'            => (string) get_permalink( (int) $row->post_id ),
					'edit_url'       => (string) get_edit_post_link( (int) $row->post_id, 'raw' ),
					'words'          => (int) $row->word_count,
					'similarity'     => (int) $row->dup_similarity,
					'recommendation' => (string) $row->recommendation,
				);
			}
			$items[] = array(
				'group_id'       => (int) $head->dup_group_id,
				'size'           => (int) $head->size,
				'max_similarity' => (int) $head->max_similarity,
				'primary_id'     => $this->primary( (int) $head->dup_group_id ),
				'members'        => $members,
			);
		}
		// phpcs:enable
		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * The member other pages should merge into: most inbound links, then most words, then oldest.
	 *
	 * @param int $group_id Group id.
	 */
	public function primary( int $group_id ): int {
		global $wpdb;
		if ( $group_id <= 0 ) {
			return 0;
		}
		$table = Migrations::table( 'content_scan' );
		$stats = Migrations::table( 'link_stats' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT s.post_id FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id LEFT JOIN {$stats} l ON l.post_id = s.post_id LEFT JOIN {$wpdb->postmeta} ni ON ni.post_id = s.post_id AND ni.meta_key = '_flseo_noindex' AND ni.meta_value = '1' WHERE p.post_status = 'publish' AND s.dup_group_id = %d ORDER BY (ni.meta_id IS NULL) DESC, COALESCE(l.inbound, 0) DESC, s.word_count DESC, s.post_id ASC LIMIT 1", $group_id ) );
	}
}
