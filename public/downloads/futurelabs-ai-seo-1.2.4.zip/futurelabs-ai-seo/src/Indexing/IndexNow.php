<?php
/**
 * IndexNow: tells Bing, Yandex and other participating search engines about
 * added, changed and removed URLs straight away. Google does not use IndexNow.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Indexing;

defined( 'ABSPATH' ) || exit;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Meta\RobotsResolver;

/**
 * Queues changed URLs and submits them in batches; serves the key file.
 */
final class IndexNow implements Module {

	public const HOOK         = 'flseo_indexnow_submit';
	public const KEY_OPTION   = 'flseo_indexnow_key';
	public const QUEUE_OPTION = 'flseo_indexnow_pending';
	public const STATUS       = 'flseo_indexnow_status';
	public const MAX_URLS     = 10000;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hooks.
	 */
	public function register(): void {
		add_action( 'parse_request', array( $this, 'serve_key' ), 0 );
		add_action( 'post_updated', array( $this, 'post_updated' ), 10, 3 );
		add_action( 'flseo_sitemap_changed', array( $this, 'sitemap_changed' ), 10, 2 );
		add_action( 'before_delete_post', array( $this, 'before_delete' ), 10, 2 );
		add_action( self::HOOK, array( $this, 'submit' ) );
	}

	/**
	 * Whether submissions are switched on.
	 */
	public function enabled(): bool {
		return (bool) $this->c->get( Settings::class )->get( 'indexnow_enabled' );
	}

	/**
	 * Whether this site may contact the IndexNow API: switched on, visible to
	 * search engines, and the live (production) site, so staging and local
	 * copies never announce their URLs.
	 */
	public function allowed(): bool {
		$allowed = $this->enabled() && '1' === (string) get_option( 'blog_public' ) && 'production' === wp_get_environment_type();
		return (bool) apply_filters( 'flseo_indexnow_allowed', $allowed );
	}

	/**
	 * The site's key, created on first use.
	 */
	public function key(): string {
		$key = (string) get_option( self::KEY_OPTION, '' );
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $key ) ) {
			$key = bin2hex( random_bytes( 16 ) );
			update_option( self::KEY_OPTION, $key, false );
		}
		return $key;
	}

	/**
	 * URL of the key file.
	 */
	public function key_url(): string {
		return home_url( '/' . $this->key() . '.txt' );
	}

	/**
	 * Key file contents for a request path, or null when the path isn't the key file.
	 *
	 * @param string $path Request path.
	 */
	public function key_response( string $path ): ?string {
		if ( ! $this->enabled() ) {
			return null;
		}
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		return trailingslashit( $home ) . $this->key() . '.txt' === $path ? $this->key() : null;
	}

	/**
	 * Serve the key file.
	 */
	public function serve_key(): void {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
		$body = '' !== $path ? $this->key_response( $path ) : null;
		if ( null === $body ) {
			return;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=UTF-8' );
		echo esc_html( $body );
		exit;
	}

	/**
	 * A post changed: announce published changes, removals and old URLs after a slug change.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $after   Post after the update.
	 * @param \WP_Post $before  Post before the update.
	 */
	public function post_updated( $post_id, $after, $before ): void {
		if ( ! $after instanceof \WP_Post || ! $before instanceof \WP_Post || ! $this->trackable( $after ) ) {
			return;
		}
		$was = 'publish' === $before->post_status;
		$is  = 'publish' === $after->post_status;
		if ( $was ) {
			$old = (string) get_permalink( $before );
			if ( ! $is || (string) get_permalink( $after ) !== $old ) {
				$this->queue( $old );
			}
		}
		if ( $is && $this->indexable( $after ) ) {
			$this->queue( (string) get_permalink( $after ) );
		}
	}

	/**
	 * A post entered the published set without an update (e.g. created as published).
	 *
	 * @param \WP_Post $post       Post.
	 * @param string   $new_status New status.
	 */
	public function sitemap_changed( $post, $new_status ): void {
		if ( $post instanceof \WP_Post && 'publish' === $new_status && $this->trackable( $post ) && $this->indexable( $post ) ) {
			$this->queue( (string) get_permalink( $post ) );
		}
	}

	/**
	 * A published post is being deleted outright.
	 *
	 * @param int           $post_id Post ID.
	 * @param \WP_Post|null $post    Post.
	 */
	public function before_delete( $post_id, $post = null ): void {
		$post = $post instanceof \WP_Post ? $post : get_post( (int) $post_id );
		if ( $post instanceof \WP_Post && 'publish' === $post->post_status && $this->trackable( $post ) ) {
			$this->queue( (string) get_permalink( $post ) );
		}
	}

	/**
	 * Add a URL to the pending batch and schedule a submission.
	 *
	 * @param string $url URL.
	 */
	public function queue( string $url ): void {
		if ( ! $this->enabled() || '' === $url || ! str_starts_with( $url, home_url() ) ) {
			return;
		}
		$pending = $this->pending();
		if ( in_array( $url, $pending, true ) || count( $pending ) >= self::MAX_URLS ) {
			return;
		}
		$pending[] = $url;
		update_option( self::QUEUE_OPTION, $pending, false );
		$queue = $this->c->get( Queue::class );
		if ( ! $queue->is_pending( self::HOOK ) ) {
			$queue->at( time() + MINUTE_IN_SECONDS, self::HOOK );
		}
	}

	/**
	 * URLs waiting to be submitted.
	 *
	 * @return array<int, string>
	 */
	public function pending(): array {
		return array_values( array_filter( (array) get_option( self::QUEUE_OPTION, array() ), 'is_string' ) );
	}

	/**
	 * Submit the pending batch. Success and permanent errors clear it; rate
	 * limits and server errors keep it for a retry in an hour.
	 */
	public function submit(): void {
		$urls = $this->pending();
		if ( ! $urls ) {
			return;
		}
		if ( ! $this->allowed() ) {
			delete_option( self::QUEUE_OPTION );
			return;
		}
		$response = wp_safe_remote_post(
			(string) apply_filters( 'flseo_indexnow_endpoint', 'https://api.indexnow.org/indexnow' ),
			array(
				'timeout' => 15,
				'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
				'body'    => wp_json_encode(
					array(
						'host'        => (string) wp_parse_url( home_url(), PHP_URL_HOST ),
						'key'         => $this->key(),
						'keyLocation' => $this->key_url(),
						'urlList'     => $urls,
					)
				),
			)
		);
		$code     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		update_option(
			self::STATUS,
			array(
				'time'  => time(),
				'count' => count( $urls ),
				'code'  => $code,
			),
			false
		);
		if ( in_array( $code, array( 200, 202 ), true ) ) {
			delete_option( self::QUEUE_OPTION );
			return;
		}
		$logger = $this->c->get( Logger::class );
		if ( 0 === $code || 429 === $code || $code >= 500 ) {
			$logger->warning( 'IndexNow submission will be retried.', array( 'code' => $code ) );
			$this->c->get( Queue::class )->at( time() + HOUR_IN_SECONDS, self::HOOK );
			return;
		}
		$logger->error( 'IndexNow rejected the submission.', array( 'code' => $code ) );
		delete_option( self::QUEUE_OPTION );
	}

	/**
	 * A post of a public type, not a revision or autosave.
	 *
	 * @param \WP_Post $post Post.
	 */
	private function trackable( \WP_Post $post ): bool {
		return ! wp_is_post_revision( $post ) && ! wp_is_post_autosave( $post ) && is_post_type_viewable( $post->post_type );
	}

	/**
	 * Whether the post should be in search results.
	 *
	 * @param \WP_Post $post Post.
	 */
	private function indexable( \WP_Post $post ): bool {
		return $this->c->get( RobotsResolver::class )->is_indexable( $post );
	}
}
