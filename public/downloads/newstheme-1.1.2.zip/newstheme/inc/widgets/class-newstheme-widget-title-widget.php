<?php
/**
 * NewsTheme Widget Title Widget.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Widget title: a styled heading on its own (e.g. above a group of widgets).
 */
class NewsTheme_Widget_Title_Widget extends NewsTheme_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->fields = array(
			'title' => array(
				'type'    => 'text',
				'label'   => __( 'Heading', 'newstheme' ),
				'default' => '',
			),
			'align' => array(
				'type'    => 'select',
				'label'   => __( 'Alignment', 'newstheme' ),
				'default' => 'left',
				'choices' => array(
					'left'   => __( 'Left', 'newstheme' ),
					'center' => __( 'Center', 'newstheme' ),
				),
			),
		);
		parent::__construct( 'widget_title', __( 'NewsTheme: Widget Title', 'newstheme' ), __( 'A styled heading.', 'newstheme' ) );
	}

	/**
	 * Output: just the heading.
	 *
	 * @param array $args     Sidebar args.
	 * @param array $instance Saved instance.
	 */
	public function widget( $args, $instance ) {
		$values = $this->values( $instance );
		if ( '' === $values['title'] ) {
			return;
		}
		printf(
			'<div class="widget nt-widget--title-only nt-align-%1$s"><h2 class="widget-title"><span>%2$s</span></h2></div>',
			esc_attr( $values['align'] ),
			esc_html( $values['title'] )
		);
	}

	/**
	 * Unused (widget() is overridden).
	 *
	 * @param array $values Instance values.
	 */
	protected function render( array $values ) {}
}
