<?php
/**
 * Schema.org types FutureLabs AI SEO can emit.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Type catalogue and required properties used for validation.
 */
final class Types {

	/**
	 * Types an editor can pick per post or per post type.
	 *
	 * @return array<int, string>
	 */
	public static function selectable(): array {
		return array( 'Article', 'BlogPosting', 'NewsArticle', 'WebPage', 'Course', 'Product', 'None' );
	}

	/**
	 * Required properties per type (schema.org / Google rich result minimums).
	 *
	 * @return array<string, array<int, string>>
	 */
	public static function required(): array {
		return array(
			'Organization'   => array( '@id', 'name', 'url' ),
			'Person'         => array( '@id', 'name' ),
			'WebSite'        => array( '@id', 'url', 'name' ),
			'WebPage'        => array( '@id', 'url', 'name' ),
			'Article'        => array( '@id', 'headline', 'datePublished', 'author', 'mainEntityOfPage' ),
			'BlogPosting'    => array( '@id', 'headline', 'datePublished', 'author', 'mainEntityOfPage' ),
			'NewsArticle'    => array( '@id', 'headline', 'datePublished', 'author', 'mainEntityOfPage' ),
			'BreadcrumbList' => array( '@id', 'itemListElement' ),
			'FAQPage'        => array( '@id', 'mainEntity' ),
			'Course'         => array( '@id', 'name', 'description', 'provider' ),
			'Product'        => array( '@id', 'name', 'offers' ),
			'LocalBusiness'  => array( '@id', 'name', 'address' ),
			'VideoObject'    => array( '@id', 'name', 'thumbnailUrl', 'uploadDate', 'embedUrl' ),
		);
	}

	/**
	 * Validate one graph node. Returns a list of problems (empty when valid).
	 *
	 * @param array<string, mixed> $node Node.
	 * @return array<int, string>
	 */
	public static function validate( array $node ): array {
		$problems = array();
		$type     = $node['@type'] ?? '';
		if ( ! is_string( $type ) || '' === $type ) {
			return array( 'Missing @type' );
		}
		$base = self::base_type( $type );
		foreach ( self::required()[ $base ] ?? array( '@id' ) as $property ) {
			if ( ! isset( $node[ $property ] ) || '' === $node[ $property ] || array() === $node[ $property ] ) {
				$problems[] = sprintf( '%s is missing %s', $type, $property );
			}
		}
		return $problems;
	}

	/**
	 * Map subtypes (e.g. Restaurant) to the base type used for validation.
	 *
	 * @param string $type Type.
	 */
	public static function base_type( string $type ): string {
		$local = array( 'LocalBusiness', 'Restaurant', 'Store', 'ProfessionalService', 'MedicalBusiness', 'EducationalOrganization', 'FinancialService', 'LegalService' );
		return in_array( $type, $local, true ) ? 'LocalBusiness' : $type;
	}
}
