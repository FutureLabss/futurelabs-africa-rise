<?php
/**
 * Footer element: widget area "Footer - Column 2".
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

echo '<div class="nt-footer__widgets">';
dynamic_sidebar( 'footer-2' );
echo '</div>';
