<?php
/**
 * Pluggable backend for "related post" similarity (TF-IDF by default, embeddings optional).
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Links;

defined( 'ABSPATH' ) || exit;

/**
 * Ranks other indexable posts by similarity to a post.
 */
interface SimilarityProvider {

	/**
	 * Machine name, e.g. "tfidf" or "embeddings".
	 */
	public function name(): string;

	/**
	 * Most similar posts.
	 *
	 * @param int             $post_id Source post.
	 * @param int             $limit   Max results.
	 * @param array<int, int> $exclude Post IDs to skip.
	 * @return array<int, float> Map of post ID to score in [0,1], best first.
	 */
	public function similar( int $post_id, int $limit = 10, array $exclude = array() ): array;
}
