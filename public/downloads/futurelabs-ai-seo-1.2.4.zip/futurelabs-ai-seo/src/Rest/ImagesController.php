<?php
/**
 * REST: image audit.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Images\Audit;

defined( 'ABSPATH' ) || exit;

/**
 * Routes under /images.
 */
class ImagesController extends Controller {

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		$this->route(
			'/images/audit',
			'GET',
			array( $this, 'audit' ),
			\FutureLabs\AISEO\Core\Capabilities::DATA,
			array(
				'issue' => array(
					'type' => 'string',
					'enum' => array_merge( array( '' ), array_keys( Audit::ISSUES ) ),
				),
			)
		);
	}

	/**
	 * GET /images/audit?issue=&page=&per_page=&refresh=1.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	public function audit( \WP_REST_Request $request ): array {
		list( $page, $per_page ) = $this->paging( $request );
		$issue                   = (string) $request->get_param( 'issue' );
		return $this->c->get( Audit::class )->audit( $issue, $page, $per_page, (bool) $request->get_param( 'refresh' ) ) + array(
			'page'     => $page,
			'per_page' => $per_page,
		);
	}
}
