<?php
/**
 * Header element: mobile menu toggle (hidden on desktop).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

if ( ! has_nav_menu( 'primary' ) ) {
	return;
}
$newstheme_suffix = newstheme_element_suffix( $args );
?>
<button type="button" class="nt-icon-btn nt-burger nt-menu-toggle" aria-controls="nt-site-navigation<?php echo esc_attr( $newstheme_suffix ); ?>" aria-expanded="false" aria-label="<?php esc_attr_e( 'Menu', 'newstheme' ); ?>">
	<span></span><span></span><span></span>
</button>
