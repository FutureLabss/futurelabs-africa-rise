<?php
/**
 * Minimal dependency injection container.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Lazily builds and caches shared services by id.
 */
final class Container {

	/**
	 * Registered factories keyed by service id.
	 *
	 * @var array<string, callable(Container): object>
	 */
	private array $factories = array();

	/**
	 * Built service instances keyed by service id.
	 *
	 * @var array<string, object>
	 */
	private array $instances = array();

	/**
	 * Register a shared service factory.
	 *
	 * @param string                      $id      Service id, normally a class name.
	 * @param callable(Container): object $factory Factory receiving the container.
	 */
	public function set( string $id, callable $factory ): void {
		$this->factories[ $id ] = $factory;
		unset( $this->instances[ $id ] );
	}

	/**
	 * Replace a service with a ready instance (used by tests to inject mocks).
	 *
	 * @param string $id       Service id.
	 * @param object $instance Instance.
	 */
	public function instance( string $id, object $instance ): void {
		$this->instances[ $id ] = $instance;
	}

	/**
	 * Whether a service is registered.
	 *
	 * @param string $id Service id.
	 */
	public function has( string $id ): bool {
		return isset( $this->instances[ $id ] ) || isset( $this->factories[ $id ] );
	}

	/**
	 * Resolve a service.
	 *
	 * @template T of object
	 * @param class-string<T> $id Service id.
	 * @return T
	 * @throws \InvalidArgumentException When the service is unknown.
	 */
	public function get( string $id ): object {
		if ( isset( $this->instances[ $id ] ) ) {
			return $this->instances[ $id ];
		}
		if ( ! isset( $this->factories[ $id ] ) ) {
			// Plugin classes follow one convention: the constructor receives the container.
			if ( str_starts_with( $id, 'FutureLabs\\AISEO\\' ) && class_exists( $id ) ) {
				$this->instances[ $id ] = new $id( $this );
				return $this->instances[ $id ];
			}
			throw new \InvalidArgumentException( sprintf( 'Unknown FutureLabs AI SEO service: %s', esc_html( $id ) ) );
		}
		$this->instances[ $id ] = ( $this->factories[ $id ] )( $this );
		return $this->instances[ $id ];
	}
}
