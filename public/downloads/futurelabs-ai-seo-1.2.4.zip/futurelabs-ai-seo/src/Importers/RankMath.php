<?php
/**
 * Rank Math importer.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Importers;

defined( 'ABSPATH' ) || exit;

/**
 * Reads `rank_math_*` post and term meta and the `{prefix}rank_math_redirections` table.
 */
class RankMath extends Importer {

	public const POST_KEYS = array(
		'rank_math_title',
		'rank_math_description',
		'rank_math_canonical_url',
		'rank_math_robots',
		'rank_math_facebook_title',
		'rank_math_facebook_description',
		'rank_math_facebook_image',
		'rank_math_twitter_title',
		'rank_math_twitter_description',
		'rank_math_twitter_image',
		'rank_math_focus_keyword',
		'rank_math_rich_snippet',
	);

	public const TERM_KEYS = array(
		'rank_math_title',
		'rank_math_description',
		'rank_math_canonical_url',
		'rank_math_robots',
		'rank_math_facebook_title',
		'rank_math_facebook_description',
		'rank_math_facebook_image',
	);

	/**
	 * Slug.
	 */
	public function slug(): string {
		return 'rankmath';
	}

	/**
	 * Label.
	 */
	public function label(): string {
		return 'Rank Math';
	}

	/**
	 * Redirections table.
	 */
	private static function redirect_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'rank_math_redirections';
	}

	/**
	 * Counts.
	 *
	 * @return array{posts: int, terms: int, redirects: int}
	 */
	public function count(): array {
		global $wpdb;
		$redirects = 0;
		if ( self::table_exists( self::redirect_table() ) ) {
			$table = self::redirect_table();
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$redirects = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status='active'" );
		}
		return array(
			'posts'     => self::meta_post_count( self::POST_KEYS ),
			'terms'     => self::meta_term_count( self::TERM_KEYS ),
			'redirects' => $redirects,
		);
	}

	/**
	 * Post IDs.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, int>
	 */
	protected function post_ids( int $offset, int $limit ): array {
		return self::meta_post_ids( self::POST_KEYS, $offset, $limit );
	}

	/**
	 * Shared field mapping for posts and terms.
	 *
	 * @param callable $get Reads a meta key without the rank_math_ prefix.
	 * @return array<string, string>
	 */
	private function fields( callable $get ): array {
		$robots = maybe_unserialize( $get( 'robots' ) );
		$robots = is_array( $robots ) ? array_map( 'strval', $robots ) : array_filter( array_map( 'trim', explode( ',', (string) $robots ) ) );
		return array(
			'title'          => (string) $get( 'title' ),
			'description'    => (string) $get( 'description' ),
			'canonical'      => (string) $get( 'canonical_url' ),
			// Only an explicit noindex is imported; Rank Math also stores "index" as its default.
			'noindex'        => in_array( 'noindex', $robots, true ) ? '1' : '',
			'og_title'       => '' !== (string) $get( 'facebook_title' ) ? (string) $get( 'facebook_title' ) : (string) $get( 'twitter_title' ),
			'og_description' => '' !== (string) $get( 'facebook_description' ) ? (string) $get( 'facebook_description' ) : (string) $get( 'twitter_description' ),
			'og_image'       => '' !== (string) $get( 'facebook_image' ) ? (string) $get( 'facebook_image' ) : (string) $get( 'twitter_image' ),
		);
	}

	/**
	 * Post fields.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string, string>
	 */
	protected function post_fields( int $post_id ): array {
		$get    = static fn( string $key ) => get_post_meta( $post_id, 'rank_math_' . $key, true );
		$fields = $this->fields( $get );
		$focus  = explode( ',', (string) $get( 'focus_keyword' ) );

		$fields['focus_topic'] = trim( (string) reset( $focus ) );
		$fields['schema_type'] = $this->post_schema_type( $post_id, (string) $get( 'rich_snippet' ), (string) $get( 'snippet_article_type' ) );
		return $fields;
	}

	/**
	 * Schema type from the legacy rich snippet meta or the newer rank_math_schema_{Type} meta.
	 *
	 * @param int    $post_id      Post ID.
	 * @param string $rich_snippet Legacy rich snippet type.
	 * @param string $article_type Legacy article subtype.
	 */
	private function post_schema_type( int $post_id, string $rich_snippet, string $article_type ): string {
		foreach ( array_keys( (array) get_post_meta( $post_id ) ) as $key ) {
			if ( str_starts_with( (string) $key, 'rank_math_schema_' ) ) {
				$type = self::schema_type( substr( (string) $key, strlen( 'rank_math_schema_' ) ) );
				if ( '' !== $type ) {
					return $type;
				}
			}
		}
		if ( 'article' === $rich_snippet ) {
			return self::schema_type( '' !== $article_type ? $article_type : 'Article' );
		}
		return self::schema_type( $rich_snippet );
	}

	/**
	 * Term IDs.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, int>
	 */
	protected function term_ids( int $offset, int $limit ): array {
		return self::meta_term_ids( self::TERM_KEYS, $offset, $limit );
	}

	/**
	 * Term fields.
	 *
	 * @param int $term_id Term ID.
	 * @return array<string, string>
	 */
	protected function term_fields( int $term_id ): array {
		return $this->fields( static fn( string $key ) => get_term_meta( $term_id, 'rank_math_' . $key, true ) );
	}

	/**
	 * Redirect rows (one Rank Math row may hold several sources).
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, array{source: string, target: string, type: int, is_regex: bool}>
	 */
	protected function redirect_rows( int $offset, int $limit ): array {
		global $wpdb;
		if ( ! self::table_exists( self::redirect_table() ) ) {
			return array();
		}
		$table = self::redirect_table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, sources, url_to, header_code FROM {$table} WHERE status='active' ORDER BY id ASC LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_A );
		$out  = array();
		foreach ( $rows as $row ) {
			$sources = maybe_unserialize( (string) $row['sources'] );
			foreach ( is_array( $sources ) ? $sources : array() as $source ) {
				if ( ! is_array( $source ) || '' === (string) ( $source['pattern'] ?? '' ) ) {
					continue;
				}
				$converted = self::source( (string) $source['pattern'], (string) ( $source['comparison'] ?? 'exact' ) );
				$out[]     = array(
					'source'   => $converted[0],
					'target'   => (string) $row['url_to'],
					'type'     => absint( $row['header_code'] ),
					'is_regex' => $converted[1],
				);
			}
		}
		return $out;
	}

	/**
	 * Convert a Rank Math source and comparison to a FutureLabs AI SEO source.
	 *
	 * @param string $pattern    Pattern.
	 * @param string $comparison exact, regex, contains, start, end.
	 * @return array{0: string, 1: bool} Source and whether it is a regex.
	 */
	private static function source( string $pattern, string $comparison ): array {
		// Rules::regex_pattern() escapes the ~ delimiter itself, so no delimiter is passed here.
		// phpcs:disable WordPress.PHP.PregQuoteDelimiter.Missing
		$quoted = preg_quote( '/' . ltrim( $pattern, '/' ) );
		switch ( $comparison ) {
			case 'regex':
				return array( $pattern, true );
			case 'contains':
				return array( preg_quote( $pattern ), true );
			case 'start':
				return array( '^' . $quoted, true );
			case 'end':
				return array( preg_quote( $pattern ) . '$', true );
		}
		// phpcs:enable
		return array( $pattern, false );
	}

	/**
	 * Posts excluded from the Rank Math sitemap.
	 *
	 * @return array<int, int>
	 */
	public function sitemap_excluded(): array {
		$options = get_option( 'rank-math-options-sitemap', array() );
		$raw     = is_array( $options ) ? (string) ( $options['exclude_posts'] ?? '' ) : '';
		return array_values( array_filter( array_map( 'absint', explode( ',', $raw ) ) ) );
	}

	/**
	 * Variable pattern: %name% or %name(arg)%.
	 */
	protected function variable_pattern(): string {
		return '/%([a-z0-9_]+)(?:\([^)%]*\))?%/i';
	}

	/**
	 * Variable map.
	 *
	 * @return array<string, string>
	 */
	protected function variable_map(): array {
		return array(
			'title'            => '%title%',
			'sitename'         => '%sitename%',
			'sitedesc'         => '%tagline%',
			'tagline'          => '%tagline%',
			'sep'              => '%sep%',
			'excerpt'          => '%excerpt%',
			'excerpt_only'     => '%excerpt%',
			'category'         => '%category%',
			'primary_category' => '%category%',
			'term'             => '%title%',
			'date'             => '%date%',
			'publish_date'     => '%date%',
			'name'             => '%author%',
			'post_author'      => '%author%',
			'author'           => '%author%',
			'page'             => '%page%',
		);
	}
}
