<?php
/**
 * Any server that speaks the OpenAI Chat Completions format: OpenRouter, Groq,
 * DeepSeek, Mistral, Together, or a local Ollama / LM Studio.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Ai;

use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * OpenAI-compatible provider with an administrator-set base URL.
 */
class OpenAiCompatibleClient extends OpenAiClient {

	public const KEY_OPTION = 'flseo_ai_key_compatible';

	/**
	 * Provider ID.
	 */
	public function id(): string {
		return 'compatible';
	}

	/**
	 * Service name: the server's host, so messages say which service failed.
	 */
	public function label(): string {
		$host = (string) wp_parse_url( $this->base_url(), PHP_URL_HOST );
		return '' !== $host ? $host : __( 'AI provider', 'futurelabs-ai-seo' );
	}

	/**
	 * Key option.
	 */
	public function key_option(): string {
		return self::KEY_OPTION;
	}

	/**
	 * Local servers such as Ollama need no key.
	 */
	protected function key_optional(): bool {
		return true;
	}

	/**
	 * Ready when a base URL is set; the key is optional.
	 */
	public function has_key(): bool {
		return '' !== $this->base_url();
	}

	/**
	 * Base URL from settings, e.g. https://openrouter.ai/api/v1 (a pasted
	 * …/chat/completions endpoint is accepted too).
	 */
	protected function base_url(): string {
		return self::clean_base_url( (string) $this->c->get( Settings::class )->get( 'ai_compatible_url', '' ) );
	}

	/**
	 * Normalise a base URL: http(s) only, no trailing slash or endpoint path.
	 *
	 * @param string $url Raw URL.
	 */
	public static function clean_base_url( string $url ): string {
		$url = esc_url_raw( trim( $url ), array( 'http', 'https' ) );
		if ( '' === $url ) {
			return '';
		}
		$url = (string) preg_replace( '#/(chat/completions|completions|models)/?$#', '', $url );
		return rtrim( $url, '/' );
	}

	/**
	 * Setting that stores the model ID.
	 */
	protected function model_setting(): string {
		return 'ai_model_compatible';
	}

	/**
	 * Images only when the administrator says the model reads them.
	 *
	 * @return array<int, string>
	 */
	public function image_types(): array {
		return $this->c->get( Settings::class )->get( 'ai_compatible_vision' ) ? self::IMAGE_TYPES : array();
	}

	/**
	 * Compatible servers use the original field name.
	 */
	protected function max_tokens_field(): string {
		return 'max_tokens';
	}

	/**
	 * Every listed model is offered: these servers list only chat models, or name them freely.
	 *
	 * @param string $id Model ID.
	 */
	protected function is_text_model( string $id ): bool {
		return ! preg_match( '/embed/i', $id );
	}

	/**
	 * Fail clearly before any request when no server is configured.
	 *
	 * @param string                                              $system      System prompt.
	 * @param string                                              $text        User text.
	 * @param array<int, array{media_type: string, data: string}> $images      Images.
	 * @param bool                                                $interactive Interactive.
	 * @return array{text: string, stop_reason: string, truncated: bool}|\WP_Error
	 */
	public function send( string $system, string $text, array $images = array(), bool $interactive = true ) {
		if ( $this->enabled() && '' === $this->base_url() ) {
			return new \WP_Error( 'flseo_ai_no_url', __( 'Add the API base URL of your OpenAI-compatible provider in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		return parent::send( $system, $text, $images, $interactive );
	}

	/**
	 * Models from the server.
	 *
	 * @return array<int, string>|\WP_Error
	 */
	public function list_models() {
		if ( '' === $this->base_url() ) {
			return new \WP_Error( 'flseo_ai_no_url', __( 'Add the API base URL of your OpenAI-compatible provider in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		return parent::list_models();
	}
}
