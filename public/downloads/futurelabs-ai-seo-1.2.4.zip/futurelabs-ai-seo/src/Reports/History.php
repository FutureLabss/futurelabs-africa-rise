<?php
/**
 * Daily index snapshot for "indexed pages over time" reports.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Reports;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Writes one `flseo_history` row per day.
 */
class History implements Module {

	public const HOOK = 'flseo_history_snapshot';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'flseo_daily', array( $this, 'run_snapshot' ) );
		add_action( self::HOOK, array( $this, 'run_snapshot' ) );
	}

	/**
	 * Job callback for the daily snapshot.
	 */
	public function run_snapshot(): void {
		$this->snapshot();
	}

	/**
	 * Current counts.
	 *
	 * Known: published posts of indexable public types; inspected: URLs with a URL Inspection
	 * result; indexed: inspected URLs Google reports as indexed (verdict PASS); noindex: published
	 * posts with a noindex override; flagged: posts with an open content finding.
	 *
	 * @return array{known: int, inspected: int, indexed: int, noindex: int, flagged: int}
	 */
	public function metrics(): array {
		global $wpdb;
		$settings = $this->c->get( Settings::class );
		$types    = array();
		foreach ( get_post_types( array( 'public' => true ), 'names' ) as $type ) {
			if ( 'attachment' !== $type && $settings->post_type( $type )['index'] ) {
				$types[] = $type;
			}
		}
		$known = 0;
		if ( $types ) {
			$in = implode( ',', array_fill( 0, count( $types ), '%s' ) );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$known = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ($in)", $types ) );
		}
		$status = Migrations::table( 'index_status' );
		$scan   = Migrations::table( 'content_scan' );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$inspected = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$status} WHERE inspected_at IS NOT NULL" );
		$indexed   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$status} WHERE inspected_at IS NOT NULL AND UPPER(verdict)='PASS'" );
		$noindex   = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT m.post_id) FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID=m.post_id WHERE m.meta_key='_flseo_noindex' AND m.meta_value='1' AND p.post_status='publish'" );
		$flagged   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$scan} s INNER JOIN {$wpdb->posts} p ON p.ID=s.post_id WHERE s.recommendation<>'ok' AND s.recommendation<>'' AND p.post_status='publish'" );
		// phpcs:enable
		return array(
			'known'     => $known,
			'inspected' => $inspected,
			'indexed'   => $indexed,
			'noindex'   => $noindex,
			'flagged'   => $flagged,
		);
	}

	/**
	 * Store today's snapshot (site timezone). Re-running the same day overwrites it.
	 *
	 * @return array<string, int|string>
	 */
	public function snapshot(): array {
		global $wpdb;
		$row = array( 'day' => current_time( 'Y-m-d' ) ) + $this->metrics();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->replace( Migrations::table( 'history' ), $row, array( '%s', '%d', '%d', '%d', '%d', '%d' ) );
		return $row;
	}

	/**
	 * Snapshots for the last N days, oldest first.
	 *
	 * @param int $days Days.
	 * @return array<int, array<string, mixed>>
	 */
	public function series( int $days = 90 ): array {
		global $wpdb;
		$table = Migrations::table( 'history' );
		$since = gmdate( 'Y-m-d', (int) current_time( 'timestamp' ) - ( max( 1, $days ) - 1 ) * DAY_IN_SECONDS ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested -- site-local day boundary.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE day >= %s ORDER BY day ASC", $since ), ARRAY_A );
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$known = (int) $row['known'];
			$out[] = array(
				'day'             => (string) $row['day'],
				'known'           => $known,
				'inspected'       => (int) $row['inspected'],
				'indexed'         => (int) $row['indexed'],
				'noindex'         => (int) $row['noindex'],
				'flagged'         => (int) $row['flagged'],
				'indexed_percent' => $known > 0 ? round( (int) $row['indexed'] / $known * 100, 1 ) : null,
			);
		}
		return $out;
	}
}
