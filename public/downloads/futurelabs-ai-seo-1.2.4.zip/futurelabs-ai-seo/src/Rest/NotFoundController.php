<?php
/**
 * GET /404 · POST /404/{id}/redirect · POST /404/{id}/ignore · GET /404/{id}/suggestions
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Bulk\AuditLog;
use FutureLabs\AISEO\Redirects\Log404;
use FutureLabs\AISEO\Redirects\Rules;
use FutureLabs\AISEO\Redirects\Suggester;

defined( 'ABSPATH' ) || exit;

/**
 * 404 log review and one-click redirect creation.
 */
class NotFoundController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/404', 'GET', array( $this, 'index' ) );
		$this->route( '/404/(?P<id>\d+)/redirect', 'POST', array( $this, 'redirect' ) );
		$this->route( '/404/(?P<id>\d+)/ignore', 'POST', array( $this, 'ignore' ) );
		$this->route( '/404/(?P<id>\d+)/suggestions', 'GET', array( $this, 'suggestions' ) );
	}

	/**
	 * List logged 404s.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function index( \WP_REST_Request $request ): \WP_REST_Response {
		list( $page, $per_page ) = $this->paging( $request, 200 );
		return rest_ensure_response(
			$this->c->get( Log404::class )->list(
				array(
					'page'     => $page,
					'per_page' => $per_page,
					'ignored'  => (bool) $request->get_param( 'ignored' ),
					'search'   => sanitize_text_field( (string) $request->get_param( 'search' ) ),
					'suggest'  => (bool) $request->get_param( 'suggest' ),
				)
			)
		);
	}

	/**
	 * Create a redirect from a 404 row. Target defaults to the best suggestion.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function redirect( \WP_REST_Request $request ) {
		$log = $this->c->get( Log404::class );
		$row = $log->get( absint( $request['id'] ) );
		if ( ! $row ) {
			return $this->error( 'not_found', __( '404 record not found.', 'futurelabs-ai-seo' ), 404 );
		}
		$body   = $this->body( $request );
		$target = (string) ( $body['target'] ?? '' );
		if ( '' === $target ) {
			$best   = $this->c->get( Suggester::class )->suggest( (string) $row['url'], 1 );
			$target = $best ? $best[0]['url'] : '';
		}
		$rules = $this->c->get( Rules::class );
		$id    = $rules->save(
			array(
				'source' => (string) $row['url'],
				'target' => $target,
				'type'   => absint( $body['type'] ?? 301 ) ?: 301,
			),
			0,
			'404'
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$log->delete( (int) $row['id'] );
		$this->c->get( AuditLog::class )->write(
			$this->c->get( AuditLog::class )->new_batch(),
			'redirect_create',
			'redirect',
			$id,
			array(
				'kind'    => 'redirect',
				'row'     => null,
				'log_404' => $row,
			),
			array(
				'kind' => 'redirect',
				'row'  => $rules->get( $id ),
			)
		);
		return new \WP_REST_Response( $rules->get( $id ), 201 );
	}

	/**
	 * Ignore or un-ignore a 404 row.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function ignore( \WP_REST_Request $request ): \WP_REST_Response {
		$ignored = ! isset( $this->body( $request )['ignored'] ) || ! empty( $this->body( $request )['ignored'] );
		return rest_ensure_response( array( 'updated' => $this->c->get( Log404::class )->set_ignored( absint( $request['id'] ), $ignored ) ) );
	}

	/**
	 * Suggested targets for one 404.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function suggestions( \WP_REST_Request $request ) {
		$row = $this->c->get( Log404::class )->get( absint( $request['id'] ) );
		if ( ! $row ) {
			return $this->error( 'not_found', __( '404 record not found.', 'futurelabs-ai-seo' ), 404 );
		}
		return rest_ensure_response( $this->c->get( Suggester::class )->suggest( (string) $row['url'], 5 ) );
	}
}
