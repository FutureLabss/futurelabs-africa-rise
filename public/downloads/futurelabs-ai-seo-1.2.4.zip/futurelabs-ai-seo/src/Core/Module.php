<?php
/**
 * Contract for hookable plugin modules.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * A module attaches its WordPress hooks in register().
 */
interface Module {

	/**
	 * Attach hooks. Must not perform heavy work.
	 */
	public function register(): void;
}
