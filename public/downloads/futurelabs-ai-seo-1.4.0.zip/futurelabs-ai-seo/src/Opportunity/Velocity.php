<?php
/**
 * Publishing velocity guard (OL-11).
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Opportunity;

use FutureLabs\AISEO\Content\Analyzer;
use FutureLabs\AISEO\Content\Duplicate;
use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Features;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Warns when many near-identical posts went live in the last 24 hours.
 *
 * Posts published in the window are clustered when their bodies are at least
 * `velocity_similarity`% similar or share a template signature; the warning fires
 * when the largest cluster is bigger than `velocity_posts`.
 */
class Velocity implements Module {

	public const TRANSIENT = 'flseo_velocity';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'admin_notices', array( $this, 'notice' ) );
		add_action( 'transition_post_status', array( $this, 'invalidate' ), 10, 2 );
		add_action( 'flseo_scan_complete', array( $this, 'flush' ) );
	}

	/**
	 * Drop the cached result when a post is published.
	 *
	 * @param string $new_status New status.
	 * @param string $old_status Old status.
	 */
	public function invalidate( $new_status, $old_status ): void {
		if ( 'publish' === $new_status && 'publish' !== $old_status ) {
			delete_transient( self::TRANSIENT );
		}
	}

	/**
	 * Drop the cached result.
	 */
	public function flush(): void {
		delete_transient( self::TRANSIENT );
	}

	/**
	 * Evaluate the last 24 hours.
	 *
	 * @return array{triggered: bool, published: int, cluster: int, limit: int, similarity: int, template_sig: string, sample: array<int, array{id: int, title: string}>}
	 */
	public function check(): array {
		global $wpdb;
		$settings  = $this->c->get( Settings::class );
		$limit     = max( 1, (int) $settings->get( 'velocity_posts', 10 ) );
		$threshold = max( 50, min( 100, (int) $settings->get( 'velocity_similarity', 70 ) ) );
		$types     = Analyzer::post_types();
		$result    = array(
			'triggered'    => false,
			'published'    => 0,
			'cluster'      => 0,
			'limit'        => $limit,
			'similarity'   => $threshold,
			'template_sig' => '',
			'sample'       => array(),
		);
		if ( ! $types ) {
			return $result;
		}
		$table = Migrations::table( 'content_scan' );
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$since = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$rows                = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, p.post_title, s.simhash, s.template_sig FROM {$wpdb->posts} p LEFT JOIN {$table} s ON s.post_id = p.ID WHERE p.post_status = 'publish' AND p.post_type IN ({$in}) AND p.post_date_gmt >= %s ORDER BY p.post_date_gmt DESC LIMIT 1000", array_merge( $types, array( $since ) ) ) );
		$result['published'] = count( (array) $rows );
		if ( $result['published'] <= $limit ) {
			return $result;
		}
		$parent = array();
		$find   = static function ( int $x ) use ( &$parent ): int {
			while ( isset( $parent[ $x ] ) && $parent[ $x ] !== $x ) {
				$parent[ $x ] = $parent[ $parent[ $x ] ] ?? $parent[ $x ];
				$x            = $parent[ $x ];
			}
			return $x;
		};
		$by_sig = array();
		$list   = array_values( (array) $rows );
		$n      = count( $list );
		foreach ( $list as $i => $row ) {
			$parent[ $i ] = $i;
			if ( '' !== (string) $row->template_sig ) {
				$by_sig[ (string) $row->template_sig ][] = $i;
			}
		}
		foreach ( $by_sig as $members ) {
			$first = $members[0];
			foreach ( $members as $m ) {
				$parent[ $find( $m ) ] = $find( $first );
			}
		}
		for ( $i = 0; $i < $n; $i++ ) {
			if ( '' === (string) $list[ $i ]->simhash ) {
				continue;
			}
			for ( $j = $i + 1; $j < $n; $j++ ) {
				if ( '' === (string) $list[ $j ]->simhash || $find( $i ) === $find( $j ) ) {
					continue;
				}
				if ( Duplicate::similarity( (string) $list[ $i ]->simhash, (string) $list[ $j ]->simhash ) >= $threshold ) {
					$parent[ $find( $j ) ] = $find( $i );
				}
			}
		}
		$clusters = array();
		for ( $i = 0; $i < $n; $i++ ) {
			$clusters[ $find( $i ) ][] = $i;
		}
		usort( $clusters, static fn( $a, $b ) => count( $b ) <=> count( $a ) );
		$largest           = $clusters ? $clusters[0] : array();
		$result['cluster'] = count( $largest );
		if ( $result['cluster'] > $limit ) {
			$result['triggered'] = true;
			$sigs                = array_count_values( array_filter( array_map( static fn( $i ) => (string) $list[ $i ]->template_sig, $largest ) ) );
			arsort( $sigs );
			$result['template_sig'] = (string) ( array_key_first( $sigs ) ?? '' );
			foreach ( array_slice( $largest, 0, 5 ) as $i ) {
				$result['sample'][] = array(
					'id'    => (int) $list[ $i ]->ID,
					'title' => html_entity_decode( (string) $list[ $i ]->post_title, ENT_QUOTES ),
				);
			}
		}
		return $result;
	}

	/**
	 * Cached check (15 minutes).
	 *
	 * @return array<string, mixed>
	 */
	public function cached(): array {
		$cached = get_transient( self::TRANSIENT );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$result = $this->check();
		set_transient( self::TRANSIENT, $result, 15 * MINUTE_IN_SECONDS );
		return $result;
	}

	/**
	 * Admin notice on the dashboard and post screens.
	 */
	public function notice(): void {
		if ( ! Capabilities::can( Capabilities::EDITOR ) || ! $this->c->get( Features::class )->enabled( Features::VELOCITY ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && ! in_array( $screen->base, array( 'dashboard', 'edit', 'post', 'toplevel_page_futurelabs-ai-seo' ), true ) ) {
			return;
		}
		$result = $this->cached();
		if ( empty( $result['triggered'] ) ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: 1: similar posts, 2: posts published in 24 hours. */
					__( 'FutureLabs AI SEO: %1$d of the %2$d posts published in the last 24 hours look very similar (shared template or wording). Publishing many near-identical pages in a short time is a common pattern behind "Crawled, not indexed". Consider adding unique details to each post before publishing more.', 'futurelabs-ai-seo' ),
					(int) $result['cluster'],
					(int) $result['published']
				)
			)
		);
	}
}
