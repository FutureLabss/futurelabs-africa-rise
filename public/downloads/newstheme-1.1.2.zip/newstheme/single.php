<?php
/**
 * Single post.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();
newstheme_layout_open( 'single' );

while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/content/single' );

	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}

	if ( newstheme_get_mod( 'single_related' ) ) {
		get_template_part( 'template-parts/content/related' );
	}
endwhile;

newstheme_layout_close();
get_footer();
