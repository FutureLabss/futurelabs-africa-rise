<?php
/**
 * Block-editor sidebar assets.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Admin;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Loads the FutureLabs AI SEO sidebar in the block editor for public post types.
 */
class EditorAssets implements Module {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue' ) );
	}

	/**
	 * Enqueue the sidebar.
	 */
	public function enqueue(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'post' !== $screen->base || ! $screen->post_type ) {
			return;
		}
		$type = get_post_type_object( $screen->post_type );
		if ( ! $type || ! $type->public || 'attachment' === $type->name ) {
			return;
		}
		$asset_file = FLSEO_DIR . 'build/editor/index.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;
		wp_enqueue_script( 'flseo-editor', FLSEO_URL . 'build/editor/index.js', $asset['dependencies'], $asset['version'], true );
		wp_set_script_translations( 'flseo-editor', 'futurelabs-ai-seo', FLSEO_DIR . 'languages' );
		if ( file_exists( FLSEO_DIR . 'build/editor/index.css' ) ) {
			wp_enqueue_style( 'flseo-editor', FLSEO_URL . 'build/editor/index.css', array(), $asset['version'] );
		}
		$settings = $this->c->get( Settings::class );
		$post     = get_post();
		$post_id  = $post instanceof \WP_Post && current_user_can( 'edit_post', $post->ID ) ? (int) $post->ID : 0;
		wp_add_inline_script(
			'flseo-editor',
			'window.flseoEditor = ' . wp_json_encode(
				array(
					'restRoot'        => esc_url_raw( rest_url( 'flseo/v1/' ) ),
					'siteName'        => wp_strip_all_tags( get_bloginfo( 'name' ) ),
					'siteUrl'         => home_url( '/' ),
					'separator'       => (string) $settings->get( 'title_separator', '|' ),
					'titleTemplate'   => (string) $settings->post_type( $screen->post_type )['title'],
					'defaultOgImage'  => esc_url_raw( (string) $settings->get( 'default_og_image' ) ),
					'hardChecklist'   => (bool) $settings->get( 'hard_checklist' ),
					'aiEnabled'       => (bool) $settings->get( 'ai_enabled' ),
					'schemaTypes'     => \FutureLabs\AISEO\Schema\Types::selectable(),
					'noindex'         => $post_id ? '1' === (string) get_post_meta( $post_id, '_flseo_noindex', true ) : false,
					'defaultCategory' => (int) get_option( 'default_category', 1 ),
					'variables'       => \FutureLabs\AISEO\Meta\Variables::supported(),
				)
			) . ';',
			'before'
		);
	}
}
