<?php
/**
 * Minimal Claude Messages API client over the WordPress HTTP API.
 *
 * The official Anthropic PHP SDK is intentionally not used: it pulls Guzzle/PSR
 * dependencies that conflict with other plugins and bypasses `pre_http_request`,
 * which tests and site owners rely on to observe or block outbound calls.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Ai;

use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Builds and sends one-shot requests to POST /v1/messages.
 */
class ClaudeClient extends Provider {

	public const ENDPOINT      = 'https://api.anthropic.com/v1/messages';
	public const API_VERSION   = '2023-06-01';
	public const DEFAULT_MODEL = 'claude-opus-5-5';
	public const FALLBACK_BETA = 'server-side-fallback-2026-07-01';
	public const KEY_OPTION    = 'flseo_ai_key';
	public const MAX_TOKENS    = 1024;

	/**
	 * Image types the Messages API accepts.
	 */
	public const IMAGE_TYPES = array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' );

	/**
	 * Provider ID.
	 */
	public function id(): string {
		return 'anthropic';
	}

	/**
	 * Service name.
	 */
	public function label(): string {
		return 'Claude';
	}

	/**
	 * Key option.
	 */
	public function key_option(): string {
		return self::KEY_OPTION;
	}

	/**
	 * Image types.
	 *
	 * @return array<int, string>
	 */
	public function image_types(): array {
		return self::IMAGE_TYPES;
	}

	/**
	 * Models offered in settings (ID => label).
	 *
	 * @return array<string, string>
	 */
	public static function models(): array {
		return array(
			'claude-opus-5-5'   => __( 'Claude Opus 5.5 (best quality)', 'futurelabs-ai-seo' ),
			'claude-sonnet-5-5' => __( 'Claude Sonnet 5.5 (balanced)', 'futurelabs-ai-seo' ),
			'claude-haiku-5-5'  => __( 'Claude Haiku 5.5 (fastest, lowest cost)', 'futurelabs-ai-seo' ),
		);
	}

	/**
	 * Suggested models.
	 *
	 * @return array<string, string>
	 */
	public function suggested_models(): array {
		return self::models();
	}

	/**
	 * Configured model ID, falling back to the default for empty or malformed values.
	 */
	public function model(): string {
		$model = trim( (string) $this->c->get( Settings::class )->get( 'ai_model', '' ) );
		return preg_match( '/^claude-[a-z0-9][a-z0-9.\-]{1,62}$/', $model ) ? $model : self::DEFAULT_MODEL;
	}

	/**
	 * Build the request body.
	 *
	 * Deliberately omits `thinking`, `temperature`, `top_p`, `budget_tokens` and any
	 * assistant prefill: current models reject them with HTTP 400.
	 *
	 * @param string                                              $system System prompt.
	 * @param string                                              $text   User text.
	 * @param array<int, array{media_type: string, data: string}> $images Base64 images, placed before the text.
	 * @return array<string, mixed>
	 */
	public function body( string $system, string $text, array $images = array() ): array {
		$content = array();
		foreach ( $images as $image ) {
			$content[] = array(
				'type'   => 'image',
				'source' => array(
					'type'       => 'base64',
					'media_type' => $image['media_type'],
					'data'       => $image['data'],
				),
			);
		}
		$content[] = array(
			'type' => 'text',
			'text' => $text,
		);
		$body      = array(
			'model'         => $this->model(),
			'max_tokens'    => self::MAX_TOKENS,
			'system'        => $system,
			'messages'      => array(
				array(
					'role'    => 'user',
					'content' => $content,
				),
			),
			'output_config' => array( 'effort' => 'low' ),
		);
		if ( $this->use_fallback() ) {
			$body['fallbacks'] = 'default';
		}
		return $body;
	}

	/**
	 * HTTP request (headers contain the key; never log them).
	 *
	 * @param string                                              $system System prompt.
	 * @param string                                              $text   User text.
	 * @param array<int, array{media_type: string, data: string}> $images Images.
	 * @param string                                              $key    API key.
	 * @return array{url: string, args: array<string, mixed>}
	 */
	protected function request( string $system, string $text, array $images, string $key ): array {
		$headers = array(
			'x-api-key'         => $key,
			'anthropic-version' => self::API_VERSION,
			'content-type'      => 'application/json',
		);
		if ( $this->use_fallback() ) {
			$headers['anthropic-beta'] = self::FALLBACK_BETA;
		}
		return array(
			'url'  => self::ENDPOINT,
			'args' => array(
				'headers' => $headers,
				'body'    => (string) wp_json_encode( $this->body( $system, $text, $images ) ),
			),
		);
	}

	/**
	 * Whether server-side refusal fallback is requested.
	 *
	 * On by default: if the chosen model declines a request, Anthropic may route it to
	 * another model instead of returning a refusal. Return false from the
	 * `flseo_ai_server_fallback` filter to turn this off.
	 */
	private function use_fallback(): bool {
		return (bool) apply_filters( 'flseo_ai_server_fallback', true );
	}

	/**
	 * Read a 200 response: refusals save nothing; only text blocks are kept.
	 *
	 * @param array<string, mixed> $data Decoded body.
	 * @return array{text: string, stop_reason: string, truncated: bool}|\WP_Error
	 */
	protected function parse( array $data ) {
		$stop_reason = (string) ( $data['stop_reason'] ?? '' );
		if ( 'refusal' === $stop_reason ) {
			return $this->refusal( is_array( $data['stop_details'] ?? null ) ? (string) ( $data['stop_details']['category'] ?? '' ) : '' );
		}
		$text = '';
		foreach ( (array) ( $data['content'] ?? array() ) as $block ) {
			if ( is_array( $block ) && 'text' === ( $block['type'] ?? '' ) ) {
				$text .= (string) ( $block['text'] ?? '' );
			}
		}
		return array(
			'text'        => trim( $text ),
			'stop_reason' => $stop_reason,
			'truncated'   => 'max_tokens' === $stop_reason,
		);
	}
}
