<?php
/**
 * Admin notices for conflicts, with one-click actions.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Conflicts;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Shows conflict notices and handles "Disable FutureLabs AI SEO output".
 */
class Notices implements Module {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'admin_notices', array( $this, 'render' ) );
		add_action( 'admin_post_flseo_disable_output', array( $this, 'disable_output' ) );
		add_action( 'admin_post_flseo_dismiss_notice', array( $this, 'dismiss' ) );
		add_action( 'flseo_probe_frontend', array( $this, 'run_probe' ) );
		add_action( 'flseo_activated', array( $this, 'queue_probe' ) );
		add_action( 'activated_plugin', array( $this, 'queue_probe' ) );
	}

	/**
	 * Queue a background frontend probe.
	 */
	public function queue_probe(): void {
		$this->c->get( Queue::class )->at( time() + 30, 'flseo_probe_frontend' );
	}

	/**
	 * Run the probe (job handler).
	 */
	public function run_probe(): void {
		$this->c->get( FrontendProbe::class )->run();
	}

	/**
	 * Render notices.
	 */
	public function render(): void {
		if ( ! Capabilities::can( Capabilities::SETTINGS ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && ! in_array( $screen->base, array( 'dashboard', 'plugins', 'toplevel_page_futurelabs-ai-seo', 'options-reading' ), true ) && ! str_contains( (string) $screen->id, 'futurelabs-ai-seo' ) ) {
			return;
		}
		$detector  = $this->c->get( Detector::class );
		$dismissed = (array) get_user_meta( get_current_user_id(), 'flseo_dismissed_notices', true );

		if ( '0' === (string) get_option( 'blog_public' ) && ! in_array( 'discourage', $dismissed, true ) ) {
			$this->notice(
				'error',
				__( 'Search engines are discouraged from indexing this site (Settings → Reading). No page can be indexed until this is turned off.', 'futurelabs-ai-seo' ),
				array( array( admin_url( 'options-reading.php' ), __( 'Open Reading settings', 'futurelabs-ai-seo' ), 'primary' ) ),
				'discourage'
			);
		}

		$settings = $this->c->get( Settings::class );
		$output   = $settings->get( 'output_title' ) || $settings->get( 'output_description' ) || $settings->get( 'output_canonical' ) || $settings->get( 'output_robots' ) || $settings->get( 'output_social' );
		foreach ( $detector->active_seo_plugins() as $plugin ) {
			if ( ! $output || in_array( 'seo_' . $plugin['slug'], $dismissed, true ) ) {
				continue;
			}
			$actions = array(
				array(
					wp_nonce_url( admin_url( 'admin-post.php?action=flseo_disable_output' ), 'flseo_disable_output' ),
					__( 'Disable FutureLabs AI SEO output', 'futurelabs-ai-seo' ),
					'secondary',
				),
			);
			if ( '' !== $plugin['importer'] ) {
				$actions[] = array(
					admin_url( 'admin.php?page=futurelabs-ai-seo#/import?source=' . rawurlencode( $plugin['importer'] ) . '&deactivate=' . rawurlencode( $plugin['slug'] ) ),
					/* translators: %s: plugin name. */
					sprintf( __( 'Import from %s and deactivate it', 'futurelabs-ai-seo' ), $plugin['name'] ),
					'primary',
				);
			}
			$this->notice(
				'warning',
				/* translators: %s: plugin name. */
				sprintf( __( '%s is active alongside FutureLabs AI SEO. Both may print titles, descriptions, canonical and robots tags, which can confuse search engines. Choose one source of SEO metadata.', 'futurelabs-ai-seo' ), $plugin['name'] ),
				$actions,
				'seo_' . $plugin['slug']
			);
		}

		$probe = get_option( FrontendProbe::OPTION, array() );
		if ( is_array( $probe ) && ! empty( $probe['duplicates'] ) && ! in_array( 'probe_' . md5( (string) wp_json_encode( $probe['duplicates'] ) ), $dismissed, true ) ) {
			$sources = array();
			foreach ( (array) $probe['pages'] as $page ) {
				$sources = array_merge( $sources, (array) ( $page['sources'] ?? array() ) );
			}
			$sources = array_diff( array_unique( $sources ), array( 'FutureLabs AI SEO' ) );
			$this->notice(
				'warning',
				sprintf(
					/* translators: 1: duplicated tags, 2: detected sources. */
					__( 'FutureLabs AI SEO found duplicate tags in your rendered pages: %1$s. Other output detected: %2$s. Review the theme, page builder and social plugins, or turn off overlapping output.', 'futurelabs-ai-seo' ),
					implode( ', ', (array) $probe['duplicates'] ),
					$sources ? implode( ', ', $sources ) : __( 'theme or unknown plugin', 'futurelabs-ai-seo' )
				),
				array( array( admin_url( 'admin.php?page=futurelabs-ai-seo#/settings' ), __( 'Review output settings', 'futurelabs-ai-seo' ), 'secondary' ) ),
				'probe_' . md5( (string) wp_json_encode( $probe['duplicates'] ) )
			);
		}

		if ( ! current_theme_supports( 'title-tag' ) && $settings->get( 'output_title' ) && ! in_array( 'title_tag', $dismissed, true ) ) {
			$this->notice(
				'info',
				__( 'Your theme prints its own <title> tag, so FutureLabs AI SEO titles may not appear. Ask your theme developer to add title-tag support.', 'futurelabs-ai-seo' ),
				array(),
				'title_tag'
			);
		}
	}

	/**
	 * Print a notice.
	 *
	 * @param string                                        $type    notice type.
	 * @param string                                        $message Message.
	 * @param array<int, array{0:string,1:string,2:string}> $actions Buttons [url, label, style].
	 * @param string                                        $id      Dismiss id.
	 */
	private function notice( string $type, string $message, array $actions, string $id ): void {
		echo '<div class="notice notice-' . esc_attr( $type ) . '"><p><strong>FutureLabs AI SEO:</strong> ' . esc_html( $message ) . '</p>';
		echo '<p>';
		foreach ( $actions as $action ) {
			printf( '<a class="button button-%1$s" href="%2$s">%3$s</a> ', esc_attr( $action[2] ), esc_url( $action[0] ), esc_html( $action[1] ) );
		}
		printf(
			'<a class="button-link" href="%1$s">%2$s</a>',
			esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=flseo_dismiss_notice&notice=' . rawurlencode( $id ) ), 'flseo_dismiss_notice' ) ),
			esc_html__( 'Dismiss', 'futurelabs-ai-seo' )
		);
		echo '</p></div>';
	}

	/**
	 * Turn off all FutureLabs AI SEO head output.
	 */
	public function disable_output(): void {
		if ( ! Capabilities::can( Capabilities::SETTINGS ) ) {
			wp_die( esc_html__( 'You are not allowed to change FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), 403 );
		}
		check_admin_referer( 'flseo_disable_output' );
		$this->c->get( Settings::class )->update(
			array(
				'output_title'       => false,
				'output_description' => false,
				'output_canonical'   => false,
				'output_robots'      => false,
				'output_social'      => false,
				'output_schema'      => false,
			)
		);
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=futurelabs-ai-seo' ) );
		exit;
	}

	/**
	 * Dismiss a notice for the current user.
	 */
	public function dismiss(): void {
		check_admin_referer( 'flseo_dismiss_notice' );
		$id        = isset( $_GET['notice'] ) ? sanitize_text_field( wp_unslash( $_GET['notice'] ) ) : '';
		$dismissed = (array) get_user_meta( get_current_user_id(), 'flseo_dismissed_notices', true );
		if ( '' !== $id ) {
			$dismissed[] = $id;
			update_user_meta( get_current_user_id(), 'flseo_dismissed_notices', array_values( array_unique( array_filter( $dismissed ) ) ) );
		}
		wp_safe_redirect( wp_get_referer() ?: admin_url() );
		exit;
	}
}
