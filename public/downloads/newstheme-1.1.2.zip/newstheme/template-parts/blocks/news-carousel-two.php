<?php
/**
 * Block: news carousel, layout two — text over the image.
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args.
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="nt-block nt-block--carousel nt-block--carousel-two" <?php echo $args['title'] ? 'aria-labelledby="' . esc_attr( $args['id'] ) . '-title"' : ''; ?>>
	<?php newstheme_block_heading( $args['title'], $args['id'] ); ?>
	<div class="nt-carousel" data-nt-carousel data-loop<?php echo $args['autoplay'] ? ' data-autoplay="' . esc_attr( $args['autoplay'] * 1000 ) . '"' : ''; ?> style="--nt-per-view: <?php echo (int) $args['columns']; ?>" role="region" aria-roledescription="<?php esc_attr_e( 'carousel', 'newstheme' ); ?>" aria-label="<?php echo esc_attr( $args['title'] ? $args['title'] : __( 'Posts', 'newstheme' ) ); ?>">
		<div class="nt-carousel__track">
			<?php
			while ( $args['loop']->have_posts() ) :
				$args['loop']->the_post();
				?>
				<article <?php post_class( 'nt-carousel__slide nt-overlay-card nt-overlay-card--tile' ); ?> aria-roledescription="<?php esc_attr_e( 'slide', 'newstheme' ); ?>">
					<?php newstheme_post_thumb( 'newstheme-medium' ); ?>
					<div class="nt-overlay-card__body">
						<?php
						newstheme_post_categories();
						newstheme_post_title( 'h3' );
						?>
						<div class="nt-overlay-card__top">
							<?php newstheme_posted_on( null, true ); ?>
						</div>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
		<?php
		if ( $args['arrows'] ) {
			get_template_part( 'template-parts/blocks/carousel-controls' );
		}
		?>
	</div>
</section>
