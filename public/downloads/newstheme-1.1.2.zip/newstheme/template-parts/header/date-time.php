<?php
/**
 * Header element: current date and live clock (site timezone).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_now = time();
?>
<div class="nt-date-time">
	<?php if ( newstheme_get_mod( 'show_date' ) ) : ?>
		<span class="nt-date"><?php echo esc_html( wp_date( 'l, F j, Y', $newstheme_now ) ); ?></span>
	<?php endif; ?>
	<?php if ( newstheme_get_mod( 'show_time' ) ) : ?>
		<time class="nt-clock" data-nt-clock data-now="<?php echo esc_attr( $newstheme_now ); ?>" data-offset="<?php echo esc_attr( (int) ( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ); ?>">
			<?php echo esc_html( wp_date( 'g:i:s A', $newstheme_now ) ); ?>
		</time>
	<?php endif; ?>
</div>
