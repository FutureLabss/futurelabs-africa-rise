<?php
/**
 * Per-post SEO and opportunity fields: registration, classic meta box and saving.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Meta;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Registers `_flseo_*` post meta and the back-compat meta box for the classic editor.
 */
class PostMeta implements Module {

	public const OPP_STATUSES = array( 'open', 'closing-soon', 'closed', 'rolling' );

	/**
	 * Expiry actions that change indexing site-wide and so need the data capability.
	 */
	public const PRIVILEGED_EXPIRY = array( 'noindex', 'redirect' );

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Meta keys (without prefix) and their sanitizer names.
	 *
	 * @return array<string, string>
	 */
	public static function fields(): array {
		return array(
			'title'             => 'template',
			'description'       => 'template',
			'canonical'         => 'url',
			'og_title'          => 'template',
			'og_description'    => 'template',
			'og_image'          => 'url',
			'focus_topic'       => 'text',
			'schema_type'       => 'schema_type',
			'schema_overrides'  => 'json',
			'opp_deadline'      => 'date',
			'opp_status'        => 'opp_status',
			'opp_funding'       => 'text',
			'opp_level'         => 'text',
			'opp_region'        => 'text',
			'opp_source_url'    => 'url',
			'opp_expiry_action' => 'expiry_action',
		);
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'register_meta' ), 20 );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'save_post', array( $this, 'save' ), 10, 2 );
		add_action( 'admin_notices', array( $this, 'notices' ) );
		add_action( 'init', array( $this, 'register_rest_filters' ), 21 );
	}

	/**
	 * REST filters for every public post type: hide `_flseo_*` meta from people who cannot
	 * edit the post, and stop non-administrators scheduling a noindex or redirect expiry.
	 */
	public function register_rest_filters(): void {
		foreach ( $this->post_types() as $type ) {
			add_filter( "rest_prepare_{$type}", array( $this, 'filter_rest_meta' ), 10, 2 );
			add_filter( "rest_pre_insert_{$type}", array( $this, 'guard_rest_expiry' ), 10, 2 );
		}
	}

	/**
	 * Remove `_flseo_*` meta from REST responses unless the user can edit the post.
	 *
	 * @param mixed $response Response.
	 * @param mixed $post     Post.
	 * @return mixed
	 */
	public function filter_rest_meta( $response, $post ) {
		if ( ! $response instanceof \WP_REST_Response || ! $post instanceof \WP_Post || current_user_can( 'edit_post', $post->ID ) ) {
			return $response;
		}
		$data = $response->get_data();
		if ( is_array( $data ) && isset( $data['meta'] ) && is_array( $data['meta'] ) ) {
			foreach ( array_keys( $data['meta'] ) as $key ) {
				if ( str_starts_with( (string) $key, '_flseo_' ) ) {
					unset( $data['meta'][ $key ] );
				}
			}
			$response->set_data( $data );
		}
		return $response;
	}

	/**
	 * Reject REST writes that set a noindex or redirect expiry action without the data capability.
	 *
	 * @param mixed            $prepared Prepared post.
	 * @param \WP_REST_Request $request  Request.
	 * @return mixed
	 */
	public function guard_rest_expiry( $prepared, $request ) {
		if ( is_wp_error( $prepared ) || ! $request instanceof \WP_REST_Request ) {
			return $prepared;
		}
		$meta = $request->get_param( 'meta' );
		if ( ! is_array( $meta ) || ! array_key_exists( '_flseo_opp_expiry_action', $meta ) ) {
			return $prepared;
		}
		$value   = is_scalar( $meta['_flseo_opp_expiry_action'] ) ? (string) $meta['_flseo_opp_expiry_action'] : '';
		$post_id = absint( $request['id'] ?? 0 );
		$current = $post_id ? (string) get_post_meta( $post_id, '_flseo_opp_expiry_action', true ) : '';
		if ( ! self::may_set_expiry( $value, $current ) ) {
			return new \WP_Error( 'rest_cannot_update', __( 'Only administrators can set a noindex or redirect expiry action.', 'futurelabs-ai-seo' ), array( 'status' => rest_authorization_required_code() ) );
		}
		return $prepared;
	}

	/**
	 * Whether the current user may change the expiry action from $current to $value.
	 *
	 * @param string $value   New value.
	 * @param string $current Stored value.
	 */
	public static function may_set_expiry( string $value, string $current ): bool {
		return $value === $current || ! in_array( $value, self::PRIVILEGED_EXPIRY, true ) || Capabilities::can( Capabilities::DATA );
	}

	/**
	 * Register meta for every public post type.
	 */
	public function register_meta(): void {
		foreach ( $this->post_types() as $type ) {
			foreach ( self::fields() as $key => $kind ) {
				register_post_meta(
					$type,
					'_flseo_' . $key,
					array(
						'type'              => 'string',
						'single'            => true,
						'show_in_rest'      => true,
						'default'           => '',
						'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
							return current_user_can( 'edit_post', (int) $post_id );
						},
						'sanitize_callback' => static function ( $value ) use ( $kind ) {
							return self::sanitize( $kind, $value );
						},
					)
				);
			}
			// Noindex is changed through the guarded save path or the bulk API, never raw REST meta.
			register_post_meta(
				$type,
				'_flseo_noindex',
				array(
					'type'          => 'string',
					'single'        => true,
					'show_in_rest'  => false,
					'auth_callback' => static function ( $allowed, $meta_key, $post_id ) {
						return current_user_can( 'edit_post', (int) $post_id );
					},
				)
			);
		}
	}

	/**
	 * Sanitize a value by field kind. Invalid values become empty strings.
	 *
	 * @param string $kind  Field kind.
	 * @param mixed  $value Raw value.
	 */
	public static function sanitize( string $kind, $value ): string {
		$value = is_scalar( $value ) ? (string) $value : '';
		switch ( $kind ) {
			case 'url':
				$url = esc_url_raw( trim( $value ) );
				return ( '' !== $url && \FutureLabs\AISEO\Core\Url::is_valid( $url ) ) ? $url : '';
			case 'date':
				$value = trim( $value );
				if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m ) || ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
					return '';
				}
				return $value;
			case 'opp_status':
				return in_array( $value, self::OPP_STATUSES, true ) ? $value : '';
			case 'expiry_action':
				return in_array( $value, array( '', 'update', 'notice', 'noindex', 'redirect' ), true ) ? $value : '';
			case 'schema_type':
				return in_array( $value, \FutureLabs\AISEO\Schema\Types::selectable(), true ) ? $value : '';
			case 'json':
				return \FutureLabs\AISEO\Schema\Overrides::sanitize( $value );
			case 'template':
				return self::sanitize_template( $value );
		}
		return sanitize_text_field( $value );
	}

	/**
	 * Sanitize text that may contain %variables%. sanitize_text_field() would strip
	 * sequences such as "%ca" and "%da" as percent-encoded octets and break %category%/%date%.
	 *
	 * @param string $value Raw value.
	 */
	public static function sanitize_template( string $value ): string {
		$value = wp_check_invalid_utf8( $value );
		$value = wp_strip_all_tags( $value, true );
		return trim( (string) preg_replace( '/[\r\n\t ]+/', ' ', $value ) );
	}

	/**
	 * Public post types that get fields.
	 *
	 * @return array<int, string>
	 */
	private function post_types(): array {
		return array_values( array_diff( get_post_types( array( 'public' => true ), 'names' ), array( 'attachment' ) ) );
	}

	/**
	 * Add the classic-editor meta box (hidden in the block editor, which uses the sidebar).
	 */
	public function add_meta_box(): void {
		foreach ( $this->post_types() as $type ) {
			add_meta_box(
				'flseo-meta',
				__( 'FutureLabs AI SEO: SEO and opportunity details', 'futurelabs-ai-seo' ),
				array( $this, 'render' ),
				$type,
				'normal',
				'high',
				array( '__back_compat_meta_box' => true )
			);
		}
	}

	/**
	 * Render the meta box.
	 *
	 * @param \WP_Post $post Post.
	 */
	public function render( \WP_Post $post ): void {
		wp_nonce_field( 'flseo_save_post', 'flseo_nonce' );
		$labels = array(
			'title'          => sprintf(
				/* translators: %s: list of template variables such as %title%. */
				__( 'SEO title (supports %s)', 'futurelabs-ai-seo' ),
				implode( ', ', array_keys( Variables::supported() ) )
			),
			'description'    => __( 'Meta description (120–160 characters recommended)', 'futurelabs-ai-seo' ),
			'focus_topic'    => __( 'Focus topic', 'futurelabs-ai-seo' ),
			'canonical'      => __( 'Canonical URL (leave empty for this page)', 'futurelabs-ai-seo' ),
			'og_title'       => __( 'Social title', 'futurelabs-ai-seo' ),
			'og_description' => __( 'Social description', 'futurelabs-ai-seo' ),
			'og_image'       => __( 'Social image URL', 'futurelabs-ai-seo' ),
			'opp_deadline'   => __( 'Opportunity deadline', 'futurelabs-ai-seo' ),
			'opp_funding'    => __( 'Funding', 'futurelabs-ai-seo' ),
			'opp_level'      => __( 'Level (e.g. undergraduate, masters)', 'futurelabs-ai-seo' ),
			'opp_region'     => __( 'Eligible region', 'futurelabs-ai-seo' ),
			'opp_source_url' => __( 'Official source URL', 'futurelabs-ai-seo' ),
		);
		echo '<div class="flseo-fields">';
		foreach ( $labels as $key => $label ) {
			$value = (string) get_post_meta( $post->ID, '_flseo_' . $key, true );
			$id    = 'flseo_' . $key;
			printf( '<p><label for="%1$s"><strong>%2$s</strong></label><br />', esc_attr( $id ), esc_html( $label ) );
			if ( 'description' === $key ) {
				printf( '<textarea class="widefat" rows="3" id="%1$s" name="%1$s">%2$s</textarea>', esc_attr( $id ), esc_textarea( $value ) );
			} elseif ( 'opp_deadline' === $key ) {
				printf( '<input type="date" id="%1$s" name="%1$s" value="%2$s" />', esc_attr( $id ), esc_attr( $value ) );
			} else {
				$type = in_array( $key, array( 'canonical', 'og_image', 'opp_source_url' ), true ) ? 'url' : 'text';
				printf( '<input class="widefat" type="%3$s" id="%1$s" name="%1$s" value="%2$s" />', esc_attr( $id ), esc_attr( $value ), esc_attr( $type ) );
			}
			echo '</p>';
		}
		$status = (string) get_post_meta( $post->ID, '_flseo_opp_status', true );
		echo '<p><label for="flseo_opp_status"><strong>' . esc_html__( 'Opportunity status', 'futurelabs-ai-seo' ) . '</strong></label><br /><select id="flseo_opp_status" name="flseo_opp_status"><option value="">' . esc_html__( 'Not an opportunity / not set', 'futurelabs-ai-seo' ) . '</option>';
		foreach ( self::OPP_STATUSES as $option ) {
			printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $option ), selected( $status, $option, false ), esc_html( ucwords( str_replace( '-', ' ', $option ) ) ) );
		}
		echo '</select></p>';
		$schema = (string) get_post_meta( $post->ID, '_flseo_schema_type', true );
		echo '<p><label for="flseo_schema_type"><strong>' . esc_html__( 'Schema type', 'futurelabs-ai-seo' ) . '</strong></label><br /><select id="flseo_schema_type" name="flseo_schema_type"><option value="">' . esc_html__( 'Post type default', 'futurelabs-ai-seo' ) . '</option>';
		foreach ( \FutureLabs\AISEO\Schema\Types::selectable() as $option ) {
			printf( '<option value="%1$s" %2$s>%1$s</option>', esc_attr( $option ), selected( $schema, $option, false ) );
		}
		echo '</select></p>';
		$noindex = '1' === (string) get_post_meta( $post->ID, '_flseo_noindex', true );
		echo '<p><label><input type="checkbox" name="flseo_noindex" value="1" ' . checked( $noindex, true, false ) . ' /> ' . esc_html__( 'Ask search engines not to index this page (noindex)', 'futurelabs-ai-seo' ) . '</label></p>';
		echo '<p><label for="flseo_noindex_confirmation">' . esc_html__( 'Confirmation phrase (only needed if FutureLabs AI SEO asks for it)', 'futurelabs-ai-seo' ) . '</label><br /><input class="regular-text" id="flseo_noindex_confirmation" name="flseo_noindex_confirmation" autocomplete="off" /></p>';
		echo '<p class="description">' . esc_html__( 'A passed deadline does not remove a page from search. FutureLabs AI SEO marks it closed after the grace period and adds a visible notice.', 'futurelabs-ai-seo' ) . '</p>';
		echo '</div>';
		$checklist = $this->c->get( \FutureLabs\AISEO\Opportunity\Checklist::class );
		echo '<hr /><h4>' . esc_html__( 'Publishing checklist', 'futurelabs-ai-seo' ) . '</h4><ul>';
		foreach ( $checklist->evaluate( $post ) as $item ) {
			printf( '<li>%1$s %2$s</li>', $item['ok'] ? '&#10003;' : '&#9675;', esc_html( $item['label'] ) );
		}
		echo '</ul>';
	}

	/**
	 * Save meta box fields.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post.
	 */
	public function save( int $post_id, \WP_Post $post ): void {
		if ( ! isset( $_POST['flseo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['flseo_nonce'] ) ), 'flseo_save_post' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		foreach ( self::fields() as $key => $kind ) {
			$field = 'flseo_' . $key;
			if ( ! isset( $_POST[ $field ] ) ) {
				continue;
			}
			$value = self::sanitize( $kind, wp_unslash( $_POST[ $field ] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized by kind.
			if ( 'opp_expiry_action' === $key && ! self::may_set_expiry( $value, (string) get_post_meta( $post_id, '_flseo_opp_expiry_action', true ) ) ) {
				continue;
			}
			if ( '' === $value ) {
				delete_post_meta( $post_id, '_flseo_' . $key );
			} else {
				update_post_meta( $post_id, '_flseo_' . $key, $value );
			}
		}
		$want    = isset( $_POST['flseo_noindex'] );
		$current = '1' === (string) get_post_meta( $post_id, '_flseo_noindex', true );
		if ( $want && ! $current ) {
			$confirmation = isset( $_POST['flseo_noindex_confirmation'] ) ? sanitize_text_field( wp_unslash( $_POST['flseo_noindex_confirmation'] ) ) : '';
			$verdict      = $this->c->get( NoindexGuard::class )->check_posts( array( $post_id ), $confirmation );
			if ( ! $verdict['allowed'] ) {
				set_transient( 'flseo_noindex_blocked_' . get_current_user_id(), $verdict, 5 * MINUTE_IN_SECONDS );
				return;
			}
			$this->c->get( \FutureLabs\AISEO\Bulk\AuditLog::class )->record_single( 'noindex', $post_id, '_flseo_noindex', '', '1' );
			update_post_meta( $post_id, '_flseo_noindex', '1' );
		} elseif ( ! $want && $current ) {
			$this->c->get( \FutureLabs\AISEO\Bulk\AuditLog::class )->record_single( 'index', $post_id, '_flseo_noindex', '1', '' );
			delete_post_meta( $post_id, '_flseo_noindex' );
		}
	}

	/**
	 * Show the blocked-noindex notice.
	 */
	public function notices(): void {
		if ( ! Capabilities::can( Capabilities::EDITOR ) ) {
			return;
		}
		$key     = 'flseo_noindex_blocked_' . get_current_user_id();
		$verdict = get_transient( $key );
		if ( ! is_array( $verdict ) ) {
			return;
		}
		delete_transient( $key );
		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: 1: projected noindexed pages, 2: published pages, 3: confirmation phrase. */
					__( 'Noindex was not applied: it would leave %1$d of %2$d published pages noindexed. To continue, save again and type: %3$s', 'futurelabs-ai-seo' ),
					(int) $verdict['projected'],
					(int) $verdict['published'],
					(string) $verdict['phrase']
				)
			)
		);
	}
}
