<?php
/**
 * Site header.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="nt-skip-link screen-reader-text" href="#nt-main"><?php esc_html_e( 'Skip to content', 'newstheme' ); ?></a>
<div id="nt-page" class="nt-site">
	<?php do_action( 'newstheme_before_header' ); ?>
	<?php newstheme_render_masthead(); ?>
	<?php do_action( 'newstheme_after_header' ); ?>
	<main id="nt-main" class="nt-main" tabindex="-1">
