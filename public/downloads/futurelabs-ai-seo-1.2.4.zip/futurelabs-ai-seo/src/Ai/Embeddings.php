<?php
/**
 * Embeddings-based similarity (Voyage AI) behind the Links\SimilarityProvider interface.
 *
 * Anthropic does not offer an embeddings endpoint; Voyage AI is the provider it recommends.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Ai;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Crypto;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Links\SimilarityProvider;

defined( 'ABSPATH' ) || exit;

/**
 * Stores one vector per post in `flseo_embeddings` (keyed by a content hash so unchanged
 * posts are not re-embedded) and ranks posts by cosine similarity.
 */
class Embeddings implements SimilarityProvider {

	public const ENDPOINT         = 'https://api.voyageai.com/v1/embeddings';
	public const MODEL            = 'voyage-3.5';
	public const KEY_OPTION       = 'flseo_embeddings_key';
	public const HOOK             = 'flseo_embeddings_batch';
	public const BATCH            = 64;
	public const STATE            = 'flseo_embeddings_state';
	private const TEXT_CHARS      = 8000;
	private const SCAN_LIMIT      = 500;
	private const MAX_PAIRS_POSTS = 3000;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Provider used when a post has no vector yet.
	 *
	 * @var SimilarityProvider|null
	 */
	private ?SimilarityProvider $fallback = null;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Machine name.
	 */
	public function name(): string {
		return 'embeddings';
	}

	/**
	 * Whether embeddings are enabled and configured.
	 */
	public function available(): bool {
		$settings = $this->c->get( Settings::class );
		return (bool) $settings->get( 'ai_enabled' ) && (bool) $settings->get( 'ai_embeddings' ) && $this->c->get( Crypto::class )->has_secret( self::KEY_OPTION );
	}

	/**
	 * Filter callback for `flseo_similarity_provider`.
	 *
	 * @param mixed $provider Incoming provider.
	 * @return mixed This provider when available, otherwise the incoming one unchanged.
	 */
	public function filter_provider( $provider ) {
		if ( ! $this->available() ) {
			return $provider;
		}
		if ( $provider instanceof SimilarityProvider && $provider !== $this ) {
			$this->fallback = $provider;
		}
		return $this;
	}

	/**
	 * Most similar posts by cosine similarity. Falls back to the previous provider
	 * when the source post has no vector yet.
	 *
	 * @param int             $post_id Source post.
	 * @param int             $limit   Max results.
	 * @param array<int, int> $exclude Post IDs to skip.
	 * @return array<int, float>
	 */
	public function similar( int $post_id, int $limit = 10, array $exclude = array() ): array {
		$vectors = $this->vectors();
		if ( ! isset( $vectors[ $post_id ] ) ) {
			return $this->fallback ? $this->fallback->similar( $post_id, $limit, $exclude ) : array();
		}
		$source  = $vectors[ $post_id ];
		$exclude = array_map( 'intval', $exclude );
		$scores  = array();
		foreach ( $vectors as $id => $vector ) {
			if ( $id === $post_id || in_array( $id, $exclude, true ) ) {
				continue;
			}
			$score = self::cosine( $source, $vector );
			if ( $score > 0 ) {
				$scores[ $id ] = round( min( 1.0, $score ), 4 );
			}
		}
		arsort( $scores );
		return array_slice( $scores, 0, max( 1, $limit ), true );
	}

	/**
	 * Near-duplicate pairs at or above a cosine threshold, best first.
	 *
	 * @param float $threshold Threshold in [0,1], e.g. 0.92.
	 * @return array<int, array{a: int, b: int, score: float}>
	 */
	public function similar_pairs( float $threshold = 0.92 ): array {
		$vectors = array_slice( $this->vectors(), 0, self::MAX_PAIRS_POSTS, true );
		$ids     = array_keys( $vectors );
		$count   = count( $ids );
		$pairs   = array();
		for ( $i = 0; $i < $count; $i++ ) {
			for ( $j = $i + 1; $j < $count; $j++ ) {
				$score = self::cosine( $vectors[ $ids[ $i ] ], $vectors[ $ids[ $j ] ] );
				if ( $score >= $threshold ) {
					$pairs[] = array(
						'a'     => min( $ids[ $i ], $ids[ $j ] ),
						'b'     => max( $ids[ $i ], $ids[ $j ] ),
						'score' => round( min( 1.0, $score ), 4 ),
					);
				}
			}
		}
		usort( $pairs, static fn( $x, $y ) => $y['score'] <=> $x['score'] );
		return $pairs;
	}

	/**
	 * Cosine similarity.
	 *
	 * @param array<int, float> $a Vector.
	 * @param array<int, float> $b Vector.
	 */
	public static function cosine( array $a, array $b ): float {
		$n = min( count( $a ), count( $b ) );
		if ( 0 === $n ) {
			return 0.0;
		}
		$dot = 0.0;
		$na  = 0.0;
		$nb  = 0.0;
		for ( $i = 0; $i < $n; $i++ ) {
			$dot += $a[ $i ] * $b[ $i ];
			$na  += $a[ $i ] * $a[ $i ];
			$nb  += $b[ $i ] * $b[ $i ];
		}
		return ( $na > 0 && $nb > 0 ) ? $dot / ( sqrt( $na ) * sqrt( $nb ) ) : 0.0;
	}

	/**
	 * Stored vectors of published posts for the current model.
	 *
	 * @return array<int, array<int, float>>
	 */
	private function vectors(): array {
		global $wpdb;
		$table = Migrations::table( 'embeddings' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT e.post_id, e.vector FROM {$table} e INNER JOIN {$wpdb->posts} p ON p.ID = e.post_id WHERE e.model=%s AND p.post_status='publish' ORDER BY e.post_id ASC", self::MODEL ) );
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$vector = self::decode( (string) $row->vector );
			if ( $vector ) {
				$out[ (int) $row->post_id ] = $vector;
			}
		}
		return $out;
	}

	/**
	 * Pack a vector as base64 float32.
	 *
	 * @param array<int, float> $vector Vector.
	 */
	public static function encode( array $vector ): string {
		return base64_encode( pack( 'g*', ...array_map( 'floatval', $vector ) ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- compact storage.
	}

	/**
	 * Unpack a stored vector.
	 *
	 * @param string $stored Stored value.
	 * @return array<int, float>
	 */
	public static function decode( string $stored ): array {
		$raw = base64_decode( $stored, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- compact storage.
		if ( false === $raw || '' === $raw || 0 !== strlen( $raw ) % 4 ) {
			return array();
		}
		$values = unpack( 'g*', $raw );
		return is_array( $values ) ? array_values( array_map( 'floatval', $values ) ) : array();
	}

	/**
	 * Request embeddings for texts.
	 *
	 * @param array<int, string> $texts Texts (max 64).
	 * @return array<int, array<int, float>>|\WP_Error Vectors in input order.
	 */
	public function embed( array $texts ) {
		if ( ! $this->available() ) {
			return new \WP_Error( 'flseo_embeddings_disabled', __( 'Embeddings are turned off or no Voyage AI key is stored.', 'futurelabs-ai-seo' ) );
		}
		$texts    = array_values( array_slice( $texts, 0, self::BATCH ) );
		$response = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout' => 60,
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->c->get( Crypto::class )->get_secret( self::KEY_OPTION ),
					'Content-Type'  => 'application/json',
				),
				'body'    => (string) wp_json_encode(
					array(
						'input'      => $texts,
						'model'      => self::MODEL,
						'input_type' => 'document',
					)
				),
			)
		);
		if ( is_wp_error( $response ) ) {
			$this->c->get( Logger::class )->warning( 'Voyage AI embeddings request failed.', array( 'status' => 0 ) );
			return new \WP_Error( 'flseo_embeddings_unreachable', __( 'Could not reach Voyage AI.', 'futurelabs-ai-seo' ) );
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		$data   = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $status || ! is_array( $data ) || ! is_array( $data['data'] ?? null ) ) {
			$this->c->get( Logger::class )->warning( 'Voyage AI embeddings request failed.', array( 'status' => $status ) );
			$message = 401 === $status
				? __( 'Voyage AI rejected the embeddings API key. Check the key in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' )
				: ( 429 === $status ? __( 'Voyage AI rate limit reached. FutureLabs AI SEO will retry later.', 'futurelabs-ai-seo' ) : __( 'Voyage AI returned an error.', 'futurelabs-ai-seo' ) );
			return new \WP_Error( 'flseo_embeddings_failed', $message, array( 'api_status' => $status ) );
		}
		$out = array();
		foreach ( $data['data'] as $item ) {
			$index = (int) ( $item['index'] ?? -1 );
			if ( $index >= 0 && $index < count( $texts ) && is_array( $item['embedding'] ?? null ) ) {
				$out[ $index ] = array_map( 'floatval', $item['embedding'] );
			}
		}
		if ( count( $out ) !== count( $texts ) ) {
			return new \WP_Error( 'flseo_embeddings_failed', __( 'Voyage AI returned an incomplete response.', 'futurelabs-ai-seo' ) );
		}
		ksort( $out );
		return $out;
	}

	/**
	 * Text embedded for a post.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function text_for( \WP_Post $post ): string {
		$title = wp_strip_all_tags( html_entity_decode( get_the_title( $post ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		return $title . "\n\n" . Prompts::plain_text( $post, self::TEXT_CHARS );
	}

	/**
	 * Post types that get vectors.
	 *
	 * @return array<int, string>
	 */
	private function post_types(): array {
		$settings = $this->c->get( Settings::class );
		$types    = array();
		foreach ( get_post_types( array( 'public' => true ), 'names' ) as $type ) {
			if ( 'attachment' !== $type && $settings->post_type( $type )['index'] ) {
				$types[] = $type;
			}
		}
		return $types;
	}

	/**
	 * Start a full (re)index run.
	 */
	public function start(): void {
		if ( ! $this->available() ) {
			return;
		}
		$state           = $this->state();
		$state['cursor'] = 0;
		$state['active'] = true;
		update_option( self::STATE, $state, false );
		$this->c->get( Queue::class )->async( self::HOOK );
	}

	/**
	 * Run state.
	 *
	 * @return array{cursor: int, active: bool, pending: array<int, int>, embedded: int, last_run: string, last_error: string}
	 */
	public function state(): array {
		$stored = (array) get_option( self::STATE, array() );
		return array(
			'cursor'     => (int) ( $stored['cursor'] ?? 0 ),
			'active'     => (bool) ( $stored['active'] ?? false ),
			'pending'    => array_values( array_map( 'intval', (array) ( $stored['pending'] ?? array() ) ) ),
			'embedded'   => (int) ( $stored['embedded'] ?? 0 ),
			'last_run'   => (string) ( $stored['last_run'] ?? '' ),
			'last_error' => (string) ( $stored['last_error'] ?? '' ),
		);
	}

	/**
	 * Status for the admin UI.
	 *
	 * @return array<string, mixed>
	 */
	public function status(): array {
		global $wpdb;
		$table = Migrations::table( 'embeddings' );
		$state = $this->state();
		return array(
			'available'  => $this->available(),
			'model'      => self::MODEL,
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			'stored'     => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE model=%s", self::MODEL ) ),
			'running'    => $state['active'] || (bool) $state['pending'],
			'last_run'   => $state['last_run'],
			'last_error' => $state['last_error'],
		);
	}

	/**
	 * Job: embed up to 64 changed posts, then re-queue until done.
	 */
	public function run_batch(): void {
		if ( ! $this->available() ) {
			return;
		}
		global $wpdb;
		$state = $this->state();
		$types = $this->post_types();
		$work  = array();

		// Posts saved since the last run come first.
		foreach ( $state['pending'] as $id ) {
			$post = get_post( $id );
			if ( $post instanceof \WP_Post && 'publish' === $post->post_status && in_array( $post->post_type, $types, true ) ) {
				$work[ $id ] = $post;
			}
		}
		$state['pending'] = array();

		$scanned = 0;
		if ( $state['active'] && $types ) {
			$in     = implode( ',', array_fill( 0, count( $types ), '%s' ) );
			$queued = count( $work );
			while ( $queued < self::BATCH && $scanned < self::SCAN_LIMIT ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
				$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ($in) AND ID > %d ORDER BY ID ASC LIMIT %d", array_merge( $types, array( $state['cursor'], self::BATCH ) ) ) );
				if ( ! $ids ) {
					$state['active'] = false;
					break;
				}
				foreach ( $ids as $id ) {
					$id              = (int) $id;
					$state['cursor'] = $id;
					++$scanned;
					$post = get_post( $id );
					if ( $post instanceof \WP_Post ) {
						$work[ $id ] = $post;
					}
				}
				$queued = count( $work );
			}
		}

		$hashes  = $this->stored_hashes( array_keys( $work ) );
		$texts   = array();
		$targets = array();
		foreach ( $work as $id => $post ) {
			$text = self::text_for( $post );
			$hash = hash( 'sha256', self::MODEL . '|' . $text );
			if ( ( $hashes[ $id ] ?? '' ) === $hash ) {
				continue;
			}
			if ( count( $texts ) >= self::BATCH ) {
				$state['pending'][] = $id;
				continue;
			}
			$texts[]   = $text;
			$targets[] = array( $id, $hash );
		}

		if ( $texts ) {
			$vectors = $this->embed( $texts );
			if ( is_wp_error( $vectors ) ) {
				$state['last_error'] = $vectors->get_error_message();
				// Keep the work so a later run retries it.
				$state['pending'] = array_values( array_unique( array_merge( $state['pending'], array_column( $targets, 0 ) ) ) );
				update_option( self::STATE, $state, false );
				$this->c->get( Queue::class )->at( time() + HOUR_IN_SECONDS, self::HOOK );
				return;
			}
			foreach ( $targets as $index => $target ) {
				$this->store( $target[0], $target[1], $vectors[ $index ] );
			}
			$state['embedded']  += count( $targets );
			$state['last_error'] = '';
		}
		$state['last_run'] = current_time( 'mysql', true );
		update_option( self::STATE, $state, false );
		if ( $state['active'] || $state['pending'] ) {
			$this->c->get( Queue::class )->async( self::HOOK );
		}
	}

	/**
	 * Stored content hashes.
	 *
	 * @param array<int, int> $ids Post IDs.
	 * @return array<int, string>
	 */
	private function stored_hashes( array $ids ): array {
		if ( ! $ids ) {
			return array();
		}
		global $wpdb;
		$table = Migrations::table( 'embeddings' );
		$in    = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, content_hash FROM {$table} WHERE model=%s AND post_id IN ($in)", array_merge( array( self::MODEL ), $ids ) ) );
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$out[ (int) $row->post_id ] = (string) $row->content_hash;
		}
		return $out;
	}

	/**
	 * Save a vector.
	 *
	 * @param int               $post_id Post.
	 * @param string            $hash    Content hash.
	 * @param array<int, float> $vector  Vector.
	 */
	public function store( int $post_id, string $hash, array $vector ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->replace(
			Migrations::table( 'embeddings' ),
			array(
				'post_id'      => $post_id,
				'model'        => self::MODEL,
				'content_hash' => $hash,
				'vector'       => self::encode( $vector ),
				'updated_at'   => current_time( 'mysql', true ),
			),
			array( '%d', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Queue a published post for (re)embedding.
	 *
	 * @param int      $post_id Post.
	 * @param \WP_Post $post    Post.
	 */
	public function on_save_post( int $post_id, \WP_Post $post ): void {
		if ( wp_is_post_revision( $post_id ) || 'publish' !== $post->post_status || ! $this->available() ) {
			return;
		}
		$state = $this->state();
		if ( ! in_array( $post_id, $state['pending'], true ) ) {
			$state['pending'][] = $post_id;
			update_option( self::STATE, $state, false );
		}
		$this->c->get( Queue::class )->async( self::HOOK );
	}

	/**
	 * Start a run when embeddings get switched on.
	 *
	 * @param array<string, mixed> $settings New settings.
	 */
	public function on_settings_updated( $settings ): void {
		if ( is_array( $settings ) && ! empty( $settings['ai_embeddings'] ) && ! empty( $settings['ai_enabled'] ) && ! $this->state()['last_run'] ) {
			$this->start();
		}
	}

	/**
	 * Drop the vector of a deleted post.
	 *
	 * @param int $post_id Post.
	 */
	public function forget( int $post_id ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->delete( Migrations::table( 'embeddings' ), array( 'post_id' => $post_id ), array( '%d' ) );
	}
}
