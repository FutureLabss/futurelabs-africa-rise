<?php
/**
 * Stores PageSpeed results, runs the weekly top-pages queue and flags regressions.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Performance;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Reports\SearchData;

defined( 'ABSPATH' ) || exit;

/**
 * `flseo_perf_results` reader/writer and the `flseo_psi_top_pages` job.
 */
class Results implements Module {

	public const HOOK     = 'flseo_psi_top_pages';
	public const QUEUE    = 'flseo_psi_queue';
	public const LAST_RUN = 'flseo_psi_last_queued';
	private const PER_RUN = 2;

	/**
	 * Regression thresholds.
	 */
	public const SCORE_DROP = 10;
	public const LCP_RISE   = 0.5;
	public const CLS_RISE   = 0.05;
	public const INP_RISE   = 100;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( self::HOOK, array( $this, 'run_queue' ) );
		add_action( 'flseo_daily', array( $this, 'maybe_weekly' ) );
	}

	/**
	 * Daily check: queue the top pages once a week when a key is stored.
	 */
	public function maybe_weekly(): void {
		if ( ! $this->c->get( PsiClient::class )->has_key() ) {
			return;
		}
		$last = (int) get_option( self::LAST_RUN, 0 );
		if ( time() - $last >= WEEK_IN_SECONDS - HOUR_IN_SECONDS ) {
			$this->queue_top_pages();
		}
	}

	/**
	 * Measure one URL now and store the result.
	 *
	 * @param string $url      URL.
	 * @param string $strategy mobile|desktop.
	 * @return array<string, mixed>|\WP_Error Stored row with previous result and regressions.
	 */
	public function run( string $url, string $strategy ) {
		$metrics = $this->c->get( PsiClient::class )->run( $url, $strategy );
		if ( is_wp_error( $metrics ) ) {
			return $metrics;
		}
		$this->store( $metrics );
		foreach ( $this->latest() as $row ) {
			if ( $row['url'] === $metrics['url'] && $row['strategy'] === $metrics['strategy'] ) {
				return $row;
			}
		}
		return $metrics;
	}

	/**
	 * Insert a result.
	 *
	 * @param array<string, mixed> $metrics Metrics from PsiClient.
	 * @param string|null          $when    GMT datetime (defaults to now).
	 */
	public function store( array $metrics, ?string $when = null ): void {
		global $wpdb;
		$row     = array(
			'url_hash'   => hash( 'sha256', (string) $metrics['url'] ),
			'url'        => (string) $metrics['url'],
			'strategy'   => (string) $metrics['strategy'],
			'fetched_at' => $when ?? current_time( 'mysql', true ),
		);
		$formats = array( '%s', '%s', '%s', '%s' );
		foreach ( array(
			'lcp'   => '%f',
			'inp'   => '%f',
			'cls'   => '%f',
			'score' => '%d',
		) as $key => $format ) {
			if ( isset( $metrics[ $key ] ) && null !== $metrics[ $key ] ) {
				$row[ $key ] = $metrics[ $key ];
				$formats[]   = $format;
			}
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert( Migrations::table( 'perf_results' ), $row, $formats );
	}

	/**
	 * Latest result per URL and strategy, with the previous one and regression flags.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function latest(): array {
		global $wpdb;
		$table = Migrations::table( 'perf_results' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows    = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY fetched_at DESC, id DESC LIMIT 5000", ARRAY_A );
		$grouped = array();
		foreach ( (array) $rows as $row ) {
			$key = $row['url_hash'] . '|' . $row['strategy'];
			if ( ! isset( $grouped[ $key ] ) ) {
				$grouped[ $key ] = array( self::format( $row ), null );
			} elseif ( null === $grouped[ $key ][1] ) {
				$grouped[ $key ][1] = self::format( $row );
			}
		}
		$out = array();
		foreach ( $grouped as $pair ) {
			list( $current, $previous ) = $pair;
			$current['previous']        = $previous;
			$current['regressions']     = $previous ? self::regressions( $current, $previous ) : array();
			$out[]                      = $current;
		}
		return $out;
	}

	/**
	 * Format a DB row.
	 *
	 * @param array<string, mixed> $row Row.
	 * @return array<string, mixed>
	 */
	private static function format( array $row ): array {
		return array(
			'url'        => (string) $row['url'],
			'strategy'   => (string) $row['strategy'],
			'lcp'        => null !== $row['lcp'] ? (float) $row['lcp'] : null,
			'inp'        => null !== $row['inp'] ? (float) $row['inp'] : null,
			'cls'        => null !== $row['cls'] ? (float) $row['cls'] : null,
			'score'      => null !== $row['score'] ? (int) $row['score'] : null,
			'fetched_at' => (string) $row['fetched_at'],
		);
	}

	/**
	 * Regression flags between two results of the same URL and strategy.
	 *
	 * @param array<string, mixed> $current  Latest.
	 * @param array<string, mixed> $previous Previous.
	 * @return array<int, string> Any of score, lcp, cls, inp.
	 */
	public static function regressions( array $current, array $previous ): array {
		$flags = array();
		$both  = static fn( string $k ): bool => null !== ( $current[ $k ] ?? null ) && null !== ( $previous[ $k ] ?? null );
		if ( $both( 'score' ) && $previous['score'] - $current['score'] >= self::SCORE_DROP ) {
			$flags[] = 'score';
		}
		if ( $both( 'lcp' ) && $current['lcp'] - $previous['lcp'] >= self::LCP_RISE - 1e-9 ) {
			$flags[] = 'lcp';
		}
		if ( $both( 'cls' ) && $current['cls'] - $previous['cls'] >= self::CLS_RISE - 1e-9 ) {
			$flags[] = 'cls';
		}
		if ( $both( 'inp' ) && $current['inp'] - $previous['inp'] >= self::INP_RISE - 1e-9 ) {
			$flags[] = 'inp';
		}
		return $flags;
	}

	/**
	 * Summary for the dashboard.
	 *
	 * @param array<int, array<string, mixed>>|null $latest Latest rows (computed when null).
	 * @return array<string, mixed>
	 */
	public function summary( ?array $latest = null ): array {
		$latest  = $latest ?? $this->latest();
		$average = array();
		foreach ( PsiClient::STRATEGIES as $strategy ) {
			$scores               = array_filter( array_column( array_filter( $latest, static fn( $r ) => $r['strategy'] === $strategy ), 'score' ), 'is_int' );
			$average[ $strategy ] = $scores ? (int) round( array_sum( $scores ) / count( $scores ) ) : null;
		}
		$fetched = array_column( $latest, 'fetched_at' );
		return array(
			'measured'      => count( array_unique( array_column( $latest, 'url' ) ) ),
			'regressions'   => count( array_filter( $latest, static fn( $r ) => ! empty( $r['regressions'] ) ) ),
			'average_score' => $average,
			'last_fetched'  => $fetched ? max( $fetched ) : null,
			'queued'        => count( (array) get_option( self::QUEUE, array() ) ),
			'has_key'       => $this->c->get( PsiClient::class )->has_key(),
		);
	}

	/**
	 * Top pages: most GSC clicks in the latest period, else the most recently published posts.
	 *
	 * @param int $limit How many.
	 * @return array<int, string>
	 */
	public function top_pages( int $limit ): array {
		$limit = max( 1, $limit );
		$data  = $this->c->get( SearchData::class );
		$range = $data->latest_range();
		/**
		 * Collected URLs.
		 *
		 * @var array<int, string> $urls
		 */
		$urls = array();
		if ( '' !== $range ) {
			$totals = $data->totals( $range );
			uasort( $totals, static fn( $a, $b ) => $b['clicks'] <=> $a['clicks'] ?: $b['impressions'] <=> $a['impressions'] );
			foreach ( $totals as $row ) {
				$url = $data->url( $row['url_hash'], $row['url'] );
				if ( '' !== $url && PsiClient::is_allowed_url( $url ) && ! in_array( $url, $urls, true ) ) {
					$urls[] = $url;
				}
				if ( count( $urls ) >= $limit ) {
					return $urls;
				}
			}
		}
		$types = array_values( array_diff( get_post_types( array( 'public' => true ) ), array( 'attachment' ) ) );
		$posts = get_posts(
			array(
				'post_type'        => $types,
				'post_status'      => 'publish',
				'posts_per_page'   => $limit * 2,
				'orderby'          => 'date',
				'order'            => 'DESC',
				'fields'           => 'ids',
				'suppress_filters' => false,
			)
		);
		foreach ( $posts as $id ) {
			$url = (string) get_permalink( (int) $id );
			if ( '' !== $url && ! in_array( $url, $urls, true ) ) {
				$urls[] = $url;
			}
			if ( count( $urls ) >= $limit ) {
				break;
			}
		}
		return $urls;
	}

	/**
	 * Queue mobile and desktop runs for the top pages.
	 *
	 * @return int Jobs queued.
	 */
	public function queue_top_pages(): int {
		$limit = (int) $this->c->get( Settings::class )->get( 'psi_top_pages', 10 );
		$queue = array();
		foreach ( $this->top_pages( max( 1, min( 100, $limit ) ) ) as $url ) {
			foreach ( PsiClient::STRATEGIES as $strategy ) {
				$queue[] = array(
					'url'      => $url,
					'strategy' => $strategy,
				);
			}
		}
		update_option( self::QUEUE, $queue, false );
		update_option( self::LAST_RUN, time(), false );
		if ( $queue ) {
			$this->c->get( Queue::class )->async( self::HOOK );
		}
		return count( $queue );
	}

	/**
	 * Job: run the next queued measurements, then re-queue.
	 */
	public function run_queue(): void {
		$queue = (array) get_option( self::QUEUE, array() );
		$jobs  = $this->c->get( Queue::class );
		$count = 0;
		while ( $queue && $count < self::PER_RUN ) {
			$item   = (array) array_shift( $queue );
			$result = $this->run( (string) ( $item['url'] ?? '' ), (string) ( $item['strategy'] ?? 'mobile' ) );
			++$count;
			if ( is_wp_error( $result ) ) {
				$code = (int) ( ( (array) $result->get_error_data() )['api_status'] ?? 0 );
				if ( 429 === $code ) {
					array_unshift( $queue, $item );
					update_option( self::QUEUE, $queue, false );
					$jobs->at( time() + HOUR_IN_SECONDS, self::HOOK );
					return;
				}
				if ( 'flseo_psi_no_key' === $result->get_error_code() || 403 === $code ) {
					update_option( self::QUEUE, array(), false );
					return;
				}
			}
		}
		update_option( self::QUEUE, $queue, false );
		if ( $queue ) {
			$jobs->async( self::HOOK );
		}
	}
}
