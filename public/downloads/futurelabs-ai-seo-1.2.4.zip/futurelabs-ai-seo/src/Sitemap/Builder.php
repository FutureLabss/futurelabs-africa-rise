<?php
/**
 * Builds sitemap entries: only published, indexable, self-canonical, non-redirected URLs.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Sitemap;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Meta\CanonicalResolver;
use FutureLabs\AISEO\Meta\RobotsResolver;

defined( 'ABSPATH' ) || exit;

/**
 * Produces sub-sitemap entry lists and the sitemap index list.
 */
class Builder {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Max URLs per sub-sitemap.
	 */
	public function per_page(): int {
		return (int) $this->c->get( Settings::class )->get( 'sitemap_max_urls', 1000 );
	}

	/**
	 * Post types included in the sitemap.
	 *
	 * @return array<int, string>
	 */
	public function post_types(): array {
		$settings = $this->c->get( Settings::class );
		$types    = array();
		foreach ( get_post_types( array( 'public' => true ), 'names' ) as $type ) {
			if ( 'attachment' !== $type && $settings->post_type( $type )['index'] ) {
				$types[] = $type;
			}
		}
		return (array) apply_filters( 'flseo_sitemap_post_types', $types );
	}

	/**
	 * Taxonomies included in the sitemap.
	 *
	 * @return array<int, string>
	 */
	public function taxonomies(): array {
		$settings = $this->c->get( Settings::class );
		$out      = array();
		foreach ( get_taxonomies( array( 'public' => true ), 'names' ) as $taxonomy ) {
			if ( 'post_format' !== $taxonomy && $settings->taxonomy( $taxonomy )['index'] ) {
				$out[] = $taxonomy;
			}
		}
		return (array) apply_filters( 'flseo_sitemap_taxonomies', $out );
	}

	/**
	 * Sitemap index entries.
	 *
	 * @return array<int, array{name: string, page: int, loc: string, lastmod: string}>
	 */
	public function index(): array {
		global $wpdb;
		$entries  = array();
		$per_page = $this->per_page();
		foreach ( $this->post_types() as $type ) {
			// One pass per type: modified dates in ID order, chunked into sitemap pages in PHP.
			// A per-page OFFSET subquery took over 10 s on a 50,000-post site.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$dates = (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_modified_gmt FROM {$wpdb->posts} WHERE post_type=%s AND post_status='publish' AND post_password='' ORDER BY ID ASC", $type ) );
			foreach ( array_chunk( $dates, $per_page ) as $index => $chunk ) {
				$entries[] = array(
					'name'    => $type,
					'page'    => $index + 1,
					'loc'     => Router::url( $type, $index + 1 ),
					'lastmod' => self::w3c( (string) max( $chunk ) ),
				);
			}
			unset( $dates );
		}
		foreach ( $this->taxonomies() as $taxonomy ) {
			$count = (int) wp_count_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => true,
				)
			);
			$pages = (int) ceil( $count / $per_page );
			for ( $page = 1; $page <= $pages; $page++ ) {
				$entries[] = array(
					'name'    => $taxonomy,
					'page'    => $page,
					'loc'     => Router::url( $taxonomy, $page ),
					'lastmod' => '',
				);
			}
		}
		return $entries;
	}

	/**
	 * Entries for one sub-sitemap.
	 *
	 * @param string $name Post type or taxonomy.
	 * @param int    $page Page number.
	 * @return array<int, array{loc: string, lastmod: string, images: array<int, string>, id: int}>|null Null when the sitemap does not exist.
	 */
	public function entries( string $name, int $page ): ?array {
		if ( in_array( $name, $this->post_types(), true ) ) {
			return $this->post_entries( $name, $page );
		}
		if ( in_array( $name, $this->taxonomies(), true ) ) {
			return $this->term_entries( $name, $page );
		}
		return null;
	}

	/**
	 * Post entries.
	 *
	 * @param string $type Post type.
	 * @param int    $page Page.
	 * @return array<int, array{loc: string, lastmod: string, images: array<int, string>, id: int}>
	 */
	private function post_entries( string $type, int $page ): array {
		global $wpdb;
		$per_page = $this->per_page();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ids = array_map( 'absint', (array) $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type=%s AND post_status='publish' AND post_password='' ORDER BY ID ASC LIMIT %d OFFSET %d", $type, $per_page, ( max( 1, $page ) - 1 ) * $per_page ) ) );
		if ( ! $ids ) {
			return array();
		}
		_prime_post_caches( $ids, false, true );
		$robots     = $this->c->get( RobotsResolver::class );
		$canonical  = $this->c->get( CanonicalResolver::class );
		$images     = (bool) $this->c->get( Settings::class )->get( 'sitemap_images' );
		$candidates = array();
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post instanceof \WP_Post || ! $robots->is_indexable( $post ) || ! $canonical->is_self_canonical( $post ) ) {
				continue;
			}
			$url = (string) get_permalink( $post );
			if ( '' === $url ) {
				continue;
			}
			$candidates[ self::path_hash( $url ) ] = array(
				'loc'     => $url,
				'lastmod' => self::w3c( $post->post_modified_gmt ),
				'images'  => $images ? $this->images( $post ) : array(),
				'id'      => $id,
			);
		}
		$excluded = $this->excluded_hashes( array_keys( $candidates ) );
		return array_values( array_diff_key( $candidates, array_flip( $excluded ) ) );
	}

	/**
	 * Term entries.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param int    $page     Page.
	 * @return array<int, array{loc: string, lastmod: string, images: array<int, string>, id: int}>
	 */
	private function term_entries( string $taxonomy, int $page ): array {
		$per_page = $this->per_page();
		$terms    = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => true,
				'number'     => $per_page,
				'offset'     => ( max( 1, $page ) - 1 ) * $per_page,
				'orderby'    => 'term_id',
			)
		);
		if ( is_wp_error( $terms ) ) {
			return array();
		}
		$robots     = $this->c->get( RobotsResolver::class );
		$candidates = array();
		foreach ( $terms as $term ) {
			if ( ! $robots->for_term( $term )['index'] ) {
				continue;
			}
			$override = (string) get_term_meta( $term->term_id, '_flseo_canonical', true );
			$link     = get_term_link( $term );
			if ( is_wp_error( $link ) || ( '' !== $override && ! CanonicalResolver::same_url( $override, $link ) ) ) {
				continue;
			}
			$candidates[ self::path_hash( $link ) ] = array(
				'loc'     => $link,
				'lastmod' => '',
				'images'  => array(),
				'id'      => (int) $term->term_id,
			);
		}
		$excluded = $this->excluded_hashes( array_keys( $candidates ) );
		return array_values( array_diff_key( $candidates, array_flip( $excluded ) ) );
	}

	/**
	 * Image URLs for a post: featured image plus images attached to it.
	 *
	 * @param \WP_Post $post Post.
	 * @return array<int, string>
	 */
	private function images( \WP_Post $post ): array {
		$urls  = array();
		$thumb = (int) get_post_thumbnail_id( $post );
		if ( $thumb ) {
			$src = wp_get_attachment_image_url( $thumb, 'full' );
			if ( $src ) {
				$urls[] = $src;
			}
		}
		if ( preg_match_all( '~<img\b[^>]*\bsrc=["\']([^"\']+)["\']~i', $post->post_content, $m ) ) {
			foreach ( $m[1] as $src ) {
				if ( \FutureLabs\AISEO\Conflicts\FrontendProbe::is_own_url( $src ) ) {
					$urls[] = $src;
				}
			}
		}
		return array_slice( array_values( array_unique( $urls ) ), 0, 20 );
	}

	/**
	 * Hashes of URL paths that are redirect sources or known 404s.
	 *
	 * @param array<int, string> $hashes Candidate path hashes.
	 * @return array<int, string>
	 */
	private function excluded_hashes( array $hashes ): array {
		global $wpdb;
		if ( ! $hashes ) {
			return array();
		}
		$in        = implode( ',', array_fill( 0, count( $hashes ), '%s' ) );
		$redirects = Migrations::table( 'redirects' );
		$log       = Migrations::table( 'log_404' );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$redirected = (array) $wpdb->get_col( $wpdb->prepare( "SELECT source_hash FROM {$redirects} WHERE is_regex=0 AND source_hash IN ($in)", $hashes ) );
		$missing    = (array) $wpdb->get_col( $wpdb->prepare( "SELECT url_hash FROM {$log} WHERE ignored=0 AND url_hash IN ($in)", $hashes ) );
		// phpcs:enable
		return array_merge( $redirected, $missing );
	}

	/**
	 * Hash used by the redirects and 404 tables for a URL's path.
	 *
	 * @param string $url URL or path.
	 */
	public static function path_hash( string $url ): string {
		return hash( 'sha256', \FutureLabs\AISEO\Redirects\Rules::normalize_path( $url ) );
	}

	/**
	 * Convert a GMT MySQL datetime to W3C format.
	 *
	 * @param string $gmt Datetime.
	 */
	public static function w3c( string $gmt ): string {
		if ( '' === $gmt || '0000-00-00 00:00:00' === $gmt ) {
			return '';
		}
		$time = strtotime( $gmt . ' UTC' );
		return false === $time ? '' : gmdate( 'c', $time );
	}
}
