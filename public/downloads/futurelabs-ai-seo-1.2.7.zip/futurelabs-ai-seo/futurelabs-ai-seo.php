<?php
/**
 * Plugin Name:       FutureLabs AI SEO
 * Plugin URI:        https://opportunitylab.net/
 * Description:       Find and remove common indexing blockers, highlight weak content, manage redirects, and maintain opportunity content. Does not guarantee rankings.
 * Version:           1.2.7
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Update URI:        https://futurelabs.africa/downloads/futurelabs-ai-seo.json
 * Author:            Future Labs
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       futurelabs-ai-seo
 * Domain Path:       /languages
 *
 * @package FutureLabs AI SEO
 */

defined( 'ABSPATH' ) || exit;

define( 'FLSEO_VERSION', '1.2.7' );
define( 'FLSEO_FILE', __FILE__ );
define( 'FLSEO_DIR', plugin_dir_path( __FILE__ ) );
define( 'FLSEO_URL', plugin_dir_url( __FILE__ ) );

if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'FutureLabs AI SEO requires PHP 8.0 or newer.', 'futurelabs-ai-seo' ) . '</p></div>';
		}
	);
	return;
}

if ( ! file_exists( FLSEO_DIR . 'vendor/autoload.php' ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'FutureLabs AI SEO is missing its dependencies. Install the release zip, or run composer install in the plugin folder.', 'futurelabs-ai-seo' ) . '</p></div>';
		}
	);
	return;
}

require_once FLSEO_DIR . 'vendor/autoload.php';

// Action Scheduler must load early; it picks the newest bundled copy across plugins.
if ( file_exists( FLSEO_DIR . 'vendor/woocommerce/action-scheduler/action-scheduler.php' ) ) {
	require_once FLSEO_DIR . 'vendor/woocommerce/action-scheduler/action-scheduler.php';
}

register_activation_hook( __FILE__, array( \FutureLabs\AISEO\Core\Plugin::class, 'activate' ) );
register_deactivation_hook( __FILE__, array( \FutureLabs\AISEO\Core\Plugin::class, 'deactivate' ) );

\FutureLabs\AISEO\Core\Plugin::instance()->boot();

/**
 * Resolve a FutureLabs AI SEO service.
 *
 * @template T of object
 * @param class-string<T> $id Service class.
 * @return T
 */
function flseo( string $id ): object {
	return \FutureLabs\AISEO\Core\Plugin::instance()->container()->get( $id );
}

/**
 * Breadcrumbs for the current page as HTML: a labelled nav with an ordered
 * list, matching the BreadcrumbList structured data. Empty on the front page.
 *
 * @param array<string, mixed> $args `separator` (default "»"), `class`.
 */
function flseo_get_breadcrumbs( array $args = array() ): string {
	return flseo( \FutureLabs\AISEO\Schema\Breadcrumbs::class )->render( null, $args );
}

/**
 * Print the breadcrumbs for the current page. For themes:
 * `if ( function_exists( 'flseo_breadcrumbs' ) ) { flseo_breadcrumbs(); }`
 *
 * @param array<string, mixed> $args See flseo_get_breadcrumbs().
 */
function flseo_breadcrumbs( array $args = array() ): void {
	echo flseo_get_breadcrumbs( $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in Breadcrumbs::render().
}
