/**
 * Editor side of the FutureLabs AI SEO breadcrumbs block. The block is
 * rendered on the server; in the editor it shows a live preview.
 * @param wp
 */
( function ( wp ) {
	const { registerBlockType } = wp.blocks;
	const { createElement: el } = wp.element;
	const { __ } = wp.i18n;
	const ServerSideRender = wp.serverSideRender;

	registerBlockType( 'futurelabs-ai-seo/breadcrumbs', {
		apiVersion: 3,
		title: __( 'Breadcrumbs', 'futurelabs-ai-seo' ),
		description: __(
			'Shows the path from the home page to the current page. Matches the breadcrumb data search engines see.',
			'futurelabs-ai-seo'
		),
		category: 'theme',
		icon: 'arrow-right-alt2',
		supports: { html: false, align: [ 'wide', 'full' ] },
		edit() {
			return el(
				'div',
				wp.blockEditor.useBlockProps(),
				el( ServerSideRender, {
					block: 'futurelabs-ai-seo/breadcrumbs',
					EmptyResponsePlaceholder() {
						return el(
							'p',
							{},
							__(
								'Breadcrumbs appear here on posts, pages and archives.',
								'futurelabs-ai-seo'
							)
						);
					},
				} )
			);
		},
		save() {
			return null;
		},
	} );
} )( window.wp );
