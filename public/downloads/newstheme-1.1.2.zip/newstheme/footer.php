<?php
/**
 * Site footer (from the footer builder) and scroll-to-top.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
	</main>
	<?php
	do_action( 'newstheme_before_footer' );
	newstheme_render_colophon();
	?>
	<?php if ( newstheme_get_mod( 'stt_show' ) ) : ?>
		<button type="button" class="nt-scroll-top" data-nt-scroll-top aria-label="<?php esc_attr_e( 'Back to top', 'newstheme' ); ?>" hidden><?php newstheme_icon( 'chevron-up' ); ?></button>
	<?php endif; ?>
</div>
<?php wp_footer(); ?>
</body>
</html>
