<?php
/**
 * Undo an audit-logged batch within the retention window.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Bulk;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Redirects\Rules;

defined( 'ABSPATH' ) || exit;

/**
 * Restores the `old` side of every audit row in a batch, newest first.
 */
class Undo {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Undo a batch.
	 *
	 * @param string $batch Batch id (UUID).
	 * @return array{batch_id: string, restored: int, skipped: int, by_kind: array<string, int>, errors: array<int, array{row: int, error: string}>}|\WP_Error
	 */
	public function undo( string $batch ) {
		if ( ! wp_is_uuid( $batch ) ) {
			return new \WP_Error( 'flseo_undo_batch', __( 'Invalid batch id.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$audit = $this->c->get( AuditLog::class );
		$rows  = $audit->batch_rows( $batch );
		if ( ! $rows ) {
			/* translators: %d: days in the undo window. */
			return new \WP_Error( 'flseo_undo_empty', sprintf( __( 'Nothing to undo: the batch was not found, was already undone, or is older than %d days.', 'futurelabs-ai-seo' ), AuditLog::RETENTION_DAYS ), array( 'status' => 404 ) );
		}
		$done    = array();
		$by_kind = array();
		$errors  = array();
		$skipped = 0;
		foreach ( $rows as $row ) {
			$old   = json_decode( (string) $row->old_value, true );
			$after = json_decode( (string) $row->new_value, true );
			if ( ! is_array( $old ) || empty( $old['kind'] ) ) {
				++$skipped;
				$errors[] = array(
					'row'   => (int) $row->id,
					'error' => __( 'This change was recorded in an older format and cannot be undone automatically.', 'futurelabs-ai-seo' ),
				);
				continue;
			}
			$kind = (string) $old['kind'];
			if ( ! $this->allowed( $kind, (string) $row->object_type, (int) $row->object_id ) ) {
				++$skipped;
				$errors[] = array(
					'row'   => (int) $row->id,
					'error' => __( 'You are not allowed to undo this change.', 'futurelabs-ai-seo' ),
				);
				continue;
			}
			$result = $this->restore( $kind, (int) $row->object_id, $old, is_array( $after ) ? $after : array() );
			if ( is_wp_error( $result ) ) {
				++$skipped;
				$errors[] = array(
					'row'   => (int) $row->id,
					'error' => $result->get_error_message(),
				);
				continue;
			}
			$done[]           = (int) $row->id;
			$by_kind[ $kind ] = ( $by_kind[ $kind ] ?? 0 ) + 1;
		}
		$audit->mark_undone( $done );
		if ( isset( $by_kind['redirect'] ) ) {
			wp_cache_delete( 'regex_rules', 'futurelabs-ai-seo' );
			do_action( 'flseo_redirects_changed' );
		}
		/**
		 * Fires after a batch was undone.
		 *
		 * @param string $batch    Batch id.
		 * @param int    $restored Restored rows.
		 */
		do_action( 'flseo_batch_undone', $batch, count( $done ) );
		return array(
			'batch_id' => $batch,
			'restored' => count( $done ),
			'skipped'  => $skipped,
			'by_kind'  => $by_kind,
			'errors'   => $errors,
		);
	}

	/**
	 * Whether the current user may restore one row.
	 *
	 * @param string $kind        Kind.
	 * @param string $object_type Object type.
	 * @param int    $object_id   Object id.
	 */
	private function allowed( string $kind, string $object_type, int $object_id ): bool {
		switch ( $kind ) {
			case 'post_meta':
			case 'post_status':
			case 'post_content':
			case 'attachment_meta':
				return current_user_can( 'edit_post', $object_id );
			case 'term_meta':
				return current_user_can( 'edit_term', $object_id );
			case 'redirect':
			case 'settings':
				return Capabilities::can( 'settings' === $kind ? Capabilities::SETTINGS : Capabilities::DATA );
		}
		return false;
	}

	/**
	 * Restore one row's old state.
	 *
	 * @param string               $kind      Kind.
	 * @param int                  $object_id Object id.
	 * @param array<string, mixed> $old       Old state.
	 * @param array<string, mixed> $after     New state.
	 * @return true|\WP_Error
	 */
	private function restore( string $kind, int $object_id, array $old, array $after ) {
		switch ( $kind ) {
			case 'post_meta':
			case 'attachment_meta':
			case 'term_meta':
				$key = (string) ( $old['key'] ?? '' );
				if ( '' === $key ) {
					return new \WP_Error( 'flseo_undo_key', __( 'The audit row has no meta key.', 'futurelabs-ai-seo' ) );
				}
				$value = $old['value'] ?? '';
				$term  = 'term_meta' === $kind;
				if ( '' === $value || array() === $value ) {
					$term ? delete_term_meta( $object_id, $key ) : delete_post_meta( $object_id, $key );
				} else {
					$term ? update_term_meta( $object_id, $key, $value ) : update_post_meta( $object_id, $key, $value );
				}
				return true;
			case 'post_status':
				$status = sanitize_key( (string) ( $old['value'] ?? 'draft' ) );
				// Restoring a public status is publishing, which needs the publish capability.
				if ( in_array( $status, array( 'publish', 'future', 'private' ), true ) && ! current_user_can( 'publish_post', $object_id ) ) {
					return new \WP_Error( 'flseo_undo_publish', __( 'You are not allowed to publish this post, so its status was not restored.', 'futurelabs-ai-seo' ) );
				}
				return $this->update_post(
					array(
						'ID'          => $object_id,
						'post_status' => $status,
					)
				);
			case 'post_content':
				return $this->update_post(
					array(
						'ID'           => $object_id,
						'post_content' => wp_slash( (string) ( $old['value'] ?? '' ) ),
					)
				);
			case 'redirect':
				return $this->restore_redirect( $object_id, $old['row'] ?? null, $after['row'] ?? null );
			case 'settings':
				if ( ! is_array( $old['value'] ?? null ) ) {
					return new \WP_Error( 'flseo_undo_settings', __( 'The previous settings could not be read.', 'futurelabs-ai-seo' ) );
				}
				$this->c->get( Settings::class )->replace( $old['value'] );
				return true;
		}
		return new \WP_Error( 'flseo_undo_kind', __( 'Unknown change type.', 'futurelabs-ai-seo' ) );
	}

	/**
	 * Update a post and surface failures.
	 *
	 * @param array<string, mixed> $data Post data.
	 * @return true|\WP_Error
	 */
	private function update_post( array $data ) {
		if ( ! get_post( (int) $data['ID'] ) ) {
			return new \WP_Error( 'flseo_undo_post', __( 'The post no longer exists.', 'futurelabs-ai-seo' ) );
		}
		$result = wp_update_post( $data, true );
		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * Restore a redirect rule: delete a created rule or put the previous row back exactly.
	 *
	 * @param int                       $id  Rule id the change affected.
	 * @param array<string, mixed>|null $old Previous row, null when the change created the rule.
	 * @param array<string, mixed>|null $after Row after the change, null when the change deleted it.
	 * @return true|\WP_Error
	 */
	private function restore_redirect( int $id, $old, $after ) {
		global $wpdb;
		$table = Rules::table();
		$rules = $this->c->get( Rules::class );
		if ( ! is_array( $old ) ) {
			$target = is_array( $after ) && ! empty( $after['id'] ) ? (int) $after['id'] : $id;
			$rules->delete( $target );
			return true;
		}
		$columns = array( 'id', 'source', 'source_hash', 'target', 'type', 'is_regex', 'hits', 'last_hit', 'created_by', 'origin', 'created_at' );
		$row     = array_intersect_key( $old, array_flip( $columns ) );
		if ( empty( $row['id'] ) || empty( $row['source_hash'] ) ) {
			return new \WP_Error( 'flseo_undo_redirect', __( 'The previous redirect could not be read.', 'futurelabs-ai-seo' ) );
		}
		// Remove any other rule that took over the same source since, then put the old row back
		// exactly (same id). Deleting through Rules also clears its regex cache.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$others = (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$table} WHERE source_hash=%s OR id=%d", $row['source_hash'], (int) $row['id'] ) );
		foreach ( $others as $other ) {
			$rules->delete( (int) $other );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ok = $wpdb->insert( $table, $row );
		if ( false === $ok ) {
			return new \WP_Error( 'flseo_undo_redirect_db', __( 'The previous redirect could not be restored.', 'futurelabs-ai-seo' ) );
		}
		return true;
	}
}
