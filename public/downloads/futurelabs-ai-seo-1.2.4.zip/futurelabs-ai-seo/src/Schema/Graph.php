<?php
/**
 * Single JSON-LD @graph output.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Schema;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Meta\CanonicalResolver;
use FutureLabs\AISEO\Meta\Context;
use FutureLabs\AISEO\Meta\Templates;
use FutureLabs\AISEO\Meta\Variables;

defined( 'ABSPATH' ) || exit;

/**
 * Builds one schema.org graph per page.
 *
 * Generated types: Organization or Person, WebSite (+SearchAction), WebPage and archive
 * subtypes, Article/BlogPosting/NewsArticle, BreadcrumbList, FAQPage (visible FAQ blocks
 * only), Course, Product, LocalBusiness and VideoObject. JobPosting, Event, Scholarship and
 * other types are never generated; they only appear when an editor adds them as a per-post
 * override. Nothing is printed on search results or 404 pages, or when building fails.
 */
class Graph implements Module {

	public const ARTICLE_TYPES = array( 'Article', 'BlogPosting', 'NewsArticle' );
	public const MAX_VIDEOS    = 5;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'wp_head', array( $this, 'output' ), 30 );
	}

	/**
	 * Print the graph. Fails safe: on any error nothing is printed.
	 */
	public function output(): void {
		if ( is_admin() || is_feed() || ! $this->c->get( Settings::class )->get( 'output_schema' ) ) {
			return;
		}
		try {
			$doc = $this->build( Context::current() );
			if ( $doc ) {
				echo "\n" . self::script( $doc ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded with JSON_HEX_TAG in script().
			}
		} catch ( \Throwable $e ) {
			$this->c->get( Logger::class )->error( 'Schema output failed: ' . $e->getMessage() );
		}
	}

	/**
	 * Script tag for a document.
	 *
	 * @param array<string, mixed> $doc Document.
	 */
	public static function script( array $doc ): string {
		$json = wp_json_encode( $doc, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP );
		return false === $json ? '' : '<script type="application/ld+json" class="flseo-schema">' . $json . '</script>';
	}

	/**
	 * Build the JSON-LD document for a context; empty array when nothing should be output.
	 *
	 * @param Context $context Context.
	 * @return array<string, mixed>
	 */
	public function build( Context $context ): array {
		if ( in_array( $context->kind, array( 'search', '404' ), true ) ) {
			return array();
		}
		$nodes   = array();
		$nodes[] = $this->entity();
		$nodes[] = $this->website();
		$page    = $this->page( $context );
		$post    = $page['post'] ?? null;
		if ( $page ) {
			$image = $post instanceof \WP_Post ? $this->primary_image( $post, $page['url'] ) : null;
			if ( $image ) {
				$nodes[] = $image;
			}
			$crumbs  = $this->breadcrumbs( $context, $page );
			$nodes[] = $this->webpage( $context, $page, $image, (bool) $crumbs );
			if ( $crumbs ) {
				$nodes[] = $crumbs;
			}
			if ( $post instanceof \WP_Post && in_array( $context->kind, array( 'singular', 'front' ), true ) ) {
				$nodes = array_merge( $nodes, $this->main_nodes( $post, $page['url'], $image ) );
				$faq   = $this->faq( $post, $page['url'] );
				if ( $faq ) {
					$nodes[] = $faq;
				}
				$nodes = array_merge( $nodes, $this->videos( $post, $page['url'], $image ) );
			}
		}
		if ( 'front' === $context->kind ) {
			$business = $this->local_business();
			if ( $business ) {
				$nodes[] = $business;
			}
		}
		/**
		 * Filter generated graph nodes before per-post overrides are merged.
		 *
		 * @param array   $nodes   Nodes.
		 * @param Context $context Context.
		 */
		$nodes = (array) apply_filters( 'flseo_schema_graph', $nodes, $context );
		if ( $post instanceof \WP_Post && 'singular' === $context->kind ) {
			$nodes = $this->merge_overrides( $nodes, (string) get_post_meta( $post->ID, '_flseo_schema_overrides', true ), $page['url'] );
		}
		$nodes = self::unique_ids( array_values( array_filter( array_map( array( self::class, 'prune' ), array_filter( $nodes, 'is_array' ) ) ) ) );
		return array(
			'@context' => 'https://schema.org',
			'@graph'   => $nodes,
		);
	}

	/**
	 * Site home URL with trailing slash (base for site-level @id values).
	 */
	private function home(): string {
		return trailingslashit( home_url( '/' ) );
	}

	/**
	 * The @id of the site entity.
	 */
	public function entity_id(): string {
		return $this->home() . ( 'Person' === $this->c->get( Settings::class )->get( 'schema_entity' ) ? '#person' : '#organization' );
	}

	/**
	 * Site entity name.
	 */
	private function entity_name(): string {
		$name = trim( (string) $this->c->get( Settings::class )->get( 'schema_name' ) );
		return '' !== $name ? $name : wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
	}

	/**
	 * Other names the site is known by, for `alternateName` (Google uses it for site names).
	 *
	 * @return string|array<int, string>|null One name, several, or null when none are set.
	 */
	private function alternate_names() {
		$names = array_values( array_filter( array_map( 'trim', explode( ',', (string) $this->c->get( Settings::class )->get( 'schema_alternate_names' ) ) ) ) );
		if ( ! $names ) {
			return null;
		}
		return 1 === count( $names ) ? $names[0] : $names;
	}

	/**
	 * Logo URL from settings, the custom logo or the site icon.
	 */
	private function logo_url(): string {
		$logo = (string) $this->c->get( Settings::class )->get( 'schema_logo' );
		if ( '' !== $logo ) {
			return $logo;
		}
		$id = (int) get_theme_mod( 'custom_logo' );
		if ( $id ) {
			$url = wp_get_attachment_image_url( $id, 'full' );
			if ( $url ) {
				return (string) $url;
			}
		}
		return (string) get_site_icon_url( 512 );
	}

	/**
	 * Organization or Person node.
	 *
	 * @return array<string, mixed>
	 */
	private function entity(): array {
		$person = 'Person' === $this->c->get( Settings::class )->get( 'schema_entity' );
		$node   = array(
			'@type' => $person ? 'Person' : 'Organization',
			'@id'   => $this->entity_id(),
			'name'  => $this->entity_name(),
			'url'   => $this->home(),
		);
		$alt    = $this->alternate_names();
		if ( null !== $alt && ! $person ) {
			$node['alternateName'] = $alt;
		}
		$logo = $this->logo_url();
		if ( '' !== $logo ) {
			$image = array(
				'@type'      => 'ImageObject',
				'@id'        => $this->home() . '#logo',
				'url'        => $logo,
				'contentUrl' => $logo,
				'caption'    => $node['name'],
			);
			if ( $person ) {
				$node['image'] = $image;
			} else {
				$node['logo']  = $image;
				$node['image'] = array( '@id' => $image['@id'] );
			}
		}
		return $node;
	}

	/**
	 * WebSite node.
	 *
	 * @return array<string, mixed>
	 */
	private function website(): array {
		$node = array(
			'@type'       => 'WebSite',
			'@id'         => $this->home() . '#website',
			'url'         => $this->home(),
			'name'        => wp_strip_all_tags( (string) get_bloginfo( 'name' ) ),
			'description' => wp_strip_all_tags( (string) get_bloginfo( 'description' ) ),
			'publisher'   => array( '@id' => $this->entity_id() ),
			'inLanguage'  => get_bloginfo( 'language' ),
		);
		$alt  = $this->alternate_names();
		if ( null !== $alt ) {
			$node['alternateName'] = $alt;
		}
		if ( $this->c->get( Settings::class )->get( 'schema_sitesearch' ) ) {
			$node['potentialAction'] = array(
				array(
					'@type'       => 'SearchAction',
					'target'      => array(
						'@type'       => 'EntryPoint',
						'urlTemplate' => home_url( '/?s={search_term_string}' ),
					),
					'query-input' => 'required name=search_term_string',
				),
			);
		}
		return $node;
	}

	/**
	 * Page facts: url, type and the post when the page is a single post.
	 *
	 * @param Context $context Context.
	 * @return array{url: string, type: string, post: \WP_Post|null}|array{}
	 */
	private function page( Context $context ): array {
		$object = $context->object;
		switch ( $context->kind ) {
			case 'singular':
				if ( $object instanceof \WP_Post ) {
					return array(
						'url'  => (string) get_permalink( $object ),
						'type' => 'WebPage',
						'post' => $object,
					);
				}
				return array();
			case 'front':
				if ( $object instanceof \WP_Post ) {
					return array(
						'url'  => $this->home(),
						'type' => 'WebPage',
						'post' => $object,
					);
				}
				return array(
					'url'  => $this->canonical( $context, $this->home() ),
					'type' => 'CollectionPage',
					'post' => null,
				);
			case 'home':
				$fallback = $object instanceof \WP_Post ? (string) get_permalink( $object ) : $this->home();
				return array(
					'url'  => $this->canonical( $context, $fallback ),
					'type' => 'CollectionPage',
					'post' => null,
				);
			case 'term':
				$link = $object instanceof \WP_Term ? get_term_link( $object ) : '';
				return array(
					'url'  => $this->canonical( $context, is_string( $link ) ? $link : '' ),
					'type' => 'CollectionPage',
					'post' => null,
				);
			case 'author':
				$link = $object instanceof \WP_User ? get_author_posts_url( $object->ID ) : '';
				return array(
					'url'  => $this->canonical( $context, $link ),
					'type' => 'ProfilePage',
					'post' => null,
				);
			case 'post_type_archive':
				$link = $object instanceof \WP_Post_Type ? get_post_type_archive_link( $object->name ) : '';
				return array(
					'url'  => $this->canonical( $context, (string) $link ),
					'type' => 'CollectionPage',
					'post' => null,
				);
		}
		return array();
	}

	/**
	 * Canonical URL for an archive context, with a fallback.
	 *
	 * @param Context $context  Context.
	 * @param string  $fallback Fallback URL.
	 */
	private function canonical( Context $context, string $fallback ): string {
		$url = $this->c->get( CanonicalResolver::class )->resolve( $context );
		return '' !== $url ? $url : $fallback;
	}

	/**
	 * WebPage (or subtype) node.
	 *
	 * @param Context                   $context Context.
	 * @param array<string, mixed>      $page    Page facts.
	 * @param array<string, mixed>|null $image   Primary image node.
	 * @param bool                      $crumbs  Whether a breadcrumb node exists.
	 * @return array<string, mixed>
	 */
	private function webpage( Context $context, array $page, ?array $image, bool $crumbs ): array {
		$templates = $this->c->get( Templates::class );
		$node      = array(
			'@type'       => $page['type'],
			'@id'         => $page['url'] . '#webpage',
			'url'         => $page['url'],
			'name'        => $templates->title( $context ),
			'description' => $templates->description( $context ),
			'isPartOf'    => array( '@id' => $this->home() . '#website' ),
			'inLanguage'  => get_bloginfo( 'language' ),
		);
		$post      = $page['post'];
		if ( $post instanceof \WP_Post ) {
			$node['datePublished'] = (string) get_post_time( 'c', true, $post );
			$node['dateModified']  = (string) get_post_modified_time( 'c', true, $post );
		}
		if ( '' === $node['name'] ) {
			$node['name'] = wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
		}
		if ( $image ) {
			$node['primaryImageOfPage'] = array( '@id' => $image['@id'] );
		}
		if ( $crumbs ) {
			$node['breadcrumb'] = array( '@id' => $page['url'] . '#breadcrumb' );
		}
		if ( 'front' === $context->kind ) {
			$node['about'] = array( '@id' => $this->entity_id() );
		}
		return $node;
	}

	/**
	 * Featured image node.
	 *
	 * @param \WP_Post $post Post.
	 * @param string   $url  Page URL.
	 * @return array<string, mixed>|null
	 */
	private function primary_image( \WP_Post $post, string $url ): ?array {
		$id = (int) get_post_thumbnail_id( $post );
		if ( ! $id ) {
			return null;
		}
		$src = wp_get_attachment_image_src( $id, 'full' );
		if ( ! $src ) {
			return null;
		}
		return array(
			'@type'      => 'ImageObject',
			'@id'        => $url . '#primaryimage',
			'url'        => (string) $src[0],
			'contentUrl' => (string) $src[0],
			'width'      => (int) $src[1],
			'height'     => (int) $src[2],
			'caption'    => wp_strip_all_tags( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ),
		);
	}

	/**
	 * BreadcrumbList node, or null when the trail would only hold the home page.
	 *
	 * @param Context              $context Context.
	 * @param array<string, mixed> $page    Page facts.
	 * @return array<string, mixed>|null
	 */
	private function breadcrumbs( Context $context, array $page ): ?array {
		$trail = $this->c->get( Breadcrumbs::class )->trail( $context, (string) $page['url'] );
		if ( ! $trail ) {
			return null;
		}
		$items = array();
		foreach ( $trail as $i => $crumb ) {
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $i + 1,
				'name'     => $crumb['name'],
				'item'     => $crumb['url'],
			);
		}
		return array(
			'@type'           => 'BreadcrumbList',
			'@id'             => $page['url'] . '#breadcrumb',
			'itemListElement' => $items,
		);
	}

	/**
	 * Main entity type for a post: per-post selection, course post types, WooCommerce product, then the post type setting.
	 *
	 * @param \WP_Post $post Post.
	 */
	public function main_type( \WP_Post $post ): string {
		$selected = (string) get_post_meta( $post->ID, '_flseo_schema_type', true );
		if ( in_array( $selected, Types::selectable(), true ) ) {
			return $selected;
		}
		$settings = $this->c->get( Settings::class );
		if ( in_array( $post->post_type, (array) $settings->get( 'course_post_types', array() ), true ) ) {
			return 'Course';
		}
		if ( 'product' === $post->post_type && $this->product_data( $post ) ) {
			return 'Product';
		}
		return (string) $settings->post_type( $post->post_type )['schema'];
	}

	/**
	 * Article, Course or Product node(s) for a post.
	 *
	 * @param \WP_Post                  $post  Post.
	 * @param string                    $url   Page URL.
	 * @param array<string, mixed>|null $image Primary image.
	 * @return array<int, array<string, mixed>>
	 */
	private function main_nodes( \WP_Post $post, string $url, ?array $image ): array {
		$type = $this->main_type( $post );
		if ( in_array( $type, self::ARTICLE_TYPES, true ) ) {
			return $this->article( $post, $type, $url, $image );
		}
		if ( 'Course' === $type ) {
			return array( $this->course( $post, $url ) );
		}
		if ( 'Product' === $type ) {
			$product = $this->product( $post, $url );
			return $product ? array( $product ) : array();
		}
		return array();
	}

	/**
	 * Article node plus its author Person node.
	 *
	 * @param \WP_Post                  $post  Post.
	 * @param string                    $type  Article, BlogPosting or NewsArticle.
	 * @param string                    $url   Page URL.
	 * @param array<string, mixed>|null $image Primary image.
	 * @return array<int, array<string, mixed>>
	 */
	private function article( \WP_Post $post, string $type, string $url, ?array $image ): array {
		$nodes  = array();
		$author = get_userdata( (int) $post->post_author );
		if ( $author ) {
			$person  = array(
				'@type' => 'Person',
				'@id'   => $this->home() . '#/schema/person/' . md5( $this->home() . $author->ID ),
				'name'  => $author->display_name,
				'url'   => get_author_posts_url( $author->ID ),
			);
			$nodes[] = $person;
			$ref     = array( '@id' => $person['@id'] );
		} else {
			$ref = array( '@id' => $this->entity_id() );
		}
		$headline = wp_strip_all_tags( get_the_title( $post ) );
		$node     = array(
			'@type'            => $type,
			'@id'              => $url . '#article',
			'isPartOf'         => array( '@id' => $url . '#webpage' ),
			'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
			'headline'         => mb_strlen( $headline ) > 110 ? mb_substr( $headline, 0, 109 ) . '…' : $headline,
			'description'      => $this->c->get( Templates::class )->post_description( $post ),
			'datePublished'    => (string) get_post_time( 'c', true, $post ),
			'dateModified'     => (string) get_post_modified_time( 'c', true, $post ),
			'author'           => $ref,
			'publisher'        => array( '@id' => $this->entity_id() ),
			'inLanguage'       => get_bloginfo( 'language' ),
		);
		if ( '' === (string) $post->post_password ) {
			$node['wordCount'] = str_word_count( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) );
		}
		if ( $image ) {
			$node['image'] = array( '@id' => $image['@id'] );
		}
		if ( 'post' === $post->post_type ) {
			$node['articleSection'] = wp_list_pluck( get_the_category( $post->ID ), 'name' );
			$tags                   = get_the_tags( $post->ID );
			$node['keywords']       = is_array( $tags ) ? wp_list_pluck( $tags, 'name' ) : array();
		}
		array_unshift( $nodes, $node );
		return $nodes;
	}

	/**
	 * Course node.
	 *
	 * @param \WP_Post $post Post.
	 * @param string   $url  Page URL.
	 * @return array<string, mixed>
	 */
	private function course( \WP_Post $post, string $url ): array {
		$title       = wp_strip_all_tags( get_the_title( $post ) );
		$description = $this->c->get( Templates::class )->post_description( $post );
		return array(
			'@type'            => 'Course',
			'@id'              => $url . '#course',
			'name'             => $title,
			'description'      => '' !== $description ? $description : $title,
			'url'              => $url,
			'provider'         => array( '@id' => $this->entity_id() ),
			'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
			'inLanguage'       => get_bloginfo( 'language' ),
		);
	}

	/**
	 * Product facts: name, description, image, sku, price, currency, availability, url,
	 * and optional low_price/high_price/offer_count for variable products.
	 * Read from WooCommerce when available and filterable via `flseo_schema_product_data`.
	 *
	 * @param \WP_Post $post Post.
	 * @return array<string, mixed>
	 */
	public function product_data( \WP_Post $post ): array {
		$data = array();
		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $post->ID );
			if ( $product && is_object( $product ) ) {
				$image = $product->get_image_id() ? wp_get_attachment_image_url( (int) $product->get_image_id(), 'full' ) : '';
				$stock = (string) $product->get_stock_status();
				$data  = array(
					'name'         => wp_strip_all_tags( (string) $product->get_name() ),
					'description'  => wp_strip_all_tags( (string) ( $product->get_short_description() ? $product->get_short_description() : $product->get_description() ) ),
					'image'        => $image ? (string) $image : '',
					'sku'          => (string) $product->get_sku(),
					'price'        => (string) $product->get_price(),
					'currency'     => function_exists( 'get_woocommerce_currency' ) ? (string) get_woocommerce_currency() : '',
					'availability' => 'instock' === $stock ? 'InStock' : ( 'onbackorder' === $stock ? 'BackOrder' : 'OutOfStock' ),
					'url'          => (string) get_permalink( $post ),
				);
				if ( method_exists( $product, 'is_type' ) && $product->is_type( 'variable' ) && method_exists( $product, 'get_variation_price' ) ) {
					$data['low_price']   = (string) $product->get_variation_price( 'min' );
					$data['high_price']  = (string) $product->get_variation_price( 'max' );
					$data['offer_count'] = method_exists( $product, 'get_children' ) ? count( (array) $product->get_children() ) : 0;
				}
			}
		}
		/**
		 * Filter product facts used for Product schema. Return an empty array to omit the node.
		 *
		 * @param array    $data Product facts.
		 * @param \WP_Post $post Post.
		 */
		$data = apply_filters( 'flseo_schema_product_data', $data, $post );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Product node; null when there is no price to describe.
	 *
	 * @param \WP_Post $post Post.
	 * @param string   $url  Page URL.
	 * @return array<string, mixed>|null
	 */
	private function product( \WP_Post $post, string $url ): ?array {
		$data = $this->product_data( $post );
		$name = (string) ( $data['name'] ?? '' );
		if ( '' === $name || ( '' === (string) ( $data['price'] ?? '' ) && '' === (string) ( $data['low_price'] ?? '' ) ) ) {
			return null;
		}
		$availability = (string) ( $data['availability'] ?? 'InStock' );
		$offer_url    = (string) ( $data['url'] ?? $url );
		if ( '' !== (string) ( $data['low_price'] ?? '' ) ) {
			$offers = array(
				'@type'         => 'AggregateOffer',
				'lowPrice'      => (string) $data['low_price'],
				'highPrice'     => (string) ( $data['high_price'] ?? $data['low_price'] ),
				'offerCount'    => (int) ( $data['offer_count'] ?? 0 ),
				'priceCurrency' => (string) ( $data['currency'] ?? '' ),
				'availability'  => 'https://schema.org/' . $availability,
				'url'           => $offer_url,
			);
		} else {
			$offers = array(
				'@type'         => 'Offer',
				'price'         => (string) $data['price'],
				'priceCurrency' => (string) ( $data['currency'] ?? '' ),
				'availability'  => 'https://schema.org/' . $availability,
				'url'           => $offer_url,
				'seller'        => array( '@id' => $this->entity_id() ),
			);
		}
		return array(
			'@type'            => 'Product',
			'@id'              => $url . '#product',
			'name'             => $name,
			'description'      => (string) ( $data['description'] ?? '' ),
			'image'            => (string) ( $data['image'] ?? '' ),
			'sku'              => (string) ( $data['sku'] ?? '' ),
			'url'              => $url,
			'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
			'offers'           => $offers,
		);
	}

	/**
	 * FAQPage node from visible FAQ blocks; null when the post has none.
	 *
	 * @param \WP_Post $post Post.
	 * @param string   $url  Page URL.
	 * @return array<string, mixed>|null
	 */
	private function faq( \WP_Post $post, string $url ): ?array {
		if ( '' !== (string) $post->post_password || ! has_blocks( $post->post_content ) ) {
			return null;
		}
		$items = self::faq_items( parse_blocks( $post->post_content ) );
		if ( ! $items ) {
			return null;
		}
		$questions = array();
		foreach ( $items as $item ) {
			$questions[] = array(
				'@type'          => 'Question',
				'name'           => $item[0],
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => $item[1],
				),
			);
		}
		return array(
			'@type'      => 'FAQPage',
			'@id'        => $url . '#faq',
			'isPartOf'   => array( '@id' => $url . '#webpage' ),
			'mainEntity' => $questions,
		);
	}

	/**
	 * Question/answer pairs from Yoast, Rank Math and AIOSEO FAQ blocks and from core
	 * Details blocks whose summary is a question.
	 *
	 * @param array<int, array<string, mixed>> $blocks Parsed blocks.
	 * @return array<int, array{0: string, 1: string}>
	 */
	public static function faq_items( array $blocks ): array {
		$items = array();
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			$name  = (string) ( $block['blockName'] ?? '' );
			$attrs = (array) ( $block['attrs'] ?? array() );
			$inner = (array) ( $block['innerBlocks'] ?? array() );
			switch ( $name ) {
				case 'yoast/faq-block':
					foreach ( (array) ( $attrs['questions'] ?? array() ) as $q ) {
						if ( is_array( $q ) ) {
							$items[] = array( self::text( $q['jsonQuestion'] ?? $q['question'] ?? '' ), self::text( $q['jsonAnswer'] ?? $q['answer'] ?? '' ) );
						}
					}
					continue 2;
				case 'rank-math/faq-block':
					foreach ( (array) ( $attrs['questions'] ?? array() ) as $q ) {
						if ( is_array( $q ) && ( ! isset( $q['visible'] ) || false !== $q['visible'] ) ) {
							$items[] = array( self::text( $q['title'] ?? '' ), self::text( $q['content'] ?? '' ) );
						}
					}
					continue 2;
				case 'aioseo/faq':
					if ( empty( $attrs['hidden'] ) ) {
						$answer  = $inner ? serialize_blocks( $inner ) : (string) ( $block['innerHTML'] ?? '' );
						$items[] = array( self::text( $attrs['question'] ?? '' ), self::text( $answer ) );
					}
					continue 2;
				case 'core/details':
					$html = (string) ( $block['innerHTML'] ?? '' );
					if ( preg_match( '~<summary[^>]*>(.*?)</summary>~is', $html, $m ) ) {
						$question = self::text( $m[1] );
						if ( str_ends_with( $question, '?' ) ) {
							$answer  = (string) preg_replace( '~<summary[^>]*>.*?</summary>~is', '', $html ) . ( $inner ? serialize_blocks( $inner ) : '' );
							$items[] = array( $question, self::text( $answer ) );
						}
					}
					continue 2;
			}
			if ( $inner ) {
				$items = array_merge( $items, self::faq_items( $inner ) );
			}
		}
		return array_values( array_filter( $items, static fn( $item ) => '' !== $item[0] && '' !== $item[1] ) );
	}

	/**
	 * Plain text from a block attribute (string or rich-text array).
	 *
	 * @param mixed $value Value.
	 */
	private static function text( $value ): string {
		if ( is_array( $value ) ) {
			$parts = array();
			array_walk_recursive(
				$value,
				static function ( $leaf ) use ( &$parts ) {
					if ( is_scalar( $leaf ) ) {
						$parts[] = (string) $leaf;
					}
				}
			);
			$value = implode( ' ', $parts );
		}
		$text = html_entity_decode( wp_strip_all_tags( (string) $value ), ENT_QUOTES, 'UTF-8' );
		return trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	}

	/**
	 * VideoObject nodes for YouTube and Vimeo embeds in the content.
	 *
	 * @param \WP_Post                  $post  Post.
	 * @param string                    $url   Page URL.
	 * @param array<string, mixed>|null $image Primary image (thumbnail for Vimeo).
	 * @return array<int, array<string, mixed>>
	 */
	private function videos( \WP_Post $post, string $url, ?array $image ): array {
		if ( '' !== (string) $post->post_password ) {
			return array();
		}
		$found = self::detect_videos( $post->post_content );
		if ( ! $found ) {
			return array();
		}
		$title       = wp_strip_all_tags( get_the_title( $post ) );
		$description = $this->c->get( Templates::class )->post_description( $post );
		$description = '' !== $description ? $description : Variables::excerpt( $post );
		$nodes       = array();
		foreach ( $found as $video ) {
			$thumb = 'youtube' === $video['provider'] ? 'https://i.ytimg.com/vi/' . $video['id'] . '/hqdefault.jpg' : (string) ( $image['url'] ?? '' );
			if ( '' === $thumb ) {
				continue;
			}
			$n       = count( $nodes ) + 1;
			$nodes[] = array(
				'@type'        => 'VideoObject',
				'@id'          => $url . '#video-' . $n,
				/* translators: 1: post title, 2: video number. */
				'name'         => count( $found ) > 1 ? sprintf( __( '%1$s (video %2$d)', 'futurelabs-ai-seo' ), $title, $n ) : $title,
				'description'  => '' !== $description ? $description : $title,
				'thumbnailUrl' => $thumb,
				'uploadDate'   => (string) get_post_time( 'c', true, $post ),
				'embedUrl'     => $video['embed'],
				'isPartOf'     => array( '@id' => $url . '#webpage' ),
			);
		}
		return $nodes;
	}

	/**
	 * Detect YouTube and Vimeo videos in content.
	 *
	 * @param string $content Post content.
	 * @return array<int, array{provider: string, id: string, embed: string}>
	 */
	public static function detect_videos( string $content ): array {
		$found = array();
		if ( preg_match_all( '~(?:youtube(?:-nocookie)?\.com/(?:watch\?(?:[^"\'\s<>]*?&(?:amp;)?)?v=|embed/|shorts/|live/|v/)|youtu\.be/)([A-Za-z0-9_-]{11})~i', $content, $m ) ) {
			foreach ( $m[1] as $id ) {
				$found[ 'youtube:' . $id ] = array(
					'provider' => 'youtube',
					'id'       => $id,
					'embed'    => 'https://www.youtube.com/embed/' . $id,
				);
			}
		}
		if ( preg_match_all( '~(?:player\.)?vimeo\.com/(?:video/)?(\d{6,12})~i', $content, $m ) ) {
			foreach ( $m[1] as $id ) {
				$found[ 'vimeo:' . $id ] = array(
					'provider' => 'vimeo',
					'id'       => $id,
					'embed'    => 'https://player.vimeo.com/video/' . $id,
				);
			}
		}
		return array_slice( array_values( $found ), 0, self::MAX_VIDEOS );
	}

	/**
	 * LocalBusiness node from settings; null when disabled or without an address.
	 *
	 * @return array<string, mixed>|null
	 */
	private function local_business(): ?array {
		$settings = (array) $this->c->get( Settings::class )->get( 'local_business', array() );
		if ( empty( $settings['enabled'] ) || ( '' === (string) ( $settings['street'] ?? '' ) && '' === (string) ( $settings['locality'] ?? '' ) ) ) {
			return null;
		}
		$type    = (string) ( $settings['type'] ?? 'LocalBusiness' );
		$type    = preg_match( '/^[A-Z][A-Za-z]+$/', $type ) ? $type : 'LocalBusiness';
		$address = array_filter(
			array(
				'@type'           => 'PostalAddress',
				'streetAddress'   => (string) ( $settings['street'] ?? '' ),
				'addressLocality' => (string) ( $settings['locality'] ?? '' ),
				'addressRegion'   => (string) ( $settings['region'] ?? '' ),
				'postalCode'      => (string) ( $settings['postcode'] ?? '' ),
				'addressCountry'  => (string) ( $settings['country'] ?? '' ),
			)
		);
		$node    = array(
			'@type'     => $type,
			'@id'       => $this->home() . '#localbusiness',
			'name'      => $this->entity_name(),
			'url'       => $this->home(),
			'address'   => $address,
			'telephone' => (string) ( $settings['telephone'] ?? '' ),
			'image'     => $this->logo_url(),
		);
		if ( 'Organization' === $this->c->get( Settings::class )->get( 'schema_entity' ) ) {
			$node['parentOrganization'] = array( '@id' => $this->entity_id() );
		}
		return $node;
	}

	/**
	 * Merge per-post override nodes: a node replaces the first generated node of the same
	 *
	 * @type (keeping its @id when the override has none); other nodes are appended.
	 *
	 * @param array<int, array<string, mixed>> $nodes Generated nodes.
	 * @param string                           $raw   Override JSON.
	 * @param string                           $url   Page URL.
	 * @return array<int, array<string, mixed>>
	 */
	public function merge_overrides( array $nodes, string $raw, string $url ): array {
		$parsed = Overrides::parse( $raw );
		if ( ! $parsed['valid'] ) {
			return $nodes;
		}
		$replaced = array();
		foreach ( $parsed['nodes'] as $override ) {
			$target = null;
			foreach ( $nodes as $i => $node ) {
				if ( ! isset( $replaced[ $i ] ) && ( $node['@type'] ?? '' ) === $override['@type'] ) {
					$target = $i;
					break;
				}
			}
			if ( null !== $target ) {
				if ( empty( $override['@id'] ) && ! empty( $nodes[ $target ]['@id'] ) ) {
					$override['@id'] = $nodes[ $target ]['@id'];
				}
				$nodes[ $target ]    = $override;
				$replaced[ $target ] = true;
				continue;
			}
			if ( empty( $override['@id'] ) || ! is_string( $override['@id'] ) ) {
				$override['@id'] = $url . '#' . strtolower( $override['@type'] );
			}
			$nodes[]                              = $override;
			$replaced[ array_key_last( $nodes ) ] = true;
		}
		return array_values( $nodes );
	}

	/**
	 * Make every top-level @id unique by suffixing duplicates.
	 *
	 * @param array<int, array<string, mixed>> $nodes Nodes.
	 * @return array<int, array<string, mixed>>
	 */
	public static function unique_ids( array $nodes ): array {
		$seen = array();
		foreach ( $nodes as $i => $node ) {
			$id = isset( $node['@id'] ) && is_string( $node['@id'] ) ? $node['@id'] : '';
			if ( '' === $id ) {
				continue;
			}
			$candidate = $id;
			$n         = 2;
			while ( isset( $seen[ $candidate ] ) ) {
				$candidate = $id . '-' . $n;
				++$n;
			}
			$seen[ $candidate ] = true;
			$nodes[ $i ]['@id'] = $candidate;
		}
		return $nodes;
	}

	/**
	 * Remove empty strings, nulls and empty arrays recursively.
	 *
	 * @param mixed $value Value.
	 * @return mixed
	 */
	public static function prune( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}
		$out = array();
		foreach ( $value as $key => $item ) {
			$item = self::prune( $item );
			if ( null === $item || '' === $item || array() === $item ) {
				continue;
			}
			$out[ $key ] = $item;
		}
		if ( $out && array_keys( $value ) === range( 0, count( $value ) - 1 ) ) {
			$out = array_values( $out );
		}
		return $out;
	}
}
