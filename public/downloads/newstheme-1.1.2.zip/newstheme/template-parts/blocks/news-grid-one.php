<?php
/**
 * Block: news grid — cards with the category badge on the image.
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args (see newstheme_block_types()).
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="nt-block nt-block--grid nt-block--grid-one" <?php echo $args['title'] ? 'aria-labelledby="' . esc_attr( $args['id'] ) . '-title"' : ''; ?>>
	<?php newstheme_block_heading( $args['title'], $args['id'] ); ?>
	<div class="nt-grid nt-grid--<?php echo (int) $args['columns']; ?>">
		<?php
		while ( $args['loop']->have_posts() ) :
			$args['loop']->the_post();
			?>
			<article <?php post_class( 'nt-post nt-post--grid' ); ?> data-nt-animate>
				<?php newstheme_post_thumb( 'newstheme-medium', array( 'badge' => true ) ); ?>
				<?php newstheme_post_title( 'h3' ); ?>
				<?php newstheme_post_meta( $args['meta'] ); ?>
			</article>
		<?php endwhile; ?>
	</div>
</section>
