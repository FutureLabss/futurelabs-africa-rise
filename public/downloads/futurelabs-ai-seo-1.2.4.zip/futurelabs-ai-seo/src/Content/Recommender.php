<?php
/**
 * Assigns one editorial recommendation per scanned post.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Content;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Meta\RobotsResolver;
use FutureLabs\AISEO\Opportunity\Editions;

defined( 'ABSPATH' ) || exit;

/**
 * Recommendations: improve | noindex | merge:{id} | delete_redirect:{id} | ok, each
 * with a one-line reason. These are editorial prompts, not search engine verdicts.
 */
class Recommender {

	/**
	 * Index status reason codes that raise priority.
	 */
	public const BOOST_REASONS = array( 'crawled_not_indexed', 'discovered_not_indexed' );

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Search Console "not indexed" bucket for a post, or '' when unknown.
	 *
	 * @param int $post_id Post ID.
	 * @return string crawled_not_indexed, discovered_not_indexed or ''.
	 */
	public function index_reason( int $post_id ): string {
		global $wpdb;
		$table = Migrations::table( 'index_status' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT reason_code, coverage_state FROM {$table} WHERE post_id = %d ORDER BY inspected_at DESC LIMIT 1", $post_id ) );
		if ( ! $row ) {
			return '';
		}
		return self::normalize_reason( (string) $row->reason_code, (string) $row->coverage_state );
	}

	/**
	 * Map a stored reason code or coverage label onto a boost reason.
	 *
	 * @param string $code     Reason code.
	 * @param string $coverage Coverage state label.
	 */
	public static function normalize_reason( string $code, string $coverage ): string {
		$code = strtolower( $code );
		if ( in_array( $code, self::BOOST_REASONS, true ) ) {
			return $code;
		}
		$coverage = strtolower( $coverage );
		if ( str_contains( $coverage, 'crawled' ) && str_contains( $coverage, 'not indexed' ) ) {
			return 'crawled_not_indexed';
		}
		if ( str_contains( $coverage, 'discovered' ) && str_contains( $coverage, 'not indexed' ) ) {
			return 'discovered_not_indexed';
		}
		return '';
	}

	/**
	 * Recommendation for a scan row.
	 *
	 * @param array<string, mixed> $row  Scan row (word_count, thin_score, title_generic, dup_group_id, dup_similarity, missing_sections, edition_key, edition_year).
	 * @param \WP_Post             $post Post.
	 * @return array{recommendation: string, reason: string, priority: int}
	 */
	public function recommend( array $row, \WP_Post $post ): array {
		$result = $this->base( $row, $post );
		$reason = $this->index_reason( $post->ID );
		if ( '' !== $reason && 'ok' !== $result['recommendation'] ) {
			$label               = 'crawled_not_indexed' === $reason ? __( 'Search Console: Crawled, not indexed.', 'futurelabs-ai-seo' ) : __( 'Search Console: Discovered, not indexed.', 'futurelabs-ai-seo' );
			$result['reason']    = $label . ' ' . $result['reason'];
			$result['priority'] += 50;
		}
		return $result;
	}

	/**
	 * Rules without the Search Console boost.
	 *
	 * @param array<string, mixed> $row  Scan row.
	 * @param \WP_Post             $post Post.
	 * @return array{recommendation: string, reason: string, priority: int}
	 */
	private function base( array $row, \WP_Post $post ): array {
		$thin      = $this->c->get( Thin::class );
		$words     = (int) ( $row['word_count'] ?? 0 );
		$group     = (int) ( $row['dup_group_id'] ?? 0 );
		$similar   = (int) ( $row['dup_similarity'] ?? 0 );
		$missing   = array_filter( explode( ',', (string) ( $row['missing_sections'] ?? '' ) ) );
		$indexable = $this->c->get( RobotsResolver::class )->is_indexable( $post );

		if ( ! $indexable ) {
			return self::make( 'ok', __( 'Already kept out of search results (noindex), so no content action is needed for indexing.', 'futurelabs-ai-seo' ), 0 );
		}
		if ( 'closed' === (string) get_post_meta( $post->ID, '_flseo_opp_status', true ) ) {
			$newer = $this->c->get( Editions::class )->newer_edition( $post->ID );
			if ( $newer ) {
				/* translators: %d: post ID of the newer edition. */
				return self::make( 'delete_redirect:' . $newer, sprintf( __( 'This edition has closed and a newer edition exists (post #%d); redirect this URL to it.', 'futurelabs-ai-seo' ), $newer ), 35 );
			}
		}
		if ( $group > 0 ) {
			$primary = $this->c->get( Duplicate::class )->primary( $group );
			if ( $primary && $primary !== $post->ID ) {
				if ( $thin->is_very_thin( $words ) ) {
					/* translators: 1: similarity percent, 2: post ID. */
					return self::make( 'delete_redirect:' . $primary, sprintf( __( '%1$d%% similar to post #%2$d and too short to be worth merging; redirect it to that post.', 'futurelabs-ai-seo' ), $similar, $primary ), 30 );
				}
				/* translators: 1: similarity percent, 2: post ID. */
				return self::make( 'merge:' . $primary, sprintf( __( '%1$d%% similar to post #%2$d; merge any unique details into it, then redirect.', 'futurelabs-ai-seo' ), $similar, $primary ), 30 );
			}
			/* translators: %d: similarity percent. */
			return self::make( 'improve', sprintf( __( 'Other posts are up to %d%% similar to this one; keep this as the main page and make it clearly distinct.', 'futurelabs-ai-seo' ), $similar ), 25 );
		}
		if ( $thin->is_very_thin( $words ) ) {
			/* translators: %d: word count. */
			return self::make( 'noindex', sprintf( __( 'Only %d words; expand it, or keep it out of search results until it is expanded.', 'futurelabs-ai-seo' ), $words ), 25 );
		}
		if ( $thin->is_thin( $words ) ) {
			/* translators: 1: word count, 2: threshold. */
			return self::make( 'improve', sprintf( __( '%1$d words, below the %2$d-word threshold; add useful detail.', 'futurelabs-ai-seo' ), $words, $thin->threshold() ), 20 );
		}
		if ( $missing ) {
			$labels   = array();
			$sections = Template::sections();
			foreach ( $missing as $key ) {
				$labels[] = isset( $sections[ $key ] ) ? $sections[ $key ][0] : $key;
			}
			/* translators: %s: comma-separated section names. */
			return self::make( 'improve', sprintf( __( 'Missing opportunity sections: %s.', 'futurelabs-ai-seo' ), implode( ', ', $labels ) ), 20 );
		}
		if ( ! empty( $row['title_generic'] ) ) {
			return self::make( 'improve', __( 'The title is generic or mostly template wording; say what is specific about this page.', 'futurelabs-ai-seo' ), 10 );
		}
		return self::make( 'ok', '', 0 );
	}

	/**
	 * Result array.
	 *
	 * @param string $recommendation Recommendation.
	 * @param string $reason         Reason.
	 * @param int    $priority       Priority.
	 * @return array{recommendation: string, reason: string, priority: int}
	 */
	private static function make( string $recommendation, string $reason, int $priority ): array {
		return array(
			'recommendation' => $recommendation,
			'reason'         => $reason,
			'priority'       => $priority,
		);
	}

	/**
	 * Split a stored recommendation into action and target.
	 *
	 * @param string $value Stored value such as "merge:12".
	 * @return array{action: string, target_id: int}
	 */
	public static function parse( string $value ): array {
		$parts = explode( ':', $value, 2 );
		return array(
			'action'    => $parts[0],
			'target_id' => isset( $parts[1] ) ? absint( $parts[1] ) : 0,
		);
	}
}
