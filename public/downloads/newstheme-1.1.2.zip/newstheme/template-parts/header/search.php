<?php
/**
 * Header element: search toggle with dropdown form and live results.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_live   = newstheme_get_mod( 'live_search' );
$newstheme_suffix = newstheme_element_suffix( $args );
?>
<div class="nt-search" data-nt-search<?php echo $newstheme_live ? ' data-live' : ''; ?>>
	<button type="button" class="nt-icon-btn nt-search__toggle" aria-expanded="false" aria-controls="nt-search-panel<?php echo esc_attr( $newstheme_suffix ); ?>" aria-label="<?php esc_attr_e( 'Search', 'newstheme' ); ?>">
		<?php newstheme_icon( 'search' ); ?>
	</button>
	<div id="nt-search-panel<?php echo esc_attr( $newstheme_suffix ); ?>" class="nt-search__panel" hidden>
		<?php
		get_search_form(
			array(
				'nt_id_suffix' => $newstheme_suffix,
				'nt_live'      => $newstheme_live,
				'nt_class'     => 'nt-search__form',
			)
		);
		?>
		<?php if ( $newstheme_live ) : ?>
			<p id="nt-search-status<?php echo esc_attr( $newstheme_suffix ); ?>" class="screen-reader-text nt-search__status" aria-live="polite"></p>
			<div class="nt-search__results"></div>
		<?php endif; ?>
	</div>
</div>
