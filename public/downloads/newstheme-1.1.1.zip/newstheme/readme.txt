=== NewsTheme ===
Contributors: futurelabs
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A fast, accessible news and magazine theme with a drag-and-drop header/footer builder, editable homepage sections and dark mode.

== Description ==

NewsTheme is a news and magazine theme for WordPress. Everything is set up in the Customizer with a live preview:

* Header and footer builder: drag elements (logo, menus, ticker, search, dark-mode toggle, newsletter, buttons, ads, widgets) into rows and columns, with a separate phone layout.
* Homepage sections: banner slider, news grids, lists, tabbed news filter, carousels, ads, video playlist and opinions — add, reorder and configure each block.
* Typography, colors (light and dark), category colors, layout widths and spacing.
* Single posts with reading time, share buttons, author box, related posts; archives with a featured hero.
* Nine widgets: posts list, popular posts, posts grid, carousel, banner ad, social icons, author info, category collection, widget title.
* Accessible (WCAG 2.2 AA tested), translation ready, no jQuery on the front end.

== Installation ==

1. In your admin, go to Appearance → Themes → Add New → Upload Theme and upload the zip.
2. Activate NewsTheme.
3. Open Appearance → Customize to set up the header, homepage and colors.

See docs/getting-started.md in the theme package for a full guide.

== Frequently Asked Questions ==

= How do I use more fonts? =

Install them in Appearance → Fonts (WordPress's Font Library). They then appear in every Font Family list under Customize → Global Options → Typography.

= How do I add a newsletter form? =

Install a newsletter plugin that provides a shortcode (e.g. MailPoet, Mailchimp for WP), then paste the shortcode in Customize → Header → Newsletter Button.

= Does the video playlist load YouTube for every visitor? =

No. The player loads (from youtube-nocookie.com) only when a visitor presses play. Video thumbnails are loaded from YouTube's image server.

== Changelog ==

= 1.1.1 =
* The demo content is now hosted at futurelabs.africa, so Appearance → Import Demo Data works without setup (needs the One Click Demo Import plugin).

= 1.1.0 =
* New: deadline badges on post images ("Closes in 3 days", "Closed"), from deadlines set in the FutureLabs AI SEO plugin. The countdown updates in the visitor's browser, so cached pages stay correct.
* New: "Closing soon" source for homepage blocks: upcoming deadlines, soonest first.
* New: Global Options → Opportunity Deadlines (turn badges off, choose the highlight window).
* Breadcrumbs come from FutureLabs AI SEO when it is active, matching its breadcrumb structured data.
* The theme's meta description steps aside for FutureLabs AI SEO (renamed from IndexLift).

= 1.0.1 =
* SEO: featured images use the post title as alt text when none is written.
* SEO: on the front page, a custom logo is now the page's main heading (h1).
* SEO: the theme's meta description steps aside for the IndexLift SEO plugin too.

= 1.0.0 =
* Initial release.

== Copyright ==

NewsTheme, Copyright 2026 Future Labs.
NewsTheme is distributed under the terms of the GNU GPL v2 or later.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Resources ==

* Jost — Copyright Indestructible Type*, SIL Open Font License 1.1, https://fonts.google.com/specimen/Jost (via Fontsource)
* Roboto — Copyright Google, SIL Open Font License 1.1, https://fonts.google.com/specimen/Roboto (via Fontsource)
* Inter — Copyright The Inter Project Authors, SIL Open Font License 1.1, https://rsms.me/inter/ (via Fontsource)
* Brand icons — Simple Icons, CC0 1.0, https://simpleicons.org/
* Interface icons — Lucide, ISC License, https://lucide.dev/
* LinkedIn icon — drawn for NewsTheme, GPLv2 or later
* screenshot.jpg — photos are CC0 (public domain), found via Openverse:
  * city-night-explosion-firework — https://www.flickr.com/photos/137643065@N06/24244363641
  * city-night-evening-canal — https://www.flickr.com/photos/137643065@N06/24242513501
  * City night lights, long exposure — https://www.flickr.com/photos/157635012@N07/48124795256
  * Fashion Street — https://www.flickr.com/photos/24490288@N04/33816483678
  * Forest Lake — https://www.flickr.com/photos/132795455@N08/17079182290
  * Wooden Deck on Forest Lake — https://www.flickr.com/photos/132795455@N08/17998360694
  * landscape-nature-forest-lake — https://www.flickr.com/photos/137643065@N06/24300004076
  * Laptop Desk — https://stocksnap.io/photo/laptop-desk-JCXQS3IVWD
  * Laptop Desk — https://stocksnap.io/photo/laptop-desk-WTSQO9T3DK
  * Laptop Desk — https://stocksnap.io/photo/laptop-desk-T2VQ2QPA3R
  * Mount Everest Mountain Landscape — https://www.flickr.com/photos/132795455@N08/18502982581
  * Snow Covered Mountain Landscape — https://www.flickr.com/photos/132795455@N08/18661752705
