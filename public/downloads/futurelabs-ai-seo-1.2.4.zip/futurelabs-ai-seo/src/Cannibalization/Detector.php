<?php
/**
 * Keyword cannibalization: queries where two or more of this site's URLs earn impressions.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Cannibalization;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Reports\SearchData;

defined( 'ABSPATH' ) || exit;

/**
 * Builds conflict groups from the latest Search Console period and recommends a primary page
 * plus an action (merge, redirect or differentiate) for each competing page.
 */
class Detector {

	public const MAX_QUERIES = 500;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Conflicts in the latest period.
	 *
	 * @param int $limit Max queries returned.
	 * @return array{range: string, items: array<int, array<string, mixed>>, total: int, editions: array<int, array<string, mixed>>}
	 */
	public function detect( int $limit = self::MAX_QUERIES ): array {
		$data  = $this->c->get( SearchData::class );
		$range = $data->latest_range();
		$out   = array(
			'range'    => $range,
			'items'    => array(),
			'total'    => 0,
			'editions' => $this->edition_groups(),
		);
		if ( '' === $range ) {
			return $out;
		}
		global $wpdb;
		$table = Migrations::table( 'gsc_queries' );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$queries = $wpdb->get_col( $wpdb->prepare( "SELECT query FROM {$table} WHERE date_range=%s AND impressions>0 GROUP BY query HAVING COUNT(DISTINCT url_hash)>=2 ORDER BY SUM(impressions) DESC LIMIT %d", $range, max( 1, $limit ) ) );
		if ( ! $queries ) {
			return $out;
		}
		$in   = implode( ',', array_fill( 0, count( $queries ), '%s' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT query, url_hash, MAX(url) url, SUM(clicks) clicks, SUM(impressions) impressions, AVG(position) position FROM {$table} WHERE date_range=%s AND impressions>0 AND query IN ($in) GROUP BY query, url_hash", array_merge( array( $range ), $queries ) ) ); // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		// phpcs:enable
		$grouped = array();
		foreach ( (array) $rows as $row ) {
			$grouped[ (string) $row->query ][] = $row;
		}
		$scan = array();
		foreach ( $queries as $query ) {
			$item = $this->conflict( (string) $query, $grouped[ $query ] ?? array(), $data, $scan );
			if ( $item ) {
				$out['items'][] = $item;
			}
		}
		$out['total'] = count( $out['items'] );
		return $out;
	}

	/**
	 * Build one conflict group.
	 *
	 * @param string                           $query Query.
	 * @param array<int, object>               $rows  Per-URL rows.
	 * @param SearchData                       $data  Data helper.
	 * @param array<int, array<string, mixed>> $scan  Content scan cache (by reference).
	 * @return array<string, mixed>|null
	 */
	private function conflict( string $query, array $rows, SearchData $data, array &$scan ): ?array {
		$pages = array();
		foreach ( $rows as $row ) {
			$url = $data->url( (string) $row->url_hash, (string) $row->url );
			if ( '' === $url ) {
				continue;
			}
			$post_id = $data->post_id( $url );
			$pages[] = array(
				'url'         => $url,
				'post_id'     => $post_id,
				'title'       => $post_id ? html_entity_decode( get_the_title( $post_id ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) : '',
				'clicks'      => (int) $row->clicks,
				'impressions' => (int) $row->impressions,
				'position'    => round( (float) $row->position, 1 ),
			);
		}
		if ( count( $pages ) < 2 ) {
			return null;
		}
		usort(
			$pages,
			static function ( $a, $b ) {
				if ( $a['clicks'] !== $b['clicks'] ) {
					return $b['clicks'] <=> $a['clicks'];
				}
				if ( $a['position'] !== $b['position'] ) {
					return $a['position'] <=> $b['position'];
				}
				return $b['impressions'] <=> $a['impressions'];
			}
		);
		$primary          = $pages[0];
		$primary_scan     = $this->scan_row( $primary['post_id'], $scan );
		$edition_conflict = false;
		foreach ( $pages as $index => $page ) {
			if ( 0 === $index ) {
				$pages[ $index ] += array(
					'primary' => true,
					'action'  => 'keep',
					'reason'  => __( 'Recommended primary: it earns the most clicks for this query (ties go to the better average position).', 'futurelabs-ai-seo' ),
				);
				continue;
			}
			list( $action, $reason, $edition ) = $this->recommend( $page, $primary, $primary_scan, $this->scan_row( $page['post_id'], $scan ) );
			$edition_conflict                  = $edition_conflict || $edition;
			$pages[ $index ]                  += array(
				'primary' => false,
				'action'  => $action,
				'reason'  => $reason,
			);
		}
		return array(
			'query'            => $query,
			'clicks'           => array_sum( array_column( $pages, 'clicks' ) ),
			'impressions'      => array_sum( array_column( $pages, 'impressions' ) ),
			'page_count'       => count( $pages ),
			'primary'          => array(
				'url'     => $primary['url'],
				'post_id' => $primary['post_id'],
			),
			'edition_conflict' => $edition_conflict,
			'pages'            => $pages,
		);
	}

	/**
	 * Action for a competing page.
	 *
	 * @param array<string, mixed>      $page         Competing page.
	 * @param array<string, mixed>      $primary      Primary page.
	 * @param array<string, mixed>|null $primary_scan Primary scan row.
	 * @param array<string, mixed>|null $page_scan    Competing scan row.
	 * @return array{0: string, 1: string, 2: bool} action, reason, whether it is an edition conflict.
	 */
	private function recommend( array $page, array $primary, ?array $primary_scan, ?array $page_scan ): array {
		if ( $primary_scan && $page_scan && '' !== $primary_scan['edition_key'] && $primary_scan['edition_key'] === $page_scan['edition_key'] ) {
			return array(
				'redirect',
				__( 'Same programme in a different edition (year). Keep one URL per programme: update the primary page with the current edition and redirect this one to it.', 'futurelabs-ai-seo' ),
				true,
			);
		}
		if ( $primary_scan && $page_scan && $primary_scan['dup_group_id'] > 0 && $primary_scan['dup_group_id'] === $page_scan['dup_group_id'] ) {
			return array(
				'merge',
				__( 'The content scan found these pages to be near-duplicates. Move any unique, accurate details into the primary page, then redirect this URL to it.', 'futurelabs-ai-seo' ),
				false,
			);
		}
		if ( ! $page['post_id'] ) {
			return array(
				'differentiate',
				__( 'This URL is not a single post (for example an archive or tag page). Make its title and description clearly about the listing, and link to the primary page.', 'futurelabs-ai-seo' ),
				false,
			);
		}
		$meaningful_clicks = $page['clicks'] >= 5 && $page['clicks'] >= 0.25 * max( 1, $primary['clicks'] );
		if ( $meaningful_clicks ) {
			return array(
				'differentiate',
				__( 'Both pages earn clicks for this query. Give each page a distinct purpose (different intent, audience or angle), adjust titles and headings to match, and link between them.', 'futurelabs-ai-seo' ),
				false,
			);
		}
		if ( 0 === $page['clicks'] && $page['position'] - $primary['position'] >= 10 ) {
			return array(
				'redirect',
				__( 'This page earns no clicks and ranks far below the primary. If it covers the same topic, redirect it to the primary page; if not, refocus it on a different query.', 'futurelabs-ai-seo' ),
				false,
			);
		}
		return array(
			'merge',
			__( 'This page splits impressions with the primary but earns few clicks. Merge its useful content into the primary page and redirect it.', 'futurelabs-ai-seo' ),
			false,
		);
	}

	/**
	 * Content scan row (cached per run).
	 *
	 * @param int                              $post_id Post.
	 * @param array<int, array<string, mixed>> $cache   Cache.
	 * @return array{edition_key: string, dup_group_id: int}|null
	 */
	private function scan_row( int $post_id, array &$cache ): ?array {
		if ( ! $post_id ) {
			return null;
		}
		if ( ! array_key_exists( $post_id, $cache ) ) {
			global $wpdb;
			$table = Migrations::table( 'content_scan' );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$row               = $wpdb->get_row( $wpdb->prepare( "SELECT edition_key, dup_group_id FROM {$table} WHERE post_id=%d", $post_id ) );
			$cache[ $post_id ] = $row ? array(
				'edition_key'  => (string) $row->edition_key,
				'dup_group_id' => (int) $row->dup_group_id,
			) : null;
		}
		return $cache[ $post_id ];
	}

	/**
	 * OL-3 edition groups from the content scan (independent of Search Console data).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function edition_groups(): array {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows   = $wpdb->get_results( "SELECT s.edition_key, s.post_id, s.edition_year FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE s.edition_key<>'' AND p.post_status='publish' AND s.edition_key IN (SELECT edition_key FROM {$table} WHERE edition_key<>'' GROUP BY edition_key HAVING COUNT(*)>=2) ORDER BY s.edition_key, s.edition_year DESC, s.post_id DESC LIMIT 1000" );
		$groups = array();
		foreach ( (array) $rows as $row ) {
			$groups[ (string) $row->edition_key ][] = array(
				'post_id' => (int) $row->post_id,
				'title'   => html_entity_decode( get_the_title( (int) $row->post_id ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
				'url'     => (string) get_permalink( (int) $row->post_id ),
				'year'    => (int) $row->edition_year,
			);
		}
		$out = array();
		foreach ( $groups as $key => $posts ) {
			if ( count( $posts ) < 2 ) {
				continue;
			}
			$out[] = array(
				'edition_key'    => $key,
				'keep'           => $posts[0],
				'posts'          => $posts,
				'recommendation' => __( 'Keep one URL per programme: update the newest edition in place each year and redirect older editions to it.', 'futurelabs-ai-seo' ),
			);
		}
		return $out;
	}
}
