<?php
/**
 * Related posts after a single post.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_related = newstheme_related_query();
if ( ! $newstheme_related->have_posts() ) {
	return;
}
$newstheme_grid = 'grid' === newstheme_get_mod( 'single_related_layout' );
?>
<section class="nt-block nt-related nt-related--<?php echo $newstheme_grid ? 'grid' : 'list'; ?>" aria-labelledby="nt-related-title">
	<div class="nt-block__head">
		<h2 class="nt-block-title" id="nt-related-title"><span><?php echo esc_html( newstheme_get_mod( 'single_related_title' ) ); ?></span></h2>
	</div>
	<div class="nt-grid nt-grid--2">
		<?php
		while ( $newstheme_related->have_posts() ) :
			$newstheme_related->the_post();
			?>
			<article <?php post_class( $newstheme_grid ? 'nt-post nt-post--grid' : 'nt-post nt-post--row nt-post--small' ); ?>>
				<?php newstheme_post_thumb( $newstheme_grid ? 'newstheme-medium' : 'newstheme-list', array( 'badge' => $newstheme_grid ) ); ?>
				<div class="nt-post__body">
					<?php
					newstheme_post_title( 'h3' );
					newstheme_post_meta( array( 'date' ) );
					?>
				</div>
			</article>
		<?php endwhile; ?>
	</div>
</section>
<?php
wp_reset_postdata();
