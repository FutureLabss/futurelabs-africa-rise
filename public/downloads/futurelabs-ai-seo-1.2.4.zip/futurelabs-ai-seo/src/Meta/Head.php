<?php
/**
 * Front-end head output: title, description, canonical, robots, Open Graph and X card.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Meta;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Replaces core canonical/robots output and prints one set of tags.
 *
 * Fail safe: when resolving throws, no robots or canonical tag is printed.
 */
class Head implements Module {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Whether output already happened in this request.
	 *
	 * @var bool
	 */
	private bool $printed = false;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'template_redirect', array( $this, 'take_over_core' ), 0 );
		add_filter( 'pre_get_document_title', array( $this, 'document_title' ), 20 );
		add_action( 'wp_head', array( $this, 'print_head' ), 1 );
		// Jetpack prints its own Open Graph and Twitter tags unless it recognises an SEO
		// plugin; it doesn't recognise this one, so pages got two sets. Jetpack takes the
		// job back whenever social output is switched off here.
		add_filter( 'jetpack_enable_open_graph', array( $this, 'jetpack_open_graph' ), 99 );
		add_filter( 'jetpack_disable_twitter_cards', array( $this, 'jetpack_disable_twitter_cards' ), 99 );
	}

	/**
	 * Whether Jetpack should print Open Graph tags.
	 *
	 * @param mixed $enabled Jetpack's own decision.
	 */
	public function jetpack_open_graph( $enabled ): bool {
		return $this->c->get( Settings::class )->get( 'output_social' ) ? false : (bool) $enabled;
	}

	/**
	 * Whether Jetpack should skip Twitter card tags.
	 *
	 * @param mixed $disabled Jetpack's own decision.
	 */
	public function jetpack_disable_twitter_cards( $disabled ): bool {
		return $this->c->get( Settings::class )->get( 'output_social' ) ? true : (bool) $disabled;
	}

	/**
	 * Remove core canonical and robots output when FutureLabs AI SEO owns them.
	 */
	public function take_over_core(): void {
		$settings = $this->c->get( Settings::class );
		if ( $settings->get( 'output_canonical' ) ) {
			remove_action( 'wp_head', 'rel_canonical' );
		}
		if ( $settings->get( 'output_robots' ) ) {
			remove_action( 'wp_head', 'wp_robots', 1 );
			remove_action( 'wp_head', 'noindex', 1 );
		}
	}

	/**
	 * Filter the document title.
	 *
	 * @param string $title Title from WordPress or other filters.
	 * @return string
	 */
	public function document_title( $title ) {
		if ( ! $this->c->get( Settings::class )->get( 'output_title' ) || is_admin() || is_feed() ) {
			return $title;
		}
		try {
			$resolved = $this->c->get( Templates::class )->title( Context::current() );
			// The filtered title is printed raw by core, so escape it here.
			return '' !== $resolved ? esc_html( wp_strip_all_tags( $resolved ) ) : $title;
		} catch ( \Throwable $e ) {
			$this->c->get( Logger::class )->error( 'Title resolution failed: ' . $e->getMessage() );
			return $title;
		}
	}

	/**
	 * Print head tags once.
	 */
	public function print_head(): void {
		if ( $this->printed || is_admin() || is_feed() ) {
			return;
		}
		$this->printed = true;
		echo $this->render( Context::current() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every value is escaped in render().
	}

	/**
	 * Build head markup for a context. Each part fails independently and safely.
	 *
	 * @param Context $context Context.
	 */
	public function render( Context $context ): string {
		$settings = $this->c->get( Settings::class );
		$lines    = array();

		$robots = null;
		if ( $settings->get( 'output_robots' ) ) {
			$robots = $this->safely(
				function () use ( $context ) {
					$resolver = $this->c->get( RobotsResolver::class );
					return $resolver->content( $resolver->resolve( $context ) );
				}
			);
			if ( is_string( $robots ) && '' !== $robots ) {
				$lines[] = sprintf( '<meta name="robots" content="%s" />', esc_attr( $robots ) );
			}
		}
		$noindex = is_string( $robots ) && str_starts_with( $robots, 'noindex' );

		$description = '';
		if ( $settings->get( 'output_description' ) || $settings->get( 'output_social' ) ) {
			$description = (string) $this->safely( fn() => $this->c->get( Templates::class )->description( $context ) );
			$description = self::trim_description( $description );
			if ( $settings->get( 'output_description' ) && '' !== $description ) {
				$lines[] = sprintf( '<meta name="description" content="%s" />', esc_attr( $description ) );
			}
		}

		$canonical = '';
		if ( ! $noindex && ( $settings->get( 'output_canonical' ) || $settings->get( 'output_social' ) ) ) {
			$canonical = (string) $this->safely( fn() => $this->c->get( CanonicalResolver::class )->resolve( $context ) );
			if ( $settings->get( 'output_canonical' ) && '' !== $canonical && \FutureLabs\AISEO\Core\Url::is_valid( $canonical ) ) {
				$lines[] = sprintf( '<link rel="canonical" href="%s" />', esc_url( $canonical ) );
			}
		}

		if ( $settings->get( 'output_social' ) && ! in_array( $context->kind, array( 'search', '404' ), true ) ) {
			$social = $this->safely(
				function () use ( $context, $description, $canonical ) {
					$templates = $this->c->get( Templates::class );
					$title     = $templates->title( $context );
					return $templates->social( $context, '' !== $title ? $title : wp_get_document_title(), $description, $canonical );
				}
			);
			if ( is_array( $social ) ) {
				$lines = array_merge( $lines, $this->social_tags( $social ) );
			}
		}

		if ( ! $lines ) {
			return '';
		}
		return "\n<!-- FutureLabs AI SEO -->\n" . implode( "\n", $lines ) . "\n<!-- /FutureLabs AI SEO -->\n";
	}

	/**
	 * Open Graph and X card tags.
	 *
	 * @param array<string, mixed> $s Social fields.
	 * @return array<int, string>
	 */
	private function social_tags( array $s ): array {
		$tags = array(
			sprintf( '<meta property="og:locale" content="%s" />', esc_attr( str_replace( '-', '_', get_bloginfo( 'language' ) ) ) ),
			sprintf( '<meta property="og:type" content="%s" />', esc_attr( (string) $s['type'] ) ),
			sprintf( '<meta property="og:title" content="%s" />', esc_attr( wp_strip_all_tags( (string) $s['title'] ) ) ),
		);
		if ( '' !== $s['description'] ) {
			$tags[] = sprintf( '<meta property="og:description" content="%s" />', esc_attr( wp_strip_all_tags( (string) $s['description'] ) ) );
		}
		if ( '' !== $s['url'] ) {
			$tags[] = sprintf( '<meta property="og:url" content="%s" />', esc_url( (string) $s['url'] ) );
		}
		$tags[] = sprintf( '<meta property="og:site_name" content="%s" />', esc_attr( wp_strip_all_tags( get_bloginfo( 'name' ) ) ) );
		if ( '' !== $s['published'] ) {
			$tags[] = sprintf( '<meta property="article:published_time" content="%s" />', esc_attr( (string) $s['published'] ) );
			$tags[] = sprintf( '<meta property="article:modified_time" content="%s" />', esc_attr( (string) $s['modified'] ) );
		}
		if ( '' !== $s['image'] ) {
			$tags[] = sprintf( '<meta property="og:image" content="%s" />', esc_url( (string) $s['image'] ) );
			if ( $s['image_width'] ) {
				$tags[] = sprintf( '<meta property="og:image:width" content="%d" />', (int) $s['image_width'] );
				$tags[] = sprintf( '<meta property="og:image:height" content="%d" />', (int) $s['image_height'] );
			}
		}
		$tags[] = sprintf( '<meta name="twitter:card" content="%s" />', '' !== $s['image'] ? 'summary_large_image' : 'summary' );
		$tags[] = sprintf( '<meta name="twitter:title" content="%s" />', esc_attr( wp_strip_all_tags( (string) $s['title'] ) ) );
		if ( '' !== $s['description'] ) {
			$tags[] = sprintf( '<meta name="twitter:description" content="%s" />', esc_attr( wp_strip_all_tags( (string) $s['description'] ) ) );
		}
		if ( '' !== $s['image'] ) {
			$tags[] = sprintf( '<meta name="twitter:image" content="%s" />', esc_url( (string) $s['image'] ) );
		}
		$site = ltrim( (string) $this->c->get( Settings::class )->get( 'twitter_site' ), '@' );
		if ( '' !== $site ) {
			$tags[] = sprintf( '<meta name="twitter:site" content="@%s" />', esc_attr( $site ) );
		}
		return $tags;
	}

	/**
	 * Run a resolver and swallow errors, returning null on failure.
	 *
	 * @param callable $callback Resolver.
	 * @return mixed|null
	 */
	private function safely( callable $callback ) {
		try {
			return $callback();
		} catch ( \Throwable $e ) {
			$this->c->get( Logger::class )->error( 'Head output skipped after resolver error: ' . $e->getMessage() );
			return null;
		}
	}

	/**
	 * Limit a description to about 160 characters on a word boundary.
	 *
	 * @param string $text Text.
	 */
	public static function trim_description( string $text ): string {
		$text = trim( (string) preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $text ) ) );
		if ( mb_strlen( $text ) <= 160 ) {
			return $text;
		}
		$cut   = mb_substr( $text, 0, 157 );
		$space = mb_strrpos( $cut, ' ' );
		return rtrim( false !== $space && $space > 100 ? mb_substr( $cut, 0, $space ) : $cut, ' ,.;:' ) . '…';
	}
}
