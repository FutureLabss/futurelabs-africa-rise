<?php
/**
 * Search Console connection, property, sitemap submission and analytics sync.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Gsc\Analytics;
use FutureLabs\AISEO\Gsc\Client;
use FutureLabs\AISEO\Gsc\Inspector;
use FutureLabs\AISEO\Gsc\OAuth;
use FutureLabs\AISEO\Gsc\Sitemaps;

defined( 'ABSPATH' ) || exit;

/**
 * `/gsc/*` and `/sitemap/submit`. Never returns tokens or client secrets.
 */
class GscController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/gsc/connect', 'POST', array( $this, 'connect' ), Capabilities::SETTINGS );
		$this->route( '/gsc/status', 'GET', array( $this, 'status' ) );
		$this->route( '/gsc/disconnect', 'POST', array( $this, 'disconnect' ), Capabilities::SETTINGS );
		$this->route( '/gsc/properties', 'GET', array( $this, 'properties' ), Capabilities::SETTINGS );
		$this->route(
			'/gsc/property',
			'POST',
			array( $this, 'set_property' ),
			Capabilities::SETTINGS,
			array(
				'property' => array(
					'type'     => 'string',
					'required' => true,
				),
			)
		);
		$this->route( '/sitemap/submit', 'POST', array( $this, 'submit_sitemap' ) );
		$this->route( '/gsc/sync', 'POST', array( $this, 'sync' ) );
	}

	/**
	 * Start OAuth: returns the Google consent URL.
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function connect() {
		$url = $this->c->get( OAuth::class )->authorization_url();
		if ( is_wp_error( $url ) ) {
			return $this->error( 'gsc_no_client', $url->get_error_message(), 400 );
		}
		return rest_ensure_response(
			array(
				'authorization_url' => $url,
				'redirect_uri'      => OAuth::redirect_uri(),
			)
		);
	}

	/**
	 * Connection status.
	 */
	public function status(): \WP_REST_Response {
		$oauth    = $this->c->get( OAuth::class );
		$property = $oauth->property();
		return rest_ensure_response(
			array(
				'connected'               => $oauth->is_connected(),
				'client_configured'       => $oauth->has_client(),
				'redirect_uri'            => OAuth::redirect_uri(),
				'property'                => $property,
				'property_type'           => '' === $property ? null : ( str_starts_with( $property, 'sc-domain:' ) ? 'domain' : 'url_prefix' ),
				'quota'                   => $this->c->get( Inspector::class )->quota( $property ),
				'last_sync'               => $this->c->get( Analytics::class )->last() ?: null,
				'sync_pending'            => $this->c->get( Queue::class )->is_pending( Analytics::HOOK ),
				'last_sitemap_submission' => $this->c->get( Sitemaps::class )->last() ?: null,
			)
		);
	}

	/**
	 * Disconnect (revokes at Google when possible; always clears local tokens).
	 */
	public function disconnect(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( OAuth::class )->disconnect() );
	}

	/**
	 * Properties available to the connected account.
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function properties() {
		$oauth = $this->c->get( OAuth::class );
		if ( ! $oauth->is_connected() ) {
			return $this->error( 'gsc_not_connected', __( 'Search Console is not connected.', 'futurelabs-ai-seo' ), 400 );
		}
		$sites = $this->c->get( Client::class )->sites();
		if ( is_wp_error( $sites ) ) {
			return $this->error( 'gsc_api', $sites->get_error_message(), 502 );
		}
		return rest_ensure_response(
			array(
				'items'     => $sites,
				'total'     => count( $sites ),
				'selected'  => $oauth->property(),
				'suggested' => $this->suggest( $sites ),
			)
		);
	}

	/**
	 * Property that best matches this site: URL prefix of home_url, else the domain property.
	 *
	 * @param array<int, array<string, string>> $sites Sites.
	 */
	private function suggest( array $sites ): string {
		$home = trailingslashit( home_url( '/' ) );
		$host = strtolower( (string) wp_parse_url( $home, PHP_URL_HOST ) );
		$best = '';
		foreach ( $sites as $site ) {
			if ( 'url_prefix' === $site['type'] && str_starts_with( $home, trailingslashit( $site['site_url'] ) ) ) {
				return $site['site_url'];
			}
			$domain = strtolower( $site['label'] );
			if ( 'domain' === $site['type'] && ( $host === $domain || str_ends_with( $host, '.' . $domain ) ) ) {
				$best = $site['site_url'];
			}
		}
		return $best;
	}

	/**
	 * Select a property. It must be one the account can access.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function set_property( \WP_REST_Request $request ) {
		$oauth = $this->c->get( OAuth::class );
		if ( ! $oauth->is_connected() ) {
			return $this->error( 'gsc_not_connected', __( 'Search Console is not connected.', 'futurelabs-ai-seo' ), 400 );
		}
		$property = trim( sanitize_text_field( (string) $request->get_param( 'property' ) ) );
		if ( '' === $property ) {
			return $this->error( 'invalid_property', __( 'Choose a Search Console property.', 'futurelabs-ai-seo' ) );
		}
		$sites = $this->c->get( Client::class )->sites();
		if ( is_wp_error( $sites ) ) {
			return $this->error( 'gsc_api', $sites->get_error_message(), 502 );
		}
		$match = null;
		foreach ( $sites as $site ) {
			if ( $site['site_url'] === $property ) {
				$match = $site;
				break;
			}
		}
		if ( null === $match ) {
			return $this->error( 'invalid_property', __( 'That property is not available to the connected Google account.', 'futurelabs-ai-seo' ) );
		}
		$oauth->set_property( $property );
		return rest_ensure_response(
			array(
				'property'      => $property,
				'property_type' => $match['type'],
			)
		);
	}

	/**
	 * Submit the sitemap now.
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function submit_sitemap() {
		$result = $this->c->get( Sitemaps::class )->submit();
		if ( is_wp_error( $result ) ) {
			return $this->error( 'gsc_not_ready', $result->get_error_message(), 400 );
		}
		if ( ! $result['ok'] ) {
			return $this->error( 'gsc_api', $result['error'], 502, array( 'submission' => $result ) );
		}
		return rest_ensure_response( $result );
	}

	/**
	 * Queue a Search Analytics sync.
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function sync() {
		if ( ! $this->c->get( Analytics::class )->queue() ) {
			return $this->error( 'gsc_not_ready', __( 'Connect Search Console and choose a property first.', 'futurelabs-ai-seo' ), 400 );
		}
		return rest_ensure_response(
			array(
				'queued'  => true,
				'pending' => $this->c->get( Queue::class )->is_pending( Analytics::HOOK ),
			)
		);
	}
}
