<?php
/**
 * GET /sitemap/status · POST /sitemap/validate
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Sitemap\Builder;
use FutureLabs\AISEO\Sitemap\Router;
use FutureLabs\AISEO\Sitemap\Validator;

defined( 'ABSPATH' ) || exit;

/**
 * Sitemap status and validation.
 */
class SitemapController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/sitemap/status', 'GET', array( $this, 'status' ) );
		$this->route( '/sitemap/validate', 'POST', array( $this, 'validate' ) );
	}

	/**
	 * Sitemap index entries and last validation.
	 */
	public function status(): \WP_REST_Response {
		$builder = $this->c->get( Builder::class );
		$last    = get_option( 'flseo_gsc_sitemap_submitted', array() );
		// An empty PHP array encodes as JSON [], which the screen would read as a record.
		$last = is_array( $last ) && $last ? $last : null;
		$gsc  = class_exists( \FutureLabs\AISEO\Gsc\OAuth::class ) ? $this->c->get( \FutureLabs\AISEO\Gsc\OAuth::class )->is_connected() : false;
		return rest_ensure_response(
			array(
				'index_url'             => Router::index_url(),
				'sitemaps'              => '0' === (string) get_option( 'blog_public' ) ? array() : $builder->index(),
				'post_types'            => $builder->post_types(),
				'taxonomies'            => $builder->taxonomies(),
				'core_sitemap_disabled' => ! apply_filters( 'wp_sitemaps_enabled', true ), // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- reading the core filter.
				'discouraged'           => '0' === (string) get_option( 'blog_public' ),
				'last_validation'       => $this->c->get( Validator::class )->last(),
				'last_submission'       => $last,
				'search_console'        => $gsc,
			)
		);
	}

	/**
	 * Validate now (sample of up to 10 when sync=1) or queue a full background validation.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function validate( \WP_REST_Request $request ): \WP_REST_Response {
		$validator = $this->c->get( Validator::class );
		if ( $request->get_param( 'sync' ) ) {
			return rest_ensure_response( $validator->run( min( 10, absint( $request->get_param( 'sample' ) ?: 10 ) ) ) );
		}
		$validator->queue();
		return rest_ensure_response(
			array(
				'queued'  => true,
				'pending' => $this->c->get( Queue::class )->is_pending( 'flseo_validate_sitemap' ),
			)
		);
	}
}
