<?php
/**
 * Validation for per-post JSON-LD overrides.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Overrides are a JSON object (one node) or array of nodes, each with a @type.
 */
final class Overrides {

	/**
	 * Parse and validate an override string.
	 *
	 * @param string $raw JSON text.
	 * @return array{valid: bool, nodes: array<int, array<string, mixed>>, error: string}
	 */
	public static function parse( string $raw ): array {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return array(
				'valid' => true,
				'nodes' => array(),
				'error' => '',
			);
		}
		$decoded = json_decode( $raw, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			return array(
				'valid' => false,
				'nodes' => array(),
				'error' => __( 'Schema overrides must be valid JSON.', 'futurelabs-ai-seo' ),
			);
		}
		$is_list = array() === $decoded || array_keys( $decoded ) === range( 0, count( $decoded ) - 1 );
		$nodes   = $is_list ? $decoded : array( $decoded );
		if ( isset( $decoded['@graph'] ) && is_array( $decoded['@graph'] ) ) {
			$nodes = $decoded['@graph'];
		}
		$clean = array();
		foreach ( $nodes as $node ) {
			if ( ! is_array( $node ) || empty( $node['@type'] ) || ! is_string( $node['@type'] ) ) {
				return array(
					'valid' => false,
					'nodes' => array(),
					'error' => __( 'Every override node needs a string @type.', 'futurelabs-ai-seo' ),
				);
			}
			if ( ! preg_match( '/^[A-Z][A-Za-z]+$/', $node['@type'] ) ) {
				return array(
					'valid' => false,
					'nodes' => array(),
					'error' => __( '@type must be a schema.org type name.', 'futurelabs-ai-seo' ),
				);
			}
			unset( $node['@context'] );
			$clean[] = $node;
		}
		return array(
			'valid' => true,
			'nodes' => $clean,
			'error' => '',
		);
	}

	/**
	 * Sanitizer for meta storage: returns normalized JSON or an empty string.
	 *
	 * @param string $raw JSON text.
	 */
	public static function sanitize( string $raw ): string {
		$parsed = self::parse( $raw );
		if ( ! $parsed['valid'] || ! $parsed['nodes'] ) {
			return '';
		}
		return (string) wp_json_encode( $parsed['nodes'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	}
}
