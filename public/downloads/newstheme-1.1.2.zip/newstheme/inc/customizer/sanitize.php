<?php
/**
 * Sanitizers for every control type. Each receives the raw value and the
 * setting's config array, and returns a clean value (falling back to the
 * default on anything invalid).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Pick the sanitizer for a setting config.
 *
 * @param array $setting Setting config.
 * @return callable
 */
function newstheme_sanitizer_for( array $setting ) {
	return function ( $value ) use ( $setting ) {
		$fallback = $setting['default'] ?? null;
		switch ( $setting['control'] ) {
			case 'color':
				return newstheme_sanitize_color( $value, ! empty( $setting['gradient'] ), $fallback );
			case 'palette':
				return newstheme_sanitize_palette( $value, $fallback );
			case 'toggle':
				return (bool) $value;
			case 'number':
				return newstheme_sanitize_number( $value, $setting, $fallback );
			case 'responsive':
				return newstheme_sanitize_responsive( $value, $setting, $fallback );
			case 'typography':
				return newstheme_sanitize_typography( $value, $fallback );
			case 'select':
			case 'buttons':
				return array_key_exists( (string) $value, $setting['choices'] ) ? (string) $value : $fallback;
			case 'sortable':
				return newstheme_sanitize_sortable( $value, $setting );
			case 'repeater':
				return newstheme_sanitize_repeater( $value, $setting );
			case 'multiselect':
				return newstheme_sanitize_id_list( $value );
			case 'builder':
				return newstheme_sanitize_builder( $value, $setting['builder'] );
			case 'image':
				return absint( $value );
			case 'blocks':
				return newstheme_sanitize_blocks( $value, $setting['types'] );
			case 'url':
				return esc_url_raw( (string) $value );
			default:
				return sanitize_text_field( (string) $value );
		}
	};
}

/**
 * Color: hex, rgb(a), hsl(a), a preset var, or (if allowed) a CSS gradient.
 *
 * @param mixed  $value          Raw value.
 * @param bool   $allow_gradient Whether gradients are allowed.
 * @param string $fallback       Fallback value.
 * @return string
 */
function newstheme_sanitize_color( $value, $allow_gradient = false, $fallback = '' ) {
	$value = trim( (string) $value );

	if ( '' === $value ) {
		return '';
	}
	if ( sanitize_hex_color( $value ) ) {
		return strtolower( $value );
	}
	if ( preg_match( '/^(rgba?|hsla?)\(\s*[\d.%\s,\/]+\)$/i', $value ) ) {
		return $value;
	}
	if ( preg_match( '/^var\(--nt-preset-\d{1,2}\)$/', $value ) ) {
		return $value;
	}
	if ( $allow_gradient && preg_match( '/^(linear|radial)-gradient\([#\w\s,.%()\-\/]+\)$/i', $value ) ) {
		return $value;
	}
	return (string) $fallback;
}

/**
 * Palette: list of hex colors, same length as the default.
 *
 * @param mixed $value   Raw value.
 * @param array $fallback Default palette.
 * @return array
 */
function newstheme_sanitize_palette( $value, $fallback ) {
	$value = is_array( $value ) ? array_values( $value ) : array();
	$clean = array();
	foreach ( $fallback as $i => $default_color ) {
		$color       = isset( $value[ $i ] ) ? sanitize_hex_color( $value[ $i ] ) : null;
		$clean[ $i ] = $color ? strtolower( $color ) : $default_color;
	}
	return $clean;
}

/**
 * Clamp a number to the setting's min/max.
 *
 * @param mixed     $value    Raw value.
 * @param array     $setting  Setting config.
 * @param int|float $fallback Fallback when empty/invalid.
 * @return int|float|string Empty string means "inherit".
 */
function newstheme_sanitize_number( $value, array $setting, $fallback ) {
	if ( '' === $value || null === $value ) {
		return $fallback;
	}
	if ( ! is_numeric( $value ) ) {
		return $fallback;
	}
	$value = 0 + $value;
	if ( isset( $setting['min'] ) ) {
		$value = max( $setting['min'], $value );
	}
	if ( isset( $setting['max'] ) ) {
		$value = min( $setting['max'], $value );
	}
	return $value;
}

/**
 * Responsive value: { desktop, tablet, mobile } numbers.
 *
 * @param mixed $value   Raw value.
 * @param array $setting Setting config.
 * @param array $fallback Default value.
 * @return array
 */
function newstheme_sanitize_responsive( $value, array $setting, array $fallback ) {
	$value = is_array( $value ) ? $value : array();
	$clean = array();
	foreach ( array( 'desktop', 'tablet', 'mobile' ) as $device ) {
		$clean[ $device ] = newstheme_sanitize_number( $value[ $device ] ?? null, $setting, $fallback[ $device ] );
	}
	return $clean;
}

/**
 * Typography value.
 *
 * @param mixed $value   Raw value.
 * @param array $fallback Default value.
 * @return array
 */
function newstheme_sanitize_typography( $value, array $fallback ) {
	$value = is_array( $value ) ? $value : array();
	$clean = $fallback;

	if ( isset( $value['family'] ) && array_key_exists( $value['family'], newstheme_font_families() ) ) {
		$clean['family'] = $value['family'];
	}
	if ( isset( $value['weight'] ) && in_array( (int) $value['weight'], range( 100, 900, 100 ), true ) ) {
		$clean['weight'] = (int) $value['weight'];
	}
	if ( isset( $value['transform'] ) && in_array( $value['transform'], array( 'none', 'capitalize', 'uppercase', 'lowercase' ), true ) ) {
		$clean['transform'] = $value['transform'];
	}
	if ( isset( $value['decoration'] ) && in_array( $value['decoration'], array( 'none', 'underline', 'line-through' ), true ) ) {
		$clean['decoration'] = $value['decoration'];
	}

	$limits = array(
		'size'       => array(
			'min' => 8,
			'max' => 120,
		),
		'lineHeight' => array(
			'min' => 8,
			'max' => 160,
		),
		'spacing'    => array(
			'min' => -5,
			'max' => 20,
		),
	);
	foreach ( $limits as $key => $limit ) {
		if ( isset( $value[ $key ] ) ) {
			$clean[ $key ] = newstheme_sanitize_responsive( $value[ $key ], $limit, $fallback[ $key ] );
		}
	}

	return $clean;
}

/**
 * Sortable list: [ { id, enabled } ] containing exactly the known choices.
 *
 * @param mixed $value   Raw value.
 * @param array $setting Setting config.
 * @return array
 */
function newstheme_sanitize_sortable( $value, array $setting ) {
	$value = is_array( $value ) ? $value : array();
	$seen  = array();
	$clean = array();

	foreach ( $value as $item ) {
		$id = is_array( $item ) && isset( $item['id'] ) ? (string) $item['id'] : '';
		if ( isset( $setting['choices'][ $id ] ) && ! isset( $seen[ $id ] ) ) {
			$seen[ $id ] = true;
			$clean[]     = array(
				'id'      => $id,
				'enabled' => ! empty( $item['enabled'] ),
			);
		}
	}

	// Append choices added after the value was saved.
	foreach ( array_keys( $setting['choices'] ) as $id ) {
		if ( ! isset( $seen[ $id ] ) ) {
			$clean[] = array(
				'id'      => $id,
				'enabled' => true,
			);
		}
	}

	return $clean;
}

/**
 * Repeater: list of items, each sanitized field by field.
 *
 * @param mixed $value   Raw value.
 * @param array $setting Setting config.
 * @return array
 */
function newstheme_sanitize_repeater( $value, array $setting ) {
	$value = is_array( $value ) ? array_values( $value ) : array();
	$clean = array();

	foreach ( array_slice( $value, 0, 50 ) as $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}
		$row = array();
		foreach ( $setting['fields'] as $key => $field ) {
			$raw = $item[ $key ] ?? $field['default'];
			switch ( $field['type'] ) {
				case 'url':
					$row[ $key ] = esc_url_raw( (string) $raw );
					break;
				case 'toggle':
					$row[ $key ] = (bool) $raw;
					break;
				case 'select':
					$row[ $key ] = array_key_exists( (string) $raw, $field['choices'] ) ? (string) $raw : $field['default'];
					break;
				case 'image':
					$row[ $key ] = absint( $raw );
					break;
				case 'textarea':
					$row[ $key ] = sanitize_textarea_field( (string) $raw );
					break;
				default:
					$row[ $key ] = sanitize_text_field( (string) $raw );
			}
		}
		$clean[] = $row;
	}

	return $clean;
}

/**
 * List of unique positive integer IDs.
 *
 * @param mixed $value Raw value.
 * @return int[]
 */
function newstheme_sanitize_id_list( $value ) {
	$value = is_array( $value ) ? $value : array();
	return array_values( array_unique( array_filter( array_map( 'absint', $value ) ) ) );
}
