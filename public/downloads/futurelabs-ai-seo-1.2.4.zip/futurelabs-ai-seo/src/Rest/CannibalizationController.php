<?php
/**
 * GET /cannibalization
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Cannibalization\Detector;
use FutureLabs\AISEO\Core\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Queries where several of this site's URLs compete, plus edition groups.
 */
class CannibalizationController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/cannibalization', 'GET', array( $this, 'index' ), Capabilities::DATA );
	}

	/**
	 * Conflicts list.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function index( \WP_REST_Request $request ): \WP_REST_Response {
		list( $page, $per_page ) = $this->paging( $request );
		$detector                = $this->c->get( Detector::class );
		$result                  = $detector instanceof Detector ? $detector->detect() : array();
		$result['items']         = array_slice( (array) ( $result['items'] ?? array() ), ( $page - 1 ) * $per_page, $per_page );
		if ( '' === ( $result['range'] ?? '' ) ) {
			$result['message'] = __( 'No Search Console query data yet. Connect Search Console and sync analytics to find competing pages.', 'futurelabs-ai-seo' );
		}
		return new \WP_REST_Response( $result );
	}
}
