<?php
/**
 * Header element: opens the off-canvas sidebar.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

newstheme_dialogs( 'offcanvas' );
?>
<button type="button" class="nt-icon-btn nt-burger nt-offcanvas-toggle" data-nt-open="nt-offcanvas" aria-haspopup="dialog" aria-label="<?php esc_attr_e( 'Open sidebar', 'newstheme' ); ?>">
	<span></span><span></span><span></span>
</button>
