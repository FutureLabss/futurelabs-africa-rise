<?php
/**
 * Extras: video playlist, opinions strip, headlines marquee, preloader.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * YouTube video ID from a URL (watch, youtu.be, embed, shorts) or a bare ID.
 *
 * @param string $url URL or ID.
 * @return string Empty if not recognized.
 */
function newstheme_youtube_id( $url ) {
	$url = trim( (string) $url );
	if ( preg_match( '/^[\w-]{11}$/', $url ) ) {
		return $url;
	}
	if ( preg_match( '~(?:youtu\.be/|youtube(?:-nocookie)?\.com/(?:watch\?(?:.*&)?v=|embed/|shorts/|live/))([\w-]{11})~', $url, $m ) ) {
		return $m[1];
	}
	return '';
}

/**
 * Video title via oEmbed, cached for a week (empty if unavailable).
 *
 * @param string $id YouTube ID.
 * @return string
 */
function newstheme_youtube_title( $id ) {
	$key   = 'nt_yt_' . $id;
	$title = get_transient( $key );
	if ( false === $title ) {
		$title = '';
		$data  = _wp_oembed_get_object()->get_data( 'https://www.youtube.com/watch?v=' . $id );
		if ( $data && ! empty( $data->title ) ) {
			$title = (string) $data->title;
		}
		// Cache failures briefly so an offline server isn't asked on every view.
		set_transient( $key, $title, $title ? WEEK_IN_SECONDS : HOUR_IN_SECONDS );
	}
	return $title;
}

/**
 * Playlist items with IDs, titles and thumbnails resolved.
 *
 * @return array[]
 */
function newstheme_video_items() {
	$items = array();
	foreach ( (array) newstheme_get_mod( 'video_items' ) as $i => $item ) {
		$id = newstheme_youtube_id( $item['url'] ?? '' );
		if ( ! $id ) {
			continue;
		}
		$title   = trim( (string) ( $item['title'] ?? '' ) );
		$items[] = array(
			'id'       => $id,
			/* translators: %d: video number. */
			'title'    => $title ? $title : ( newstheme_youtube_title( $id ) ? newstheme_youtube_title( $id ) : sprintf( __( 'Video %d', 'newstheme' ), $i + 1 ) ),
			'duration' => trim( (string) ( $item['duration'] ?? '' ) ),
			'thumb'    => 'https://i.ytimg.com/vi/' . $id . '/mqdefault.jpg',
			'poster'   => 'https://i.ytimg.com/vi/' . $id . '/hqdefault.jpg',
		);
	}
	return $items;
}

/**
 * Opinions with images resolved.
 *
 * @return array[]
 */
function newstheme_opinion_items() {
	return array_values(
		array_filter(
			(array) newstheme_get_mod( 'opinion_items' ),
			static function ( $item ) {
				return '' !== trim( (string) ( $item['title'] ?? '' ) );
			}
		)
	);
}

/**
 * Opinions strip wrapper. Printed above the footer (location "footer") or
 * as a homepage section; the wrapper is the selective-refresh target.
 */
function newstheme_render_opinions_wrap() {
	echo '<div class="nt-opinions-wrap">';
	get_template_part( 'template-parts/sections/opinions' );
	echo '</div>';
}

/**
 * Print the opinions strip above the footer on every page.
 */
function newstheme_opinions_above_footer() {
	if ( 'footer' === newstheme_get_mod( 'opinions_location' ) ) {
		newstheme_render_opinions_wrap();
	}
}
add_action( 'newstheme_before_footer', 'newstheme_opinions_above_footer' );

/**
 * Whether the headlines bar shows on the current page.
 *
 * @return bool
 */
function newstheme_headlines_visible() {
	$show = newstheme_get_mod( 'headlines_show' );
	return 'all' === $show || ( 'inner' === $show && ! is_front_page() );
}

/**
 * Headlines bar wrapper (selective-refresh target). The wrapper is printed
 * even when the bar is hidden so the Customizer preview can fill it.
 */
function newstheme_render_headlines_wrap() {
	echo '<div class="nt-headlines-wrap">';
	if ( newstheme_headlines_visible() ) {
		get_template_part( 'template-parts/sections/headlines' );
	}
	echo '</div>';
}
add_action( 'newstheme_after_header', 'newstheme_render_headlines_wrap' );

/**
 * Preloader overlay (removed by JS on load; CSS hides it without JS and for
 * reduced motion).
 */
function newstheme_preloader() {
	$style = newstheme_get_mod( 'preloader' );
	if ( 'off' === $style || is_customize_preview() ) {
		return;
	}
	printf( '<div class="nt-preloader nt-preloader--%s" data-nt-preloader aria-hidden="true">', esc_attr( $style ) );
	if ( 'title' === $style ) {
		printf( '<span class="nt-preloader__title">%s</span>', esc_html( get_bloginfo( 'name' ) ) );
	} elseif ( in_array( $style, array( 'dots', 'bars' ), true ) ) {
		echo '<span></span><span></span><span></span><span></span>';
	} else {
		echo '<span class="nt-preloader__shape"></span>';
	}
	echo '</div><noscript><style>.nt-preloader{display:none}</style></noscript>';
}
add_action( 'wp_body_open', 'newstheme_preloader', 2 );
