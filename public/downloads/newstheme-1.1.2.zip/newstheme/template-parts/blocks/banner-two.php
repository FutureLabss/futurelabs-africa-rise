<?php
/**
 * Block: main banner, layout two — full-width slider with a row of cards below.
 * Same markup as layout one; the arrangement is CSS (.nt-banner--two).
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args.
 */

defined( 'ABSPATH' ) || exit;

get_template_part( 'template-parts/blocks/banner', 'one', array_merge( $args, array( 'variant' => 'two' ) ) );
