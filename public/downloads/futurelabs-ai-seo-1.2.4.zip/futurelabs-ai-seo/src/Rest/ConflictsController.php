<?php
/**
 * GET /conflicts · POST /conflicts/probe · POST /conflicts/deactivate
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Conflicts\Detector;
use FutureLabs\AISEO\Conflicts\FrontendProbe;
use FutureLabs\AISEO\Core\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Conflict report, on-demand frontend probe and deactivation of a replaced SEO plugin.
 */
class ConflictsController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/conflicts', 'GET', array( $this, 'report' ), Capabilities::SETTINGS );
		$this->route( '/conflicts/probe', 'POST', array( $this, 'probe' ), Capabilities::SETTINGS );
		$this->route( '/conflicts/deactivate', 'POST', array( $this, 'deactivate' ), Capabilities::SETTINGS );
	}

	/**
	 * Conflict report.
	 */
	public function report(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( Detector::class )->report() );
	}

	/**
	 * Run the frontend probe now.
	 */
	public function probe(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( FrontendProbe::class )->run() );
	}

	/**
	 * Deactivate a known SEO plugin after import.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function deactivate( \WP_REST_Request $request ) {
		$slug = (string) ( $this->body( $request )['slug'] ?? '' );
		if ( ! array_key_exists( $slug, Detector::seo_plugins() ) ) {
			return $this->error( 'unknown_plugin', __( 'Only known SEO plugins can be deactivated from FutureLabs AI SEO.', 'futurelabs-ai-seo' ), 400 );
		}
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return $this->error( 'forbidden', __( 'You are not allowed to deactivate plugins.', 'futurelabs-ai-seo' ), 403 );
		}
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		deactivate_plugins( $slug );
		return rest_ensure_response( array( 'deactivated' => ! is_plugin_active( $slug ) ) );
	}
}
