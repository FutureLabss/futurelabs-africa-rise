<?php
/**
 * Block: news filter, layout two — tabs over a grid of cards. Shares the tab
 * markup with layout one; only the panel differs (news-filter-two-panel.php).
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args.
 */

defined( 'ABSPATH' ) || exit;

get_template_part( 'template-parts/blocks/news-filter', 'one', $args );
