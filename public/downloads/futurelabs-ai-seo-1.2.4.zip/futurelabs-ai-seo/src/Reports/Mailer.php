<?php
/**
 * Sends report emails through wp_mail with an HTML body and a plain-text alternative.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Reports;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Thin wrapper around wp_mail().
 */
class Mailer {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Plain-text alternative for the message being sent.
	 *
	 * @var string
	 */
	private string $alt = '';

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Valid recipients from settings.
	 *
	 * @return array<int, string>
	 */
	public function recipients(): array {
		$raw   = (string) $this->c->get( Settings::class )->get( 'reports_recipients', '' );
		$items = preg_split( '/[,;\s]+/', $raw, -1, PREG_SPLIT_NO_EMPTY ) ?: array();
		return array_values( array_unique( array_filter( array_map( 'sanitize_email', $items ), 'is_email' ) ) );
	}

	/**
	 * Send one email.
	 *
	 * @param array<int, string> $to      Recipients.
	 * @param string             $subject Subject.
	 * @param string             $html    HTML body.
	 * @param string             $text    Plain-text alternative.
	 */
	public function send( array $to, string $subject, string $html, string $text ): bool {
		if ( ! $to ) {
			return false;
		}
		$this->alt = $text;
		add_action( 'phpmailer_init', array( $this, 'add_alt_body' ) );
		$sent = wp_mail( $to, $subject, $html, array( 'Content-Type: text/html; charset=UTF-8' ) );
		remove_action( 'phpmailer_init', array( $this, 'add_alt_body' ) );
		$this->alt = '';
		return (bool) $sent;
	}

	/**
	 * Attach the plain-text alternative (turns the message into multipart/alternative).
	 *
	 * @param object $phpmailer PHPMailer instance.
	 */
	public function add_alt_body( $phpmailer ): void {
		if ( '' !== $this->alt && property_exists( $phpmailer, 'AltBody' ) ) {
			$phpmailer->AltBody = $this->alt; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		}
	}
}
