<?php
/**
 * Structured eligibility fields for opportunities (optional feature).
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Opportunity;

defined( 'ABSPATH' ) || exit;

/**
 * Field definitions, allowed values and labels for `_flseo_elig_*` and the opportunity
 * type, format and funding fields.
 *
 * Values are machine-readable so a reader-matching service can filter on them: country
 * codes (see Countries), whole numbers, or keys from the lists below. List fields store
 * comma-separated keys. Empty always means "not set", never "nobody".
 */
class Eligibility {

	/**
	 * Single-choice fields: meta key (without prefix) => allowed values.
	 */
	public const CHOICES = array(
		'opp_type'           => array( 'scholarship', 'fellowship', 'grant', 'internship', 'job', 'accelerator', 'competition', 'training', 'event', 'other' ),
		'opp_format'         => array( 'online', 'in_person', 'hybrid' ),
		'opp_funding_type'   => array( 'full', 'partial', 'none' ),
		'elig_country_basis' => array( 'citizenship', 'residence', 'either' ),
		'elig_gender'        => array( 'any', 'women', 'men' ),
	);

	/**
	 * Multiple-choice fields: meta key (without prefix) => allowed values.
	 */
	public const LISTS = array(
		'elig_levels'         => array( 'secondary', 'undergraduate', 'graduate', 'masters', 'phd', 'postdoc', 'professional' ),
		'elig_business_stage' => array( 'idea', 'prototype', 'revenue', 'growth' ),
	);

	/**
	 * Meta keys (without prefix) and their sanitizer kinds, for PostMeta::fields().
	 *
	 * @return array<string, string>
	 */
	public static function fields(): array {
		return array(
			'opp_type'            => 'choice',
			'opp_format'          => 'choice',
			'opp_funding_type'    => 'choice',
			'elig_countries'      => 'countries',
			'elig_country_basis'  => 'choice',
			'elig_age_min'        => 'age',
			'elig_age_max'        => 'age',
			'elig_gender'         => 'choice',
			'elig_levels'         => 'list',
			'elig_fields'         => 'text',
			'elig_experience_min' => 'years',
			'elig_business_stage' => 'list',
		);
	}

	/**
	 * Sanitize one eligibility value. Invalid values become ''.
	 *
	 * @param string $key   Meta key without prefix.
	 * @param string $kind  Kind from fields().
	 * @param mixed  $value Raw value.
	 */
	public static function sanitize( string $key, string $kind, $value ): string {
		switch ( $kind ) {
			case 'countries':
				return Countries::normalize( $value );
			case 'age':
				return self::whole_number( $value, 10, 100 );
			case 'years':
				return self::whole_number( $value, 0, 50 );
			case 'choice':
				$value = is_scalar( $value ) ? sanitize_key( (string) $value ) : '';
				return in_array( $value, self::CHOICES[ $key ] ?? array(), true ) ? $value : '';
			case 'list':
				$parts = is_array( $value ) ? $value : explode( ',', is_scalar( $value ) ? (string) $value : '' );
				$parts = array_map( static fn( $part ) => sanitize_key( trim( (string) $part ) ), $parts );
				return implode( ',', array_values( array_intersect( self::LISTS[ $key ] ?? array(), $parts ) ) );
		}
		return is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '';
	}

	/**
	 * A whole number within bounds, or '' when empty or out of range.
	 *
	 * @param mixed $value Raw value.
	 * @param int   $min   Minimum.
	 * @param int   $max   Maximum.
	 */
	private static function whole_number( $value, int $min, int $max ): string {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';
		if ( ! preg_match( '/^\d+$/', $value ) ) {
			return '';
		}
		$number = (int) $value;
		return $number >= $min && $number <= $max ? (string) $number : '';
	}

	/**
	 * Translated labels for field values, for the editor and classic meta box.
	 *
	 * @return array<string, string>
	 */
	public static function value_labels(): array {
		return array(
			'scholarship'   => __( 'Scholarship', 'futurelabs-ai-seo' ),
			'fellowship'    => __( 'Fellowship', 'futurelabs-ai-seo' ),
			'grant'         => __( 'Grant', 'futurelabs-ai-seo' ),
			'internship'    => __( 'Internship', 'futurelabs-ai-seo' ),
			'job'           => __( 'Job', 'futurelabs-ai-seo' ),
			'accelerator'   => __( 'Accelerator or incubator', 'futurelabs-ai-seo' ),
			'competition'   => __( 'Competition or prize', 'futurelabs-ai-seo' ),
			'training'      => __( 'Training or course', 'futurelabs-ai-seo' ),
			'event'         => __( 'Event or conference', 'futurelabs-ai-seo' ),
			'other'         => __( 'Other', 'futurelabs-ai-seo' ),
			'online'        => __( 'Online', 'futurelabs-ai-seo' ),
			'in_person'     => __( 'In person', 'futurelabs-ai-seo' ),
			'hybrid'        => __( 'Hybrid', 'futurelabs-ai-seo' ),
			'full'          => __( 'Fully funded', 'futurelabs-ai-seo' ),
			'partial'       => __( 'Partly funded', 'futurelabs-ai-seo' ),
			'none'          => __( 'Not funded', 'futurelabs-ai-seo' ),
			'citizenship'   => __( 'Citizens of these countries', 'futurelabs-ai-seo' ),
			'residence'     => __( 'Residents of these countries', 'futurelabs-ai-seo' ),
			'either'        => __( 'Citizens or residents', 'futurelabs-ai-seo' ),
			'any'           => __( 'Any gender', 'futurelabs-ai-seo' ),
			'women'         => __( 'Women only', 'futurelabs-ai-seo' ),
			'men'           => __( 'Men only', 'futurelabs-ai-seo' ),
			'secondary'     => __( 'Secondary school', 'futurelabs-ai-seo' ),
			'undergraduate' => __( 'Undergraduate', 'futurelabs-ai-seo' ),
			'graduate'      => __( 'Graduate (bachelor\'s completed)', 'futurelabs-ai-seo' ),
			'masters'       => __( 'Master\'s', 'futurelabs-ai-seo' ),
			'phd'           => __( 'PhD', 'futurelabs-ai-seo' ),
			'postdoc'       => __( 'Postdoctoral', 'futurelabs-ai-seo' ),
			'professional'  => __( 'Working professional', 'futurelabs-ai-seo' ),
			'idea'          => __( 'Idea', 'futurelabs-ai-seo' ),
			'prototype'     => __( 'Prototype or MVP', 'futurelabs-ai-seo' ),
			'revenue'       => __( 'Early revenue', 'futurelabs-ai-seo' ),
			'growth'        => __( 'Growth', 'futurelabs-ai-seo' ),
		);
	}

	/**
	 * Translated field labels.
	 *
	 * @return array<string, string>
	 */
	public static function field_labels(): array {
		return array(
			'opp_type'            => __( 'Opportunity type', 'futurelabs-ai-seo' ),
			'opp_format'          => __( 'Format', 'futurelabs-ai-seo' ),
			'opp_funding_type'    => __( 'Funding', 'futurelabs-ai-seo' ),
			'elig_countries'      => __( 'Eligible countries (codes such as NG, KE, or AFRICA / ALL)', 'futurelabs-ai-seo' ),
			'elig_country_basis'  => __( 'Country rule applies to', 'futurelabs-ai-seo' ),
			'elig_age_min'        => __( 'Minimum age', 'futurelabs-ai-seo' ),
			'elig_age_max'        => __( 'Maximum age', 'futurelabs-ai-seo' ),
			'elig_gender'         => __( 'Gender', 'futurelabs-ai-seo' ),
			'elig_levels'         => __( 'Education or career level', 'futurelabs-ai-seo' ),
			'elig_fields'         => __( 'Fields of study or work (comma-separated)', 'futurelabs-ai-seo' ),
			'elig_experience_min' => __( 'Minimum years of work experience', 'futurelabs-ai-seo' ),
			'elig_business_stage' => __( 'Business stage', 'futurelabs-ai-seo' ),
		);
	}

	/**
	 * Everything the editor needs to draw the eligibility panel.
	 *
	 * @return array<string, mixed>
	 */
	public static function editor_config(): array {
		$countries = array();
		foreach ( Countries::all() as $code => $name ) {
			$countries[] = array(
				'value' => $code,
				'label' => $name,
			);
		}
		return array(
			'choices'     => self::CHOICES,
			'lists'       => self::LISTS,
			'fieldLabels' => self::field_labels(),
			'valueLabels' => self::value_labels(),
			'countries'   => $countries,
			'regions'     => array_keys( Countries::regions() ),
		);
	}
}
