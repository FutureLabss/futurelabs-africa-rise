<?php
/**
 * Team publishing checklist (OL-5) with an optional hard publish gate.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Opportunity;

use FutureLabs\AISEO\Content\Template;
use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Features;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Links\Crawler;
use FutureLabs\AISEO\Meta\Variables;

defined( 'ABSPATH' ) || exit;

/**
 * Evaluates the publishing checklist for saved posts and unsaved editor data.
 *
 * Mode comes from the `checklist_mode` setting (Features::checklist_mode()): off runs
 * nothing, soft reports only, required keeps classic-editor posts in draft and rejects
 * block-editor/REST publish requests with HTTP 400. `checklist_items` picks which checks run.
 */
class Checklist implements Module {

	/**
	 * Set when the classic gate kept a post in draft during this request.
	 *
	 * @var bool
	 */
	private bool $blocked = false;

	/**
	 * Post IDs the Elementor gate already checked against the content being saved.
	 *
	 * @var array<int, bool>
	 */
	private array $elementor_checked = array();

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_filter( 'wp_insert_post_data', array( $this, 'classic_gate' ), 20, 3 );
		add_action( 'init', array( $this, 'register_rest_gates' ), 99 );
		add_filter( 'redirect_post_location', array( $this, 'redirect_location' ) );
		add_action( 'admin_notices', array( $this, 'notice' ) );
		add_action( 'elementor/document/before_save', array( $this, 'elementor_gate' ), 10, 2 );
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'elementor_script' ) );
	}

	/**
	 * Attach the REST gate to every public post type.
	 */
	public function register_rest_gates(): void {
		foreach ( get_post_types( array( 'public' => true ), 'names' ) as $type ) {
			if ( 'attachment' !== $type ) {
				add_filter( 'rest_pre_insert_' . $type, array( $this, 'rest_gate' ), 10, 2 );
			}
		}
	}

	/**
	 * Whether the hard gate is on.
	 */
	public function is_hard(): bool {
		return 'required' === $this->c->get( Features::class )->checklist_mode();
	}

	/**
	 * Whether the checklist runs at all (soft or required).
	 */
	public function is_on(): bool {
		return 'off' !== $this->c->get( Features::class )->checklist_mode();
	}

	/**
	 * Evaluate the checklist.
	 *
	 * @param \WP_Post             $post Post (may be unsaved, ID 0).
	 * @param array<string, mixed> $data Unsaved values that override stored ones:
	 *                                   meta (array of `_flseo_*` => value), featured_media (int),
	 *                                   categories (int[]), content (string), title (string).
	 * @return array<int, array{key: string, label: string, ok: bool}>
	 */
	public function evaluate( \WP_Post $post, array $data = array() ): array {
		if ( ! $this->is_on() ) {
			return array();
		}
		$post = clone $post;
		if ( isset( $data['content'] ) ) {
			$post->post_content = (string) $data['content'];
		}
		if ( isset( $data['title'] ) ) {
			$post->post_title = (string) $data['title'];
		}
		$meta = isset( $data['meta'] ) && is_array( $data['meta'] ) ? $data['meta'] : array();
		$get  = static function ( string $key ) use ( $post, $meta ): string {
			if ( array_key_exists( $key, $meta ) ) {
				return is_scalar( $meta[ $key ] ) ? trim( (string) $meta[ $key ] ) : '';
			}
			return $post->ID ? trim( (string) get_post_meta( $post->ID, $key, true ) ) : '';
		};

		$html = (string) $post->post_content;
		if ( '' === trim( $html ) && $post->ID ) {
			$elementor = (string) get_post_meta( $post->ID, '_elementor_data', true );
			$html      = '' !== $elementor ? \FutureLabs\AISEO\Content\Analyzer::elementor_data_html( $elementor ) : '';
		}
		$parsed = Crawler::parse_html( $html );

		$description = $get( '_flseo_description' );
		if ( '' !== $description && str_contains( $description, '%' ) && $post->ID ) {
			$description = $this->c->get( Variables::class )->replace( $description, $post );
		}
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $description ) : strlen( $description );

		$thumb = array_key_exists( 'featured_media', $data ) ? absint( $data['featured_media'] ) : ( $post->ID ? (int) get_post_thumbnail_id( $post->ID ) : 0 );
		$alt   = $thumb ? trim( (string) get_post_meta( $thumb, '_wp_attachment_image_alt', true ) ) : '';

		$cats    = null;
		$has_tax = is_object_in_taxonomy( $post->post_type, 'category' );
		if ( $has_tax ) {
			$cats    = isset( $data['categories'] ) ? array_map( 'absint', (array) $data['categories'] ) : ( $post->ID ? Template::category_ids( $post->ID ) : array() );
			$default = (int) get_option( 'default_category' );
			$cats    = array_values( array_filter( $cats, static fn( $id ) => $id > 0 && $id !== $default ) );
		}

		$internal = 0;
		$external = false;
		$targets  = array();
		foreach ( $parsed['links'] as $link ) {
			if ( Crawler::is_internal( $link['href'] ) ) {
				// Only links to other posts and pages count: category and home links don't
				// give a post's neighbours any inbound links.
				$target = $this->c->get( Crawler::class )->resolve( $link['href'] );
				if ( 'post' === $target['kind'] && $target['post_id'] && (int) $target['post_id'] !== (int) $post->ID && ! isset( $targets[ $target['post_id'] ] ) ) {
					$targets[ $target['post_id'] ] = true;
					++$internal;
				}
			} elseif ( Crawler::is_external( $link['href'] ) ) {
				$external = true;
			}
		}

		$is_opp = Template::is_opportunity( $post, \FutureLabs\AISEO\Content\Analyzer::text_without_anchors( $parsed ), $meta, $has_tax ? ( isset( $data['categories'] ) ? array_map( 'absint', (array) $data['categories'] ) : null ) : array() );

		$items = array(
			array(
				'key'   => 'description',
				/* translators: %d: current length in characters. */
				'label' => sprintf( __( 'Meta description is 120–160 characters (now %d)', 'futurelabs-ai-seo' ), $length ),
				'ok'    => $length >= 120 && $length <= 160,
			),
			array(
				'key'   => 'focus_topic',
				'label' => __( 'Focus topic is set', 'futurelabs-ai-seo' ),
				'ok'    => '' !== $get( '_flseo_focus_topic' ),
			),
			array(
				'key'   => 'featured_image',
				'label' => __( 'Featured image has alt text', 'futurelabs-ai-seo' ),
				'ok'    => $thumb > 0 && '' !== $alt,
			),
		);
		if ( $has_tax ) {
			$items[] = array(
				'key'   => 'category',
				'label' => __( 'A category other than the default is chosen', 'futurelabs-ai-seo' ),
				'ok'    => (bool) $cats,
			);
		}
		if ( $is_opp ) {
			$items[] = array(
				'key'   => 'deadline',
				'label' => __( 'Opportunity deadline is set (or status is rolling)', 'futurelabs-ai-seo' ),
				'ok'    => '' !== $get( '_flseo_opp_deadline' ) || 'rolling' === $get( '_flseo_opp_status' ),
			);
			$items[] = array(
				'key'   => 'eligibility',
				'label' => __( 'Eligible countries are set', 'futurelabs-ai-seo' ),
				'ok'    => '' !== $get( '_flseo_elig_countries' ),
			);
			$items[] = array(
				'key'   => 'source_link',
				'label' => __( 'Official source link is present', 'futurelabs-ai-seo' ),
				'ok'    => '' !== $get( '_flseo_opp_source_url' ) || $external,
			);
		}
		$items[] = array(
			'key'   => 'internal_links',
			/* translators: %d: internal links found. */
			'label' => sprintf( __( 'Links to at least 2 other posts on this site (now %d)', 'futurelabs-ai-seo' ), $internal ),
			'ok'    => $internal >= 2,
		);
		$items    = array_merge( $items, $this->quality_items( $post, $html, $parsed, $is_opp, $meta ) );
		$features = $this->c->get( Features::class );
		$items    = array_values( array_filter( $items, static fn( $item ) => $features->checklist_item_enabled( (string) $item['key'] ) ) );
		/**
		 * Filter checklist items.
		 *
		 * @param array    $items Items: key, label, ok.
		 * @param \WP_Post $post  Post.
		 * @param array    $data  Unsaved overrides.
		 */
		return (array) apply_filters( 'flseo_checklist_items', $items, $post, $data );
	}

	/**
	 * Patterns left behind by copying from AI chat tools: tracking tags, citation markers
	 * and template placeholders. Matched against the title and content HTML.
	 */
	public const AI_LEFTOVERS = array(
		'utm_source=chatgpt.com'  => '/utm_source=(chatgpt\.com|openai|perplexity|copilot\.com)/i',
		'oaicite markers'         => '/contentReference\[oaicite|\boaicite:\d+/i',
		'【source】 markers'        => '/【\d+(?::\d+)?†[^】]*】/u',
		'turn0search markers'     => '/\bturn\d+(?:search|news|view|image)\d+\b/',
		'As an AI language model' => '/\bas an ai (?:language )?model\b/i',
		'[Insert …] placeholders' => '/\[(?:insert|add your|your) [^\]\n]{2,40}\]/i',
	);

	/**
	 * Content quality items: length, opportunity sections, broken links, AI leftovers, duplicates.
	 *
	 * @param \WP_Post             $post   Post with unsaved values applied.
	 * @param string               $html   Content HTML.
	 * @param array<string, mixed> $parsed Crawler::parse_html() result.
	 * @param bool                 $is_opp Whether opportunity items apply.
	 * @param array<string, mixed> $meta   Unsaved meta.
	 * @return array<int, array{key: string, label: string, ok: bool}>
	 */
	private function quality_items( \WP_Post $post, string $html, array $parsed, bool $is_opp, array $meta ): array {
		$items   = array();
		$words   = Crawler::word_count( $parsed['text'] );
		$min     = $this->c->get( \FutureLabs\AISEO\Content\Thin::class )->threshold();
		$items[] = array(
			'key'   => 'length',
			/* translators: 1: minimum words, 2: current words. */
			'label' => sprintf( __( 'At least %1$d words (now %2$d)', 'futurelabs-ai-seo' ), $min, $words ),
			'ok'    => $words >= $min,
		);

		if ( $is_opp ) {
			$missing = array();
			foreach ( Template::completeness( $post, $parsed['text'], $parsed['headings'], $parsed['links'], $meta ) as $section ) {
				if ( in_array( $section['key'], array( 'eligibility', 'benefits', 'how_to_apply' ), true ) && ! $section['ok'] ) {
					$missing[] = $section['label'];
				}
			}
			$items[] = array(
				'key'   => 'sections',
				'label' => $missing
					/* translators: %s: missing section names. */
					? sprintf( __( 'Covers eligibility, benefits and how to apply (missing: %s)', 'futurelabs-ai-seo' ), implode( ', ', $missing ) )
					: __( 'Covers eligibility, benefits and how to apply', 'futurelabs-ai-seo' ),
				'ok'    => ! $missing,
			);
		}

		$crawler = $this->c->get( Crawler::class );
		$broken  = array();
		foreach ( $parsed['links'] as $link ) {
			$href = trim( (string) $link['href'] );
			if ( '' !== $href && '#' !== $href[0] && Crawler::is_internal( $href ) && 'broken' === $crawler->resolve( $href )['kind'] ) {
				$broken[ Crawler::absolute( $href ) ] = true;
			}
		}
		$items[] = array(
			'key'   => 'broken_links',
			'label' => $broken
				/* translators: %s: the broken links. */
				? sprintf( __( 'No broken internal links (broken: %s)', 'futurelabs-ai-seo' ), implode( ', ', array_slice( array_keys( $broken ), 0, 3 ) ) )
				: __( 'No broken internal links', 'futurelabs-ai-seo' ),
			'ok'    => ! $broken,
		);

		$found = array();
		foreach ( self::AI_LEFTOVERS as $label => $pattern ) {
			if ( preg_match( $pattern, $post->post_title . ' ' . $html ) ) {
				$found[] = $label;
			}
		}
		$items[] = array(
			'key'   => 'ai_leftovers',
			'label' => $found
				/* translators: %s: leftovers found. */
				? sprintf( __( 'No AI copy-paste leftovers (found: %s)', 'futurelabs-ai-seo' ), implode( ', ', $found ) )
				: __( 'No AI copy-paste leftovers', 'futurelabs-ai-seo' ),
			'ok'    => ! $found,
		);

		$twin    = $words >= \FutureLabs\AISEO\Content\Duplicate::MIN_WORDS ? $this->c->get( \FutureLabs\AISEO\Content\Duplicate::class )->closest( $parsed['text'], (int) $post->ID ) : null;
		$items[] = array(
			'key'   => 'duplicate',
			'label' => $twin
				/* translators: 1: similarity percent, 2: post title. */
				? sprintf( __( 'Not a copy of a published post (%1$d%% like “%2$s”)', 'futurelabs-ai-seo' ), $twin['similarity'], get_the_title( $twin['post_id'] ) )
				: __( 'Not a copy of a published post', 'futurelabs-ai-seo' ),
			'ok'    => ! $twin,
		);
		return $items;
	}

	/**
	 * Failed items.
	 *
	 * @param array<int, array{key: string, label: string, ok: bool}> $items Items.
	 * @return array<int, array{key: string, label: string, ok: bool}>
	 */
	public static function failures( array $items ): array {
		return array_values( array_filter( $items, static fn( $item ) => empty( $item['ok'] ) ) );
	}

	/**
	 * Whether the gate applies to a post being published.
	 *
	 * @param string $new_status Requested status.
	 * @param int    $post_id    Post ID (0 when new).
	 * @param string $type       Post type.
	 */
	private function gate_applies( string $new_status, int $post_id, string $type ): bool {
		if ( ! $this->is_hard() || ! in_array( $new_status, array( 'publish', 'future' ), true ) ) {
			return false;
		}
		if ( 'attachment' === $type || ! in_array( $type, get_post_types( array( 'public' => true ), 'names' ), true ) ) {
			return false;
		}
		if ( $post_id && in_array( get_post_status( $post_id ), array( 'publish', 'future' ), true ) ) {
			return false;
		}
		/**
		 * Whether the hard checklist gate applies to this publish.
		 *
		 * @param bool   $applies Default true.
		 * @param int    $post_id Post ID.
		 * @param string $type    Post type.
		 */
		return (bool) apply_filters( 'flseo_checklist_gate_applies', true, $post_id, $type );
	}

	/**
	 * Classic editor gate: keep the post as a draft when the checklist fails.
	 *
	 * @param array<string, mixed> $data    Slashed post data.
	 * @param array<string, mixed> $postarr Raw post array.
	 * @param array<string, mixed> $raw     Unsanitized post array.
	 * @return array<string, mixed>
	 */
	public function classic_gate( $data, $postarr, $raw = array() ) {
		if ( ! is_array( $data ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ! is_admin() ) {
			return $data;
		}
		$post_id = absint( $postarr['ID'] ?? 0 );
		if ( isset( $this->elementor_checked[ $post_id ] ) ) {
			return $data;
		}
		if ( ! $this->gate_applies( (string) ( $data['post_status'] ?? '' ), $post_id, (string) ( $data['post_type'] ?? 'post' ) ) ) {
			return $data;
		}
		$post               = $post_id ? get_post( $post_id ) : null;
		$post               = $post instanceof \WP_Post ? $post : new \WP_Post(
			(object) array(
				'ID'        => 0,
				'post_type' => (string) ( $data['post_type'] ?? 'post' ),
			)
		);
		$overrides          = array(
			'content' => wp_unslash( (string) ( $data['post_content'] ?? '' ) ),
			'title'   => wp_unslash( (string) ( $data['post_title'] ?? '' ) ),
			'meta'    => array(),
		);
		$source             = wp_unslash( is_array( $raw ) && $raw ? $raw : (array) $postarr );
		$nonce              = isset( $source['flseo_nonce'] ) ? sanitize_text_field( (string) $source['flseo_nonce'] ) : '';
		$fields_are_trusted = '' !== $nonce && wp_verify_nonce( $nonce, 'flseo_save_post' );
		if ( $fields_are_trusted ) {
			foreach ( array( 'description', 'focus_topic', 'opp_deadline', 'opp_source_url', 'opp_status' ) as $key ) {
				if ( isset( $source[ 'flseo_' . $key ] ) ) {
					$overrides['meta'][ '_flseo_' . $key ] = sanitize_text_field( (string) $source[ 'flseo_' . $key ] );
				}
			}
		}
		if ( isset( $source['_thumbnail_id'] ) ) {
			$overrides['featured_media'] = (int) $source['_thumbnail_id'];
		}
		if ( isset( $source['post_category'] ) ) {
			$overrides['categories'] = array_map( 'absint', (array) $source['post_category'] );
		}
		$failed = self::failures( $this->evaluate( $post, $overrides ) );
		if ( $failed ) {
			$data['post_status'] = 'draft';
			$this->blocked       = true;
			set_transient( 'flseo_checklist_blocked_' . get_current_user_id(), array_column( $failed, 'label' ), 5 * MINUTE_IN_SECONDS );
		}
		return $data;
	}

	/**
	 * Show "draft updated" instead of "published" after the classic gate blocked a publish.
	 *
	 * @param string $location Redirect URL.
	 * @return mixed
	 */
	public function redirect_location( $location ) {
		if ( $this->blocked && is_string( $location ) ) {
			return add_query_arg( 'message', 10, $location );
		}
		return $location;
	}

	/**
	 * REST / block editor gate.
	 *
	 * @param \stdClass|\WP_Error $prepared Prepared post.
	 * @param \WP_REST_Request    $request  Request.
	 * @return \stdClass|\WP_Error
	 */
	public function rest_gate( $prepared, $request ) {
		if ( is_wp_error( $prepared ) || ! $request instanceof \WP_REST_Request ) {
			return $prepared;
		}
		$post_id = absint( $prepared->ID ?? $request->get_param( 'id' ) );
		$type    = (string) ( $prepared->post_type ?? ( $post_id ? get_post_type( $post_id ) : 'post' ) );
		$status  = (string) ( $prepared->post_status ?? ( $post_id ? get_post_status( $post_id ) : '' ) );
		if ( ! $this->gate_applies( $status, $post_id, $type ) ) {
			return $prepared;
		}
		$post      = $post_id ? get_post( $post_id ) : null;
		$post      = $post instanceof \WP_Post ? $post : new \WP_Post(
			(object) array(
				'ID'        => 0,
				'post_type' => $type,
			)
		);
		$overrides = array();
		if ( isset( $prepared->post_content ) ) {
			$overrides['content'] = (string) $prepared->post_content;
		}
		if ( isset( $prepared->post_title ) ) {
			$overrides['title'] = (string) $prepared->post_title;
		}
		$meta = $request->get_param( 'meta' );
		if ( is_array( $meta ) ) {
			$overrides['meta'] = $meta;
		}
		if ( null !== $request->get_param( 'featured_media' ) ) {
			$overrides['featured_media'] = absint( $request->get_param( 'featured_media' ) );
		}
		if ( null !== $request->get_param( 'categories' ) ) {
			$overrides['categories'] = array_map( 'absint', (array) $request->get_param( 'categories' ) );
		}
		$failed = self::failures( $this->evaluate( $post, $overrides ) );
		if ( ! $failed ) {
			return $prepared;
		}
		return new \WP_Error(
			'flseo_checklist_incomplete',
			/* translators: %s: list of unmet checklist items. */
			sprintf( __( 'Complete the FutureLabs AI SEO publishing checklist before publishing: %s', 'futurelabs-ai-seo' ), implode( '; ', array_column( $failed, 'label' ) ) ),
			array(
				'status' => 400,
				'items'  => $failed,
			)
		);
	}

	/**
	 * Elementor gate. Elementor saves the post status before the new content, so the
	 * classic gate would see the old content; check the elements being saved instead
	 * and stop the save (Elementor keeps the edits in the editor) when items fail.
	 *
	 * @param object               $document Elementor document.
	 * @param array<string, mixed> $data     Save request: settings (post_status) and elements.
	 * @throws \Exception When the checklist fails.
	 */
	public function elementor_gate( $document, $data ): void {
		if ( ! is_object( $document ) || ! method_exists( $document, 'get_main_id' ) || ! is_array( $data ) ) {
			return;
		}
		$post_id = (int) $document->get_main_id();
		$post    = get_post( $post_id );
		$status  = (string) ( $data['settings']['post_status'] ?? '' );
		if ( ! $post instanceof \WP_Post || ! $this->gate_applies( $status, $post_id, $post->post_type ) ) {
			return;
		}
		$elements = isset( $data['elements'] ) && is_array( $data['elements'] ) ? (string) wp_json_encode( $data['elements'] ) : (string) get_post_meta( $post_id, '_elementor_data', true );
		$html     = \FutureLabs\AISEO\Content\Analyzer::elementor_data_html( $elements );
		$failed   = self::failures( $this->evaluate( $post, array( 'content' => '' !== trim( $html ) ? $html : (string) $post->post_content ) ) );
		if ( $failed ) {
			// The editor script inserts this as text, never as HTML.
			throw new \Exception( self::blocked_message( $failed ), 403 ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
		}
		$this->elementor_checked[ $post_id ] = true;
	}

	/**
	 * Message listing failed items.
	 *
	 * @param array<int, array{key: string, label: string, ok: bool}> $failed Failed items.
	 */
	public static function blocked_message( array $failed ): string {
		return __( 'Not published: FutureLabs AI SEO requires the publishing checklist to be complete.', 'futurelabs-ai-seo' ) . "\n• " . implode( "\n• ", array_column( $failed, 'label' ) );
	}

	/**
	 * Show the gate's reason in Elementor, which otherwise reports only "Server Error 403".
	 */
	public function elementor_script(): void {
		if ( ! $this->is_hard() ) {
			return;
		}
		$title = wp_json_encode( __( 'Not published yet', 'futurelabs-ai-seo' ) );
		$js    = <<<JS
(function () {
	function find( d, depth ) {
		if ( depth > 6 || d === null || d === undefined ) { return ''; }
		if ( typeof d === 'string' ) { return d.indexOf( 'FutureLabs AI SEO' ) !== -1 ? d : ''; }
		if ( typeof d === 'object' ) { for ( var k in d ) { var r = find( d[ k ], depth + 1 ); if ( r ) { return r; } } }
		return '';
	}
	function attach() {
		if ( ! window.elementor || ! elementor.saver || elementor.saver.flseoGate ) { return; }
		elementor.saver.flseoGate = true;
		elementor.saver.on( 'after:saveError', function ( data ) {
			var text = find( data, 0 );
			if ( ! text ) { return; }
			var box = document.createElement( 'div' );
			box.textContent = text;
			elementorCommon.dialogsManager.createWidget( 'alert', { headerMessage: {$title}, message: box.innerHTML.replace( /\n/g, '<br>' ) } ).show();
		} );
	}
	jQuery( window ).on( 'elementor:init', function () {
		attach();
		elementor.on( 'document:loaded', attach );
	} );
})();
JS;
		wp_add_inline_script( 'elementor-editor', $js );
	}

	/**
	 * Notice after the classic gate kept a post in draft.
	 */
	public function notice(): void {
		if ( ! Capabilities::can( Capabilities::EDITOR ) ) {
			return;
		}
		$key    = 'flseo_checklist_blocked_' . get_current_user_id();
		$failed = get_transient( $key );
		if ( ! is_array( $failed ) ) {
			return;
		}
		delete_transient( $key );
		echo '<div class="notice notice-error"><p>' . esc_html__( 'FutureLabs AI SEO kept this post as a draft because the publishing checklist is incomplete:', 'futurelabs-ai-seo' ) . '</p><ul>';
		foreach ( $failed as $label ) {
			echo '<li>' . esc_html( (string) $label ) . '</li>';
		}
		echo '</ul></div>';
	}
}
