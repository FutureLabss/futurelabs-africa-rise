<?php
/**
 * Template tags: small output helpers shared by blocks, archives and widgets.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Print the post date as "x ago".
 *
 * @param int|null $post_id Post ID, defaults to the current post.
 * @param bool     $icon    Whether to show the clock icon.
 */
function newstheme_posted_on( $post_id = null, $icon = false ) {
	$post_id   = $post_id ? $post_id : get_the_ID();
	$timestamp = get_post_time( 'U', true, $post_id );
	$label     = sprintf(
		/* translators: %s: human-readable time difference, e.g. "3 days". */
		esc_html__( '%s ago', 'newstheme' ),
		human_time_diff( $timestamp, time() )
	);

	printf(
		'<span class="nt-meta__item nt-meta__date">%1$s<time datetime="%2$s">%3$s</time></span>',
		$icon ? newstheme_get_icon( 'clock' ) : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in newstheme_get_icon().
		esc_attr( get_the_date( DATE_W3C, $post_id ) ),
		esc_html( $label )
	);
}

/**
 * Print the post author link.
 *
 * @param int|null $post_id Post ID, defaults to the current post.
 * @param bool     $icon    Whether to show the user icon.
 */
function newstheme_posted_by( $post_id = null, $icon = false ) {
	$author_id = (int) get_post_field( 'post_author', $post_id ? $post_id : get_the_ID() );
	$name      = get_the_author_meta( 'display_name', $author_id );
	if ( '' === (string) $name ) {
		return;
	}

	printf(
		'<span class="nt-meta__item nt-meta__author">%1$s<a href="%2$s">%3$s</a></span>',
		$icon ? newstheme_get_icon( 'user' ) : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in newstheme_get_icon().
		esc_url( get_author_posts_url( $author_id ) ),
		esc_html( $name )
	);
}

/**
 * Print the comment count link.
 *
 * @param int|null $post_id Post ID, defaults to the current post.
 */
function newstheme_comment_count( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$count   = (int) get_comments_number( $post_id );

	printf(
		'<span class="nt-meta__item nt-meta__comments">%1$s<a href="%2$s" aria-label="%3$s">%4$d</a></span>',
		newstheme_get_icon( 'message-circle' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in newstheme_get_icon().
		esc_url( get_comments_link( $post_id ) ),
		/* translators: %d: number of comments. */
		esc_attr( sprintf( _n( '%d comment', '%d comments', $count, 'newstheme' ), $count ) ),
		esc_html( $count )
	);
}

/**
 * Print a post meta row.
 *
 * @param string[] $fields Any of 'author', 'date', 'comments', in display order.
 * @param int|null $post_id Post ID, defaults to the current post.
 */
function newstheme_post_meta( array $fields, $post_id = null ) {
	if ( ! $fields ) {
		return;
	}
	echo '<div class="nt-meta">';
	foreach ( $fields as $field ) {
		switch ( $field ) {
			case 'author':
				newstheme_posted_by( $post_id, true );
				break;
			case 'date':
				newstheme_posted_on( $post_id, true );
				break;
			case 'comments':
				newstheme_comment_count( $post_id );
				break;
		}
	}
	echo '</div>';
}

/**
 * Print category badges for a post. Each badge carries `nt-cat-{id}` so the
 * per-category colors from the Customizer apply.
 *
 * @param int|null $post_id Post ID, defaults to the current post.
 * @param int      $limit   Maximum number of categories to show.
 * @param string   $style   'badge' (filled) or 'text' (colored text).
 */
function newstheme_post_categories( $post_id = null, $limit = 1, $style = 'badge' ) {
	$categories = get_the_category( $post_id ? $post_id : get_the_ID() );
	if ( empty( $categories ) ) {
		return;
	}

	printf( '<ul class="nt-cats nt-cats--%s">', esc_attr( $style ) );
	foreach ( array_slice( $categories, 0, $limit ) as $category ) {
		printf(
			'<li class="nt-cats__item nt-cat-%1$d"><a href="%2$s">%3$s</a></li>',
			(int) $category->term_id,
			esc_url( get_category_link( $category ) ),
			esc_html( $category->name )
		);
	}
	echo '</ul>';
}

/**
 * Alt text for a post's featured image: the image's own alt text, or the post
 * title when none was written.
 *
 * @param int|WP_Post|null $post Post (default: current).
 * @return string
 */
function newstheme_thumbnail_alt( $post = null ) {
	$alt = trim( (string) get_post_meta( (int) get_post_thumbnail_id( $post ), '_wp_attachment_image_alt', true ) );
	return '' !== $alt ? $alt : trim( wp_strip_all_tags( get_the_title( $post ) ) );
}

/**
 * Print the featured image as a linked figure, optionally with the category
 * badge overlaid.
 *
 * @param string $size Image size.
 * @param array  $opts Options: `badge` (bool, overlay the category badge),
 *                     `class` (string, extra figure classes), `eager` (bool,
 *                     load immediately for above-the-fold images).
 */
function newstheme_post_thumb( $size = 'newstheme-medium', array $opts = array() ) {
	$opts = wp_parse_args(
		$opts,
		array(
			'badge' => false,
			'class' => '',
			'eager' => false,
		)
	);

	$image = has_post_thumbnail()
		? get_the_post_thumbnail(
			null,
			$size,
			array(
				// The link is hidden from assistive tech (the title link follows),
				// so this alt text only describes the image for search engines.
				'alt'           => newstheme_thumbnail_alt(),
				'loading'       => $opts['eager'] ? 'eager' : 'lazy',
				'fetchpriority' => $opts['eager'] ? 'high' : 'auto',
			)
		)
		: '<span class="nt-thumb__placeholder"></span>';
	?>
	<figure class="nt-thumb<?php echo in_array( $size, array( 'newstheme-list', 'newstheme-thumb' ), true ) ? ' nt-thumb--small' : ''; ?> <?php echo esc_attr( $opts['class'] ); ?>">
		<a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><?php echo $image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core image markup. ?></a>
		<?php echo newstheme_deadline_badge(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in newstheme_deadline_badge(). ?>
		<?php
		if ( $opts['badge'] ) {
			newstheme_post_categories();
		}
		?>
	</figure>
	<?php
}

/**
 * Print the post title as a linked heading.
 *
 * @param string $tag         Heading tag.
 * @param string $extra_class Extra classes.
 */
function newstheme_post_title( $tag = 'h3', $extra_class = '' ) {
	printf(
		'<%1$s class="nt-post-title %2$s"><a href="%3$s">%4$s</a></%1$s>',
		tag_escape( $tag ),
		esc_attr( $extra_class ),
		esc_url( get_permalink() ),
		esc_html( get_the_title() )
	);
}

/**
 * Print a trimmed excerpt.
 *
 * @param int $words Word count.
 */
function newstheme_post_excerpt( $words = 18 ) {
	$text = wp_trim_words( get_the_excerpt(), $words, '…' );
	if ( $text ) {
		printf( '<p class="nt-excerpt">%s</p>', esc_html( $text ) );
	}
}

/**
 * Print the "read more" link.
 */
function newstheme_read_more() {
	printf(
		'<a class="nt-read-more" href="%1$s">%2$s<span class="screen-reader-text">: %3$s</span>%4$s</a>',
		esc_url( get_permalink() ),
		esc_html__( 'Read Full News', 'newstheme' ),
		esc_html( get_the_title() ),
		newstheme_get_icon( 'chevron-right' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in newstheme_get_icon().
	);
}
