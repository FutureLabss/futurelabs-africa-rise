<?php
/**
 * Font families offered by typography controls.
 *
 * Bundled families are self-hosted through theme.json; system stacks need no
 * download; any font installed in Appearance → Fonts is added automatically.
 * Child themes/plugins can add more via the `newstheme_font_families` filter
 * (the font must already be loaded).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Font family choices: slug => [ label, CSS stack ].
 *
 * @return array<string, array{label: string, stack: string}>
 */
function newstheme_font_families() {
	$families = array(
		'jost'         => array(
			'label' => 'Jost',
			'stack' => 'var(--wp--preset--font-family--jost)',
		),
		'roboto'       => array(
			'label' => 'Roboto',
			'stack' => 'var(--wp--preset--font-family--roboto)',
		),
		'inter'        => array(
			'label' => 'Inter',
			'stack' => 'var(--wp--preset--font-family--inter)',
		),
		'system-sans'  => array(
			'label' => __( 'System Sans-serif', 'newstheme' ),
			'stack' => 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif',
		),
		'system-serif' => array(
			'label' => __( 'System Serif', 'newstheme' ),
			'stack' => 'ui-serif, Georgia, Cambria, "Times New Roman", serif',
		),
		'mono'         => array(
			'label' => __( 'Monospace', 'newstheme' ),
			'stack' => 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
		),
	);

	// Fonts installed in Appearance → Fonts (WordPress's Font Library, incl.
	// Google Fonts it downloads and self-hosts). WordPress prints their
	// @font-face rules and --wp--preset--font-family--* variables itself.
	if ( class_exists( 'WP_Theme_JSON_Resolver' ) ) {
		$settings = WP_Theme_JSON_Resolver::get_merged_data()->get_settings();
		foreach ( (array) ( $settings['typography']['fontFamilies']['custom'] ?? array() ) as $font ) {
			if ( ! empty( $font['slug'] ) && ! isset( $families[ $font['slug'] ] ) ) {
				$families[ $font['slug'] ] = array(
					'label' => $font['name'] ?? $font['slug'],
					'stack' => 'var(--wp--preset--font-family--' . sanitize_title( $font['slug'] ) . ')',
				);
			}
		}
	}

	return apply_filters( 'newstheme_font_families', $families );
}
