<?php
/**
 * Fallback template (blog index when a static front page is set, and any
 * view without a more specific template).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();
newstheme_layout_open( 'archive' );
get_template_part(
	'template-parts/content/archive-list',
	null,
	array(
		'title'       => is_home() && ! is_front_page() ? single_post_title( '', false ) : __( 'Latest News', 'newstheme' ),
		'description' => '',
	)
);
newstheme_layout_close();
get_footer();
