<?php
/**
 * NewsTheme Category Collection Widget.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Category collection: image tiles with post counts.
 */
class NewsTheme_Category_Collection_Widget extends NewsTheme_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->fields = array(
			'title'      => array(
				'type'    => 'text',
				'label'   => __( 'Title', 'newstheme' ),
				'default' => __( 'Categories', 'newstheme' ),
			),
			'categories' => array(
				'type'        => 'categories',
				'label'       => __( 'Categories', 'newstheme' ),
				'default'     => array(),
				'description' => __( 'None selected shows the 6 largest.', 'newstheme' ),
			),
			'show_count' => array(
				'type'    => 'checkbox',
				'label'   => __( 'Show post counts', 'newstheme' ),
				'default' => true,
			),
		);
		parent::__construct( 'category_collection', __( 'NewsTheme: Category Collection', 'newstheme' ), __( 'Categories as image tiles.', 'newstheme' ) );
	}

	/**
	 * Render.
	 *
	 * @param array $values Instance values.
	 */
	protected function render( array $values ) {
		$terms = $values['categories']
			? get_categories(
				array(
					'include' => $values['categories'],
					'orderby' => 'include',
				)
			)
			: get_categories(
				array(
					'orderby' => 'count',
					'order'   => 'DESC',
					'number'  => 6,
				)
			);
		if ( ! $terms ) {
			return;
		}
		echo '<ul class="nt-wcats">';
		foreach ( $terms as $term ) {
			$latest = get_posts(
				array(
					'cat'            => $term->term_id,
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'meta_key'       => '_thumbnail_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one post per category.
					'no_found_rows'  => true,
				)
			);
			printf(
				'<li class="nt-wcats__item nt-cat-%1$d"><a href="%2$s">%3$s<span class="nt-wcats__name">%4$s</span>%5$s</a></li>',
				(int) $term->term_id,
				esc_url( get_category_link( $term ) ),
				$latest ? get_the_post_thumbnail( $latest[0], 'newstheme-list', array( 'alt' => '' ) ) : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core image markup.
				esc_html( $term->name ),
				/* translators: %d: number of posts. */
				$values['show_count'] ? '<span class="nt-wcats__count">' . esc_html( sprintf( _n( '%d post', '%d posts', $term->count, 'newstheme' ), $term->count ) ) . '</span>' : '' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			);
		}
		echo '</ul>';
	}
}
