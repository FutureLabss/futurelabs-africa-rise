<?php
/**
 * Read helpers over stored Search Console query rows (`flseo_gsc_queries`).
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Reports;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;

defined( 'ABSPATH' ) || exit;

/**
 * Period lookup and URL/post mapping shared by cannibalization, refresh alerts,
 * keyword suggestions and the PageSpeed top-pages list.
 *
 * `date_range` values are "YYYY-MM-DD/YYYY-MM-DD", so sorting them descending
 * puts the most recent period first.
 */
class SearchData {

	/**
	 * Constructor (container convention; this helper has no dependencies).
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		unset( $c );
	}

	/**
	 * Most recent stored periods, newest first.
	 *
	 * @param int $count How many.
	 * @return array<int, string>
	 */
	public function ranges( int $count = 2 ): array {
		global $wpdb;
		$table = Migrations::table( 'gsc_queries' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array_map( 'strval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT date_range FROM {$table} WHERE date_range<>'' ORDER BY date_range DESC LIMIT %d", $count ) ) );
	}

	/**
	 * The latest period or '' when none is stored.
	 */
	public function latest_range(): string {
		return $this->ranges( 1 )[0] ?? '';
	}

	/**
	 * Resolve the URL of a row: its own url column, else the inspection table.
	 *
	 * @param string $url_hash Hash.
	 * @param string $url      Stored URL (may be empty for rows written by 1.0).
	 */
	public function url( string $url_hash, string $url = '' ): string {
		if ( '' !== $url ) {
			return $url;
		}
		global $wpdb;
		$table = Migrations::table( 'index_status' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (string) $wpdb->get_var( $wpdb->prepare( "SELECT url FROM {$table} WHERE url_hash=%s LIMIT 1", $url_hash ) );
	}

	/**
	 * Post ID for a URL (0 for archives, external or unknown URLs).
	 *
	 * @param string $url URL.
	 */
	public function post_id( string $url ): int {
		if ( '' === $url ) {
			return 0;
		}
		global $wpdb;
		$table = Migrations::table( 'index_status' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$table} WHERE url_hash=%s AND post_id>0 LIMIT 1", hash( 'sha256', $url ) ) );
		return $id ? $id : (int) url_to_postid( $url );
	}

	/**
	 * Whether a URL belongs to this site.
	 *
	 * @param string $url URL.
	 */
	public static function is_local( string $url ): bool {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$home = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
		return '' !== $host && $host === $home;
	}

	/**
	 * Per-URL totals for a period.
	 *
	 * @param string $range Period.
	 * @return array<string, array{url_hash: string, url: string, clicks: int, impressions: int}>
	 */
	public function totals( string $range ): array {
		global $wpdb;
		$table = Migrations::table( 'gsc_queries' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT url_hash, MAX(url) url, SUM(clicks) clicks, SUM(impressions) impressions FROM {$table} WHERE date_range=%s GROUP BY url_hash", $range ) );
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$out[ (string) $row->url_hash ] = array(
				'url_hash'    => (string) $row->url_hash,
				'url'         => (string) $row->url,
				'clicks'      => (int) $row->clicks,
				'impressions' => (int) $row->impressions,
			);
		}
		return $out;
	}
}
