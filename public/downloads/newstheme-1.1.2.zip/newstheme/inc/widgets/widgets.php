<?php
/**
 * NewsTheme widgets: registration and admin assets.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-widget.php';
require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-posts-list-widget.php';
require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-popular-posts-widget.php';
require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-posts-grid-widget.php';
require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-posts-carousel-widget.php';
require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-banner-ad-widget.php';
require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-social-icons-widget.php';
require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-author-info-widget.php';
require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-category-collection-widget.php';
require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-widget-title-widget.php';

/**
 * Register all widgets.
 */
function newstheme_register_widgets() {
	foreach ( array(
		'NewsTheme_Posts_List_Widget',
		'NewsTheme_Popular_Posts_Widget',
		'NewsTheme_Posts_Grid_Widget',
		'NewsTheme_Posts_Carousel_Widget',
		'NewsTheme_Banner_Ad_Widget',
		'NewsTheme_Social_Icons_Widget',
		'NewsTheme_Author_Info_Widget',
		'NewsTheme_Category_Collection_Widget',
		'NewsTheme_Widget_Title_Widget',
	) as $class ) {
		register_widget( $class );
	}
}
add_action( 'widgets_init', 'newstheme_register_widgets' );

/**
 * Media picker for widget image fields (classic and block widget screens,
 * and the Customizer).
 *
 * @param string $hook Admin page.
 */
function newstheme_widget_admin_assets( $hook ) {
	if ( 'widgets.php' !== $hook ) {
		return;
	}
	newstheme_enqueue_widget_admin();
}
add_action( 'admin_enqueue_scripts', 'newstheme_widget_admin_assets' );
add_action( 'customize_controls_enqueue_scripts', 'newstheme_enqueue_widget_admin' );

/**
 * Enqueue the widget form script.
 */
function newstheme_enqueue_widget_admin() {
	wp_enqueue_media();
	wp_enqueue_script(
		'newstheme-widget-admin',
		NEWSTHEME_URI . 'assets/js/widget-admin.js',
		array( 'jquery', 'media-views' ),
		newstheme_asset_version( 'assets/js/widget-admin.js' ),
		true
	);
	wp_add_inline_style( 'wp-admin', '.nt-widget-checklist{display:block;max-height:140px;overflow:auto;border:1px solid #dcdcde;padding:6px 8px}.nt-widget-checklist label{display:block}.nt-widget-media{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.nt-widget-media img{width:60px;height:60px;object-fit:cover}' );
}
