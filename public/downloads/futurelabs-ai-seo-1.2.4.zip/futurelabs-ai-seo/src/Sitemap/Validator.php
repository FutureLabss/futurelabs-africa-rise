<?php
/**
 * Validates sitemap XML against the sitemaps.org schemas and samples URLs for problems.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Sitemap;

use FutureLabs\AISEO\Conflicts\FrontendProbe;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Daily and on-demand sitemap checks; results stored in `flseo_sitemap_validation`.
 */
class Validator implements Module {

	public const OPTION = 'flseo_sitemap_validation';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'flseo_daily', array( $this, 'queue' ) );
		add_action( 'flseo_validate_sitemap', array( $this, 'run' ) );
	}

	/**
	 * Queue a background validation.
	 */
	public function queue(): void {
		update_option( self::OPTION, array_merge( $this->last(), array( 'running' => true ) ), false );
		$this->c->get( Queue::class )->async( 'flseo_validate_sitemap' );
	}

	/**
	 * Last stored result.
	 *
	 * @return array<string, mixed>
	 */
	public function last(): array {
		$value = get_option( self::OPTION, array() );
		return is_array( $value ) ? $value : array();
	}

	/**
	 * Validate the generated XML locally (no HTTP), then sample URLs over HTTP.
	 *
	 * @param int|null $sample Sample size override.
	 * @return array<string, mixed>
	 */
	public function run( $sample = null ): array {
		$router  = $this->c->get( Router::class );
		$builder = $this->c->get( Builder::class );
		$errors  = array();
		$urls    = array();
		$index   = $router->xml( 'index' );
		$schema  = array(
			'index'    => false,
			'sitemaps' => 0,
			'invalid'  => array(),
		);
		if ( null === $index ) {
			$errors[] = __( 'The sitemap is unavailable because the site discourages search engines.', 'futurelabs-ai-seo' );
		} else {
			$schema['index'] = self::validate_xml( $index, 'siteindex' ) === array();
			foreach ( $builder->index() as $entry ) {
				$xml = $router->xml( $entry['name'], $entry['page'] );
				++$schema['sitemaps'];
				if ( null === $xml ) {
					continue;
				}
				$problems = self::validate_xml( $xml, 'sitemap' );
				if ( $problems ) {
					$schema['invalid'][] = array(
						'sitemap' => $entry['loc'],
						'errors'  => array_slice( $problems, 0, 5 ),
					);
				}
				foreach ( (array) $builder->entries( $entry['name'], $entry['page'] ) as $row ) {
					$urls[] = $row['loc'];
				}
			}
		}

		$size     = null === $sample ? (int) $this->c->get( Settings::class )->get( 'sitemap_sample_size', 50 ) : (int) $sample;
		$findings = array();
		$checked  = 0;
		if ( $urls && $size > 0 ) {
			shuffle( $urls );
			foreach ( array_slice( $urls, 0, $size ) as $url ) {
				++$checked;
				$finding = $this->check_url( $url );
				if ( $finding ) {
					$findings[] = $finding;
				}
			}
		}
		$result = array(
			'checked_at' => gmdate( 'c' ),
			'running'    => false,
			'url_count'  => count( $urls ),
			'schema'     => $schema,
			'xml_valid'  => $schema['index'] && ! $schema['invalid'],
			'sampled'    => $checked,
			'findings'   => $findings,
			'non_200'    => count( array_filter( $findings, static fn( $f ) => 'status' === $f['type'] ) ),
			'noindexed'  => count( array_filter( $findings, static fn( $f ) => 'noindex' === $f['type'] ) ),
			'errors'     => $errors,
		);
		update_option( self::OPTION, $result, false );
		return $result;
	}

	/**
	 * Fetch one URL and report non-200 status or noindex.
	 *
	 * @param string $url URL.
	 * @return array{url: string, type: string, detail: string}|null
	 */
	public function check_url( string $url ): ?array {
		if ( ! FrontendProbe::is_own_url( $url ) ) {
			return array(
				'url'    => $url,
				'type'   => 'status',
				'detail' => __( 'URL is not on this site', 'futurelabs-ai-seo' ),
			);
		}
		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 10,
				'redirection'         => 0,
				'limit_response_size' => MB_IN_BYTES,
				'user-agent'          => 'FutureLabs AI SEO-SitemapCheck/' . FLSEO_VERSION,
			)
		);
		if ( is_wp_error( $response ) ) {
			return array(
				'url'    => $url,
				'type'   => 'status',
				'detail' => $response->get_error_message(),
			);
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			$location = (string) wp_remote_retrieve_header( $response, 'location' );
			$detail   = sprintf( 'HTTP %d', $code );
			if ( '' !== $location ) {
				/* translators: 1: HTTP status code, 2: redirect location. */
				$detail = sprintf( __( 'HTTP %1$d to %2$s', 'futurelabs-ai-seo' ), $code, $location );
			}
			return array(
				'url'    => $url,
				'type'   => 'status',
				'detail' => $detail,
			);
		}
		$header = strtolower( (string) wp_remote_retrieve_header( $response, 'x-robots-tag' ) );
		if ( str_contains( $header, 'noindex' ) ) {
			return array(
				'url'    => $url,
				'type'   => 'noindex',
				'detail' => 'X-Robots-Tag: ' . $header,
			);
		}
		$body = (string) wp_remote_retrieve_body( $response );
		if ( preg_match_all( '~<meta\b[^>]*name\s*=\s*["\'](?:robots|googlebot)["\'][^>]*>~i', $body, $m ) ) {
			foreach ( $m[0] as $tag ) {
				if ( stripos( $tag, 'noindex' ) !== false ) {
					return array(
						'url'    => $url,
						'type'   => 'noindex',
						'detail' => __( 'Robots meta tag contains noindex', 'futurelabs-ai-seo' ),
					);
				}
			}
		}
		return null;
	}

	/**
	 * Validate XML against a bundled sitemaps.org schema.
	 *
	 * @param string $xml    XML.
	 * @param string $schema 'sitemap' or 'siteindex'.
	 * @return array<int, string> Problems (empty when valid).
	 */
	public static function validate_xml( string $xml, string $schema ): array {
		if ( ! class_exists( '\DOMDocument' ) ) {
			return array();
		}
		$previous = libxml_use_internal_errors( true );
		$doc      = new \DOMDocument();
		$problems = array();
		if ( ! $doc->loadXML( $xml, LIBXML_NONET ) ) {
			$problems[] = 'XML is not well formed';
		} elseif ( ! $doc->schemaValidate( FLSEO_DIR . 'assets/xsd/' . ( 'siteindex' === $schema ? 'siteindex' : 'sitemap-images' ) . '.xsd' ) ) {
			foreach ( libxml_get_errors() as $error ) {
				$problems[] = trim( $error->message ) . ' (line ' . $error->line . ')';
			}
			if ( ! $problems ) {
				$problems[] = 'Schema validation failed';
			}
		}
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );
		return $problems;
	}
}
