<?php
/**
 * HTML parsing helpers: visible text, headings, links, internal URL resolution.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Links;

use FutureLabs\AISEO\Core\Container;

defined( 'ABSPATH' ) || exit;

/**
 * Extracts text and links from rendered post HTML and resolves internal URLs to posts.
 */
class Crawler {

	/**
	 * Class-name fragments of page furniture that should not count as body text.
	 */
	public const BOILERPLATE_CLASS = '/(?:^|\s)(?:share[\w-]*|sharing[\w-]*|sharedaddy|shareaholic[\w-]*|social[\w-]*|jp-relatedposts[\w-]*|related[\w-]*|yarpp[\w-]*|addtoany[\w-]*|a2a_kit|author-bio[\w-]*|breadcrumbs?|ez-toc[\w-]*|lwptoc[\w-]*|flseo-closed-notice|flseo-related[\w-]*|wp-block-latest-posts[\w-]*)(?:\s|$)/i';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Per-request URL resolution cache.
	 *
	 * @var array<string, array{post_id: int, kind: string}>
	 */
	private array $resolved = array();

	/**
	 * Term archive URL map (lowercase URL without trailing slash => term id).
	 *
	 * @var array<string, int>|null
	 */
	private ?array $term_map = null;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Parse rendered HTML.
	 *
	 * Links are collected from the full document (related-post lists are real links);
	 * text and headings come from the document with scripts, navigation and sharing
	 * widgets removed.
	 *
	 * @param string $html HTML fragment.
	 * @return array{text: string, headings: array<int, array{level: int, text: string}>, links: array<int, array{href: string, anchor: string}>}
	 */
	public static function parse_html( string $html ): array {
		// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM API property names.
		$out = array(
			'text'     => '',
			'headings' => array(),
			'links'    => array(),
		);
		if ( '' === trim( $html ) ) {
			return $out;
		}
		// Block comments carry no visible text.
		$html = (string) preg_replace( '/<!--.*?-->/s', '', $html );
		if ( ! class_exists( '\DOMDocument' ) ) {
			return self::parse_with_regex( $html );
		}
		$doc      = new \DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$loaded   = $doc->loadHTML( '<?xml encoding="utf-8"?><html><body><div id="flseo-root">' . $html . '</div></body></html>', LIBXML_NONET | LIBXML_COMPACT );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );
		if ( ! $loaded ) {
			return self::parse_with_regex( $html );
		}
		foreach ( $doc->getElementsByTagName( 'a' ) as $a ) {
			$href = trim( (string) $a->getAttribute( 'href' ) );
			if ( '' === $href ) {
				continue;
			}
			$out['links'][] = array(
				'href'   => $href,
				'anchor' => self::squash( (string) $a->textContent ),
			);
		}
		$remove = array();
		foreach ( array( 'script', 'style', 'noscript', 'nav', 'form', 'iframe', 'svg', 'template', 'button', 'select' ) as $tag ) {
			foreach ( $doc->getElementsByTagName( $tag ) as $node ) {
				$remove[] = $node;
			}
		}
		$xpath = new \DOMXPath( $doc );
		$nodes = $xpath->query( '//*[@class]' );
		if ( $nodes ) {
			foreach ( $nodes as $node ) {
				if ( $node instanceof \DOMElement && preg_match( self::BOILERPLATE_CLASS, (string) $node->getAttribute( 'class' ) ) ) {
					$remove[] = $node;
				}
			}
		}
		foreach ( $remove as $node ) {
			if ( $node->parentNode ) {
				$node->parentNode->removeChild( $node );
			}
		}
		$headings = $xpath->query( '//h1|//h2|//h3|//h4|//h5|//h6' );
		if ( $headings ) {
			foreach ( $headings as $h ) {
				$out['headings'][] = array(
					'level' => (int) substr( $h->nodeName, 1 ),
					'text'  => self::squash( (string) $h->textContent ),
				);
			}
		}
		// Keep block-level boundaries so words do not run together.
		$blocks = $xpath->query( '//p|//div|//li|//h1|//h2|//h3|//h4|//h5|//h6|//td|//th|//br|//blockquote' );
		if ( $blocks ) {
			foreach ( $blocks as $block ) {
				$block->appendChild( $doc->createTextNode( ' ' ) );
			}
		}
		$root        = $doc->getElementById( 'flseo-root' );
		$out['text'] = self::squash( $root ? (string) $root->textContent : '' );
		// phpcs:enable
		return $out;
	}

	/**
	 * Fallback parser when DOM is unavailable.
	 *
	 * @param string $html HTML.
	 * @return array{text: string, headings: array<int, array{level: int, text: string}>, links: array<int, array{href: string, anchor: string}>}
	 */
	private static function parse_with_regex( string $html ): array {
		$out = array(
			'text'     => '',
			'headings' => array(),
			'links'    => array(),
		);
		if ( preg_match_all( '~<a\b[^>]*href=(["\'])(.*?)\1[^>]*>(.*?)</a>~is', $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $link ) {
				$out['links'][] = array(
					'href'   => html_entity_decode( trim( $link[2] ), ENT_QUOTES ),
					'anchor' => self::squash( wp_strip_all_tags( $link[3] ) ),
				);
			}
		}
		if ( preg_match_all( '~<h([1-6])\b[^>]*>(.*?)</h\1>~is', $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $h ) {
				$out['headings'][] = array(
					'level' => (int) $h[1],
					'text'  => self::squash( wp_strip_all_tags( $h[2] ) ),
				);
			}
		}
		$clean       = (string) preg_replace( '~<(script|style|noscript|nav|form)\b.*?</\1>~is', ' ', $html );
		$clean       = (string) preg_replace( '~<(p|div|li|h[1-6]|br|td)\b~i', ' <$1', $clean );
		$out['text'] = self::squash( html_entity_decode( wp_strip_all_tags( $clean ), ENT_QUOTES ) );
		return $out;
	}

	/**
	 * Collapse whitespace.
	 *
	 * @param string $text Text.
	 */
	public static function squash( string $text ): string {
		return trim( (string) preg_replace( '/[\s\x{00A0}]+/u', ' ', $text ) );
	}

	/**
	 * Count words in plain text.
	 *
	 * @param string $text Plain text.
	 */
	public static function word_count( string $text ): int {
		return (int) preg_match_all( '/[\p{L}\p{N}][\p{L}\p{N}\'’-]*/u', $text );
	}

	/**
	 * Lowercased content words (stopwords and very short tokens removed).
	 *
	 * @param string $text Plain text.
	 * @return array<int, string>
	 */
	public static function tokens( string $text ): array {
		$text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
		if ( ! preg_match_all( '/[\p{L}\p{N}]{3,}/u', $text, $m ) ) {
			return array();
		}
		$stop = self::stopwords();
		$out  = array();
		foreach ( $m[0] as $word ) {
			if ( ! isset( $stop[ $word ] ) && ! ctype_digit( $word ) ) {
				$out[] = $word;
			}
		}
		return $out;
	}

	/**
	 * English stopwords as a lookup map.
	 *
	 * @return array<string, true>
	 */
	public static function stopwords(): array {
		static $map = null;
		if ( null === $map ) {
			$words = 'the and for are but not you all any can had her was one our out has him his how its may new now old see two who boy did get let put say she too use that with have this will your from they know want been good much some time very when come here just like long make many more only over such take than them well were what into also each most other then there these thing those through about after again against because before being below between both does doing down during few further having itself just more myself once only ought ourselves same should their theirs themselves under until upwards which while whom would yours yourself yourselves where why could every within without upon onto across along among around off per via';
			$map   = array_fill_keys( explode( ' ', $words ), true );
			/**
			 * Filter the stopword list used for duplicate detection and link suggestions.
			 *
			 * @param array<string, true> $map Stopwords as keys.
			 */
			$map = (array) apply_filters( 'flseo_stopwords', $map );
		}
		return $map;
	}

	/**
	 * Whether a URL points at this site. Relative URLs count as internal.
	 *
	 * @param string $url URL or path.
	 */
	public static function is_internal( string $url ): bool {
		$url = trim( $url );
		if ( '' === $url || str_starts_with( $url, '#' ) || preg_match( '~^(mailto|tel|javascript|data|sms|ftp):~i', $url ) ) {
			return false;
		}
		if ( str_starts_with( $url, '//' ) ) {
			$url = 'https:' . $url;
		}
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( null === $host || false === $host || '' === $host ) {
			return ! preg_match( '~^[a-z][a-z0-9+.-]*:~i', $url );
		}
		return self::bare_host( (string) $host ) === self::bare_host( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	}

	/**
	 * Whether a URL is an http(s) link to another site.
	 *
	 * @param string $url URL.
	 */
	public static function is_external( string $url ): bool {
		return (bool) preg_match( '~^(https?:)?//~i', trim( $url ) ) && ! self::is_internal( $url );
	}

	/**
	 * Host without a leading www.
	 *
	 * @param string $host Host.
	 */
	private static function bare_host( string $host ): string {
		return (string) preg_replace( '/^www\./', '', strtolower( $host ) );
	}

	/**
	 * Absolute URL for an internal href, without fragment.
	 *
	 * @param string $href Href.
	 */
	public static function absolute( string $href ): string {
		$href = trim( html_entity_decode( $href, ENT_QUOTES ) );
		$href = (string) preg_replace( '/#.*$/', '', $href );
		if ( str_starts_with( $href, '//' ) ) {
			return set_url_scheme( 'http:' . $href );
		}
		if ( ! preg_match( '~^[a-z][a-z0-9+.-]*:~i', $href ) ) {
			return home_url( '/' . ltrim( $href, '/' ) );
		}
		return $href;
	}

	/**
	 * Resolve an internal URL.
	 *
	 * Kinds: post (post_id set), home, term, archive (author, date, feed, search,
	 * pagination), file (uploads and static assets), system (admin, login, REST),
	 * broken (nothing on this site answers the URL).
	 *
	 * @param string $href Internal href.
	 * @return array{post_id: int, kind: string}
	 */
	public function resolve( string $href ): array {
		$url = self::absolute( $href );
		if ( isset( $this->resolved[ $url ] ) ) {
			return $this->resolved[ $url ];
		}
		if ( count( $this->resolved ) > 5000 ) {
			$this->resolved = array();
		}
		$this->resolved[ $url ] = $this->resolve_uncached( $url, 0 );
		return $this->resolved[ $url ];
	}

	/**
	 * Resolution without cache.
	 *
	 * @param string $url   Absolute URL.
	 * @param int    $depth Redirect hops followed so far.
	 * @return array{post_id: int, kind: string}
	 */
	private function resolve_uncached( string $url, int $depth ): array {
		$home_path = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$path      = (string) wp_parse_url( $url, PHP_URL_PATH );
		$query     = (string) wp_parse_url( $url, PHP_URL_QUERY );
		$relative  = '/' . ltrim( substr( $path, strlen( rtrim( $home_path, '/' ) ) ), '/' );
		if ( '/' === $relative && '' === $query ) {
			$front = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
			return array(
				'post_id' => $front,
				'kind'    => $front ? 'post' : 'home',
			);
		}
		if ( preg_match( '~^/(wp-admin|wp-login\.php|wp-json|xmlrpc\.php|wp-cron\.php)~', $relative ) ) {
			return array(
				'post_id' => 0,
				'kind'    => 'system',
			);
		}
		if ( preg_match( '~^/(wp-content|wp-includes)/~', $relative ) || preg_match( '~\.(jpe?g|png|gif|webp|avif|svg|pdf|docx?|xlsx?|pptx?|zip|mp3|mp4|css|js|xml|txt|ico)$~i', $relative ) ) {
			return array(
				'post_id' => 0,
				'kind'    => 'file',
			);
		}
		$post_id = url_to_postid( $url );
		if ( $post_id > 0 ) {
			$status = get_post_status( $post_id );
			if ( 'publish' === $status ) {
				return array(
					'post_id' => (int) $post_id,
					'kind'    => 'post',
				);
			}
			if ( 'inherit' === $status && 'attachment' === get_post_type( $post_id ) ) {
				return array(
					'post_id' => 0,
					'kind'    => 'file',
				);
			}
			return array(
				'post_id' => 0,
				'kind'    => 'broken',
			);
		}
		if ( $this->is_term_url( $url ) ) {
			return array(
				'post_id' => 0,
				'kind'    => 'term',
			);
		}
		if ( preg_match( '~/(feed|page/\d+|comment-page-\d+|amp)/?$~', $relative ) || preg_match( '/(^|&)(s|paged|feed|cat|tag|author|m|year|monthnum|page_id|p)=/', $query ) ) {
			return array(
				'post_id' => 0,
				'kind'    => 'archive',
			);
		}
		if ( $this->is_archive_url( $url ) ) {
			return array(
				'post_id' => 0,
				'kind'    => 'archive',
			);
		}
		if ( $depth < 3 && class_exists( \FutureLabs\AISEO\Redirects\Rules::class ) ) {
			$rule = $this->c->get( \FutureLabs\AISEO\Redirects\Rules::class )->match( $relative );
			if ( $rule ) {
				$target = (string) ( $rule->resolved_target ?? '' );
				if ( '' === $target || 410 === (int) $rule->type ) {
					return array(
						'post_id' => 0,
						'kind'    => 'broken',
					);
				}
				if ( ! self::is_internal( $target ) ) {
					return array(
						'post_id' => 0,
						'kind'    => 'redirect',
					);
				}
				$next = $this->resolve_uncached( self::absolute( $target ), $depth + 1 );
				return 'broken' === $next['kind'] ? $next : array(
					'post_id' => $next['post_id'],
					'kind'    => $next['post_id'] ? 'post' : 'redirect',
				);
			}
		}
		$old = $this->old_slug_target( $relative );
		if ( $old ) {
			return array(
				'post_id' => $old,
				'kind'    => 'post',
			);
		}
		return array(
			'post_id' => 0,
			'kind'    => 'broken',
		);
	}

	/**
	 * Whether a URL is a public term archive.
	 *
	 * @param string $url Absolute URL.
	 */
	private function is_term_url( string $url ): bool {
		return null !== $this->term_for_url( $url );
	}

	/**
	 * Term whose archive URL matches, if any.
	 *
	 * @param string $url Absolute URL.
	 */
	public function term_for_url( string $url ): ?\WP_Term {
		if ( null === $this->term_map ) {
			$map   = array();
			$terms = get_terms(
				array(
					'taxonomy'   => get_taxonomies( array( 'public' => true ) ),
					'hide_empty' => false,
					'number'     => 5000,
				)
			);
			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				$link = get_term_link( $term );
				if ( is_string( $link ) ) {
					$map[ untrailingslashit( strtolower( $link ) ) ] = (int) $term->term_id;
				}
			}
			$this->term_map = $map;
		}
		$map = $this->term_map;
		$key = untrailingslashit( strtolower( (string) preg_replace( '/#.*$/', '', $url ) ) );
		if ( isset( $map[ $key ] ) ) {
			$term = get_term( $map[ $key ] );
			return $term instanceof \WP_Term ? $term : null;
		}
		return null;
	}

	/**
	 * Whether a URL is an author or date archive or the posts page.
	 *
	 * @param string $url Absolute URL.
	 */
	private function is_archive_url( string $url ): bool {
		global $wp_rewrite;
		$path = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
		if ( $wp_rewrite instanceof \WP_Rewrite && $wp_rewrite->using_permalinks() ) {
			$author_base = trim( (string) $wp_rewrite->author_base, '/' );
			if ( '' !== $author_base && preg_match( '~(^|/)' . preg_quote( $author_base, '~' ) . '/[^/]+$~', $path ) ) {
				return true;
			}
		}
		return (bool) preg_match( '~(^|/)\d{4}(/\d{2}){0,2}$~', $path );
	}

	/**
	 * Post that used to live at a path (WordPress redirects old slugs itself).
	 *
	 * @param string $relative Path relative to home.
	 */
	private function old_slug_target( string $relative ): int {
		global $wpdb;
		$parts = array_values( array_filter( explode( '/', trim( $relative, '/' ) ) ) );
		if ( ! $parts ) {
			return 0;
		}
		$slug = sanitize_title( (string) end( $parts ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT pm.post_id FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = '_wp_old_slug' AND pm.meta_value = %s AND p.post_status = 'publish' ORDER BY pm.meta_id DESC LIMIT 1", $slug ) );
		return $id;
	}

	/**
	 * Forget cached resolutions (after content or redirect changes).
	 */
	public function reset(): void {
		$this->resolved = array();
		$this->term_map = null;
	}
}
