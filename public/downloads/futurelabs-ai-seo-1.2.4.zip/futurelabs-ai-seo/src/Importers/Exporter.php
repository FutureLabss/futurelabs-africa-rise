<?php
/**
 * JSON settings export and import.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Importers;

use FutureLabs\AISEO\Bulk\AuditLog;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Exports `flseo_settings` as JSON (secrets live in separate encrypted options and are never
 * included) and imports it again with validation, a dry-run diff and an audit entry.
 */
class Exporter {

	public const FORMAT = 1;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Export document.
	 *
	 * @return array{plugin: string, format: int, version: string, generated_at: string, site: string, settings: array<string, mixed>}
	 */
	public function export(): array {
		return array(
			'plugin'       => 'futurelabs-ai-seo',
			'format'       => self::FORMAT,
			'version'      => defined( 'FLSEO_VERSION' ) ? (string) FLSEO_VERSION : '',
			'generated_at' => gmdate( 'c' ),
			'site'         => home_url( '/' ),
			'settings'     => self::without_secrets( $this->c->get( Settings::class )->all() ),
		);
	}

	/**
	 * Remove any key that looks like a credential, at any depth.
	 *
	 * @param array<string, mixed> $values Values.
	 * @return array<string, mixed>
	 */
	public static function without_secrets( array $values ): array {
		$out = array();
		foreach ( $values as $key => $value ) {
			if ( preg_match( '/secret|token|password|api_?key|client_id|private/i', (string) $key ) ) {
				continue;
			}
			$out[ $key ] = is_array( $value ) ? self::without_secrets( $value ) : $value;
		}
		return $out;
	}

	/**
	 * Import a settings document.
	 *
	 * @param string|array<string, mixed> $json    JSON text or decoded document.
	 * @param bool                        $dry_run Only report the diff.
	 * @return array{dry_run: bool, changes: array<int, array{key: string, current: mixed, new: mixed}>, ignored: array<int, string>, batch_id: string|null}|\WP_Error
	 */
	public function import( $json, bool $dry_run ) {
		$doc = is_array( $json ) ? $json : json_decode( (string) $json, true );
		if ( ! is_array( $doc ) ) {
			return new \WP_Error( 'flseo_import_json', __( 'The file is not valid JSON.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( isset( $doc['plugin'] ) && 'futurelabs-ai-seo' !== $doc['plugin'] ) {
			return new \WP_Error( 'flseo_import_plugin', __( 'This file was not exported by FutureLabs AI SEO.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( isset( $doc['format'] ) && (int) $doc['format'] > self::FORMAT ) {
			return new \WP_Error( 'flseo_import_format', __( 'This file was exported by a newer version of FutureLabs AI SEO. Update the plugin and try again.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$input = $doc['settings'] ?? null;
		if ( ! is_array( $input ) || ! $input ) {
			return new \WP_Error( 'flseo_import_settings', __( 'The file has no settings object.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$defaults = Settings::defaults();
		$input    = self::without_secrets( $input );
		$ignored  = array_values( array_map( 'strval', array_keys( array_diff_key( $input, $defaults ) ) ) );
		$known    = array_intersect_key( $input, $defaults );
		if ( ! $known ) {
			return new \WP_Error( 'flseo_import_empty', __( 'The file contains no FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$settings = $this->c->get( Settings::class );
		$current  = $settings->all();
		$changes  = array();
		foreach ( $defaults as $key => $default ) {
			$new = array_key_exists( $key, $known ) ? self::normalize( $known[ $key ], $default ) : $default;
			if ( self::normalize( $current[ $key ] ?? null, $default ) !== $new ) {
				$changes[] = array(
					'key'     => $key,
					'current' => $current[ $key ] ?? null,
					'new'     => $new,
				);
			}
		}
		$result = array(
			'dry_run'  => $dry_run,
			'changes'  => $changes,
			'ignored'  => $ignored,
			'batch_id' => null,
		);
		if ( $dry_run || ! $changes ) {
			return $result;
		}
		$saved = $settings->replace( $known );
		$audit = $this->c->get( AuditLog::class );
		$batch = $audit->new_batch();
		$audit->write(
			$batch,
			'settings_import',
			'settings',
			0,
			array(
				'kind'  => 'settings',
				'value' => $current,
			),
			array(
				'kind'  => 'settings',
				'value' => $saved,
			)
		);
		$result['batch_id'] = $batch;
		return $result;
	}

	/**
	 * Normalize a value to the default's type for comparison.
	 *
	 * @param mixed $value   Value.
	 * @param mixed $fallback Default value that determines the type.
	 * @return mixed
	 */
	private static function normalize( $value, $fallback ) {
		if ( is_bool( $fallback ) ) {
			return Settings::to_bool( $value );
		}
		if ( is_int( $fallback ) ) {
			return (int) $value;
		}
		if ( is_array( $fallback ) ) {
			$value = is_array( $value ) ? $value : array();
			if ( $fallback && array_keys( $fallback ) !== range( 0, count( $fallback ) - 1 ) ) {
				$value = array_merge( $fallback, $value );
			}
			return self::sort_deep( $value );
		}
		return is_scalar( $value ) ? (string) $value : '';
	}

	/**
	 * Sort associative arrays recursively so key order does not create false differences.
	 *
	 * @param array<mixed> $value Value.
	 * @return array<mixed>
	 */
	private static function sort_deep( array $value ): array {
		foreach ( $value as $k => $v ) {
			if ( is_array( $v ) ) {
				$value[ $k ] = self::sort_deep( $v );
			}
		}
		if ( array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
			ksort( $value );
		}
		return $value;
	}
}
