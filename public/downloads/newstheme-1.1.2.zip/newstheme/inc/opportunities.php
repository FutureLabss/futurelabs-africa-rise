<?php
/**
 * Opportunity deadlines: badges on post images ("Closes in 3 days", "Closed")
 * and the "Closing soon" block source. Deadlines are entered in the
 * FutureLabs AI SEO plugin; the theme only displays them.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Deadline facts for a post, or null when it has none.
 *
 * Reads FutureLabs AI SEO's opportunity fields (`_flseo_opp_deadline` as
 * Y-m-d, `_flseo_opp_status`). Other sources can supply the same shape
 * through the `newstheme_opportunity` filter.
 *
 * @param int|WP_Post|null $post Post (default: current).
 * @return array{deadline: string, status: string}|null
 */
function newstheme_opportunity( $post = null ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return null;
	}
	$deadline = (string) get_post_meta( $post->ID, '_flseo_opp_deadline', true );
	$data     = array(
		'deadline' => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $deadline ) ? $deadline : '',
		'status'   => sanitize_key( (string) get_post_meta( $post->ID, '_flseo_opp_status', true ) ),
	);
	$data     = apply_filters( 'newstheme_opportunity', $data, $post );
	if ( ! is_array( $data ) || ( empty( $data['deadline'] ) && 'rolling' !== ( $data['status'] ?? '' ) ) ) {
		return null;
	}
	return array(
		'deadline' => (string) ( $data['deadline'] ?? '' ),
		'status'   => (string) ( $data['status'] ?? '' ),
	);
}

/**
 * Days until a deadline (Y-m-d, in the site's timezone). 0 = closes today,
 * negative = passed.
 *
 * @param string   $deadline Deadline date.
 * @param int|null $now      Timestamp (default: now).
 * @return int
 */
function newstheme_days_until( $deadline, $now = null ) {
	$timezone = wp_timezone();
	$today    = new DateTimeImmutable( '@' . ( null === $now ? time() : (int) $now ) );
	$today    = $today->setTimezone( $timezone )->setTime( 0, 0 );
	$date     = DateTimeImmutable::createFromFormat( '!Y-m-d', $deadline, $timezone );
	if ( ! $date ) {
		return PHP_INT_MAX;
	}
	return (int) round( ( $date->getTimestamp() - $today->getTimestamp() ) / DAY_IN_SECONDS );
}

/**
 * State and label for a deadline.
 *
 * @param array    $opportunity From newstheme_opportunity().
 * @param int|null $now         Timestamp (default: now).
 * @return array{state: string, label: string}
 */
function newstheme_deadline_state( array $opportunity, $now = null ) {
	if ( 'closed' === $opportunity['status'] ) {
		return array(
			'state' => 'closed',
			'label' => __( 'Closed', 'newstheme' ),
		);
	}
	if ( '' === $opportunity['deadline'] ) {
		return array(
			'state' => 'open',
			'label' => __( 'Rolling deadline', 'newstheme' ),
		);
	}
	$days = newstheme_days_until( $opportunity['deadline'], $now );
	$soon = (int) newstheme_get_mod( 'deadline_soon_days' );
	if ( $days < 0 ) {
		return array(
			'state' => 'closed',
			'label' => __( 'Closed', 'newstheme' ),
		);
	}
	if ( 0 === $days ) {
		return array(
			'state' => 'soon',
			'label' => __( 'Closes today', 'newstheme' ),
		);
	}
	if ( 1 === $days ) {
		return array(
			'state' => 'soon',
			'label' => __( 'Closes tomorrow', 'newstheme' ),
		);
	}
	if ( $days <= $soon ) {
		return array(
			'state' => 'soon',
			/* translators: %d: number of days until the deadline. */
			'label' => sprintf( _n( 'Closes in %d day', 'Closes in %d days', $days, 'newstheme' ), $days ),
		);
	}
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $opportunity['deadline'], wp_timezone() );
	return array(
		'state' => 'open',
		/* translators: %s: deadline date, e.g. "13 Oct". */
		'label' => sprintf( __( 'Closes %s', 'newstheme' ), wp_date( _x( 'j M', 'deadline badge date format', 'newstheme' ), $date->getTimestamp() ) ),
	);
}

/**
 * Deadline badge for a post image. The label is correct when the page is
 * generated; theme.js recomputes it on the visitor's clock, so a cached page
 * never shows a stale "Closes in 3 days".
 *
 * @param int|WP_Post|null $post Post (default: current).
 * @return string HTML, or '' when the post has no deadline or badges are off.
 */
function newstheme_deadline_badge( $post = null ) {
	if ( ! newstheme_get_mod( 'deadline_badges' ) ) {
		return '';
	}
	$opportunity = newstheme_opportunity( $post );
	if ( ! $opportunity ) {
		return '';
	}
	$state = newstheme_deadline_state( $opportunity );
	return sprintf(
		'<span class="nt-deadline nt-deadline--%1$s"%2$s>%3$s<span class="nt-deadline__text">%4$s</span></span>',
		esc_attr( $state['state'] ),
		'' !== $opportunity['deadline'] && 'closed' !== $opportunity['status']
			? sprintf( ' data-nt-deadline="%s" data-nt-soon="%d"', esc_attr( $opportunity['deadline'] ), (int) newstheme_get_mod( 'deadline_soon_days' ) )
			: '',
		newstheme_get_icon( 'clock', 'nt-deadline__icon' ),
		esc_html( $state['label'] )
	);
}

/**
 * WP_Query arguments for the "Closing soon" block source: open deadlines from
 * today onwards, soonest first.
 *
 * @param array $args WP_Query arguments.
 * @return array
 */
function newstheme_closing_soon_query_args( array $args ) {
	unset( $args['offset'] );
	$args['meta_key']   = '_flseo_opp_deadline'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- the query is defined by its deadline.
	$args['meta_type']  = 'DATE';
	$args['orderby']    = 'meta_value';
	$args['order']      = 'ASC';
	$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- as above.
		array(
			'key'     => '_flseo_opp_deadline',
			'value'   => wp_date( 'Y-m-d' ),
			'compare' => '>=',
			'type'    => 'DATE',
		),
	);
	return $args;
}

/**
 * Labels and timezone for the deadline script (theme.js), all translated
 * here, including the plural form for every day count up to the maximum
 * "closing soon" window.
 *
 * @return array<string, mixed>|null Null when badges are off.
 */
function newstheme_deadline_script_data() {
	if ( ! newstheme_get_mod( 'deadline_badges' ) ) {
		return null;
	}
	$in_days = array();
	for ( $days = 2; $days <= 30; $days++ ) {
		/* translators: %d: number of days until the deadline. */
		$in_days[ $days ] = sprintf( _n( 'Closes in %d day', 'Closes in %d days', $days, 'newstheme' ), $days );
	}
	return array(
		'offset'   => (int) round( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ),
		'today'    => __( 'Closes today', 'newstheme' ),
		'tomorrow' => __( 'Closes tomorrow', 'newstheme' ),
		'closed'   => __( 'Closed', 'newstheme' ),
		'inDays'   => $in_days,
	);
}
