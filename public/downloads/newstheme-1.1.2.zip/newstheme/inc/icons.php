<?php
/**
 * SVG icons from the build-generated sprite (assets/icons/sprite.svg).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Markup for an icon.
 *
 * @param string $name  Icon name (sprite symbol without the `nt-i-` prefix).
 * @param string $extra_class Extra classes.
 * @return string
 */
function newstheme_get_icon( $name, $extra_class = '' ) {
	return sprintf(
		'<svg class="nt-icon nt-icon--%1$s %2$s" aria-hidden="true" focusable="false"><use href="#nt-i-%1$s"></use></svg>',
		esc_attr( $name ),
		esc_attr( $extra_class )
	);
}

/**
 * Print an icon.
 *
 * @param string $name  Icon name.
 * @param string $extra_class Extra classes.
 */
function newstheme_icon( $name, $extra_class = '' ) {
	echo newstheme_get_icon( $name, $extra_class ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in newstheme_get_icon().
}

/**
 * Inline the sprite once, right after <body>, so <use href="#…"> works
 * without an extra request. Also hooked to wp_footer for pages that never
 * call wp_body_open() (widget previews, some plugin templates); <use> works
 * with a sprite that appears later in the document.
 */
function newstheme_print_icon_sprite() {
	static $printed = false;
	if ( $printed ) {
		return;
	}
	$printed = true;

	$file = NEWSTHEME_DIR . 'assets/icons/sprite.svg';
	if ( is_readable( $file ) ) {
		echo file_get_contents( $file ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- static build artifact shipped with the theme.
	}
}
add_action( 'wp_body_open', 'newstheme_print_icon_sprite', 1 );
add_action( 'wp_footer', 'newstheme_print_icon_sprite', 1 );
