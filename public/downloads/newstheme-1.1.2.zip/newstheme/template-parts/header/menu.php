<?php
/**
 * Header element: primary navigation.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

if ( ! has_nav_menu( 'primary' ) ) {
	return;
}
$newstheme_suffix = newstheme_element_suffix( $args );
?>
<nav id="nt-site-navigation<?php echo esc_attr( $newstheme_suffix ); ?>" class="nt-nav" aria-label="<?php esc_attr_e( 'Primary', 'newstheme' ); ?>">
	<?php
	wp_nav_menu(
		array(
			'theme_location' => 'primary',
			'menu_id'        => 'nt-primary-menu' . $newstheme_suffix,
			'menu_class'     => 'nt-menu',
			'container'      => false,
			'depth'          => 3,
		)
	);
	?>
</nav>
