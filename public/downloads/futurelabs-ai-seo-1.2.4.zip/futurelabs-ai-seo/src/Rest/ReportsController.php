<?php
/**
 * Reports endpoints: digest test/preview, history, refresh list and keyword suggestions.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Reports\Digest;
use FutureLabs\AISEO\Reports\History;
use FutureLabs\AISEO\Reports\Keywords;
use FutureLabs\AISEO\Reports\Mailer;
use FutureLabs\AISEO\Reports\RefreshAlerts;

defined( 'ABSPATH' ) || exit;

/**
 * /reports routes.
 */
class ReportsController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/reports/test', 'POST', array( $this, 'test' ), Capabilities::DATA );
		$this->route( '/reports/preview', 'GET', array( $this, 'preview' ), Capabilities::DATA );
		$this->route( '/reports/history', 'GET', array( $this, 'history' ), Capabilities::DATA );
		$this->route( '/reports/refresh', 'GET', array( $this, 'refresh' ), Capabilities::DATA );
		$this->route( '/reports/keywords', 'GET', array( $this, 'keywords' ), Capabilities::DATA );
	}

	/**
	 * POST /reports/test: send a test digest to the configured recipients.
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function test() {
		if ( ! $this->c->get( Mailer::class )->recipients() ) {
			return $this->error( 'no_recipients', __( 'Add at least one valid report recipient in FutureLabs AI SEO settings first.', 'futurelabs-ai-seo' ), 400 );
		}
		$result = $this->c->get( Digest::class )->send( true );
		if ( ! $result['sent'] ) {
			return $this->error( 'mail_failed', __( 'WordPress could not send the email. Check your site’s mail configuration (for example an SMTP plugin).', 'futurelabs-ai-seo' ), 502 );
		}
		return rest_ensure_response( $result );
	}

	/**
	 * GET /reports/preview
	 */
	public function preview(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( Digest::class )->render( true ) );
	}

	/**
	 * GET /reports/history?days=90
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function history( \WP_REST_Request $request ): \WP_REST_Response {
		$days  = min( 730, max( 1, absint( $request->get_param( 'days' ) ?: 90 ) ) );
		$items = $this->c->get( History::class )->series( $days );
		return rest_ensure_response(
			array(
				'items' => $items,
				'total' => count( $items ),
			)
		);
	}

	/**
	 * GET /reports/refresh
	 */
	public function refresh(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( RefreshAlerts::class )->alerts() );
	}

	/**
	 * GET /reports/keywords
	 */
	public function keywords(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( Keywords::class )->suggestions() );
	}
}
