<?php
/**
 * Author box below a single post.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_author = (int) get_the_author_meta( 'ID' );
?>
<section class="nt-author-box" aria-label="<?php esc_attr_e( 'About the author', 'newstheme' ); ?>">
	<?php echo get_avatar( $newstheme_author, 80, '', '', array( 'class' => 'nt-author-box__avatar' ) ); ?>
	<div class="nt-author-box__body">
		<p class="nt-author-box__name">
			<a href="<?php echo esc_url( get_author_posts_url( $newstheme_author ) ); ?>"><?php the_author(); ?></a>
		</p>
		<?php if ( get_the_author_meta( 'description' ) ) : ?>
			<p class="nt-author-box__bio"><?php echo esc_html( get_the_author_meta( 'description' ) ); ?></p>
		<?php endif; ?>
		<a class="nt-read-more" href="<?php echo esc_url( get_author_posts_url( $newstheme_author ) ); ?>">
			<?php esc_html_e( 'View all posts', 'newstheme' ); ?><?php newstheme_icon( 'chevron-right' ); ?>
		</a>
	</div>
</section>
