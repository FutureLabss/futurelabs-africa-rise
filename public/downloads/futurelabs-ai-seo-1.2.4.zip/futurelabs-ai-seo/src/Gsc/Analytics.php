<?php
/**
 * Daily Search Analytics sync into flseo_gsc_queries.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Gsc;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;

defined( 'ABSPATH' ) || exit;

/**
 * Pulls page × query rows for the current 28 days, the previous 28 days and the last 90 days.
 */
class Analytics implements Module {

	public const HOOK        = 'flseo_sync_analytics';
	public const SETS_OPTION = 'flseo_gsc_analytics_sets';
	public const LAST_OPTION = 'flseo_gsc_analytics_last';

	/**
	 * Number of sync sets (each with three ranges) kept in the table.
	 */
	public const KEEP_SETS = 3;

	/**
	 * Search Console data lags by about two to three days.
	 */
	private const LAG_DAYS = 3;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'flseo_daily', array( $this, 'queue' ) );
		add_action( self::HOOK, array( $this, 'sync' ) );
	}

	/**
	 * Queue a sync when connected.
	 */
	public function queue(): bool {
		if ( ! $this->c->get( OAuth::class )->ready() ) {
			return false;
		}
		$this->c->get( Queue::class )->async( self::HOOK );
		return true;
	}

	/**
	 * The three ranges for a given end date.
	 *
	 * @param int|null $now Reference timestamp.
	 * @return array<string, array{0: string, 1: string}> current, previous, long.
	 */
	public static function ranges( ?int $now = null ): array {
		$now = $now ?? time();
		$end = $now - self::LAG_DAYS * DAY_IN_SECONDS;
		$day = static function ( int $offset ) use ( $end ): string {
			return gmdate( 'Y-m-d', $end - $offset * DAY_IN_SECONDS );
		};
		return array(
			'current'  => array( $day( 27 ), $day( 0 ) ),
			'previous' => array( $day( 55 ), $day( 28 ) ),
			'long'     => array( $day( 89 ), $day( 0 ) ),
		);
	}

	/**
	 * Maximum rows pulled per range.
	 */
	private function max_rows(): int {
		/**
		 * Filter the maximum Search Analytics rows stored per date range.
		 *
		 * @param int $rows Rows.
		 */
		return max( 1, (int) apply_filters( 'flseo_analytics_max_rows', 100000 ) );
	}

	/**
	 * Rows requested per API call.
	 */
	private function page_size(): int {
		/**
		 * Filter the Search Analytics page size (max 25,000).
		 *
		 * @param int $rows Rows per request.
		 */
		return max( 1, min( Client::MAX_ROWS, (int) apply_filters( 'flseo_analytics_page_size', Client::MAX_ROWS ) ) );
	}

	/**
	 * Pull and store every range.
	 *
	 * @param int|null $now Reference timestamp (defaults to now).
	 * @return array{ok: bool, rows: array<string, int>, error: string}
	 */
	public function sync( $now = null ): array {
		$oauth = $this->c->get( OAuth::class );
		if ( ! $oauth->ready() ) {
			return array(
				'ok'    => false,
				'rows'  => array(),
				'error' => __( 'Search Console is not connected.', 'futurelabs-ai-seo' ),
			);
		}
		$property = $oauth->property();
		$ranges   = self::ranges( is_numeric( $now ) ? (int) $now : null );
		$counts   = array();
		$error    = '';
		$labels   = array();
		foreach ( $ranges as $key => $range ) {
			$label = $range[0] . '/' . $range[1];
			$rows  = $this->sync_range( $property, $range[0], $range[1] );
			if ( is_wp_error( $rows ) ) {
				$error = $rows->get_error_message();
				break;
			}
			$counts[ $key ] = $rows;
			$labels[ $key ] = $label;
		}
		$ok = '' === $error;
		if ( $ok ) {
			$this->remember_set( $labels );
		}
		update_option(
			self::LAST_OPTION,
			array(
				'at'     => gmdate( 'c' ),
				'ok'     => $ok,
				'rows'   => $counts,
				'ranges' => $labels,
				'error'  => $error,
			),
			false
		);
		if ( ! $ok ) {
			$this->c->get( Logger::class )->warning( 'Search Analytics sync failed.', array( 'error' => $error ) );
		}
		return array(
			'ok'    => $ok,
			'rows'  => $counts,
			'error' => $error,
		);
	}

	/**
	 * Pull one range page by page into a staging label, then swap it in.
	 *
	 * @param string $property Property.
	 * @param string $start    Y-m-d.
	 * @param string $end      Y-m-d.
	 * @return int|\WP_Error Rows stored.
	 */
	public function sync_range( string $property, string $start, string $end ) {
		global $wpdb;
		$table   = Migrations::table( 'gsc_queries' );
		$label   = $start . '/' . $end;
		$staging = 'tmp:' . $label;
		$client  = $this->c->get( Client::class );
		$max     = $this->max_rows();
		$offset  = 0;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE date_range=%s", $staging ) );
		while ( $offset < $max ) {
			$limit = min( $this->page_size(), $max - $offset );
			$rows  = $client->search_analytics( $property, $start, $end, array( 'page', 'query' ), $limit, $offset );
			if ( is_wp_error( $rows ) ) {
				$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE date_range=%s", $staging ) );
				return $rows;
			}
			$this->insert_rows( $rows, $staging );
			$offset += count( $rows );
			if ( count( $rows ) < $limit ) {
				break;
			}
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE date_range=%s", $label ) );
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET date_range=%s WHERE date_range=%s", $label, $staging ) );
		// phpcs:enable
		return $offset;
	}

	/**
	 * Multi-row insert.
	 *
	 * @param array<int, array<string, mixed>> $rows  API rows.
	 * @param string                           $label date_range value.
	 */
	private function insert_rows( array $rows, string $label ): void {
		global $wpdb;
		$table = Migrations::table( 'gsc_queries' );
		foreach ( array_chunk( $rows, 500 ) as $chunk ) {
			$values = array();
			$params = array();
			foreach ( $chunk as $row ) {
				$url = (string) ( $row['keys'][0] ?? '' );
				if ( '' === $url ) {
					continue;
				}
				$values[] = '(%s,%s,%s,%d,%d,%f,%s)';
				array_push(
					$params,
					hash( 'sha256', $url ),
					substr( $url, 0, 2048 ),
					substr( sanitize_text_field( (string) ( $row['keys'][1] ?? '' ) ), 0, 500 ),
					(int) round( (float) ( $row['clicks'] ?? 0 ) ),
					(int) round( (float) ( $row['impressions'] ?? 0 ) ),
					(float) ( $row['position'] ?? 0 ),
					$label
				);
			}
			if ( ! $values ) {
				continue;
			}
			$sql = "INSERT INTO {$table} (url_hash,url,query,clicks,impressions,position,date_range) VALUES " . implode( ',', $values );
			$wpdb->query( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.NotPrepared
		}
	}

	/**
	 * Record a completed set and delete ranges that no longer belong to the last KEEP_SETS sets.
	 *
	 * @param array<string, string> $labels Range labels keyed by current/previous/long.
	 */
	private function remember_set( array $labels ): void {
		global $wpdb;
		$sets   = get_option( self::SETS_OPTION, array() );
		$sets   = is_array( $sets ) ? $sets : array();
		$sets   = array_values(
			array_filter(
				$sets,
				static function ( $set ) use ( $labels ): bool {
					return is_array( $set ) && ( $set['ranges'] ?? array() ) !== $labels;
				}
			)
		);
		$sets[] = array(
			'at'     => gmdate( 'c' ),
			'ranges' => $labels,
		);
		$sets   = array_slice( $sets, -self::KEEP_SETS );
		update_option( self::SETS_OPTION, $sets, false );

		$keep = array();
		foreach ( $sets as $set ) {
			foreach ( (array) $set['ranges'] as $label ) {
				$keep[] = (string) $label;
			}
		}
		$keep  = array_values( array_unique( $keep ) );
		$table = Migrations::table( 'gsc_queries' );
		$in    = implode( ',', array_fill( 0, count( $keep ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE date_range NOT IN ($in) AND date_range NOT LIKE %s", array_merge( $keep, array( 'tmp:%' ) ) ) );
	}

	/**
	 * Labels of the most recent complete set, or empty.
	 *
	 * @return array<string, string>
	 */
	public function latest_ranges(): array {
		$sets = get_option( self::SETS_OPTION, array() );
		if ( ! is_array( $sets ) || ! $sets ) {
			return array();
		}
		$last = end( $sets );
		return is_array( $last ) ? (array) ( $last['ranges'] ?? array() ) : array();
	}

	/**
	 * Last sync record.
	 *
	 * @return array<string, mixed>
	 */
	public function last(): array {
		$value = get_option( self::LAST_OPTION, array() );
		return is_array( $value ) ? $value : array();
	}
}
