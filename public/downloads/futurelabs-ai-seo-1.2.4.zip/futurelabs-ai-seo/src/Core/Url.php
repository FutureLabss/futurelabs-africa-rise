<?php
/**
 * URL helpers.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Syntactic URL validation.
 *
 * WordPress' wp_http_validate_url() resolves DNS and rejects private hosts, which suits outbound
 * requests but not stored values such as redirect targets or canonical URLs.
 */
final class Url {

	/**
	 * Whether a string is an absolute http(s) URL with a host.
	 *
	 * @param string $url URL.
	 */
	public static function is_valid( string $url ): bool {
		if ( '' === $url || strlen( $url ) > 2048 || preg_match( '/\s/', $url ) ) {
			return false;
		}
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) || ! in_array( strtolower( (string) ( $parts['scheme'] ?? '' ) ), array( 'http', 'https' ), true ) ) {
			return false;
		}
		return (bool) preg_match( '/^[a-z0-9.\-\[\]:]+$/i', (string) $parts['host'] ) || (bool) preg_match( '/^[\p{L}\p{N}.\-]+$/u', (string) $parts['host'] );
	}
}
