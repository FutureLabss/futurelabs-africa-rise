<?php
/**
 * Footer element: copyright text.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<p class="nt-copyright"><?php echo newstheme_copyright_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- kses'd. ?></p>
