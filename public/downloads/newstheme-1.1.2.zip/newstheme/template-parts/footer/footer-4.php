<?php
/**
 * Footer element: widget area "Footer - Column 4".
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

echo '<div class="nt-footer__widgets">';
dynamic_sidebar( 'footer-4' );
echo '</div>';
