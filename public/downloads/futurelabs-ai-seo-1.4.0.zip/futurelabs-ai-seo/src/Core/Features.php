<?php
/**
 * Optional feature switches: opportunity publishing, velocity warnings, eligibility
 * fields and the publishing checklist.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Answers "is this optional feature on?" from the settings store.
 *
 * New installs start with every optional feature off, so a general site gets a plain
 * SEO plugin. Sites that used these features before they became optional keep them on
 * (Migrations::migrate_4()).
 */
class Features {

	/**
	 * Opportunity fields, deadline badges, the daily expiry job and closed notices.
	 */
	public const OPPORTUNITIES = 'opportunities';

	/**
	 * Admin warning about bursts of near-identical posts.
	 */
	public const VELOCITY = 'velocity';

	/**
	 * Structured eligibility fields (countries, age, level, ...) for matching readers to opportunities.
	 */
	public const ELIGIBILITY = 'eligibility';

	/**
	 * Optional features and their setting keys.
	 */
	public const SWITCHES = array(
		self::OPPORTUNITIES => 'feature_opportunities',
		self::VELOCITY      => 'feature_velocity',
		self::ELIGIBILITY   => 'feature_eligibility',
	);

	/**
	 * Checklist modes: off (no checklist), soft (shown, never blocks), required (blocks publishing).
	 */
	public const CHECKLIST_MODES = array( 'off', 'soft', 'required' );

	/**
	 * Every checklist item key, in display order. Items that only apply to opportunities
	 * (deadline, source_link, sections, eligibility) also need the opportunities feature.
	 */
	public const CHECKLIST_ITEMS = array(
		'description',
		'focus_topic',
		'featured_image',
		'category',
		'deadline',
		'source_link',
		'eligibility',
		'internal_links',
		'length',
		'sections',
		'broken_links',
		'ai_leftovers',
		'duplicate',
	);

	/**
	 * Checklist items that only make sense on opportunity posts.
	 */
	public const OPPORTUNITY_ITEMS = array( 'deadline', 'source_link', 'sections', 'eligibility' );

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Whether an optional feature is on.
	 *
	 * @param string $feature One of the class constants.
	 */
	public function enabled( string $feature ): bool {
		if ( ! isset( self::SWITCHES[ $feature ] ) ) {
			return false;
		}
		$on = (bool) $this->c->get( Settings::class )->get( self::SWITCHES[ $feature ], false );
		if ( self::ELIGIBILITY === $feature ) {
			// Eligibility fields describe opportunities, so they need that feature too.
			$on = $on && $this->enabled( self::OPPORTUNITIES );
		}
		/**
		 * Filters whether an optional feature is on.
		 *
		 * @param bool   $on      Whether it is on.
		 * @param string $feature Feature name (opportunities, velocity, eligibility).
		 */
		return (bool) apply_filters( 'flseo_feature_enabled', $on, $feature );
	}

	/**
	 * Publishing checklist mode: off, soft or required.
	 */
	public function checklist_mode(): string {
		$mode = (string) $this->c->get( Settings::class )->get( 'checklist_mode', 'off' );
		return in_array( $mode, self::CHECKLIST_MODES, true ) ? $mode : 'off';
	}

	/**
	 * Whether a checklist item is switched on. An empty selection means every item.
	 *
	 * @param string $key Item key.
	 */
	public function checklist_item_enabled( string $key ): bool {
		if ( in_array( $key, self::OPPORTUNITY_ITEMS, true ) && ! $this->enabled( self::OPPORTUNITIES ) ) {
			return false;
		}
		if ( 'eligibility' === $key && ! $this->enabled( self::ELIGIBILITY ) ) {
			return false;
		}
		$chosen = (array) $this->c->get( Settings::class )->get( 'checklist_items', array() );
		// Items added by add-ons (flseo_checklist_items) aren't in the list and stay on.
		return array() === $chosen || ! in_array( $key, self::CHECKLIST_ITEMS, true ) || in_array( $key, $chosen, true );
	}

	/**
	 * Current switches, for the admin app and the editor.
	 *
	 * @return array<string, mixed>
	 */
	public function to_array(): array {
		$out = array();
		foreach ( array_keys( self::SWITCHES ) as $feature ) {
			$out[ $feature ] = $this->enabled( $feature );
		}
		$out['checklist'] = $this->checklist_mode();
		return $out;
	}
}
