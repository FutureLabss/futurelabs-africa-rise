<?php
/**
 * Creates or suggests redirects when a published post's URL changes or it is trashed.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Redirects;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Watches slug changes and trashing. Mode: auto (create 301), suggest (queue for review), off.
 */
class SlugWatcher implements Module {

	public const SUGGESTIONS_OPTION = 'flseo_redirect_suggestions';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Permalinks captured before trashing, keyed by post id.
	 *
	 * @var array<int, string>
	 */
	private array $before_trash = array();

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'post_updated', array( $this, 'slug_changed' ), 10, 3 );
		add_action( 'wp_trash_post', array( $this, 'capture_before_trash' ) );
		add_action( 'trashed_post', array( $this, 'trashed' ) );
		add_action( 'untrashed_post', array( $this, 'untrashed' ) );
		add_action( 'transition_post_status', array( $this, 'published' ), 20, 3 );
	}

	/**
	 * Mode setting.
	 */
	private function mode(): string {
		return (string) $this->c->get( Settings::class )->get( 'slug_redirects', 'auto' );
	}

	/**
	 * Handle a URL change of a published post.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $after   Post after.
	 * @param \WP_Post $before  Post before.
	 */
	public function slug_changed( int $post_id, \WP_Post $after, \WP_Post $before ): void {
		if ( 'off' === $this->mode() || wp_is_post_revision( $post_id ) || 'publish' !== $before->post_status || 'publish' !== $after->post_status ) {
			return;
		}
		if ( $after->post_name === $before->post_name && $after->post_parent === $before->post_parent ) {
			return;
		}
		$old = (string) get_permalink( $before );
		$new = (string) get_permalink( $after );
		if ( '' === $old || '' === $new || Rules::normalize_path( $old ) === Rules::normalize_path( $new ) ) {
			return;
		}
		// The post now lives at $new, so an automatic rule redirecting away from it must go (A→B→A renames).
		$this->remove_auto_rule_for( $new );
		$this->apply( $old, $new, $post_id, 'slug' );
	}

	/**
	 * Remember the permalink before a published post is trashed.
	 *
	 * @param int $post_id Post ID.
	 */
	public function capture_before_trash( int $post_id ): void {
		if ( 'publish' === get_post_status( $post_id ) ) {
			$this->before_trash[ $post_id ] = (string) get_permalink( $post_id );
		}
	}

	/**
	 * Redirect a trashed post's URL to the closest live page.
	 *
	 * @param int $post_id Post ID.
	 */
	public function trashed( int $post_id ): void {
		$old = $this->before_trash[ $post_id ] ?? '';
		unset( $this->before_trash[ $post_id ] );
		if ( '' === $old || 'off' === $this->mode() ) {
			return;
		}
		$target = '';
		foreach ( $this->c->get( Suggester::class )->suggest( $old, 3 ) as $suggestion ) {
			if ( $suggestion['post_id'] !== $post_id && $suggestion['score'] >= 0.6 ) {
				$target = $suggestion['url'];
				break;
			}
		}
		if ( '' === $target ) {
			$cats = get_the_category( $post_id );
			if ( $cats ) {
				$link   = get_category_link( $cats[0]->term_id );
				$target = is_string( $link ) ? $link : '';
			}
		}
		if ( '' === $target ) {
			$target = home_url( '/' );
		}
		$this->apply( $old, $target, $post_id, 'trash' );
	}

	/**
	 * Remove the automatic trash redirect when a post is restored.
	 *
	 * @param int $post_id Post ID.
	 */
	public function untrashed( int $post_id ): void {
		$this->remove_auto_rule_for( (string) get_permalink( $post_id ) );
	}

	/**
	 * When a post is published at a URL that an automatic redirect points away from, remove that redirect.
	 *
	 * @param string   $new  New status.
	 * @param string   $old  Old status.
	 * @param \WP_Post $post Post.
	 */
	public function published( string $new, string $old, \WP_Post $post ): void {
		if ( 'publish' === $new && 'publish' !== $old && ! wp_is_post_revision( $post ) ) {
			$this->remove_auto_rule_for( (string) get_permalink( $post ) );
		}
	}

	/**
	 * Delete an automatic (slug/trash) rule whose source is the given URL.
	 *
	 * @param string $url URL.
	 */
	private function remove_auto_rule_for( string $url ): void {
		global $wpdb;
		if ( '' === $url ) {
			return;
		}
		$table = Rules::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE source_hash=%s AND origin IN ('slug','trash') LIMIT 1", Rules::hash( $url ) ) );
		if ( $id ) {
			$this->c->get( Rules::class )->delete( $id );
		}
	}

	/**
	 * Create the redirect or store a suggestion depending on mode.
	 *
	 * @param string $old     Old URL.
	 * @param string $target  Target URL.
	 * @param int    $post_id Post ID.
	 * @param string $origin  slug or trash.
	 */
	private function apply( string $old, string $target, int $post_id, string $origin ): void {
		if ( 'suggest' === $this->mode() ) {
			$list   = $this->suggestions();
			$list[] = array(
				'id'      => wp_generate_uuid4(),
				'source'  => Rules::normalize_path( $old ),
				'target'  => $target,
				'post_id' => $post_id,
				'origin'  => $origin,
				'created' => gmdate( 'c' ),
			);
			update_option( self::SUGGESTIONS_OPTION, array_slice( $list, -200 ), false );
			return;
		}
		$rules = $this->c->get( Rules::class );
		// Re-point earlier automatic rules that targeted the old URL so no chain forms.
		$this->repoint( $old, $target );
		$rules->save(
			array(
				'source' => $old,
				'target' => $target,
				'type'   => 301,
			),
			0,
			$origin
		);
	}

	/**
	 * Update rules that point at an old URL so they point at the new one.
	 *
	 * @param string $old    Old URL.
	 * @param string $target New URL.
	 */
	private function repoint( string $old, string $target ): void {
		global $wpdb;
		$table = Rules::table();
		$path  = Rules::normalize_path( $old );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, target FROM {$table} WHERE is_regex=0 AND target LIKE %s LIMIT 200", '%' . $wpdb->esc_like( $path ) . '%' ) );
		foreach ( $rows as $row ) {
			if ( Rules::normalize_path( (string) $row->target ) === $path ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->update( $table, array( 'target' => esc_url_raw( $target ) ), array( 'id' => (int) $row->id ), array( '%s' ), array( '%d' ) );
			}
		}
	}

	/**
	 * Pending suggestions.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function suggestions(): array {
		$list = get_option( self::SUGGESTIONS_OPTION, array() );
		return is_array( $list ) ? array_values( $list ) : array();
	}

	/**
	 * Accept or dismiss a suggestion.
	 *
	 * @param string $id     Suggestion id.
	 * @param bool   $accept Whether to create the redirect.
	 * @return int|\WP_Error|null Rule id, error, or null when dismissed/not found.
	 */
	public function resolve_suggestion( string $id, bool $accept ) {
		$list  = $this->suggestions();
		$found = null;
		foreach ( $list as $index => $item ) {
			if ( $item['id'] === $id ) {
				$found = $item;
				unset( $list[ $index ] );
			}
		}
		update_option( self::SUGGESTIONS_OPTION, array_values( $list ), false );
		if ( ! $found || ! $accept ) {
			return null;
		}
		return $this->c->get( Rules::class )->save(
			array(
				'source' => $found['source'],
				'target' => $found['target'],
				'type'   => 301,
			),
			0,
			(string) $found['origin']
		);
	}
}
