<?php
/**
 * AI assist endpoints.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Ai\Approvals;
use FutureLabs\AISEO\Ai\AiClient;
use FutureLabs\AISEO\Ai\Embeddings;
use FutureLabs\AISEO\Ai\Prompts;
use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Crypto;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * /ai/* routes. Suggestions are always stored as pending; approve applies them.
 */
class AiController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/ai/status', 'GET', array( $this, 'status' ), Capabilities::EDITOR );
		$this->route( '/ai/suggest', 'POST', array( $this, 'suggest' ), Capabilities::EDITOR );
		$this->route( '/ai/(?P<id>\d+)/approve', 'POST', array( $this, 'approve' ), Capabilities::EDITOR );
		$this->route( '/ai/suggestions', 'GET', array( $this, 'suggestions' ), Capabilities::EDITOR );
		$this->route( '/ai/alt-batch', 'POST', array( $this, 'alt_batch' ), Capabilities::DATA );
		$this->route( '/ai/alt-batch', 'GET', array( $this, 'alt_progress' ), Capabilities::DATA );
		$this->route( '/ai/test', 'POST', array( $this, 'test' ), Capabilities::DATA );
		$this->route( '/ai/models', 'GET', array( $this, 'models' ), Capabilities::DATA );
		$this->route( '/ai/embeddings', 'GET', array( $this, 'embeddings_status' ), Capabilities::DATA );
		$this->route( '/ai/embeddings/run', 'POST', array( $this, 'embeddings_run' ), Capabilities::DATA );
	}

	/**
	 * Configuration state for the UI (never the key).
	 */
	public function status(): \WP_REST_Response {
		$client   = $this->c->get( AiClient::class );
		$provider = $client->provider();
		$models   = array();
		foreach ( $provider->suggested_models() as $id => $label ) {
			$models[] = array(
				'id'    => $id,
				'label' => $label,
			);
		}
		$providers = array();
		foreach ( AiClient::labels() as $id => $label ) {
			$providers[] = array(
				'id'      => $id,
				'label'   => $label,
				'has_key' => $client->provider( $id )->has_key(),
			);
		}
		$fields = Prompts::FIELDS;
		if ( ! $provider->supports_images() ) {
			$fields = array_values( array_diff( $fields, array( 'alt' ) ) );
		}
		return rest_ensure_response(
			array(
				'enabled'    => $provider->enabled(),
				'provider'   => $provider->id(),
				'label'      => $provider->label(),
				'providers'  => $providers,
				'has_key'    => $provider->has_key(),
				'model'      => $provider->model(),
				'models'     => $models,
				'images'     => $provider->supports_images(),
				'fields'     => $fields,
				'rate_limit' => $this->c->get( Approvals::class )->rate_usage( get_current_user_id() ),
				'embeddings' => (bool) $this->c->get( Settings::class )->get( 'ai_embeddings' ),
				'notice'     => sprintf(
					/* translators: %s: AI service, e.g. "OpenAI". */
					__( 'When you request a suggestion, the page title and up to 12,000 characters of its text (or the image, for alt text) are sent to %s using your API key. Suggestions are saved as pending and nothing changes on your site until you approve it.', 'futurelabs-ai-seo' ),
					$provider->label()
				),
			)
		);
	}

	/**
	 * POST /ai/suggest { post_id | attachment_id, field }
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function suggest( \WP_REST_Request $request ) {
		$body          = $this->body( $request );
		$attachment_id = absint( $body['attachment_id'] ?? 0 );
		$object_id     = $attachment_id ? $attachment_id : absint( $body['post_id'] ?? 0 );
		$field         = sanitize_key( (string) ( $body['field'] ?? '' ) );
		if ( $attachment_id && '' === $field ) {
			$field = 'alt';
		}
		if ( ! $object_id || ! get_post( $object_id ) ) {
			return $this->error( 'not_found', __( 'Post or image not found.', 'futurelabs-ai-seo' ), 404 );
		}
		if ( ! current_user_can( 'edit_post', $object_id ) ) {
			return $this->error( 'forbidden', __( 'You cannot edit this content.', 'futurelabs-ai-seo' ), 403 );
		}
		$result = $this->c->get( Approvals::class )->suggest( $object_id, $field, get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			return $this->wrap( $result );
		}
		return rest_ensure_response( $result );
	}

	/**
	 * POST /ai/{id}/approve { decision: approve|reject }
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function approve( \WP_REST_Request $request ) {
		$approvals = $this->c->get( Approvals::class );
		$id        = absint( $request['id'] );
		$row       = $approvals->get( $id );
		if ( ! $row ) {
			return $this->error( 'not_found', __( 'Suggestion not found.', 'futurelabs-ai-seo' ), 404 );
		}
		if ( ! current_user_can( 'edit_post', (int) $row['post_id'] ) ) {
			return $this->error( 'forbidden', __( 'You cannot edit this content.', 'futurelabs-ai-seo' ), 403 );
		}
		$body   = $this->body( $request );
		$result = $approvals->decide( $id, sanitize_key( (string) ( $body['decision'] ?? 'approve' ) ) );
		if ( is_wp_error( $result ) ) {
			return $this->wrap( $result );
		}
		return rest_ensure_response( $result );
	}

	/**
	 * GET /ai/suggestions?post_id=&status=&page=&per_page=
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function suggestions( \WP_REST_Request $request ) {
		$post_id = absint( $request->get_param( 'post_id' ) );
		if ( $post_id && ! current_user_can( 'edit_post', $post_id ) ) {
			return $this->error( 'forbidden', __( 'You cannot edit this content.', 'futurelabs-ai-seo' ), 403 );
		}
		if ( ! $post_id && ! Capabilities::can( Capabilities::DATA ) ) {
			return $this->error( 'forbidden', __( 'Choose a post to see its suggestions.', 'futurelabs-ai-seo' ), 403 );
		}
		list( $page, $per_page ) = $this->paging( $request );
		return rest_ensure_response( $this->c->get( Approvals::class )->list( $post_id, sanitize_key( (string) $request->get_param( 'status' ) ), $page, $per_page ) );
	}

	/**
	 * POST /ai/alt-batch { attachment_ids: [] }
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function alt_batch( \WP_REST_Request $request ) {
		$client = $this->c->get( AiClient::class );
		if ( ! $client->enabled() ) {
			return $this->error( 'ai_disabled', __( 'AI assist is turned off. An administrator can enable it in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), 403 );
		}
		if ( ! $client->provider()->supports_images() ) {
			return $this->error( 'ai_no_images', __( 'The selected AI provider or model cannot read images, so alt text suggestions are not available.', 'futurelabs-ai-seo' ), 400 );
		}
		$body = $this->body( $request );
		$ids  = array_filter( array_map( 'absint', (array) ( $body['attachment_ids'] ?? array() ) ) );
		$ids  = array_values( array_filter( $ids, static fn( $id ) => current_user_can( 'edit_post', $id ) ) );
		if ( ! $ids ) {
			return $this->error( 'no_images', __( 'Choose at least one image.', 'futurelabs-ai-seo' ), 400 );
		}
		$approvals = $this->c->get( Approvals::class );
		$result    = $approvals->queue_alt_batch( array_slice( $ids, 0, 500 ), get_current_user_id() );
		return rest_ensure_response( $result + array( 'progress' => $approvals->alt_progress() ) );
	}

	/**
	 * GET /ai/alt-batch
	 */
	public function alt_progress(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( Approvals::class )->alt_progress() );
	}

	/**
	 * POST /ai/test: validate the key with a tiny request.
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function test() {
		$provider = $this->c->get( AiClient::class )->provider();
		$result   = $provider->send( 'Reply with the single word OK.', 'Connection test.', array(), true );
		if ( is_wp_error( $result ) ) {
			return $this->wrap( $result );
		}
		return rest_ensure_response(
			array(
				'ok'       => true,
				'provider' => $provider->id(),
				'model'    => $provider->model(),
			)
		);
	}

	/**
	 * GET /ai/models?provider=: models the saved key can use (also checks the key without spending tokens).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function models( \WP_REST_Request $request ) {
		$provider = $this->c->get( AiClient::class )->provider( (string) $request->get_param( 'provider' ) );
		if ( ! $provider->enabled() ) {
			return $this->error( 'ai_disabled', __( 'AI assist is turned off. An administrator can enable it in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), 403 );
		}
		$models = $provider->list_models();
		if ( is_wp_error( $models ) ) {
			return $this->wrap( $models );
		}
		return rest_ensure_response(
			array(
				'provider' => $provider->id(),
				'models'   => array_slice( $models, 0, 500 ),
			)
		);
	}

	/**
	 * GET /ai/embeddings
	 */
	public function embeddings_status(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( Embeddings::class )->status() );
	}

	/**
	 * POST /ai/embeddings/run
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function embeddings_run() {
		$embeddings = $this->c->get( Embeddings::class );
		if ( ! $embeddings->available() ) {
			$message = $this->c->get( Crypto::class )->has_secret( Embeddings::KEY_OPTION )
				? __( 'Turn on AI assist and embeddings in FutureLabs AI SEO settings first.', 'futurelabs-ai-seo' )
				: __( 'Add a Voyage AI API key and turn on embeddings in FutureLabs AI SEO settings first.', 'futurelabs-ai-seo' );
			return $this->error( 'embeddings_unavailable', $message, 400 );
		}
		$embeddings->start();
		return rest_ensure_response( array( 'queued' => true ) + $embeddings->status() );
	}

	/**
	 * Normalize a service error into a REST error with a status.
	 *
	 * @param \WP_Error $error Error.
	 */
	private function wrap( \WP_Error $error ): \WP_Error {
		$data = (array) $error->get_error_data();
		$out  = array(
			'status' => (int) ( $data['status'] ?? 400 ),
		);
		foreach ( array( 'retry_after', 'category' ) as $key ) {
			if ( isset( $data[ $key ] ) && '' !== $data[ $key ] ) {
				$out[ $key ] = $data[ $key ];
			}
		}
		$code = (string) $error->get_error_code();
		return new \WP_Error( str_starts_with( $code, 'flseo_' ) ? $code : 'flseo_' . $code, $error->get_error_message(), $out );
	}
}
