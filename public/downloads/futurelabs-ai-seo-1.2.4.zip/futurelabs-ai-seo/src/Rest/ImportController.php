<?php
/**
 * GET /import/sources · POST /import/{source} · GET /export · POST /import/settings.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Importers\Aioseo;
use FutureLabs\AISEO\Importers\Exporter;
use FutureLabs\AISEO\Importers\Importer;
use FutureLabs\AISEO\Importers\RankMath;
use FutureLabs\AISEO\Importers\Yoast;

defined( 'ABSPATH' ) || exit;

/**
 * Importers from other SEO plugins and JSON settings transfer (administrators).
 */
class ImportController extends Controller {

	/**
	 * Importer classes by slug.
	 *
	 * @var array<string, class-string<Importer>>
	 */
	public const SOURCES = array(
		'yoast'    => Yoast::class,
		'aioseo'   => Aioseo::class,
		'rankmath' => RankMath::class,
	);

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/import/sources', 'GET', array( $this, 'sources' ), Capabilities::DATA );
		$this->route( '/import/(?P<source>yoast|aioseo|rankmath)', 'POST', array( $this, 'import' ), Capabilities::DATA );
		$this->route( '/export', 'GET', array( $this, 'export' ), Capabilities::SETTINGS );
		$this->route( '/import/settings', 'POST', array( $this, 'import_settings' ), Capabilities::SETTINGS );
	}

	/**
	 * Detected sources with counts.
	 */
	public function sources(): \WP_REST_Response {
		$items = array();
		foreach ( self::SOURCES as $slug => $class ) {
			$importer = $this->c->get( $class );
			$counts   = $importer->count();
			$items[]  = array(
				'source'   => $slug,
				'label'    => $importer->label(),
				'detected' => array_sum( $counts ) > 0,
				'counts'   => $counts,
			);
		}
		return rest_ensure_response(
			array(
				'items' => $items,
				'total' => count( $items ),
			)
		);
	}

	/**
	 * Run one page of an import (dry run unless dry_run is false).
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function import( \WP_REST_Request $request ): \WP_REST_Response {
		$body     = $this->body( $request );
		$importer = $this->c->get( self::SOURCES[ (string) $request['source'] ] );
		$include  = $body['include'] ?? Importer::KINDS;
		$include  = is_string( $include ) ? explode( ',', $include ) : (array) $include;
		$result   = $importer->run(
			array(
				'dry_run'      => $body['dry_run'] ?? true,
				'offset'       => absint( $body['offset'] ?? 0 ),
				'limit'        => absint( $body['limit'] ?? 100 ),
				'include'      => array_map( 'sanitize_key', $include ),
				'batch_id'     => sanitize_text_field( (string) ( $body['batch_id'] ?? '' ) ),
				'confirmation' => sanitize_text_field( (string) ( $body['confirmation'] ?? '' ) ),
			)
		);
		return new \WP_REST_Response( $result, empty( $result['confirmation_required'] ) ? 200 : 409 );
	}

	/**
	 * Settings export document.
	 */
	public function export(): \WP_REST_Response {
		$doc      = $this->c->get( Exporter::class )->export();
		$response = rest_ensure_response( $doc );
		$response->header( 'Content-Disposition', 'attachment; filename="flseo-settings-' . gmdate( 'Y-m-d' ) . '.json"' );
		return $response;
	}

	/**
	 * Import settings JSON.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function import_settings( \WP_REST_Request $request ) {
		$body = $this->body( $request );
		$json = $body['json'] ?? '';
		$dry  = ! isset( $body['dry_run'] ) || ( ! empty( $body['dry_run'] ) && 'false' !== $body['dry_run'] );
		if ( ! is_string( $json ) && ! is_array( $json ) ) {
			return $this->error( 'import_json', __( 'Send the exported JSON in the json field.', 'futurelabs-ai-seo' ) );
		}
		$result = $this->c->get( Exporter::class )->import( $json, $dry );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}
}
