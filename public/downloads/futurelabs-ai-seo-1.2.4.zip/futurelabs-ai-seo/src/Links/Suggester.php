<?php
/**
 * Internal link suggestions (TF-IDF keyword overlap) and related-post suggestions.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Links;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;

defined( 'ABSPATH' ) || exit;

/**
 * Default similarity provider ("tfidf") plus suggestion helpers for the editor and admin.
 *
 * Candidate posts are those sharing the source's strongest keywords; they are then
 * ranked by TF-IDF cosine similarity computed over the candidate pool.
 */
class Suggester implements SimilarityProvider {

	public const KEYWORDS   = 12;
	public const CANDIDATES = 200;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Machine name.
	 */
	public function name(): string {
		return 'tfidf';
	}

	/**
	 * Active provider. The `flseo_similarity_provider` filter may return a
	 * SimilarityProvider instance or a provider name registered through the
	 * `flseo_similarity_providers` filter (name => instance).
	 */
	public function provider(): SimilarityProvider {
		$chosen = apply_filters( 'flseo_similarity_provider', $this );
		if ( is_string( $chosen ) ) {
			$registry = (array) apply_filters( 'flseo_similarity_providers', array( 'tfidf' => $this ) );
			$chosen   = $registry[ $chosen ] ?? $this;
		}
		return $chosen instanceof SimilarityProvider ? $chosen : $this;
	}

	/**
	 * Plain text of a post for keyword extraction (title weighted three times).
	 *
	 * @param \WP_Post $post Post.
	 * @return array<int, string> Tokens.
	 */
	private static function post_tokens( \WP_Post $post ): array {
		$content = (string) $post->post_content;
		if ( '' === trim( $content ) ) {
			$data = (string) get_post_meta( $post->ID, '_elementor_data', true );
			if ( '' !== $data ) {
				$content = \FutureLabs\AISEO\Content\Analyzer::elementor_data_html( $data );
			}
		}
		$content = substr( wp_strip_all_tags( strip_shortcodes( $content ) ), 0, 40000 );
		$title   = Crawler::tokens( (string) $post->post_title );
		return array_merge( $title, $title, $title, Crawler::tokens( $content ) );
	}

	/**
	 * Strongest keywords of a token list.
	 *
	 * @param array<int, string> $tokens Tokens.
	 * @param int                $limit  Count.
	 * @return array<int, string>
	 */
	private static function keywords( array $tokens, int $limit ): array {
		$tf = array_count_values( $tokens );
		uksort(
			$tf,
			static function ( $a, $b ) use ( $tf ) {
				$by_count = $tf[ $b ] <=> $tf[ $a ];
				return 0 !== $by_count ? $by_count : strlen( (string) $b ) <=> strlen( (string) $a );
			}
		);
		return array_map( 'strval', array_slice( array_keys( $tf ), 0, $limit ) );
	}

	/**
	 * Most similar indexable posts.
	 *
	 * @param int             $post_id Source post.
	 * @param int             $limit   Max results.
	 * @param array<int, int> $exclude Post IDs to skip.
	 * @return array<int, float> Post ID => score in [0,1], best first.
	 */
	public function similar( int $post_id, int $limit = 10, array $exclude = array() ): array {
		global $wpdb;
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return array();
		}
		$source   = self::post_tokens( $post );
		$keywords = self::keywords( $source, self::KEYWORDS );
		$types    = $this->c->get( Orphans::class )->indexable_types();
		if ( ! $keywords || ! $types ) {
			return array();
		}
		$exclude   = array_map( 'absint', array_merge( $exclude, array( $post_id ) ) );
		$not_in    = implode( ',', $exclude );
		$in        = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$score     = array();
		$match     = array();
		$like_args = array();
		$where     = array();
		foreach ( $keywords as $keyword ) {
			$like      = '%' . $wpdb->esc_like( $keyword ) . '%';
			$score[]   = '(p.post_title LIKE %s) * 2 + (p.post_content LIKE %s)';
			$where[]   = 'p.post_title LIKE %s OR p.post_content LIKE %s';
			$like_args = array_merge( $like_args, array( $like, $like ) );
			$match     = array_merge( $match, array( $like, $like ) );
		}
		$sql  = 'SELECT p.ID, p.post_title, p.post_content, (' . implode( ' + ', $score ) . ") AS kw FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} ni ON ni.post_id = p.ID AND ni.meta_key = '_flseo_noindex' AND ni.meta_value = '1' WHERE p.post_status = 'publish' AND p.post_password = '' AND p.post_type IN ({$in}) AND p.ID NOT IN ({$not_in}) AND ni.meta_id IS NULL AND (" . implode( ' OR ', $where ) . ') ORDER BY kw DESC, p.post_date DESC LIMIT %d';
		$args = array_merge( $like_args, $types, $match, array( self::CANDIDATES ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders,WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
		if ( ! $rows ) {
			return array();
		}
		$docs = array();
		$df   = array();
		foreach ( $rows as $row ) {
			$title                  = Crawler::tokens( (string) $row->post_title );
			$text                   = substr( wp_strip_all_tags( strip_shortcodes( (string) $row->post_content ) ), 0, 40000 );
			$tf                     = array_count_values( array_merge( $title, $title, $title, Crawler::tokens( $text ) ) );
			$docs[ (int) $row->ID ] = $tf;
			foreach ( array_keys( $tf ) as $term ) {
				$df[ $term ] = ( $df[ $term ] ?? 0 ) + 1;
			}
		}
		unset( $rows );
		$source_tf = array_count_values( $source );
		foreach ( array_keys( $source_tf ) as $term ) {
			$df[ $term ] = ( $df[ $term ] ?? 0 ) + 1;
		}
		$n      = count( $docs ) + 1;
		$weight = static function ( array $tf ) use ( $df, $n ): array {
			$out  = array();
			$norm = 0.0;
			foreach ( $tf as $term => $count ) {
				$w            = ( 1 + log( (float) $count ) ) * ( log( ( 1 + $n ) / ( 1 + ( $df[ $term ] ?? 0 ) ) ) + 1 );
				$out[ $term ] = $w;
				$norm        += $w * $w;
			}
			$norm = sqrt( $norm );
			if ( $norm > 0 ) {
				foreach ( $out as $term => $w ) {
					$out[ $term ] = $w / $norm;
				}
			}
			return $out;
		};
		$query  = $weight( $source_tf );
		$scores = array();
		foreach ( $docs as $id => $tf ) {
			$vector = $weight( $tf );
			$dot    = 0.0;
			foreach ( $query as $term => $w ) {
				if ( isset( $vector[ $term ] ) ) {
					$dot += $w * $vector[ $term ];
				}
			}
			if ( $dot > 0.02 ) {
				$scores[ $id ] = round( min( 1.0, $dot ), 4 );
			}
		}
		arsort( $scores );
		return array_slice( $scores, 0, max( 1, $limit ), true );
	}

	/**
	 * Block markup for a single link paragraph.
	 *
	 * @param string $url    URL.
	 * @param string $anchor Anchor.
	 */
	public static function link_markup( string $url, string $anchor ): string {
		return "<!-- wp:paragraph -->\n<p><a href=\"" . esc_url( $url ) . '">' . esc_html( $anchor ) . "</a></p>\n<!-- /wp:paragraph -->";
	}

	/**
	 * Suggested anchor text for linking to a post: its focus topic, else its title.
	 *
	 * @param int $post_id Target.
	 */
	public static function anchor_for( int $post_id ): string {
		$topic = trim( (string) get_post_meta( $post_id, '_flseo_focus_topic', true ) );
		return '' !== $topic ? $topic : html_entity_decode( get_the_title( $post_id ), ENT_QUOTES );
	}

	/**
	 * Shape a suggestion.
	 *
	 * @param int   $id    Post ID.
	 * @param float $score Score.
	 * @return array<string, mixed>
	 */
	private static function item( int $id, float $score ): array {
		$url    = (string) get_permalink( $id );
		$anchor = self::anchor_for( $id );
		return array(
			'id'     => $id,
			'title'  => html_entity_decode( get_the_title( $id ), ENT_QUOTES ),
			'url'    => $url,
			'score'  => $score,
			'anchor' => $anchor,
			'markup' => self::link_markup( $url, $anchor ),
		);
	}

	/**
	 * Posts this post could link to (excluding ones it already links to).
	 *
	 * @param int $post_id Source post.
	 * @param int $limit   Max.
	 * @return array<int, array<string, mixed>>
	 */
	public function suggest( int $post_id, int $limit = 10 ): array {
		$exclude = $this->c->get( Graph::class )->outbound_targets( $post_id );
		$items   = array();
		foreach ( $this->provider()->similar( $post_id, $limit, $exclude ) as $id => $score ) {
			if ( 'publish' === get_post_status( (int) $id ) ) {
				$items[] = self::item( (int) $id, (float) $score );
			}
		}
		return $items;
	}

	/**
	 * Pages that should link to a post (useful for orphans): similar posts that do not
	 * link to it yet, favouring well-linked, shallow pages.
	 *
	 * @param int $post_id Target post.
	 * @param int $limit   Max.
	 * @return array<int, array<string, mixed>>
	 */
	public function inbound_suggestions( int $post_id, int $limit = 10 ): array {
		global $wpdb;
		$graph   = $this->c->get( Graph::class );
		$exclude = $graph->inbound_sources( $post_id );
		$similar = $this->provider()->similar( $post_id, $limit * 3, $exclude );
		if ( ! $similar ) {
			return array();
		}
		$stats_table = Migrations::table( 'link_stats' );
		$ids         = implode( ',', array_map( 'absint', array_keys( $similar ) ) );
		$stats       = array();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		foreach ( (array) $wpdb->get_results( "SELECT post_id, inbound, click_depth FROM {$stats_table} WHERE post_id IN ({$ids})" ) as $row ) {
			$stats[ (int) $row->post_id ] = $row;
		}
		$target_url = (string) get_permalink( $post_id );
		$anchor     = self::anchor_for( $post_id );
		$ranked     = array();
		foreach ( $similar as $id => $score ) {
			$depth         = isset( $stats[ $id ] ) ? (int) $stats[ $id ]->click_depth : Graph::MAX_DEPTH;
			$inbound       = isset( $stats[ $id ] ) ? (int) $stats[ $id ]->inbound : 0;
			$boost         = ( $depth <= 3 ? 0.1 : 0 ) + min( 0.1, $inbound * 0.01 );
			$ranked[ $id ] = round( min( 1.0, $score * ( 1 + $boost ) ), 4 );
		}
		arsort( $ranked );
		$items = array();
		foreach ( array_slice( $ranked, 0, $limit, true ) as $id => $score ) {
			$items[] = array(
				'id'          => (int) $id,
				'title'       => html_entity_decode( get_the_title( (int) $id ), ENT_QUOTES ),
				'url'         => (string) get_permalink( (int) $id ),
				'edit_url'    => (string) get_edit_post_link( (int) $id, 'raw' ),
				'score'       => (float) $score,
				'click_depth' => isset( $stats[ $id ] ) && (int) $stats[ $id ]->click_depth < Graph::MAX_DEPTH ? (int) $stats[ $id ]->click_depth : null,
				'anchor'      => $anchor,
				'target_url'  => $target_url,
				'markup'      => self::link_markup( $target_url, $anchor ),
			);
		}
		return $items;
	}

	/**
	 * Recent indexable posts in the same category (OL-8).
	 *
	 * @param int $post_id Post.
	 * @param int $limit   Max.
	 * @return array<int, array<string, mixed>>
	 */
	public function related_by_category( int $post_id, int $limit = 5 ): array {
		$cats    = \FutureLabs\AISEO\Content\Template::category_ids( $post_id );
		$default = (int) get_option( 'default_category' );
		$cats    = array_values( array_filter( $cats, static fn( $id ) => $id !== $default ) );
		if ( ! $cats ) {
			return array();
		}
		$exclude = array_merge( array( $post_id ), $this->c->get( Graph::class )->outbound_targets( $post_id ) );
		$ids     = get_posts(
			array(
				'post_type'        => $this->c->get( Orphans::class )->indexable_types(),
				'post_status'      => 'publish',
				'category__in'     => array( $cats[0] ),
				'post__not_in'     => $exclude,
				'posts_per_page'   => $limit,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'meta_query'       => array(
					'relation' => 'OR',
					array(
						'key'     => '_flseo_noindex',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => '_flseo_noindex',
						'value'   => '1',
						'compare' => '!=',
					),
				),
			)
		);
		$items = array();
		foreach ( $ids as $id ) {
			$items[] = self::item( (int) $id, 0.0 ) + array( 'category_id' => $cats[0] );
		}
		return $items;
	}

	/**
	 * Other editions of the same programme (OL-3/OL-8), newest first.
	 *
	 * @param int $post_id Post.
	 * @param int $limit   Max.
	 * @return array<int, array<string, mixed>>
	 */
	public function related_by_programme( int $post_id, int $limit = 5 ): array {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$key = (string) $wpdb->get_var( $wpdb->prepare( "SELECT edition_key FROM {$table} WHERE post_id = %d", $post_id ) );
		if ( '' === $key ) {
			return array();
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT s.post_id, s.edition_year FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.edition_key = %s AND s.post_id <> %d ORDER BY s.edition_year DESC, p.post_date DESC LIMIT %d", $key, $post_id, $limit ) );
		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = self::item( (int) $row->post_id, 0.0 ) + array( 'year' => (int) $row->edition_year );
		}
		return $items;
	}

	/**
	 * Where to place a "Related opportunities" block and the block markup to insert.
	 *
	 * @param int $post_id Post.
	 * @return array{recommended: bool, position: string, after_heading: string, reason: string, items: array<int, array<string, mixed>>, markup: string}
	 */
	public function placement( int $post_id ): array {
		$post    = get_post( $post_id );
		$content = $post instanceof \WP_Post ? (string) $post->post_content : '';
		$parsed  = Crawler::parse_html( $content );
		foreach ( $parsed['headings'] as $heading ) {
			if ( preg_match( '/\brelated\b|\byou may also like\b|\bsee also\b/i', $heading['text'] ) ) {
				return array(
					'recommended'   => false,
					'position'      => '',
					'after_heading' => '',
					'reason'        => __( 'This post already has a related-posts section.', 'futurelabs-ai-seo' ),
					'items'         => array(),
					'markup'        => '',
				);
			}
		}
		$items = array();
		$seen  = array();
		foreach ( array_merge( $this->related_by_programme( $post_id, 3 ), $this->related_by_category( $post_id, 5 ), $this->suggest( $post_id, 5 ) ) as $item ) {
			if ( count( $items ) >= 5 || isset( $seen[ $item['id'] ] ) ) {
				continue;
			}
			$seen[ $item['id'] ] = true;
			$items[]             = $item;
		}
		if ( ! $items ) {
			return array(
				'recommended'   => false,
				'position'      => '',
				'after_heading' => '',
				'reason'        => __( 'No related indexable posts were found yet.', 'futurelabs-ai-seo' ),
				'items'         => array(),
				'markup'        => '',
			);
		}
		$after = '';
		foreach ( $parsed['headings'] as $heading ) {
			if ( preg_match( '/how to apply|application process|official link/i', $heading['text'] ) ) {
				$after = $heading['text'];
			}
		}
		$list = '';
		foreach ( $items as $item ) {
			$list .= "<!-- wp:list-item -->\n<li><a href=\"" . esc_url( $item['url'] ) . '">' . esc_html( $item['title'] ) . "</a></li>\n<!-- /wp:list-item -->\n";
		}
		$markup = "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html__( 'Related opportunities', 'futurelabs-ai-seo' ) . "</h2>\n<!-- /wp:heading -->\n\n<!-- wp:list {\"className\":\"flseo-related-opportunities\"} -->\n<ul class=\"flseo-related-opportunities\">" . $list . "</ul>\n<!-- /wp:list -->";
		return array(
			'recommended'   => true,
			'position'      => '' !== $after ? 'after_section' : 'end',
			'after_heading' => $after,
			'reason'        => '' !== $after
				? __( 'Place it after the application section, where readers decide what to read next.', 'futurelabs-ai-seo' )
				: __( 'Place it at the end of the post, before comments.', 'futurelabs-ai-seo' ),
			'items'         => $items,
			'markup'        => $markup,
		);
	}
}
