<?php
/**
 * Schedules the recurring daily job other modules hook into.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Ensures `flseo_daily` runs once a day.
 *
 * Modules attach work to `flseo_daily` (expiry, 404 purge, sitemap validation,
 * audit purge, history snapshot) instead of scheduling their own recurring jobs.
 */
final class Cron implements Module {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'ensure' ), 30 );
	}

	/**
	 * Schedule the daily job if missing (cheap check, cached per day).
	 */
	public function ensure(): void {
		if ( get_transient( 'flseo_cron_checked' ) ) {
			return;
		}
		$this->c->get( Queue::class )->recurring( DAY_IN_SECONDS, 'flseo_daily' );
		set_transient( 'flseo_cron_checked', 1, HOUR_IN_SECONDS );
	}
}
