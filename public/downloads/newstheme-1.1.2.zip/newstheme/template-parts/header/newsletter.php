<?php
/**
 * Header element: newsletter button (opens the popup, or links to a URL).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_url   = newstheme_get_mod( 'newsletter_url' );
$newstheme_label = newstheme_get_mod( 'newsletter_label' );
?>
<?php if ( $newstheme_url ) : ?>
	<a class="nt-header-btn" href="<?php echo esc_url( $newstheme_url ); ?>"><?php newstheme_icon( 'newspaper' ); ?><span><?php echo esc_html( $newstheme_label ); ?></span></a>
<?php else : ?>
	<button type="button" class="nt-header-btn" data-nt-open="nt-newsletter" aria-haspopup="dialog"><?php newstheme_icon( 'newspaper' ); ?><span><?php echo esc_html( $newstheme_label ); ?></span></button>
	<?php newstheme_dialogs( 'newsletter' ); ?>
<?php endif; ?>
