<?php
/**
 * Footer options. See inc/customizer/config.php for the setting format.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

return array(
	'panels'   => array(
		'newstheme_footer' => array(
			'title'    => __( 'Footer', 'newstheme' ),
			'priority' => 24,
		),
	),

	'partials' => array(
		'footer' => array(
			'selector' => '#nt-colophon',
			'render'   => 'newstheme_render_colophon',
		),
	),
	'sections' => array(
		'newstheme_footer_builder' => array(
			'title'    => __( 'Footer Builder', 'newstheme' ),
			'panel'    => 'newstheme_footer',
			'priority' => 1,
		),
		'newstheme_footer_widgets' => array(
			'title' => __( 'Colors', 'newstheme' ),
			'panel' => 'newstheme_footer',
		),
		'newstheme_footer_bottom'  => array(
			'title' => __( 'Bottom Bar', 'newstheme' ),
			'panel' => 'newstheme_footer',
		),
		'newstheme_scroll_top'     => array(
			'title' => __( 'Scroll To Top', 'newstheme' ),
			'panel' => 'newstheme_footer',
		),
	),

	'settings' => array(
		'footer_layout'    => array(
			'section'     => 'newstheme_footer_builder',
			'control'     => 'builder',
			'builder'     => 'footer',
			'label'       => __( 'Footer Layout', 'newstheme' ),
			'description' => __( 'Choose columns per row and drag elements into them. Widget areas are filled in Appearance → Widgets.', 'newstheme' ),
			'default'     => newstheme_builder_default( 'footer' ),
			'partial'     => 'footer',
		),
		'footer_bg'        => array(
			'section'  => 'newstheme_footer_widgets',
			'control'  => 'color',
			'label'    => __( 'Background', 'newstheme' ),
			'default'  => '#000000',
			'gradient' => true,
			'css'      => array( 'var' => '--nt-footer-bg' ),
		),
		'footer_text'      => array(
			'section' => 'newstheme_footer_widgets',
			'control' => 'color',
			'label'   => __( 'Text & Titles', 'newstheme' ),
			'default' => '#ffffff',
			'css'     => array( 'var' => '--nt-footer-text' ),
		),
		'footer_border'    => array(
			'section'     => 'newstheme_footer_widgets',
			'control'     => 'color',
			'label'       => __( 'Top Border', 'newstheme' ),
			'description' => __( 'Empty uses the accent color.', 'newstheme' ),
			'default'     => '',
			'css'         => array( 'var' => '--nt-footer-border' ),
		),

		'copyright'        => array(
			'section'     => 'newstheme_footer_bottom',
			'control'     => 'text',
			'label'       => __( 'Copyright Text', 'newstheme' ),
			'description' => __( 'Use {year} for the current year and {site} for the site name. Links are allowed.', 'newstheme' ),
			'default'     => __( '© {year} {site}. All rights reserved.', 'newstheme' ),
			'partial'     => 'footer',
		),
		'footer_copyright' => array(
			'section' => 'newstheme_footer_bottom',
			'control' => 'color',
			'label'   => __( 'Copyright & Menu Color', 'newstheme' ),
			'default' => '#8a8a8a',
			'css'     => array( 'var' => '--nt-footer-copyright' ),
		),

		'stt_show'         => array(
			'section' => 'newstheme_scroll_top',
			'control' => 'toggle',
			'label'   => __( 'Show scroll-to-top button', 'newstheme' ),
			'default' => true,
		),
		'stt_hide_mobile'  => array(
			'section'    => 'newstheme_scroll_top',
			'control'    => 'toggle',
			'label'      => __( 'Hide on mobile', 'newstheme' ),
			'default'    => true,
			'body_class' => 'nt-stt-hide-mobile',
		),
	),
);
