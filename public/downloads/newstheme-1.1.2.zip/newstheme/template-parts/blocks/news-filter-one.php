<?php
/**
 * Block: news filter — tabs ("All" + categories); other tabs load on demand.
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args (see newstheme_block_types()).
 */

defined( 'ABSPATH' ) || exit;

$newstheme_tabs = array_filter( array_map( 'get_category', $args['tabs'] ) );
$newstheme_id   = $args['id'];

// Only the query/display args are needed to render other tabs via REST.
$newstheme_rest_args = array_intersect_key( $args, array_flip( array( 'layout', 'query', 'meta', 'excerpt' ) ) );

ob_start();
if ( $newstheme_tabs ) :
	?>
	<div class="nt-tabs" role="tablist" aria-labelledby="<?php echo esc_attr( $newstheme_id ); ?>-title">
		<button type="button" role="tab" id="<?php echo esc_attr( $newstheme_id ); ?>-tab-all" aria-selected="true" aria-controls="<?php echo esc_attr( $newstheme_id ); ?>-panel-all" class="nt-tabs__tab"><?php esc_html_e( 'All', 'newstheme' ); ?></button>
		<?php foreach ( $newstheme_tabs as $newstheme_term ) : ?>
			<button type="button" role="tab" id="<?php echo esc_attr( $newstheme_id . '-tab-' . $newstheme_term->term_id ); ?>" aria-selected="false" aria-controls="<?php echo esc_attr( $newstheme_id . '-panel-' . $newstheme_term->term_id ); ?>" tabindex="-1" class="nt-tabs__tab" data-term="<?php echo (int) $newstheme_term->term_id; ?>"><?php echo esc_html( $newstheme_term->name ); ?></button>
		<?php endforeach; ?>
	</div>
	<?php
endif;
$newstheme_tablist = ob_get_clean();
?>
<section class="nt-block nt-block--filter nt-block--filter-<?php echo esc_attr( $args['layout'] ); ?>" data-nt-tabs data-args="<?php echo esc_attr( wp_json_encode( $newstheme_rest_args ) ); ?>" <?php echo $args['title'] ? 'aria-labelledby="' . esc_attr( $newstheme_id ) . '-title"' : ''; ?>>
	<?php newstheme_block_heading( $args['title'], $newstheme_id, $newstheme_tablist ); ?>
	<div class="nt-tabs__panel" role="<?php echo $newstheme_tabs ? 'tabpanel' : 'presentation'; ?>" id="<?php echo esc_attr( $newstheme_id ); ?>-panel-all" <?php echo $newstheme_tabs ? 'aria-labelledby="' . esc_attr( $newstheme_id ) . '-tab-all"' : ''; ?>>
		<?php get_template_part( 'template-parts/blocks/news-filter', $args['layout'] . '-panel', $args ); ?>
	</div>
	<?php foreach ( $newstheme_tabs as $newstheme_term ) : ?>
		<div class="nt-tabs__panel" role="tabpanel" id="<?php echo esc_attr( $newstheme_id . '-panel-' . $newstheme_term->term_id ); ?>" aria-labelledby="<?php echo esc_attr( $newstheme_id . '-tab-' . $newstheme_term->term_id ); ?>" hidden></div>
	<?php endforeach; ?>
</section>
