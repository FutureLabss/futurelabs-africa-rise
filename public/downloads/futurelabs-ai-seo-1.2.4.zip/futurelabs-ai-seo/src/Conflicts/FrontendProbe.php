<?php
/**
 * Fetches rendered pages and counts SEO tags to find duplicate output.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Conflicts;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Probes the home page and one sample post. Requests are limited to this site's host.
 */
class FrontendProbe {

	public const OPTION = 'flseo_conflict_probe';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Tag patterns counted inside <head>.
	 *
	 * @return array<string, string>
	 */
	public static function patterns(): array {
		return array(
			'title'        => '~<title[\s>]~i',
			'description'  => '~<meta\b[^>]*\bname\s*=\s*["\']description["\']~i',
			'robots'       => '~<meta\b[^>]*\bname\s*=\s*["\'](?:robots|googlebot)["\']~i',
			'canonical'    => '~<link\b[^>]*\brel\s*=\s*["\']canonical["\']~i',
			'og_title'     => '~<meta\b[^>]*\bproperty\s*=\s*["\']og:title["\']~i',
			'og_url'       => '~<meta\b[^>]*\bproperty\s*=\s*["\']og:url["\']~i',
			'twitter_card' => '~<meta\b[^>]*\bname\s*=\s*["\']twitter:card["\']~i',
			'json_ld'      => '~<script\b[^>]*type\s*=\s*["\']application/ld\+json["\']~i',
		);
	}

	/**
	 * Markers that identify which component printed tags.
	 *
	 * @return array<string, string>
	 */
	public static function markers(): array {
		return array(
			'FutureLabs AI SEO'          => '<!-- FutureLabs AI SEO -->',
			'Yoast SEO'          => 'optimized with the Yoast',
			'Rank Math'          => 'Rank Math',
			'All in One SEO'     => 'All in One SEO',
			'SEOPress'           => 'SEOPress',
			'The SEO Framework'  => 'The SEO Framework',
			'Shareaholic'        => 'shareaholic',
			'Site Kit by Google' => 'Site Kit by Google',
			'Jetpack'            => 'Jetpack Open Graph',
			'Elementor'          => 'elementor',
		);
	}

	/**
	 * URLs to probe.
	 *
	 * @return array<int, string>
	 */
	public function urls(): array {
		$urls   = array( home_url( '/' ) );
		$sample = get_posts(
			array(
				'post_type'    => 'post',
				'post_status'  => 'publish',
				'numberposts'  => 1,
				'has_password' => false,
				'fields'       => 'ids',
			)
		);
		if ( $sample ) {
			$urls[] = (string) get_permalink( (int) $sample[0] );
		}
		return $urls;
	}

	/**
	 * Probe pages and store the result.
	 *
	 * @return array<string, mixed>
	 */
	public function run(): array {
		$pages = array();
		foreach ( $this->urls() as $url ) {
			$pages[] = $this->probe( $url );
		}
		$duplicates = array();
		foreach ( $pages as $page ) {
			foreach ( $page['duplicates'] ?? array() as $tag ) {
				$duplicates[ $tag ] = true;
			}
		}
		$result = array(
			'checked_at' => gmdate( 'c' ),
			'pages'      => $pages,
			'duplicates' => array_keys( $duplicates ),
		);
		update_option( self::OPTION, $result, false );
		return $result;
	}

	/**
	 * Probe one URL.
	 *
	 * @param string $url URL on this site.
	 * @return array<string, mixed>
	 */
	public function probe( string $url ): array {
		if ( ! self::is_own_url( $url ) ) {
			return array(
				'url'   => $url,
				'error' => __( 'Only URLs on this site can be probed.', 'futurelabs-ai-seo' ),
			);
		}
		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 15,
				'redirection'         => 2,
				'limit_response_size' => 2 * MB_IN_BYTES,
				'headers'             => array( 'Cache-Control' => 'no-cache' ),
				'user-agent'          => 'FutureLabs AI SEO-Probe/' . FLSEO_VERSION . '; ' . home_url( '/' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			$this->c->get( Logger::class )->warning(
				'Frontend probe failed',
				array(
					'url'   => $url,
					'error' => $response->get_error_message(),
				)
			);
			return array(
				'url'   => $url,
				'error' => __( 'Could not fetch the page from the server. Loopback requests may be blocked by the host.', 'futurelabs-ai-seo' ),
			);
		}
		return array_merge(
			array(
				'url'         => $url,
				'http_status' => (int) wp_remote_retrieve_response_code( $response ),
			),
			self::analyze( (string) wp_remote_retrieve_body( $response ) )
		);
	}

	/**
	 * Count tags in the head of an HTML document.
	 *
	 * @param string $html HTML.
	 * @return array{tag_counts: array<string, int>, duplicates: array<int, string>, sources: array<int, string>, schema_graphs: int}
	 */
	public static function analyze( string $html ): array {
		$end  = stripos( $html, '</head>' );
		$head = false === $end ? $html : substr( $html, 0, $end );
		// Ignore tags inside <noscript>, <svg> and HTML comments.
		$head   = (string) preg_replace( array( '~<!--(?!\s*/?FutureLabs AI SEO).*?-->~s', '~<noscript\b.*?</noscript>~is', '~<svg\b.*?</svg>~is' ), '', $head );
		$counts = array();
		foreach ( self::patterns() as $name => $pattern ) {
			$counts[ $name ] = (int) preg_match_all( $pattern, $head );
		}
		$duplicates = array_keys( array_filter( $counts, static fn( $n, $name ) => 'json_ld' !== $name && $n > 1, ARRAY_FILTER_USE_BOTH ) );
		$sources    = array();
		foreach ( self::markers() as $name => $marker ) {
			if ( false !== stripos( $html, $marker ) ) {
				$sources[] = $name;
			}
		}
		// Count JSON-LD blocks that declare a WebPage/Article graph: more than one means duplicate schema.
		$graphs = 0;
		if ( preg_match_all( '~<script\b[^>]*application/ld\+json[^>]*>(.*?)</script>~is', $html, $m ) ) {
			foreach ( $m[1] as $json ) {
				if ( preg_match( '~"@type"\s*:\s*"(WebPage|Article|BlogPosting|NewsArticle|WebSite)"~', $json ) ) {
					++$graphs;
				}
			}
		}
		if ( $graphs > 1 ) {
			$duplicates[] = 'schema';
		}
		return array(
			'tag_counts'    => $counts,
			'duplicates'    => $duplicates,
			'sources'       => $sources,
			'schema_graphs' => $graphs,
		);
	}

	/**
	 * Whether a URL belongs to this site (SSRF guard).
	 *
	 * @param string $url URL.
	 */
	public static function is_own_url( string $url ): bool {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$own  = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
		return '' !== $host && $host === $own && in_array( wp_parse_url( $url, PHP_URL_SCHEME ), array( 'http', 'https' ), true );
	}
}
