<?php
/**
 * REST: content quality (flagged posts, duplicate groups, scan control, editor findings).
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Content\Analyzer;
use FutureLabs\AISEO\Content\Duplicate;
use FutureLabs\AISEO\Content\Recommender;
use FutureLabs\AISEO\Content\Template;
use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Links\Graph;
use FutureLabs\AISEO\Opportunity\Checklist;
use FutureLabs\AISEO\Opportunity\Editions;
use FutureLabs\AISEO\Opportunity\Velocity;

defined( 'ABSPATH' ) || exit;

/**
 * Routes under /content.
 */
class ContentController extends Controller {

	public const REASONS = array( 'thin', 'duplicate', 'missing_sections', 'generic_title' );

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		$this->route( '/content/flagged', 'GET', array( $this, 'flagged' ) );
		$this->route( '/content/groups', 'GET', array( $this, 'groups' ) );
		$this->route( '/content/scan', 'GET', array( $this, 'progress' ) );
		$this->route( '/content/scan', 'POST', array( $this, 'scan' ) );
		$this->route( '/content/velocity', 'GET', array( $this, 'velocity' ) );
		register_rest_route(
			self::NAMESPACE,
			'/content/post/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'post' ),
				'permission_callback' => static function ( \WP_REST_Request $request ): bool {
					return Capabilities::can( Capabilities::EDITOR ) && current_user_can( 'edit_post', absint( $request['id'] ) );
				},
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * Reason codes for a scan row.
	 *
	 * @param array<string, mixed> $row Row.
	 * @return array<int, string>
	 */
	private static function reasons( array $row ): array {
		$out = array();
		if ( (int) $row['thin_score'] > 0 ) {
			$out[] = 'thin';
		}
		if ( (int) $row['dup_group_id'] > 0 ) {
			$out[] = 'duplicate';
		}
		if ( '' !== (string) $row['missing_sections'] ) {
			$out[] = 'missing_sections';
		}
		if ( (int) $row['title_generic'] ) {
			$out[] = 'generic_title';
		}
		return $out;
	}

	/**
	 * GET /content/flagged.
	 *
	 * Filters: reason (thin|duplicate|missing_sections|generic_title), recommendation
	 * (improve|noindex|merge|delete_redirect), author (user ID), post_type, page, per_page.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	public function flagged( \WP_REST_Request $request ): array {
		global $wpdb;
		list( $page, $per_page ) = $this->paging( $request );
		$scan                    = Migrations::table( 'content_scan' );
		$index                   = Migrations::table( 'index_status' );
		$where                   = array( "p.post_status = 'publish'", "(s.recommendation <> 'ok' OR s.thin_score > 0 OR s.dup_group_id > 0 OR s.missing_sections <> '' OR s.title_generic = 1)" );
		$args                    = array();
		switch ( (string) $request->get_param( 'reason' ) ) {
			case 'thin':
				$where[] = 's.thin_score > 0';
				break;
			case 'duplicate':
				$where[] = 's.dup_group_id > 0';
				break;
			case 'missing_sections':
				$where[] = "s.missing_sections <> ''";
				break;
			case 'generic_title':
				$where[] = 's.title_generic = 1';
				break;
		}
		$recommendation = sanitize_key( (string) $request->get_param( 'recommendation' ) );
		if ( in_array( $recommendation, array( 'improve', 'noindex', 'ok' ), true ) ) {
			$where[] = 's.recommendation = %s';
			$args[]  = $recommendation;
		} elseif ( in_array( $recommendation, array( 'merge', 'delete_redirect' ), true ) ) {
			$where[] = 's.recommendation LIKE %s';
			$args[]  = $wpdb->esc_like( $recommendation . ':' ) . '%';
		}
		$author = absint( $request->get_param( 'author' ) );
		if ( $author ) {
			$where[] = 'p.post_author = %d';
			$args[]  = $author;
		}
		$type = sanitize_key( (string) $request->get_param( 'post_type' ) );
		if ( '' !== $type ) {
			$where[] = 'p.post_type = %s';
			$args[]  = $type;
		}
		$sql_where = implode( ' AND ', $where );
		$from      = "FROM {$scan} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id LEFT JOIN {$index} i ON i.post_id = s.post_id";
		$priority  = "(CASE WHEN LEFT(s.recommendation, 6) = 'merge:' OR LEFT(s.recommendation, 16) = 'delete_redirect:' THEN 30 WHEN s.recommendation = 'noindex' THEN 25 WHEN s.recommendation = 'improve' THEN 20 ELSE 0 END + CASE WHEN i.reason_code IN ('crawled_not_indexed', 'discovered_not_indexed') THEN 50 ELSE 0 END)";
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$count_sql = "SELECT COUNT(DISTINCT s.post_id) {$from} WHERE {$sql_where}";
		$total     = (int) $wpdb->get_var( $args ? $wpdb->prepare( $count_sql, $args ) : $count_sql );
		$rows      = $wpdb->get_results( $wpdb->prepare( "SELECT s.*, p.post_title, p.post_type, p.post_author, MAX(i.reason_code) index_reason, MAX({$priority}) priority {$from} WHERE {$sql_where} GROUP BY s.post_id ORDER BY priority DESC, s.thin_score DESC, s.post_id DESC LIMIT %d OFFSET %d", array_merge( $args, array( $per_page, ( $page - 1 ) * $per_page ) ) ), ARRAY_A );
		// phpcs:enable
		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = $this->item( $row );
		}
		return array(
			'items'    => $items,
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	/**
	 * Shape a flagged row.
	 *
	 * @param array<string, mixed> $row Row.
	 * @return array<string, mixed>
	 */
	private function item( array $row ): array {
		$id     = (int) $row['post_id'];
		$author = get_userdata( (int) $row['post_author'] );
		$rec    = Recommender::parse( (string) $row['recommendation'] );
		return array(
			'id'               => $id,
			'title'            => html_entity_decode( (string) $row['post_title'], ENT_QUOTES ),
			'url'              => (string) get_permalink( $id ),
			'edit_url'         => (string) get_edit_post_link( $id, 'raw' ),
			'post_type'        => (string) $row['post_type'],
			'author'           => $author ? array(
				'id'   => (int) $author->ID,
				'name' => $author->display_name,
			) : null,
			'words'            => (int) $row['word_count'],
			'thin_score'       => (int) $row['thin_score'],
			'headings'         => (int) $row['headings'],
			'title_generic'    => (bool) $row['title_generic'],
			'dup_group_id'     => (int) $row['dup_group_id'],
			'dup_similarity'   => (int) $row['dup_similarity'],
			'is_opportunity'   => (bool) $row['is_opportunity'],
			'missing_sections' => array_values( array_filter( explode( ',', (string) $row['missing_sections'] ) ) ),
			'reasons'          => self::reasons( $row ),
			'recommendation'   => array(
				'action'    => $rec['action'],
				'target_id' => $rec['target_id'],
				'target'    => $rec['target_id'] ? array(
					'id'    => $rec['target_id'],
					'title' => html_entity_decode( get_the_title( $rec['target_id'] ), ENT_QUOTES ),
					'url'   => (string) get_permalink( $rec['target_id'] ),
				) : null,
			),
			'reason'           => (string) $row['reason'],
			'index_reason'     => Recommender::normalize_reason( (string) ( $row['index_reason'] ?? '' ), '' ),
			'priority'         => (int) ( $row['priority'] ?? 0 ),
			'scanned_at'       => (string) $row['scanned_at'],
		);
	}

	/**
	 * GET /content/groups.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	public function groups( \WP_REST_Request $request ): array {
		list( $page, $per_page ) = $this->paging( $request, 50 );
		return $this->c->get( Duplicate::class )->groups( $page, $per_page ) + array(
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	/**
	 * GET /content/scan.
	 *
	 * @return array<string, mixed>
	 */
	public function progress(): array {
		return $this->c->get( Analyzer::class )->progress();
	}

	/**
	 * POST /content/scan { restart?: bool }.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	public function scan( \WP_REST_Request $request ): array {
		$body = $this->body( $request );
		return $this->c->get( Analyzer::class )->start( ! empty( $body['restart'] ) );
	}

	/**
	 * GET /content/velocity.
	 *
	 * @return array<string, mixed>
	 */
	public function velocity(): array {
		return $this->c->get( Velocity::class )->cached();
	}

	/**
	 * GET /content/post/{id}: live findings, checklist and completeness for the editor sidebar.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function post( \WP_REST_Request $request ) {
		global $wpdb;
		$post = get_post( absint( $request['id'] ) );
		if ( ! $post instanceof \WP_Post ) {
			return $this->error( 'not_found', __( 'Post not found.', 'futurelabs-ai-seo' ), 404 );
		}
		$analysis = $this->c->get( Analyzer::class )->analyze( $post );
		$thin     = $this->c->get( \FutureLabs\AISEO\Content\Thin::class );
		$scan     = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$row      = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$scan} WHERE post_id = %d", $post->ID ), ARRAY_A );
		$findings = array();
		$words    = (int) $analysis['word_count'];
		if ( $thin->is_thin( $words ) ) {
			$findings[] = array(
				'code'     => 'thin',
				'severity' => 'warning',
				/* translators: 1: word count, 2: threshold. */
				'label'    => sprintf( __( '%1$d words; pages under %2$d words often add little that is not already elsewhere.', 'futurelabs-ai-seo' ), $words, $thin->threshold() ),
			);
		}
		if ( $analysis['title_generic'] ) {
			$findings[] = array(
				'code'     => 'generic_title',
				'severity' => 'info',
				'label'    => __( 'The title is mostly template wording; name what is specific about this page.', 'futurelabs-ai-seo' ),
			);
		}
		if ( count( $analysis['headings'] ) < 2 && $words >= 300 ) {
			$findings[] = array(
				'code'     => 'few_headings',
				'severity' => 'info',
				'label'    => __( 'Add section headings so readers can scan the page.', 'futurelabs-ai-seo' ),
			);
		}
		if ( $analysis['heading_skipped'] ) {
			$findings[] = array(
				'code'     => 'heading_skip',
				'severity' => 'info',
				'label'    => __( 'A heading level is skipped (for example H2 to H4).', 'futurelabs-ai-seo' ),
			);
		}
		if ( $analysis['h1_count'] > 0 ) {
			$findings[] = array(
				'code'     => 'h1_in_content',
				'severity' => 'info',
				'label'    => __( 'The content contains an H1; the post title is usually the only H1.', 'futurelabs-ai-seo' ),
			);
		}
		if ( $row && (int) $row['dup_group_id'] > 0 ) {
			$findings[] = array(
				'code'     => 'duplicate',
				'severity' => 'warning',
				/* translators: %d: similarity percent. */
				'label'    => sprintf( __( 'Another post is about %d%% similar in wording. Make this one clearly distinct or merge them.', 'futurelabs-ai-seo' ), (int) $row['dup_similarity'] ),
			);
		}
		$links = $this->c->get( Graph::class )->stats( $post->ID );
		if ( $links && 0 === $links['inbound'] && 'publish' === $post->post_status ) {
			$findings[] = array(
				'code'     => 'orphan',
				'severity' => 'warning',
				'label'    => __( 'No other post links here. Add links from related posts so readers and crawlers can find it.', 'futurelabs-ai-seo' ),
			);
		}
		$rec       = $row ? Recommender::parse( (string) $row['recommendation'] ) : array(
			'action'    => '',
			'target_id' => 0,
		);
		$editions  = array();
		$group_key = (string) ( $row['edition_key'] ?? $analysis['edition_key'] );
		if ( '' !== $group_key ) {
			$group    = $this->c->get( Editions::class )->group( $group_key );
			$editions = $group ? $group['members'] : array();
		}
		return array(
			'post_id'        => $post->ID,
			'checklist'      => $this->c->get( Checklist::class )->evaluate( $post ),
			'hard_gate'      => $this->c->get( Checklist::class )->is_hard(),
			'is_opportunity' => (bool) $analysis['is_opportunity'],
			'completeness'   => $analysis['sections'],
			'words'          => $words,
			'thin_threshold' => $thin->threshold(),
			'headings'       => $analysis['headings'],
			'findings'       => $findings,
			'recommendation' => $rec,
			'reason'         => (string) ( $row['reason'] ?? '' ),
			'links'          => $links,
			'editions'       => $editions,
			'scanned_at'     => (string) ( $row['scanned_at'] ?? '' ),
			'sections_help'  => array_map( static fn( $s ) => $s[0], Template::sections() ),
		);
	}
}
