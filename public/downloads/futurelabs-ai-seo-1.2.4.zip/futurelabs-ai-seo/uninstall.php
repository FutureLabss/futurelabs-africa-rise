<?php
/**
 * Uninstall: removes FutureLabs AI SEO data only when the "Delete data on uninstall" setting is on.
 *
 * @package FutureLabs AI SEO
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( ! function_exists( 'flseo_uninstall_site' ) ) {
	/**
	 * Delete FutureLabs AI SEO data for the current site when the site opted in.
	 */
	function flseo_uninstall_site(): void {
		global $wpdb;
		$settings = get_option( 'flseo_settings', array() );
		if ( ! is_array( $settings ) || empty( $settings['delete_data'] ) ) {
			return;
		}
		$tables = array( 'redirects', 'log_404', 'index_status', 'content_scan', 'links', 'link_stats', 'audit_log', 'gsc_queries', 'perf_results', 'ai_suggestions', 'history', 'embeddings', '404' );
		foreach ( $tables as $suffix ) {
			$table = $wpdb->prefix . 'flseo_' . $suffix;
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.SchemaChange
		}
		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s", $wpdb->esc_like( '_flseo_' ) . '%' ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->termmeta} WHERE meta_key LIKE %s", $wpdb->esc_like( '_flseo_' ) . '%' ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( 'flseo_' ) . '%', $wpdb->esc_like( '_transient_flseo_' ) . '%', $wpdb->esc_like( '_transient_timeout_flseo_' ) . '%' ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_flseo_' ) . '%', $wpdb->esc_like( '_transient_timeout_flseo_' ) . '%' ) );
		// phpcs:enable
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( '', array(), 'futurelabs-ai-seo' );
		}
		foreach ( (array) _get_cron_array() as $events ) {
			foreach ( array_keys( (array) $events ) as $hook ) {
				if ( str_starts_with( (string) $hook, 'flseo_' ) || str_starts_with( (string) $hook, 'flseo_' ) ) {
					wp_clear_scheduled_hook( (string) $hook );
				}
			}
		}
	}
}

if ( is_multisite() ) {
	foreach ( get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	) as $flseo_site_id ) {
		switch_to_blog( (int) $flseo_site_id );
		flseo_uninstall_site();
		restore_current_blog();
	}
} else {
	flseo_uninstall_site();
}
delete_metadata( 'user', 0, 'flseo_dismissed_notices', '', true );
