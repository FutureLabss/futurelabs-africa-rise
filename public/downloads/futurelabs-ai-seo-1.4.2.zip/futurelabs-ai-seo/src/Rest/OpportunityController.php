<?php
/**
 * REST: opportunity lifecycle lists, editions and per-post expiry actions.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Opportunity\Editions;
use FutureLabs\AISEO\Opportunity\Feed;
use FutureLabs\AISEO\Opportunity\Lifecycle;

defined( 'ABSPATH' ) || exit;

/**
 * Routes under /opportunities.
 */
class OpportunityController extends Controller {

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		$this->route(
			'/opportunities',
			'GET',
			array( $this, 'index' ),
			Capabilities::DATA,
			array(
				'status' => array(
					'type' => 'string',
					'enum' => array( 'closing', 'closed_indexed', 'missing_deadline' ),
				),
			)
		);
		$this->route( '/opportunities/editions', 'GET', array( $this, 'editions' ) );
		register_rest_route(
			self::NAMESPACE,
			'/opportunities/feed',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'feed' ),
				// Public: it lists only what readers already see on published posts.
				'permission_callback' => '__return_true',
				'args'                => array(
					'modified_after' => array(
						'type'   => 'string',
						'format' => 'date-time',
					),
				),
			)
		);
		register_rest_route(
			self::NAMESPACE,
			'/opportunities/(?P<id>\d+)/action',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'action' ),
				'permission_callback' => static function ( \WP_REST_Request $request ): bool {
					$id     = absint( $request['id'] );
					$action = (string) $request->get_param( 'action' );
					if ( ! Capabilities::can( Capabilities::EDITOR ) || ! current_user_can( 'edit_post', $id ) ) {
						return false;
					}
					// Noindex and redirects change site-wide indexing, so they need the data capability.
					return in_array( $action, array( 'update', 'notice' ), true ) || Capabilities::can( Capabilities::DATA );
				},
				'args'                => array(
					'action' => array(
						'type'     => 'string',
						'required' => true,
						'enum'     => Lifecycle::ACTIONS,
					),
				),
			)
		);
	}

	/**
	 * GET /opportunities?status=closing|closed_indexed|missing_deadline&days=7.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	public function index( \WP_REST_Request $request ): array {
		list( $page, $per_page ) = $this->paging( $request );
		$lifecycle               = $this->c->get( Lifecycle::class );
		$status                  = (string) ( $request->get_param( 'status' ) ? $request->get_param( 'status' ) : 'closing' );
		switch ( $status ) {
			case 'closed_indexed':
				$list = $lifecycle->closed_indexed( $page, $per_page );
				break;
			case 'missing_deadline':
				$list = $lifecycle->missing_deadline( $page, $per_page );
				break;
			default:
				$status = 'closing';
				$days   = absint( $request->get_param( 'days' ) ? $request->get_param( 'days' ) : 7 );
				$list   = $lifecycle->closing( $days, $page, $per_page );
		}
		return $list + array(
			'status'   => $status,
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	/**
	 * GET /opportunities/feed?page=1&per_page=100&modified_after=2026-10-01T00:00:00Z (public).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function feed( \WP_REST_Request $request ) {
		$feed = $this->c->get( Feed::class );
		if ( ! $feed->enabled() ) {
			return $this->error( 'feed_off', __( 'The opportunity feed is not enabled on this site.', 'futurelabs-ai-seo' ), 404 );
		}
		list( $page, $per_page ) = $this->paging( $request );
		$after                   = (string) $request->get_param( 'modified_after' );
		$after                   = '' === $after ? '' : gmdate( 'Y-m-d H:i:s', (int) strtotime( $after ) );
		$response                = new \WP_REST_Response(
			$feed->page( $page, $per_page, $after ) + array(
				'page'     => $page,
				'per_page' => $per_page,
			)
		);
		$response->header( 'Cache-Control', 'public, max-age=300' );
		return $response;
	}

	/**
	 * GET /opportunities/editions.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	public function editions( \WP_REST_Request $request ): array {
		list( $page, $per_page ) = $this->paging( $request );
		return $this->c->get( Editions::class )->groups( $page, $per_page ) + array(
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	/**
	 * POST /opportunities/{id}/action { action, target?, confirmation? }.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function action( \WP_REST_Request $request ) {
		$body   = $this->body( $request );
		$result = $this->c->get( Lifecycle::class )->apply_action(
			absint( $request['id'] ),
			sanitize_key( (string) ( $body['action'] ?? $request->get_param( 'action' ) ) ),
			esc_url_raw( (string) ( $body['target'] ?? '' ) ),
			null,
			sanitize_text_field( (string) ( $body['confirmation'] ?? '' ) ),
			true
		);
		if ( false === $result ) {
			return array(
				'post_id' => absint( $request['id'] ),
				'changed' => false,
				'status'  => (string) get_post_meta( absint( $request['id'] ), '_flseo_opp_status', true ),
			);
		}
		return $result;
	}
}
