<?php
/**
 * Capability map for plugin features, and the role manager behind it.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Each feature is guarded by its own capability. The plugin grants those
 * capabilities at check time from the "Access" setting (feature → roles), so
 * nothing is written to the roles stored in the database.
 */
final class Capabilities implements Module {

	public const SETTINGS = 'settings';
	public const DATA     = 'data';
	public const EDITOR   = 'editor';

	/**
	 * Feature → plugin capability.
	 */
	public const CAPS = array(
		self::SETTINGS => 'flseo_manage_settings',
		self::DATA     => 'flseo_manage_data',
		self::EDITOR   => 'flseo_edit_seo',
	);

	/**
	 * WordPress capability that decides the default roles for each feature.
	 */
	private const BASE = array(
		self::SETTINGS => 'manage_options',
		self::DATA     => 'manage_options',
		self::EDITOR   => 'edit_posts',
	);

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Grant the plugin capabilities from the Access setting.
	 */
	public function register(): void {
		add_filter( 'user_has_cap', array( $this, 'grant' ), 10, 4 );
	}

	/**
	 * `user_has_cap` filter: decide the plugin capabilities being checked.
	 *
	 * @param array<string, bool> $allcaps Capabilities the user has.
	 * @param array<int, string>  $caps    Capabilities being checked.
	 * @param array<int, mixed>   $args    Arguments.
	 * @param \WP_User            $user    User.
	 * @return array<string, bool>
	 */
	public function grant( $allcaps, $caps, $args, $user ) {
		$wanted = array_intersect( self::CAPS, (array) $caps );
		if ( ! $wanted || ! $user instanceof \WP_User ) {
			return $allcaps;
		}
		foreach ( $wanted as $feature => $cap ) {
			$allcaps[ $cap ] = ( is_multisite() && is_super_admin( $user->ID ) )
				|| (bool) array_intersect( (array) $user->roles, $this->roles_for( $feature ) );
		}
		return $allcaps;
	}

	/**
	 * Roles allowed to use a feature: the saved choice, else every role with the
	 * feature's base WordPress capability. Roles that can manage options always
	 * keep Settings, so an administrator can't lock everyone out.
	 *
	 * @param string $feature Feature key.
	 * @return array<int, string>
	 */
	public function roles_for( string $feature ): array {
		$saved = (array) $this->c->get( Settings::class )->get( 'role_access', array() );
		$roles = isset( $saved[ $feature ] ) ? (array) $saved[ $feature ] : self::roles_with( self::BASE[ $feature ] ?? 'manage_options' );
		if ( self::SETTINGS === $feature ) {
			$roles = array_merge( $roles, self::roles_with( 'manage_options' ) );
		}
		return array_values( array_unique( $roles ) );
	}

	/**
	 * Default roles for every feature (for the Access screen).
	 *
	 * @return array<string, array<int, string>>
	 */
	public static function default_roles(): array {
		return array_map( array( self::class, 'roles_with' ), self::BASE );
	}

	/**
	 * Roles whose definition includes a capability.
	 *
	 * @param string $cap Capability.
	 * @return array<int, string>
	 */
	public static function roles_with( string $cap ): array {
		$roles = array();
		foreach ( wp_roles()->roles as $slug => $role ) {
			if ( ! empty( $role['capabilities'][ $cap ] ) ) {
				$roles[] = (string) $slug;
			}
		}
		return $roles;
	}

	/**
	 * Feature to capability map, filterable via `flseo_capabilities`.
	 *
	 * @return array<string, string>
	 */
	public static function map(): array {
		return (array) apply_filters( 'flseo_capabilities', self::CAPS );
	}

	/**
	 * Capability for a feature.
	 *
	 * @param string $feature Feature key.
	 */
	public static function cap( string $feature ): string {
		return self::map()[ $feature ] ?? self::CAPS[ self::SETTINGS ];
	}

	/**
	 * Whether the current user may use a feature.
	 *
	 * @param string $feature Feature key.
	 */
	public static function can( string $feature ): bool {
		return current_user_can( self::cap( $feature ) );
	}
}
