<?php
/**
 * The AI provider chosen in settings.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Ai;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Resolves the `ai_provider` setting to a Provider. Callers use this instead of a provider class.
 */
class AiClient {

	/**
	 * Provider ID => class. The first entry is the default.
	 */
	public const PROVIDERS = array(
		'anthropic'  => ClaudeClient::class,
		'openai'     => OpenAiClient::class,
		'gemini'     => GeminiClient::class,
		'compatible' => OpenAiCompatibleClient::class,
	);

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Provider labels for settings (ID => label).
	 *
	 * @return array<string, string>
	 */
	public static function labels(): array {
		return array(
			'anthropic'  => __( 'Anthropic (Claude)', 'futurelabs-ai-seo' ),
			'openai'     => __( 'OpenAI', 'futurelabs-ai-seo' ),
			'gemini'     => __( 'Google Gemini', 'futurelabs-ai-seo' ),
			'compatible' => __( 'OpenAI-compatible (OpenRouter, Groq, DeepSeek, Ollama…)', 'futurelabs-ai-seo' ),
		);
	}

	/**
	 * Sanitize a provider ID.
	 *
	 * @param mixed $value Raw value.
	 */
	public static function sanitize_id( $value ): string {
		$value = sanitize_key( (string) $value );
		return isset( self::PROVIDERS[ $value ] ) ? $value : (string) array_key_first( self::PROVIDERS );
	}

	/**
	 * A provider by ID, or the configured one.
	 *
	 * @param string $id Provider ID ('' for the configured provider).
	 */
	public function provider( string $id = '' ): Provider {
		$id = self::sanitize_id( '' !== $id ? $id : $this->c->get( Settings::class )->get( 'ai_provider', '' ) );
		/** Provider instance. @var Provider $provider */
		$provider = $this->c->get( self::PROVIDERS[ $id ] );
		return $provider;
	}

	/**
	 * Whether AI assist is on.
	 */
	public function enabled(): bool {
		return $this->provider()->enabled();
	}

	/**
	 * Whether the configured provider is ready to use (key or server URL stored).
	 */
	public function has_key(): bool {
		return $this->provider()->has_key();
	}

	/**
	 * Configured model.
	 */
	public function model(): string {
		return $this->provider()->model();
	}

	/**
	 * Image types the configured provider accepts.
	 *
	 * @return array<int, string>
	 */
	public function image_types(): array {
		return $this->provider()->image_types();
	}

	/**
	 * Send through the configured provider.
	 *
	 * @param string                                              $system      System prompt.
	 * @param string                                              $text        User text.
	 * @param array<int, array{media_type: string, data: string}> $images      Images.
	 * @param bool                                                $interactive Interactive.
	 * @return array{text: string, stop_reason: string, truncated: bool}|\WP_Error
	 */
	public function send( string $system, string $text, array $images = array(), bool $interactive = true ) {
		return $this->provider()->send( $system, $text, $images, $interactive );
	}
}
