<?php
/**
 * Versioned database migrations.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Runs schema migrations in order and records `flseo_db_version`.
 */
class Migrations {

	public const OPTION  = 'flseo_db_version';
	public const VERSION = 3;

	/**
	 * Table suffixes owned by the plugin.
	 */
	public const TABLES = array( 'redirects', 'log_404', 'index_status', 'content_scan', 'links', 'link_stats', 'audit_log', 'gsc_queries', 'perf_results', 'ai_suggestions', 'history', 'embeddings' );

	/**
	 * Fully prefixed table name.
	 *
	 * @param string $suffix Table suffix.
	 */
	public static function table( string $suffix ): string {
		global $wpdb;
		return $wpdb->prefix . 'flseo_' . $suffix;
	}

	/**
	 * Run pending migrations. Safe to call on every request; it is a no-op when current.
	 */
	public function run(): void {
		$installed = (int) get_option( self::OPTION, 0 );
		if ( $installed >= self::VERSION ) {
			return;
		}
		// 1.0.0 installs tracked tables under a separate option.
		if ( 0 === $installed && get_option( 'flseo_advanced_db_version' ) ) {
			$installed = 1;
		}
		for ( $version = $installed + 1; $version <= self::VERSION; $version++ ) {
			$method = 'migrate_' . $version;
			if ( method_exists( $this, $method ) ) {
				$this->{$method}();
			}
			update_option( self::OPTION, $version, true );
		}
	}

	/**
	 * Version 1: original schema (kept for fresh installs through the same path).
	 */
	private function migrate_1(): void {
		$this->schema();
	}

	/**
	 * Version 2: rename the 404 table, add PRD columns, migrate 1.0 settings keys.
	 */
	private function migrate_2(): void {
		global $wpdb;
		$old = $wpdb->prefix . 'flseo_404';
		$new = self::table( 'log_404' );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $old ) ) === $old && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $new ) ) !== $new ) {
			$wpdb->query( "RENAME TABLE `{$old}` TO `{$new}`" );
		}
		// phpcs:enable
		$this->schema();
		$this->migrate_legacy_settings();
		delete_option( 'flseo_advanced_db_version' );
	}

	/**
	 * Version 3: history and embeddings tables.
	 */
	private function migrate_3(): void {
		$this->schema();
	}

	/**
	 * Map 1.0.0 setting keys and options onto the current settings store.
	 */
	private function migrate_legacy_settings(): void {
		$stored = get_option( Settings::OPTION, array() );
		if ( ! is_array( $stored ) ) {
			return;
		}
		$map = array(
			'description'        => 'output_description',
			'canonical'          => 'output_canonical',
			'robots'             => 'output_robots',
			'404_retention_days' => 'retention_404_days',
		);
		foreach ( $map as $from => $to ) {
			if ( array_key_exists( $from, $stored ) && ! array_key_exists( $to, $stored ) ) {
				$stored[ $to ] = $stored[ $from ];
			}
			unset( $stored[ $from ] );
		}
		if ( array_key_exists( 'auto_slug_redirect', $stored ) ) {
			$stored['slug_redirects'] = $stored['auto_slug_redirect'] ? 'auto' : 'off';
			unset( $stored['auto_slug_redirect'] );
		}
		$options = array(
			'flseo_ai_enabled'        => 'ai_enabled',
			'flseo_ai_model'          => 'ai_model',
			'flseo_reports_enabled'   => 'reports_enabled',
			'flseo_reports_cadence'   => 'reports_cadence',
			'flseo_report_recipients' => 'reports_recipients',
		);
		foreach ( $options as $option => $key ) {
			$value = get_option( $option, null );
			if ( null !== $value ) {
				$stored[ $key ] = $value;
				delete_option( $option );
			}
		}
		update_option( Settings::OPTION, $stored, true );
	}

	/**
	 * Create or update every table with dbDelta.
	 */
	public function schema(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		$t = array();
		foreach ( self::TABLES as $suffix ) {
			$t[ $suffix ] = self::table( $suffix );
		}

		dbDelta(
			"CREATE TABLE {$t['redirects']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			source varchar(2048) NOT NULL,
			source_hash char(64) NOT NULL,
			target varchar(2048) NOT NULL DEFAULT '',
			type smallint(3) NOT NULL DEFAULT 301,
			is_regex tinyint(1) NOT NULL DEFAULT 0,
			hits bigint(20) unsigned NOT NULL DEFAULT 0,
			last_hit datetime NULL,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			origin varchar(32) NOT NULL DEFAULT 'manual',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY source_hash (source_hash),
			KEY is_regex (is_regex)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['log_404']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url_hash char(64) NOT NULL,
			url varchar(2048) NOT NULL,
			hits bigint(20) unsigned NOT NULL DEFAULT 1,
			referrer varchar(2048) NOT NULL DEFAULT '',
			user_agent_class varchar(24) NOT NULL DEFAULT 'unknown',
			first_seen datetime NOT NULL,
			last_seen datetime NOT NULL,
			ignored tinyint(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY url_hash (url_hash),
			KEY last_seen (last_seen)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['index_status']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			url_hash char(64) NOT NULL,
			url text NOT NULL,
			verdict varchar(32) NOT NULL DEFAULT 'unknown',
			coverage_state varchar(191) NOT NULL DEFAULT '',
			google_canonical text NULL,
			user_canonical text NULL,
			robots_state varchar(64) NOT NULL DEFAULT '',
			page_fetch_state varchar(64) NOT NULL DEFAULT '',
			last_crawl datetime NULL,
			inspected_at datetime NULL,
			indexed_at datetime NULL,
			published_at datetime NULL,
			in_sitemap tinyint(1) NOT NULL DEFAULT 0,
			reason_code varchar(64) NOT NULL DEFAULT '',
			priority int NOT NULL DEFAULT 0,
			queued_at datetime NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY url_hash (url_hash),
			KEY post_id (post_id),
			KEY verdict (verdict),
			KEY reason_code (reason_code),
			KEY queued_at (queued_at)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['content_scan']} (
			post_id bigint(20) unsigned NOT NULL,
			word_count int unsigned NOT NULL DEFAULT 0,
			title_generic tinyint(1) NOT NULL DEFAULT 0,
			headings int unsigned NOT NULL DEFAULT 0,
			simhash char(16) NOT NULL DEFAULT '',
			template_sig char(16) NOT NULL DEFAULT '',
			edition_key char(16) NOT NULL DEFAULT '',
			edition_year smallint unsigned NOT NULL DEFAULT 0,
			thin_score int NOT NULL DEFAULT 0,
			dup_group_id bigint(20) unsigned NOT NULL DEFAULT 0,
			dup_similarity tinyint unsigned NOT NULL DEFAULT 0,
			is_opportunity tinyint(1) NOT NULL DEFAULT 0,
			missing_sections varchar(255) NOT NULL DEFAULT '',
			recommendation varchar(48) NOT NULL DEFAULT 'ok',
			reason text NOT NULL,
			scanned_at datetime NOT NULL,
			PRIMARY KEY  (post_id),
			KEY dup_group_id (dup_group_id),
			KEY template_sig (template_sig),
			KEY edition_key (edition_key),
			KEY recommendation (recommendation)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['links']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			from_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			to_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			to_url varchar(2048) NOT NULL DEFAULT '',
			anchor varchar(500) NOT NULL DEFAULT '',
			source varchar(16) NOT NULL DEFAULT 'content',
			PRIMARY KEY  (id),
			KEY from_post_id (from_post_id),
			KEY to_post_id (to_post_id),
			KEY source (source)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['link_stats']} (
			post_id bigint(20) unsigned NOT NULL,
			inbound int unsigned NOT NULL DEFAULT 0,
			outbound int unsigned NOT NULL DEFAULT 0,
			click_depth int unsigned NOT NULL DEFAULT 99,
			computed_at datetime NOT NULL,
			PRIMARY KEY  (post_id),
			KEY inbound (inbound),
			KEY click_depth (click_depth)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['audit_log']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action varchar(64) NOT NULL,
			object_type varchar(32) NOT NULL,
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			old_value longtext NULL,
			new_value longtext NULL,
			batch_id char(36) NOT NULL,
			undone tinyint(1) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY batch_id (batch_id),
			KEY object_id (object_id),
			KEY created_at (created_at)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['gsc_queries']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url_hash char(64) NOT NULL,
			url varchar(2048) NOT NULL DEFAULT '',
			query varchar(500) NOT NULL,
			clicks bigint unsigned NOT NULL DEFAULT 0,
			impressions bigint unsigned NOT NULL DEFAULT 0,
			position decimal(8,3) NOT NULL DEFAULT 0,
			date_range varchar(32) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY url_hash (url_hash),
			KEY date_range (date_range),
			KEY query (query(191))
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['perf_results']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url_hash char(64) NOT NULL,
			url varchar(2048) NOT NULL DEFAULT '',
			strategy varchar(16) NOT NULL,
			lcp decimal(9,3) NULL,
			inp decimal(9,3) NULL,
			cls decimal(9,4) NULL,
			score int NULL,
			fetched_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY url_hash (url_hash),
			KEY fetched_at (fetched_at)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['ai_suggestions']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned NOT NULL,
			field varchar(32) NOT NULL,
			suggestion longtext NOT NULL,
			status varchar(16) NOT NULL DEFAULT 'pending',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			decided_at datetime NULL,
			PRIMARY KEY  (id),
			KEY post_id (post_id),
			KEY status (status)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['history']} (
			day date NOT NULL,
			known int unsigned NOT NULL DEFAULT 0,
			inspected int unsigned NOT NULL DEFAULT 0,
			indexed int unsigned NOT NULL DEFAULT 0,
			noindex int unsigned NOT NULL DEFAULT 0,
			flagged int unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (day)
			) $c;"
		);
		dbDelta(
			"CREATE TABLE {$t['embeddings']} (
			post_id bigint(20) unsigned NOT NULL,
			model varchar(64) NOT NULL DEFAULT '',
			content_hash char(64) NOT NULL DEFAULT '',
			vector longtext NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (post_id)
			) $c;"
		);
	}

	/**
	 * Drop every plugin table (uninstall).
	 */
	public static function drop_all(): void {
		global $wpdb;
		foreach ( array_merge( self::TABLES, array( '404' ) ) as $suffix ) {
			$table = self::table( $suffix );
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.SchemaChange
		}
	}
}
