<?php
/**
 * Serves /sitemap_index.xml and per-type sub-sitemaps; disables the core sitemap.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Sitemap;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Rewrite rules, request handling, XML rendering and cache invalidation.
 */
class Router implements Module {

	public const VERSION_OPTION = 'flseo_sitemap_version';

	/**
	 * Post and term meta that decide whether a URL belongs in the sitemap. Bulk actions
	 * and undo change these without firing save_post, so the meta hooks clear the cache.
	 */
	public const INDEXING_META = array( '_flseo_noindex', '_flseo_canonical' );

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'add_rules' ) );
		add_filter( 'query_vars', array( $this, 'query_vars' ) );
		add_action( 'parse_request', array( $this, 'serve' ), 1 );
		add_filter( 'wp_sitemaps_enabled', '__return_false' );
		add_filter( 'robots_txt', array( $this, 'robots_txt' ), 20, 2 );
		add_filter( 'redirect_canonical', array( $this, 'no_trailing_slash' ), 10, 2 );
		foreach ( array( 'save_post', 'deleted_post', 'trashed_post', 'edited_term', 'delete_term', 'created_term', 'flseo_settings_updated', 'flseo_redirects_changed' ) as $hook ) {
			add_action( $hook, array( $this, 'invalidate' ) );
		}
		add_action( 'transition_post_status', array( $this, 'status_changed' ), 10, 3 );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta', 'added_term_meta', 'updated_term_meta', 'deleted_term_meta' ) as $hook ) {
			add_action( $hook, array( $this, 'meta_changed' ), 10, 3 );
		}
	}

	/**
	 * Invalidate cached sitemaps when indexing meta changes.
	 *
	 * @param int|int[] $meta_ids  Meta ID(s).
	 * @param int       $object_id Post or term ID.
	 * @param string    $meta_key  Meta key.
	 */
	public function meta_changed( $meta_ids, $object_id, $meta_key ): void {
		if ( in_array( $meta_key, self::INDEXING_META, true ) ) {
			$this->invalidate();
		}
	}

	/**
	 * Rewrite rules.
	 */
	public function add_rules(): void {
		add_rewrite_rule( '^sitemap_index\.xml$', 'index.php?flseo_sitemap=index', 'top' );
		add_rewrite_rule( '^([a-z0-9_\-]+)-sitemap([0-9]*)\.xml$', 'index.php?flseo_sitemap=$matches[1]&flseo_sitemap_page=$matches[2]', 'top' );
		add_rewrite_rule( '^flseo-sitemap\.xsl$', 'index.php?flseo_sitemap=xsl', 'top' );
	}

	/**
	 * Public query vars.
	 *
	 * @param array<int, string> $vars Vars.
	 * @return array<int, string>
	 */
	public function query_vars( array $vars ): array {
		$vars[] = 'flseo_sitemap';
		$vars[] = 'flseo_sitemap_page';
		return $vars;
	}

	/**
	 * Sub-sitemap URL.
	 *
	 * @param string $name Post type or taxonomy.
	 * @param int    $page Page.
	 */
	public static function url( string $name, int $page = 1 ): string {
		return home_url( '/' . $name . '-sitemap' . ( $page > 1 ? $page : '' ) . '.xml' );
	}

	/**
	 * Sitemap index URL.
	 */
	public static function index_url(): string {
		return home_url( '/sitemap_index.xml' );
	}

	/**
	 * Handle sitemap requests before the main query runs.
	 *
	 * @param \WP $wp Request.
	 */
	public function serve( \WP $wp ): void {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
		if ( preg_match( '~/wp-sitemap(?:-[a-z0-9\-]+)?\.xml$~', $path ) ) {
			wp_safe_redirect( self::index_url(), 301, 'FutureLabs AI SEO' );
			exit;
		}
		$name = isset( $wp->query_vars['flseo_sitemap'] ) ? sanitize_key( (string) $wp->query_vars['flseo_sitemap'] ) : '';
		if ( '' === $name ) {
			return;
		}
		$page = max( 1, absint( $wp->query_vars['flseo_sitemap_page'] ?? 1 ) );
		if ( 'xsl' === $name ) {
			$this->send( $this->stylesheet(), 'text/xsl' );
		}
		$xml = $this->xml( $name, $page );
		if ( null === $xml ) {
			status_header( 404 );
			nocache_headers();
			header( 'Content-Type: text/plain; charset=UTF-8' );
			echo esc_html__( 'Sitemap not found.', 'futurelabs-ai-seo' );
			exit;
		}
		$this->send( $xml, 'application/xml' );
	}

	/**
	 * Send a response and stop.
	 *
	 * @param string $body Body.
	 * @param string $type Content type.
	 */
	private function send( string $body, string $type ): void {
		status_header( 200 );
		header( 'Content-Type: ' . $type . '; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex, follow', true );
		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XML built with esc_xml().
		exit;
	}

	/**
	 * XML for a sitemap, cached until content changes. Null when not found or the site discourages indexing.
	 *
	 * @param string $name 'index', post type or taxonomy.
	 * @param int    $page Page.
	 */
	public function xml( string $name, int $page = 1 ): ?string {
		if ( '0' === (string) get_option( 'blog_public' ) ) {
			return null;
		}
		$key    = 'flseo_sm_' . md5( $name . '|' . $page . '|' . $this->version() );
		$cached = get_transient( $key );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}
		$builder = $this->c->get( Builder::class );
		if ( 'index' === $name ) {
			$xml = $this->render_index( $builder->index() );
		} else {
			$entries = $builder->entries( $name, $page );
			if ( null === $entries || ( $page > 1 && ! $entries ) ) {
				return null;
			}
			$xml = $this->render_urlset( $entries );
		}
		set_transient( $key, $xml, 12 * HOUR_IN_SECONDS );
		return $xml;
	}

	/**
	 * Render the sitemap index.
	 *
	 * @param array<int, array{loc: string, lastmod: string}> $entries Entries.
	 */
	public function render_index( array $entries ): string {
		$out  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		$out .= '<?xml-stylesheet type="text/xsl" href="' . esc_url( home_url( '/flseo-sitemap.xsl' ) ) . '"?>' . "\n";
		$out .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		foreach ( $entries as $entry ) {
			$out .= "\t<sitemap>\n\t\t<loc>" . esc_xml( $entry['loc'] ) . "</loc>\n";
			if ( '' !== $entry['lastmod'] ) {
				$out .= "\t\t<lastmod>" . esc_xml( $entry['lastmod'] ) . "</lastmod>\n";
			}
			$out .= "\t</sitemap>\n";
		}
		return $out . "</sitemapindex>\n";
	}

	/**
	 * Render a urlset.
	 *
	 * @param array<int, array{loc: string, lastmod: string, images: array<int, string>}> $entries Entries.
	 */
	public function render_urlset( array $entries ): string {
		$has_images = (bool) array_filter( array_column( $entries, 'images' ) );
		$out        = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		$out       .= '<?xml-stylesheet type="text/xsl" href="' . esc_url( home_url( '/flseo-sitemap.xsl' ) ) . '"?>' . "\n";
		$out       .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . ( $has_images ? ' xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"' : '' ) . ">\n";
		foreach ( $entries as $entry ) {
			$out .= "\t<url>\n\t\t<loc>" . esc_xml( $entry['loc'] ) . "</loc>\n";
			if ( '' !== $entry['lastmod'] ) {
				$out .= "\t\t<lastmod>" . esc_xml( $entry['lastmod'] ) . "</lastmod>\n";
			}
			foreach ( $entry['images'] as $image ) {
				$out .= "\t\t<image:image><image:loc>" . esc_xml( $image ) . "</image:loc></image:image>\n";
			}
			$out .= "\t</url>\n";
		}
		return $out . "</urlset>\n";
	}

	/**
	 * Human-readable XSL stylesheet.
	 */
	private function stylesheet(): string {
		$title = esc_xml( __( 'XML Sitemap', 'futurelabs-ai-seo' ) );
		$note  = esc_xml( __( 'This sitemap lists indexable pages for search engines. Generated by FutureLabs AI SEO.', 'futurelabs-ai-seo' ) );
		return '<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:s="http://www.sitemaps.org/schemas/sitemap/0.9">
<xsl:output method="html" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<html><head><title>' . $title . '</title><meta name="robots" content="noindex,follow"/>
<style>body{font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:2em;color:#1e1e1e}table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:6px 10px;border-bottom:1px solid #ddd}th{background:#f6f7f7}a{color:#2271b1}</style></head>
<body><h1>' . $title . '</h1><p>' . $note . '</p>
<xsl:if test="s:sitemapindex"><table><tr><th>Sitemap</th><th>Last modified</th></tr>
<xsl:for-each select="s:sitemapindex/s:sitemap"><tr><td><a href="{s:loc}"><xsl:value-of select="s:loc"/></a></td><td><xsl:value-of select="s:lastmod"/></td></tr></xsl:for-each></table></xsl:if>
<xsl:if test="s:urlset"><p><xsl:value-of select="count(s:urlset/s:url)"/> URLs</p><table><tr><th>URL</th><th>Last modified</th></tr>
<xsl:for-each select="s:urlset/s:url"><tr><td><a href="{s:loc}"><xsl:value-of select="s:loc"/></a></td><td><xsl:value-of select="s:lastmod"/></td></tr></xsl:for-each></table></xsl:if>
</body></html></xsl:template></xsl:stylesheet>';
	}

	/**
	 * Current cache version.
	 */
	public function version(): int {
		return (int) get_option( self::VERSION_OPTION, 1 );
	}

	/**
	 * Invalidate cached sitemaps.
	 */
	public function invalidate(): void {
		update_option( self::VERSION_OPTION, $this->version() + 1, true );
	}

	/**
	 * Signal sitemap changes on publish/unpublish so Search Console submission can be debounced.
	 *
	 * @param string   $new  New status.
	 * @param string   $old  Old status.
	 * @param \WP_Post $post Post.
	 */
	public function status_changed( string $new, string $old, \WP_Post $post ): void {
		if ( $new === $old || ( 'publish' !== $new && 'publish' !== $old ) || wp_is_post_revision( $post ) ) {
			return;
		}
		$this->invalidate();
		/**
		 * Fires when a post enters or leaves the published set.
		 *
		 * @param \WP_Post $post Post.
		 * @param string   $new  New status.
		 * @param string   $old  Old status.
		 */
		do_action( 'flseo_sitemap_changed', $post, $new, $old );
	}

	/**
	 * Add the sitemap to robots.txt.
	 *
	 * @param string $output Robots.txt.
	 * @param bool   $public Whether the site is public.
	 */
	public function robots_txt( $output, $public ): string {
		$output = (string) $output;
		if ( $public && ! str_contains( $output, self::index_url() ) ) {
			$output = rtrim( $output ) . "\n\nSitemap: " . self::index_url() . "\n";
		}
		return $output;
	}

	/**
	 * Prevent WordPress adding a trailing slash to sitemap URLs.
	 *
	 * @param string|false $redirect Redirect URL.
	 * @param string       $request  Requested URL.
	 * @return string|false
	 */
	public function no_trailing_slash( $redirect, $request ) {
		if ( is_string( $request ) && preg_match( '~(sitemap_index|-sitemap\d*)\.xml$|flseo-sitemap\.xsl$~', (string) wp_parse_url( $request, PHP_URL_PATH ) ) ) {
			return false;
		}
		return $redirect;
	}
}
