<?php
/**
 * NewsTheme Posts Grid Widget.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Posts grid: image cards (1 or 2 columns), optional "show more" link.
 */
class NewsTheme_Posts_Grid_Widget extends NewsTheme_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->fields = array_merge(
			array(
				'title'   => array(
					'type'    => 'text',
					'label'   => __( 'Title', 'newstheme' ),
					'default' => __( 'Trending News', 'newstheme' ),
				),
				'columns' => array(
					'type'    => 'select',
					'label'   => __( 'Columns', 'newstheme' ),
					'default' => '1',
					'choices' => array(
						'1' => '1',
						'2' => '2',
					),
				),
			),
			self::post_fields( 4 ),
			array(
				'show_more' => array(
					'type'    => 'checkbox',
					'label'   => __( 'Show "Show more" link', 'newstheme' ),
					'default' => true,
				),
			)
		);
		parent::__construct( 'posts_grid', __( 'NewsTheme: Posts Grid', 'newstheme' ), __( 'Image cards with centered titles.', 'newstheme' ) );
	}

	/**
	 * Render.
	 *
	 * @param array $values Instance values.
	 */
	protected function render( array $values ) {
		$query = $this->posts_query( $values );
		if ( ! $query->have_posts() ) {
			return;
		}
		printf( '<div class="nt-wgrid nt-grid nt-grid--%d">', (int) $values['columns'] );
		while ( $query->have_posts() ) {
			$query->the_post();
			echo '<article class="nt-post nt-post--centered nt-wgrid__item">';
			newstheme_post_thumb( 'newstheme-medium', array( 'badge' => true ) );
			newstheme_post_title( 'h3' );
			echo '</article>';
		}
		echo '</div>';
		wp_reset_postdata();

		if ( $values['show_more'] ) {
			$url = $values['category'] ? get_category_link( (int) $values['category'] ) : ( get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/' ) );
			printf( '<div class="nt-wgrid__more"><a class="nt-pill" href="%1$s">%2$s</a></div>', esc_url( $url ), esc_html__( 'Show more', 'newstheme' ) );
		}
	}
}
