<?php
/**
 * Block editor integration: editor styles (including Customizer colors and
 * fonts), a quote block style and block patterns.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Editor styles and core block styles.
 */
function newstheme_editor_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor.css' );
}
add_action( 'after_setup_theme', 'newstheme_editor_setup' );

/**
 * Apply the site's Customizer colors and typography inside the editor too.
 *
 * @param array $settings Editor settings.
 * @return array
 */
function newstheme_editor_dynamic_css( $settings ) {
	$css = newstheme_build_css( newstheme_all_settings(), newstheme_current_css_values(), newstheme_font_families() );
	if ( $css ) {
		$settings['styles'][] = array( 'css' => str_replace( array( '<', '>' ), '', $css ) );
	}
	return $settings;
}
add_filter( 'block_editor_settings_all', 'newstheme_editor_dynamic_css' );

/**
 * Block style and pattern category.
 */
function newstheme_register_block_extras() {
	register_block_style(
		'core/quote',
		array(
			'name'  => 'newstheme-highlight',
			'label' => __( 'Highlight', 'newstheme' ),
		)
	);
	register_block_pattern_category(
		'newstheme',
		array( 'label' => __( 'NewsTheme', 'newstheme' ) )
	);
}
add_action( 'init', 'newstheme_register_block_extras' );
