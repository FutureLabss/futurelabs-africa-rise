<?php
/**
 * Archive hero: the newest post as a full-width overlay card.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<article <?php post_class( 'nt-overlay-card nt-overlay-card--large nt-archive-hero' ); ?>>
	<?php newstheme_post_thumb( 'full', array( 'eager' => true ) ); ?>
	<div class="nt-overlay-card__body">
		<?php newstheme_post_categories(); ?>
		<?php newstheme_post_title( 'h2' ); ?>
		<div class="nt-overlay-card__top">
			<?php
			newstheme_posted_by( null, true );
			newstheme_posted_on( null, true );
			?>
		</div>
	</div>
</article>
