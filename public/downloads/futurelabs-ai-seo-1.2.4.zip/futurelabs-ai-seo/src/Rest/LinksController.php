<?php
/**
 * REST: internal link graph, suggestions and navigation coverage.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Links\Depth;
use FutureLabs\AISEO\Links\Graph;
use FutureLabs\AISEO\Links\Orphans;
use FutureLabs\AISEO\Links\Suggester;

defined( 'ABSPATH' ) || exit;

/**
 * Routes under /links.
 */
class LinksController extends Controller {

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		$this->route( '/links/orphans', 'GET', array( $this, 'orphans' ) );
		$this->route( '/links/depth', 'GET', array( $this, 'depth' ) );
		$this->route( '/links/broken', 'GET', array( $this, 'broken' ) );
		$this->route( '/links/navigation', 'GET', array( $this, 'navigation' ) );
		$this->route( '/links/compute', 'POST', array( $this, 'compute' ) );
		$post_arg = array(
			'post_id' => array(
				'type'     => 'integer',
				'required' => true,
			),
		);
		foreach ( array(
			'/links/suggest'             => 'suggest',
			'/links/inbound-suggestions' => 'inbound',
		) as $path => $method ) {
			register_rest_route(
				self::NAMESPACE,
				$path,
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, $method ),
					'permission_callback' => static function ( \WP_REST_Request $request ): bool {
						return Capabilities::can( Capabilities::EDITOR ) && current_user_can( 'edit_post', absint( $request->get_param( 'post_id' ) ) );
					},
					'args'                => $post_arg,
				)
			);
		}
	}

	/**
	 * GET /links/orphans?kind=orphan|weak&post_type=.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	public function orphans( \WP_REST_Request $request ): array {
		list( $page, $per_page ) = $this->paging( $request );
		$kind                    = 'weak' === $request->get_param( 'kind' ) ? 'weak' : 'orphan';
		$list                    = $this->c->get( Orphans::class )->list( $kind, $page, $per_page, sanitize_key( (string) $request->get_param( 'post_type' ) ) );
		return $list + array(
			'kind'        => $kind,
			'page'        => $page,
			'per_page'    => $per_page,
			'computed_at' => (string) $this->c->get( Graph::class )->state()['computed_at'],
		);
	}

	/**
	 * GET /links/depth?min_depth=5.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	public function depth( \WP_REST_Request $request ): array {
		list( $page, $per_page ) = $this->paging( $request );
		$min                     = absint( $request->get_param( 'min_depth' ) ? $request->get_param( 'min_depth' ) : Graph::DEEP + 1 );
		$depth                   = $this->c->get( Depth::class );
		$state                   = $this->c->get( Graph::class )->state();
		return $depth->deep( max( 1, $min ), $page, $per_page ) + array(
			'distribution' => $depth->distribution(),
			'min_depth'    => $min,
			'summary'      => $state,
			'page'         => $page,
			'per_page'     => $per_page,
		);
	}

	/**
	 * GET /links/broken.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	public function broken( \WP_REST_Request $request ): array {
		list( $page, $per_page ) = $this->paging( $request );
		return $this->c->get( Graph::class )->broken( $page, $per_page ) + array(
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	/**
	 * GET /links/navigation.
	 *
	 * @return array<string, mixed>
	 */
	public function navigation(): array {
		return $this->c->get( Graph::class )->navigation_coverage();
	}

	/**
	 * POST /links/compute.
	 *
	 * @return array<string, mixed>
	 */
	public function compute(): array {
		$this->c->get( Queue::class )->async( 'flseo_graph_compute' );
		return array(
			'queued' => true,
			'last'   => $this->c->get( Graph::class )->state(),
		);
	}

	/**
	 * GET /links/suggest?post_id=: posts to link to, plus related-by-category,
	 * related-by-programme and "Related opportunities" placement.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function suggest( \WP_REST_Request $request ) {
		$id = absint( $request->get_param( 'post_id' ) );
		if ( ! get_post( $id ) ) {
			return $this->error( 'not_found', __( 'Post not found.', 'futurelabs-ai-seo' ), 404 );
		}
		$suggester = $this->c->get( Suggester::class );
		return array(
			'post_id'   => $id,
			'provider'  => $suggester->provider()->name(),
			'items'     => $suggester->suggest( $id, min( 20, absint( $request->get_param( 'limit' ) ? $request->get_param( 'limit' ) : 10 ) ) ),
			'related'   => array(
				'category'  => $suggester->related_by_category( $id ),
				'programme' => $suggester->related_by_programme( $id ),
			),
			'placement' => $suggester->placement( $id ),
		);
	}

	/**
	 * GET /links/inbound-suggestions?post_id=: pages that should link to this post.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function inbound( \WP_REST_Request $request ) {
		$id = absint( $request->get_param( 'post_id' ) );
		if ( ! get_post( $id ) ) {
			return $this->error( 'not_found', __( 'Post not found.', 'futurelabs-ai-seo' ), 404 );
		}
		$suggester = $this->c->get( Suggester::class );
		return array(
			'post_id'  => $id,
			'provider' => $suggester->provider()->name(),
			'items'    => $suggester->inbound_suggestions( $id, min( 20, absint( $request->get_param( 'limit' ) ? $request->get_param( 'limit' ) : 10 ) ) ),
		);
	}
}
