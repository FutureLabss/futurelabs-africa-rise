<?php
/**
 * Normalizes URL Inspection API results into Search Console reason codes.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Indexing;

use FutureLabs\AISEO\Core\Container;

defined( 'ABSPATH' ) || exit;

/**
 * Maps `indexStatusResult` fields to stable reason codes with labels and fix suggestions.
 */
class Reasons {

	public const INDEXED                = 'indexed';
	public const CRAWLED_NOT_INDEXED    = 'crawled_not_indexed';
	public const DISCOVERED_NOT_INDEXED = 'discovered_not_indexed';
	public const NOINDEX                = 'noindex';
	public const NOT_FOUND              = 'not_found_404';
	public const SOFT_404               = 'soft_404';
	public const SERVER_ERROR           = 'server_error_5xx';
	public const BLOCKED_403            = 'blocked_403';
	public const BLOCKED_401            = 'blocked_401';
	public const BLOCKED_ROBOTS         = 'blocked_robots';
	public const REDIRECT               = 'redirect';
	public const DUPLICATE_NO_CANONICAL = 'duplicate_no_canonical';
	public const DUPLICATE_GOOGLE_CHOSE = 'duplicate_google_chose_different';
	public const ALTERNATE_CANONICAL    = 'alternate_canonical';
	public const URL_UNKNOWN            = 'url_unknown';
	public const OTHER                  = 'other';

	/**
	 * Pseudo-code for pages that have no inspection result yet. Never returned by from_result().
	 */
	public const NOT_INSPECTED = 'not_inspected';

	/**
	 * Ordered coverageState patterns (lower-case substrings) to reason codes.
	 * More specific phrases come before generic ones.
	 */
	private const COVERAGE_PATTERNS = array(
		'indexed, though blocked'                 => self::INDEXED,
		'blocked by robots.txt'                   => self::BLOCKED_ROBOTS,
		'submitted and indexed'                   => self::INDEXED,
		'indexed, not submitted'                  => self::INDEXED,
		'crawled - currently not indexed'         => self::CRAWLED_NOT_INDEXED,
		'crawled – currently not indexed'         => self::CRAWLED_NOT_INDEXED,
		'crawled, currently not indexed'          => self::CRAWLED_NOT_INDEXED,
		'discovered - currently not indexed'      => self::DISCOVERED_NOT_INDEXED,
		'discovered – currently not indexed'      => self::DISCOVERED_NOT_INDEXED,
		'discovered, currently not indexed'       => self::DISCOVERED_NOT_INDEXED,
		'noindex'                                 => self::NOINDEX,
		'soft 404'                                => self::SOFT_404,
		'not found (404)'                         => self::NOT_FOUND,
		'server error'                            => self::SERVER_ERROR,
		'(5xx)'                                   => self::SERVER_ERROR,
		'access forbidden'                        => self::BLOCKED_403,
		'(403)'                                   => self::BLOCKED_403,
		'unauthorized request'                    => self::BLOCKED_401,
		'(401)'                                   => self::BLOCKED_401,
		'google chose different canonical'        => self::DUPLICATE_GOOGLE_CHOSE,
		'submitted url not selected as canonical' => self::DUPLICATE_GOOGLE_CHOSE,
		'without user-selected canonical'         => self::DUPLICATE_NO_CANONICAL,
		'alternate page with proper canonical'    => self::ALTERNATE_CANONICAL,
		'page with redirect'                      => self::REDIRECT,
		'redirect error'                          => self::REDIRECT,
		'url is unknown to google'                => self::URL_UNKNOWN,
	);

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Every reason code with label, fix suggestion and whether it usually needs action.
	 *
	 * @return array<string, array{label: string, fix: string, actionable: bool}>
	 */
	public static function all(): array {
		return array(
			self::INDEXED                => array(
				'label'      => __( 'Indexed', 'futurelabs-ai-seo' ),
				'fix'        => __( 'No action needed. Google reports this URL as indexed.', 'futurelabs-ai-seo' ),
				'actionable' => false,
			),
			self::CRAWLED_NOT_INDEXED    => array(
				'label'      => __( 'Crawled - currently not indexed', 'futurelabs-ai-seo' ),
				'fix'        => __( 'Google fetched the page but chose not to index it yet. Make the page clearly more useful than similar pages (unique details, complete sections), add internal links from related indexed pages, then request a new inspection. Thin or near-duplicate pages may be better merged or noindexed.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::DISCOVERED_NOT_INDEXED => array(
				'label'      => __( 'Discovered - currently not indexed', 'futurelabs-ai-seo' ),
				'fix'        => __( 'Google knows the URL but has not crawled it yet. Keep it in the sitemap, link to it from important indexed pages, and check that the server responds quickly. This often resolves with time.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::NOINDEX                => array(
				'label'      => __( "Excluded by 'noindex' tag", 'futurelabs-ai-seo' ),
				'fix'        => __( 'The page tells search engines not to index it (meta robots or X-Robots-Tag header). If you want it indexed, remove the noindex in FutureLabs AI SEO or the other plugin or theme that adds it. If the noindex is intended, nothing to do.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::NOT_FOUND              => array(
				'label'      => __( 'Not found (404)', 'futurelabs-ai-seo' ),
				'fix'        => __( 'Google got a 404 for this URL. If the content moved, add a 301 redirect to the new URL. If it was removed on purpose, keep the 404 (or use 410) and remove internal links to it.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::SOFT_404               => array(
				'label'      => __( 'Soft 404', 'futurelabs-ai-seo' ),
				'fix'        => __( 'The page returns 200 but looks empty or like an error page to Google. Add real content, or return a proper 404/410, or redirect it to a relevant page.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::SERVER_ERROR           => array(
				'label'      => __( 'Server error (5xx)', 'futurelabs-ai-seo' ),
				'fix'        => __( 'Google received a server error when fetching the page. Check server logs, hosting resource limits and security or firewall rules that may block Googlebot, then request a new inspection.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::BLOCKED_403            => array(
				'label'      => __( 'Blocked due to access forbidden (403)', 'futurelabs-ai-seo' ),
				'fix'        => __( 'The server refused Googlebot with 403. Check security plugins, firewall or CDN bot rules, and make sure the page is public.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::BLOCKED_401            => array(
				'label'      => __( 'Blocked due to unauthorized request (401)', 'futurelabs-ai-seo' ),
				'fix'        => __( 'The page requires a login or password. Make it public if it should be indexed, or remove it from the sitemap if it is private.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::BLOCKED_ROBOTS         => array(
				'label'      => __( 'Blocked by robots.txt', 'futurelabs-ai-seo' ),
				'fix'        => __( 'A robots.txt rule stops Google from crawling this URL. Edit robots.txt to allow it if it should be indexed. To keep a page out of the index, use noindex instead of robots.txt.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::REDIRECT               => array(
				'label'      => __( 'Page with redirect', 'futurelabs-ai-seo' ),
				'fix'        => __( 'This URL redirects elsewhere, so Google indexes the target instead. Update internal links and the sitemap to point to the final URL. Fix redirect chains or loops if Google reports a redirect error.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::DUPLICATE_NO_CANONICAL => array(
				'label'      => __( 'Duplicate without user-selected canonical', 'futurelabs-ai-seo' ),
				'fix'        => __( 'Google sees this page as a duplicate of another URL and no canonical was declared. Make the content distinct, or merge it into the main page and redirect, or set a canonical pointing to the preferred URL.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::DUPLICATE_GOOGLE_CHOSE => array(
				'label'      => __( 'Duplicate, Google chose different canonical than user', 'futurelabs-ai-seo' ),
				'fix'        => __( 'You declared this page as canonical, but Google picked another URL. Compare the two pages: make this one clearly distinct, or accept Google\'s choice by merging and redirecting to it.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::ALTERNATE_CANONICAL    => array(
				'label'      => __( 'Alternate page with proper canonical tag', 'futurelabs-ai-seo' ),
				'fix'        => __( 'This page points to another URL as canonical and Google respected it. No action needed if that is intended.', 'futurelabs-ai-seo' ),
				'actionable' => false,
			),
			self::URL_UNKNOWN            => array(
				'label'      => __( 'URL is unknown to Google', 'futurelabs-ai-seo' ),
				'fix'        => __( 'Google has not seen this URL yet. Make sure it is in the submitted sitemap and linked from other pages on your site.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::OTHER                  => array(
				'label'      => __( 'Other', 'futurelabs-ai-seo' ),
				'fix'        => __( 'Google reported a status FutureLabs AI SEO does not classify. Open the URL Inspection tool in Search Console for details.', 'futurelabs-ai-seo' ),
				'actionable' => true,
			),
			self::NOT_INSPECTED          => array(
				'label'      => __( 'Not inspected yet', 'futurelabs-ai-seo' ),
				'fix'        => __( 'FutureLabs AI SEO has no Search Console data for this page yet. Connect Search Console and queue an inspection.', 'futurelabs-ai-seo' ),
				'actionable' => false,
			),
		);
	}

	/**
	 * Label for a reason code.
	 *
	 * @param string $code Reason code.
	 */
	public static function label( string $code ): string {
		$all = self::all();
		return $all[ $code ]['label'] ?? $all[ self::OTHER ]['label'];
	}

	/**
	 * Fix suggestion for a reason code.
	 *
	 * @param string $code Reason code.
	 */
	public static function fix( string $code ): string {
		$all = self::all();
		return $all[ $code ]['fix'] ?? $all[ self::OTHER ]['fix'];
	}

	/**
	 * Whether a reason usually needs action.
	 *
	 * @param string $code Reason code.
	 */
	public static function actionable( string $code ): bool {
		$all = self::all();
		return (bool) ( $all[ $code ]['actionable'] ?? true );
	}

	/**
	 * Reason code from a URL Inspection response, its `inspectionResult`, or its `indexStatusResult`.
	 *
	 * @param array<string, mixed> $result API data.
	 */
	public function from_result( array $result ): string {
		$status = self::index_status( $result );
		$code   = $this->from_coverage( (string) ( $status['coverageState'] ?? '' ) );
		if ( null === $code ) {
			$code = $this->from_fields( $status );
		}
		/**
		 * Filter the reason code FutureLabs AI SEO assigns to an inspection result.
		 *
		 * @param string               $code   Reason code.
		 * @param array<string, mixed> $status indexStatusResult.
		 */
		$code = (string) apply_filters( 'flseo_inspection_reason', $code, $status );
		return array_key_exists( $code, self::all() ) ? $code : self::OTHER;
	}

	/**
	 * Extract `indexStatusResult` from any of the accepted shapes.
	 *
	 * @param array<string, mixed> $result API data.
	 * @return array<string, mixed>
	 */
	public static function index_status( array $result ): array {
		if ( isset( $result['inspectionResult']['indexStatusResult'] ) && is_array( $result['inspectionResult']['indexStatusResult'] ) ) {
			return $result['inspectionResult']['indexStatusResult'];
		}
		if ( isset( $result['indexStatusResult'] ) && is_array( $result['indexStatusResult'] ) ) {
			return $result['indexStatusResult'];
		}
		return $result;
	}

	/**
	 * Match the human coverageState string.
	 *
	 * @param string $coverage coverageState.
	 */
	private function from_coverage( string $coverage ): ?string {
		$coverage = strtolower( trim( $coverage ) );
		if ( '' === $coverage ) {
			return null;
		}
		foreach ( self::COVERAGE_PATTERNS as $needle => $code ) {
			if ( str_contains( $coverage, $needle ) ) {
				return $code;
			}
		}
		return null;
	}

	/**
	 * Fall back to the structured enum fields when coverageState is missing or unrecognized.
	 *
	 * @param array<string, mixed> $status indexStatusResult.
	 */
	private function from_fields( array $status ): string {
		$verdict  = strtoupper( (string) ( $status['verdict'] ?? '' ) );
		$indexing = strtoupper( (string) ( $status['indexingState'] ?? '' ) );
		$robots   = strtoupper( (string) ( $status['robotsTxtState'] ?? '' ) );
		$fetch    = strtoupper( (string) ( $status['pageFetchState'] ?? '' ) );

		if ( 'PASS' === $verdict ) {
			return self::INDEXED;
		}
		if ( in_array( $indexing, array( 'BLOCKED_BY_META_TAG', 'BLOCKED_BY_HTTP_HEADER' ), true ) ) {
			return self::NOINDEX;
		}
		if ( 'DISALLOWED' === $robots || 'BLOCKED_BY_ROBOTS_TXT' === $indexing || 'BLOCKED_ROBOTS_TXT' === $fetch ) {
			return self::BLOCKED_ROBOTS;
		}
		$fetch_map = array(
			'SOFT_404'         => self::SOFT_404,
			'NOT_FOUND'        => self::NOT_FOUND,
			'SERVER_ERROR'     => self::SERVER_ERROR,
			'ACCESS_DENIED'    => self::BLOCKED_401,
			'ACCESS_FORBIDDEN' => self::BLOCKED_403,
			'REDIRECT_ERROR'   => self::REDIRECT,
		);
		if ( isset( $fetch_map[ $fetch ] ) ) {
			return $fetch_map[ $fetch ];
		}
		$google = (string) ( $status['googleCanonical'] ?? '' );
		$user   = (string) ( $status['userCanonical'] ?? '' );
		if ( '' !== $google && '' !== $user && ! \FutureLabs\AISEO\Meta\CanonicalResolver::same_url( $google, $user ) ) {
			return self::DUPLICATE_GOOGLE_CHOSE;
		}
		if ( 'VERDICT_UNSPECIFIED' === $verdict && '' === $fetch && '' === $google ) {
			return self::URL_UNKNOWN;
		}
		return self::OTHER;
	}
}
