<?php
/**
 * Base class for importing SEO data from other plugins.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Importers;

use FutureLabs\AISEO\Bulk\AuditLog;
use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Meta\NoindexGuard;
use FutureLabs\AISEO\Meta\PostMeta;
use FutureLabs\AISEO\Redirects\Rules;
use FutureLabs\AISEO\Schema\Types;

defined( 'ABSPATH' ) || exit;

/**
 * Maps source post meta, term meta and redirects to FutureLabs AI SEO keys.
 *
 * Each run processes one page (offset/limit) of posts, terms and redirects, returns a
 * diff (post_id, title, field, current, new) in dry-run mode, and otherwise writes the
 * changes in one audit batch so `Bulk\Undo` rolls the import back.
 */
abstract class Importer {

	public const MAX_LIMIT  = 500;
	public const KINDS      = array( 'posts', 'terms', 'redirects', 'settings' );
	public const DIFF_LIMIT = 1000;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	protected Container $c;

	/**
	 * Unsupported variables removed while converting templates during this run.
	 *
	 * @var array<string, true>
	 */
	protected array $unsupported = array();

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Source slug (yoast, aioseo, rankmath).
	 */
	abstract public function slug(): string;

	/**
	 * Human name.
	 */
	abstract public function label(): string;

	/**
	 * Number of posts, terms and redirects with source data.
	 *
	 * @return array{posts: int, terms: int, redirects: int}
	 */
	abstract public function count(): array;

	/**
	 * Post IDs with source data, ordered by ID.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, int>
	 */
	abstract protected function post_ids( int $offset, int $limit ): array;

	/**
	 * Source values for one post keyed by FutureLabs AI SEO field (title, description, canonical,
	 * og_title, og_description, og_image, focus_topic, schema_type, noindex). Template
	 * fields are returned in the source syntax; the base class converts them.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string, string>
	 */
	abstract protected function post_fields( int $post_id ): array;

	/**
	 * Source template variables mapped to FutureLabs AI SEO variables ('' = unsupported, removed).
	 *
	 * @return array<string, string>
	 */
	abstract protected function variable_map(): array;

	/**
	 * Regex matching one source variable; group 1 is the variable name.
	 */
	abstract protected function variable_pattern(): string;

	/**
	 * Term IDs with source data.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, int>
	 */
	protected function term_ids( int $offset, int $limit ): array {
		unset( $offset, $limit );
		return array();
	}

	/**
	 * Source values for one term keyed by FutureLabs AI SEO term field.
	 *
	 * @param int $term_id Term ID.
	 * @return array<string, string>
	 */
	protected function term_fields( int $term_id ): array {
		unset( $term_id );
		return array();
	}

	/**
	 * Redirect rules: list of {source, target, type, is_regex}.
	 *
	 * @param int $offset Offset in source rows.
	 * @param int $limit  Limit.
	 * @return array<int, array{source: string, target: string, type: int, is_regex: bool}>
	 */
	protected function redirect_rows( int $offset, int $limit ): array {
		unset( $offset, $limit );
		return array();
	}

	/**
	 * Site-wide settings from the source plugin, in FutureLabs AI SEO's format:
	 * any of `title_separator`, `home_title`, `home_description`, and
	 * `post_types` / `taxonomies` entries with `title`, `description`, `index`.
	 * Templates are raw source templates; they are converted on import.
	 *
	 * @return array<string, mixed>
	 */
	protected function settings_fields(): array {
		return array();
	}

	/**
	 * Post IDs the source excluded from its XML sitemap (reported, not imported).
	 *
	 * @return array<int, int>
	 */
	public function sitemap_excluded(): array {
		return array();
	}

	/**
	 * Whether this source has anything to import.
	 */
	public function detect(): bool {
		return array_sum( $this->count() ) > 0;
	}

	/**
	 * Convert a source template to FutureLabs AI SEO variables.
	 *
	 * @param string $template Source template.
	 */
	public function convert_template( string $template ): string {
		$map = $this->variable_map();
		$out = (string) preg_replace_callback(
			$this->variable_pattern(),
			function ( array $m ) use ( $map ): string {
				$name = strtolower( $m[1] );
				if ( ! array_key_exists( $name, $map ) ) {
					return $this->unknown_variable( $m[0] );
				}
				if ( '' === $map[ $name ] ) {
					$this->unsupported[ $m[0] ] = true;
				}
				return $map[ $name ];
			},
			$template
		);
		return PostMeta::sanitize_template( $out );
	}

	/**
	 * Handle a variable-looking token that is not in the map.
	 *
	 * @param string $token Token.
	 */
	protected function unknown_variable( string $token ): string {
		$this->unsupported[ $token ] = true;
		return '';
	}

	/**
	 * Run one page of the import.
	 *
	 * @param array<string, mixed> $options dry_run, offset, limit, include, batch_id, confirmation.
	 * @return array<string, mixed>
	 */
	public function run( array $options ): array {
		$this->unsupported = array();
		$dry_run           = ! isset( $options['dry_run'] ) || ( ! empty( $options['dry_run'] ) && 'false' !== $options['dry_run'] );
		$offset            = max( 0, (int) ( $options['offset'] ?? 0 ) );
		$limit             = min( self::MAX_LIMIT, max( 1, (int) ( $options['limit'] ?? 100 ) ) );
		$include           = array_values( array_intersect( self::KINDS, (array) ( $options['include'] ?? self::KINDS ) ) );
		$include           = $include ? $include : self::KINDS;
		$batch             = isset( $options['batch_id'] ) && wp_is_uuid( (string) $options['batch_id'] ) ? (string) $options['batch_id'] : $this->c->get( AuditLog::class )->new_batch();

		$changes = array();
		$errors  = array();
		$notes   = array();
		if ( in_array( 'posts', $include, true ) ) {
			$changes = array_merge( $changes, $this->post_changes( $offset, $limit ) );
		}
		if ( in_array( 'terms', $include, true ) ) {
			$changes = array_merge( $changes, $this->term_changes( $offset, $limit ) );
		}
		if ( in_array( 'redirects', $include, true ) ) {
			$changes = array_merge( $changes, $this->redirect_changes( $offset, $limit, $notes ) );
		}
		if ( 0 === $offset && in_array( 'settings', $include, true ) ) {
			$changes = array_merge( $changes, $this->settings_changes( $notes ) );
		}

		$totals = $this->count();
		$max    = 0;
		foreach ( $include as $kind ) {
			$max = max( $max, (int) ( $totals[ $kind ] ?? 0 ) );
		}
		$next = $offset + $limit < $max ? $offset + $limit : null;

		if ( 0 === $offset && in_array( 'posts', $include, true ) ) {
			$excluded = $this->sitemap_excluded();
			if ( $excluded ) {
				$notes[] = sprintf(
					/* translators: 1: source plugin, 2: number of posts. */
					__( '%1$s excluded %2$d posts from its sitemap without noindexing them. FutureLabs AI SEO lists every indexable page in its sitemap, so these posts are not changed. Review them and noindex any that should stay out of search.', 'futurelabs-ai-seo' ),
					$this->label(),
					count( $excluded )
				);
			}
		}
		// @phpstan-ignore-next-line -- filled by convert_template() calls made after the reset.
		if ( $this->unsupported ) {
			$notes[] = sprintf(
				/* translators: %s: comma-separated variables. */
				__( 'These variables have no FutureLabs AI SEO equivalent and were removed from imported titles and descriptions: %s', 'futurelabs-ai-seo' ),
				implode( ', ', array_keys( $this->unsupported ) )
			);
		}

		$noindex = array();
		foreach ( $changes as $change ) {
			if ( 'post' === $change['object_type'] && 'noindex' === $change['field'] && '1' === $change['new'] ) {
				$noindex[] = $change['object_id'];
			}
		}
		$guard   = $this->c->get( NoindexGuard::class );
		$verdict = $noindex ? $guard->check_posts( $noindex, (string) ( $options['confirmation'] ?? '' ) ) : null;

		$result = array(
			'source'      => $this->slug(),
			'dry_run'     => $dry_run,
			'offset'      => $offset,
			'limit'       => $limit,
			'next_offset' => $next,
			'totals'      => $totals,
			'count'       => count( $changes ),
			'changes'     => array_slice( $this->public_changes( $changes ), 0, self::DIFF_LIMIT ),
			'notes'       => $notes,
			'errors'      => $errors,
			'batch_id'    => null,
			'applied'     => 0,
		);
		if ( $verdict ) {
			$result['confirmation'] = array(
				'required'  => ! $guard->check_posts( $noindex )['allowed'],
				'phrase'    => $verdict['phrase'],
				'projected' => $verdict['projected'],
				'published' => $verdict['published'],
			);
		}
		if ( $dry_run ) {
			return $result;
		}
		if ( $verdict && ! $verdict['allowed'] ) {
			$result['confirmation_required'] = true;
			return $result;
		}
		$applied = $this->commit( $changes, $batch, $errors );
		if ( $applied ) {
			$result['batch_id'] = $batch;
		}
		$result['applied'] = $applied;
		$result['errors']  = $errors;
		return $result;
	}

	/**
	 * Pending settings changes. Noindexing every post or page is never imported
	 * (fail safe); it is reported as a note instead.
	 *
	 * @param array<int, string> $notes Notes (appended).
	 * @return array<int, array<string, mixed>>
	 */
	private function settings_changes( array &$notes ): array {
		$source = $this->settings_fields();
		if ( ! $source ) {
			return array();
		}
		if ( ! Capabilities::can( Capabilities::SETTINGS ) ) {
			$notes[] = __( 'Site-wide settings were skipped: you need access to FutureLabs AI SEO settings to import them.', 'futurelabs-ai-seo' );
			return array();
		}
		$settings = $this->c->get( Settings::class );
		$changes  = array();
		$add      = function ( array $path, string $label, $current, $value ) use ( &$changes ): void {
			if ( $current === $value ) {
				return;
			}
			$changes[] = array(
				'object_type' => 'settings',
				'object_id'   => 0,
				'title'       => $label,
				'field'       => implode( '.', $path ),
				'path'        => $path,
				'current'     => $current,
				'new'         => $value,
			);
		};
		if ( isset( $source['title_separator'] ) && '' !== trim( (string) $source['title_separator'] ) ) {
			$add( array( 'title_separator' ), __( 'Title separator', 'futurelabs-ai-seo' ), (string) $settings->get( 'title_separator' ), sanitize_text_field( (string) $source['title_separator'] ) );
		}
		foreach ( array(
			'home_title'       => __( 'Home page title', 'futurelabs-ai-seo' ),
			'home_description' => __( 'Home page description', 'futurelabs-ai-seo' ),
		) as $key => $label ) {
			if ( isset( $source[ $key ] ) && '' !== trim( (string) $source[ $key ] ) ) {
				$add( array( $key ), $label, (string) $settings->get( $key ), PostMeta::sanitize_template( $this->convert_template( (string) $source[ $key ] ) ) );
			}
		}
		foreach ( array( 'post_types', 'taxonomies' ) as $group ) {
			foreach ( (array) ( $source[ $group ] ?? array() ) as $name => $entry ) {
				$name   = (string) $name;
				$object = 'post_types' === $group ? get_post_type_object( $name ) : get_taxonomy( $name );
				if ( ! $object || ! is_array( $entry ) ) {
					continue;
				}
				// Effective settings (saved or computed defaults) for this type.
				$current = array( $name => $this->type_entry( $group, $name ) );
				$type    = (string) $object->labels->name;
				foreach ( array( 'title', 'description' ) as $field ) {
					if ( isset( $entry[ $field ] ) && '' !== trim( (string) $entry[ $field ] ) ) {
						$add(
							array( $group, $name, $field ),
							/* translators: 1: content type or taxonomy, 2: "title" or "description". */
							sprintf( __( '%1$s: %2$s template', 'futurelabs-ai-seo' ), $type, 'title' === $field ? __( 'title', 'futurelabs-ai-seo' ) : __( 'description', 'futurelabs-ai-seo' ) ),
							(string) ( $current[ $name ][ $field ] ?? '' ),
							PostMeta::sanitize_template( $this->convert_template( (string) $entry[ $field ] ) )
						);
					}
				}
				if ( isset( $entry['index'] ) ) {
					$index = (bool) $entry['index'];
					if ( ! $index && 'post_types' === $group && in_array( $name, array( 'post', 'page' ), true ) ) {
						$notes[] = sprintf(
							/* translators: 1: source plugin, 2: content type. */
							__( '%1$s hides all %2$s from search results. That was not imported, because it would noindex every one of them; change it under Settings → Content types if it is really intended.', 'futurelabs-ai-seo' ),
							$this->label(),
							$type
						);
						continue;
					}
					/* translators: %s: content type or taxonomy. */
					$add( array( $group, $name, 'index' ), sprintf( __( '%s: show in search results', 'futurelabs-ai-seo' ), $type ), (bool) ( $current[ $name ]['index'] ?? true ), $index );
				}
			}
		}
		return $changes;
	}

	/**
	 * Pending post changes for one page.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, array<string, mixed>>
	 */
	private function post_changes( int $offset, int $limit ): array {
		$changes = array();
		$ids     = $this->post_ids( $offset, $limit );
		_prime_post_caches( $ids, false, true );
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post instanceof \WP_Post || ! current_user_can( 'edit_post', $id ) ) {
				continue;
			}
			foreach ( $this->post_fields( $id ) as $field => $raw ) {
				$new = $this->clean( $field, (string) $raw );
				if ( '' === $new ) {
					continue;
				}
				$key     = '_flseo_' . $field;
				$current = (string) get_post_meta( $id, $key, true );
				if ( $current === $new ) {
					continue;
				}
				$changes[] = array(
					'object_type' => 'post',
					'object_id'   => $id,
					'title'       => wp_strip_all_tags( get_the_title( $post ) ),
					'field'       => $field,
					'key'         => $key,
					'current'     => $current,
					'new'         => $new,
				);
			}
		}
		return $changes;
	}

	/**
	 * Pending term changes for one page.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, array<string, mixed>>
	 */
	private function term_changes( int $offset, int $limit ): array {
		$changes = array();
		foreach ( $this->term_ids( $offset, $limit ) as $id ) {
			$term = get_term( $id );
			if ( ! $term instanceof \WP_Term || ! current_user_can( 'edit_term', $id ) ) {
				continue;
			}
			foreach ( $this->term_fields( $id ) as $field => $raw ) {
				if ( 'focus_topic' === $field || 'schema_type' === $field ) {
					continue;
				}
				$new = $this->clean( $field, (string) $raw );
				if ( '' === $new ) {
					continue;
				}
				$key     = '_flseo_' . $field;
				$current = (string) get_term_meta( $id, $key, true );
				if ( $current === $new ) {
					continue;
				}
				$changes[] = array(
					'object_type' => 'term',
					'object_id'   => $id,
					'title'       => $term->name,
					'field'       => $field,
					'key'         => $key,
					'current'     => $current,
					'new'         => $new,
				);
			}
		}
		return $changes;
	}

	/**
	 * Pending redirect changes for one page.
	 *
	 * @param int                $offset Offset.
	 * @param int                $limit  Limit.
	 * @param array<int, string> $notes  Notes (appended).
	 * @return array<int, array<string, mixed>>
	 */
	private function redirect_changes( int $offset, int $limit, array &$notes ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array();
		}
		$changes     = array();
		$unsupported = 0;
		foreach ( $this->redirect_rows( $offset, $limit ) as $rule ) {
			if ( ! in_array( (int) $rule['type'], Rules::TYPES, true ) || '' === trim( $rule['source'] ) ) {
				++$unsupported;
				continue;
			}
			$existing = self::existing_rule( $rule['source'], $rule['is_regex'] );
			$target   = 410 === (int) $rule['type'] ? '' : $this->absolute( $rule['target'] );
			$current  = $existing ? trim( $existing['type'] . ' ' . $existing['target'] ) : '';
			$new      = trim( $rule['type'] . ' ' . $target );
			if ( $current === $new ) {
				continue;
			}
			$changes[] = array(
				'object_type' => 'redirect',
				'object_id'   => $existing ? (int) $existing['id'] : 0,
				'title'       => $rule['is_regex'] ? $rule['source'] : Rules::normalize_path( $rule['source'] ),
				'field'       => 'redirect',
				'key'         => '',
				'current'     => $current,
				'new'         => $new,
				'rule'        => array(
					'source'   => $rule['source'],
					'target'   => $target,
					'type'     => (int) $rule['type'],
					'is_regex' => (bool) $rule['is_regex'],
				),
				'old_row'     => $existing,
			);
		}
		if ( $unsupported ) {
			/* translators: %d: number of rules. */
			$notes[] = sprintf( __( '%d redirects use a status code or source format FutureLabs AI SEO does not support and were skipped.', 'futurelabs-ai-seo' ), $unsupported );
		}
		return $changes;
	}

	/**
	 * Write changes in one audit batch.
	 *
	 * @param array<int, array<string, mixed>> $changes Changes.
	 * @param string                           $batch   Batch id.
	 * @param array<int, array<string, mixed>> $errors  Errors (appended).
	 */
	private function commit( array $changes, string $batch, array &$errors ): int {
		$audit            = $this->c->get( AuditLog::class );
		$action           = 'import_' . $this->slug();
		$applied          = 0;
		$settings_changes = array();
		foreach ( $changes as $change ) {
			$id = (int) $change['object_id'];
			if ( 'post' === $change['object_type'] ) {
				$audit->record_single( $action, $id, $change['key'], $change['current'], $change['new'], $batch );
				update_post_meta( $id, $change['key'], $change['new'] );
				++$applied;
			} elseif ( 'term' === $change['object_type'] ) {
				$audit->write(
					$batch,
					$action,
					'term',
					$id,
					array(
						'kind'  => 'term_meta',
						'key'   => $change['key'],
						'value' => $change['current'],
					),
					array(
						'kind'  => 'term_meta',
						'key'   => $change['key'],
						'value' => $change['new'],
					)
				);
				update_term_meta( $id, $change['key'], $change['new'] );
				++$applied;
			} elseif ( 'settings' === $change['object_type'] ) {
				$settings_changes[] = $change;
			} else {
				$rules = $this->c->get( Rules::class );
				$saved = $rules->save( $change['rule'], 0, 'import' );
				if ( is_wp_error( $saved ) ) {
					$errors[] = array(
						'source' => $change['title'],
						'error'  => $saved->get_error_message(),
					);
					continue;
				}
				$audit->write(
					$batch,
					$action,
					'redirect',
					$saved,
					array(
						'kind' => 'redirect',
						'row'  => $change['old_row'],
					),
					array(
						'kind' => 'redirect',
						'row'  => $rules->get( $saved ),
					)
				);
				++$applied;
			}
		}
		if ( $settings_changes ) {
			$applied += $this->commit_settings( $settings_changes, $batch, $action );
		}
		return $applied;
	}

	/**
	 * Effective settings for a content type or taxonomy.
	 *
	 * @param string $group `post_types` or `taxonomies`.
	 * @param string $name  Type name.
	 * @return array<string, mixed>
	 */
	private function type_entry( string $group, string $name ): array {
		$settings = $this->c->get( Settings::class );
		return 'post_types' === $group ? (array) $settings->post_type( $name ) : (array) $settings->taxonomy( $name );
	}

	/**
	 * Apply settings changes as one update with one audit row, so undo restores
	 * the previous settings as a whole.
	 *
	 * @param array<int, array<string, mixed>> $changes Settings changes.
	 * @param string                           $batch   Batch id.
	 * @param string                           $action  Audit action.
	 */
	private function commit_settings( array $changes, string $batch, string $action ): int {
		$settings = $this->c->get( Settings::class );
		$before   = $settings->all();
		$update   = array();
		foreach ( $changes as $change ) {
			$path = (array) $change['path'];
			if ( 1 === count( $path ) ) {
				$update[ $path[0] ] = $change['new'];
				continue;
			}
			list( $group, $name, $field ) = $path;
			if ( ! isset( $update[ $group ] ) ) {
				$update[ $group ] = (array) $settings->get( $group );
			}
			if ( ! isset( $update[ $group ][ $name ] ) ) {
				// Start from the full effective entry so unchanged fields keep their values.
				$update[ $group ][ $name ] = $this->type_entry( $group, $name );
			}
			$update[ $group ][ $name ][ $field ] = $change['new'];
		}
		$settings->update( $update );
		$this->c->get( AuditLog::class )->write(
			$batch,
			$action,
			'settings',
			0,
			array(
				'kind'  => 'settings',
				'value' => $before,
			),
			array(
				'kind'  => 'settings',
				'value' => $settings->all(),
			)
		);
		return count( $changes );
	}

	/**
	 * Strip internal keys from the diff.
	 *
	 * @param array<int, array<string, mixed>> $changes Changes.
	 * @return array<int, array<string, mixed>>
	 */
	private function public_changes( array $changes ): array {
		return array_map(
			static function ( array $change ): array {
				return array(
					'object_type' => $change['object_type'],
					'object_id'   => $change['object_id'],
					'title'       => $change['title'],
					'field'       => $change['field'],
					'current'     => $change['current'],
					'new'         => $change['new'],
				);
			},
			$changes
		);
	}

	/**
	 * Convert and sanitize one value for a FutureLabs AI SEO field.
	 *
	 * @param string $field Field.
	 * @param string $raw   Raw source value.
	 */
	protected function clean( string $field, string $raw ): string {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return '';
		}
		switch ( $field ) {
			case 'title':
			case 'description':
			case 'og_title':
			case 'og_description':
				return $this->convert_template( $raw );
			case 'canonical':
			case 'og_image':
				return PostMeta::sanitize( 'url', $this->absolute( $raw ) );
			case 'schema_type':
				return in_array( $raw, Types::selectable(), true ) ? $raw : '';
			case 'noindex':
				return in_array( $raw, array( '1', 'index' ), true ) ? $raw : '';
			case 'focus_topic':
				return sanitize_text_field( $raw );
		}
		return '';
	}

	/**
	 * Make a site-relative URL absolute.
	 *
	 * @param string $url URL or path.
	 */
	protected function absolute( string $url ): string {
		$url = trim( $url );
		if ( '' === $url || preg_match( '~^[a-z][a-z0-9+.\-]*://~i', $url ) ) {
			return $url;
		}
		return home_url( '/' . ltrim( $url, '/' ) );
	}

	/**
	 * Existing FutureLabs AI SEO rule for a source.
	 *
	 * @param string $source   Source path or pattern.
	 * @param bool   $is_regex Whether regex.
	 * @return array<string, mixed>|null
	 */
	public static function existing_rule( string $source, bool $is_regex ): ?array {
		global $wpdb;
		$table = Rules::table();
		$hash  = $is_regex ? hash( 'sha256', 'regex:' . trim( $source ) ) : Rules::hash( $source );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE source_hash=%s", $hash ), ARRAY_A );
		return $row ? $row : null;
	}

	/**
	 * Whether a database table exists.
	 *
	 * @param string $table Full table name.
	 */
	protected static function table_exists( string $table ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
	}

	/**
	 * Post IDs that have any of the given meta keys.
	 *
	 * @param array<int, string> $keys   Meta keys.
	 * @param int                $offset Offset.
	 * @param int                $limit  Limit.
	 * @return array<int, int>
	 */
	protected static function meta_post_ids( array $keys, int $offset, int $limit ): array {
		global $wpdb;
		$in = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT m.post_id FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID=m.post_id WHERE m.meta_key IN ($in) AND m.meta_value<>'' AND p.post_type NOT IN ('revision','nav_menu_item') ORDER BY m.post_id ASC LIMIT %d OFFSET %d", array_merge( $keys, array( $limit, $offset ) ) ) );
		return array_map( 'absint', (array) $ids );
	}

	/**
	 * Number of posts with any of the given meta keys.
	 *
	 * @param array<int, string> $keys Meta keys.
	 */
	protected static function meta_post_count( array $keys ): int {
		global $wpdb;
		$in = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT m.post_id) FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID=m.post_id WHERE m.meta_key IN ($in) AND m.meta_value<>'' AND p.post_type NOT IN ('revision','nav_menu_item')", $keys ) );
	}

	/**
	 * Term IDs that have any of the given term meta keys.
	 *
	 * @param array<int, string> $keys   Meta keys.
	 * @param int                $offset Offset.
	 * @param int                $limit  Limit.
	 * @return array<int, int>
	 */
	protected static function meta_term_ids( array $keys, int $offset, int $limit ): array {
		global $wpdb;
		$in = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT term_id FROM {$wpdb->termmeta} WHERE meta_key IN ($in) AND meta_value<>'' ORDER BY term_id ASC LIMIT %d OFFSET %d", array_merge( $keys, array( $limit, $offset ) ) ) );
		return array_map( 'absint', (array) $ids );
	}

	/**
	 * Number of terms with any of the given term meta keys.
	 *
	 * @param array<int, string> $keys Meta keys.
	 */
	protected static function meta_term_count( array $keys ): int {
		global $wpdb;
		$in = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT term_id) FROM {$wpdb->termmeta} WHERE meta_key IN ($in) AND meta_value<>''", $keys ) );
	}

	/**
	 * Map a source article/schema type name to a FutureLabs AI SEO selectable type.
	 *
	 * @param string $type Source type.
	 */
	protected static function schema_type( string $type ): string {
		$type = trim( $type );
		if ( '' === $type ) {
			return '';
		}
		$lower = strtolower( $type );
		if ( in_array( $lower, array( 'none', 'off' ), true ) ) {
			return 'None';
		}
		foreach ( Types::selectable() as $candidate ) {
			if ( strtolower( $candidate ) === $lower ) {
				return $candidate;
			}
		}
		// Article subtypes (TechArticle, ScholarlyArticle, Report...) fall back to Article.
		if ( str_ends_with( $lower, 'article' ) || in_array( $lower, array( 'report', 'socialmediaposting' ), true ) ) {
			return 'Article';
		}
		return '';
	}
}
