<?php
/**
 * News filter panel, layout two: posts as a 4-column card grid. Also rendered
 * by the REST route for lazily loaded tabs.
 *
 * @package NewsTheme
 *
 * @var array $args Block args with a `loop` WP_Query.
 */

defined( 'ABSPATH' ) || exit;

if ( ! $args['loop']->have_posts() ) {
	printf( '<p class="nt-empty">%s</p>', esc_html__( 'No posts yet.', 'newstheme' ) );
	return;
}
?>
<div class="nt-grid nt-grid--4 nt-filter nt-filter--grid">
	<?php
	while ( $args['loop']->have_posts() ) :
		$args['loop']->the_post();
		?>
		<article <?php post_class( 'nt-post nt-post--grid' ); ?>>
			<?php newstheme_post_thumb( 'newstheme-medium', array( 'badge' => true ) ); ?>
			<?php
			newstheme_post_title( 'h3' );
			newstheme_post_meta( $args['meta'] );
			?>
		</article>
	<?php endwhile; ?>
</div>
