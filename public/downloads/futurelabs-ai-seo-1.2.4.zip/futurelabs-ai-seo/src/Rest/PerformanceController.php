<?php
/**
 * Core Web Vitals endpoints.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Performance\PsiClient;
use FutureLabs\AISEO\Performance\Results;

defined( 'ABSPATH' ) || exit;

/**
 * /performance routes.
 */
class PerformanceController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/performance', 'GET', array( $this, 'index' ), Capabilities::DATA );
		$this->route( '/performance/run', 'POST', array( $this, 'run' ), Capabilities::DATA );
		$this->route( '/performance/top-pages', 'POST', array( $this, 'top_pages' ), Capabilities::DATA );
	}

	/**
	 * Latest results per URL and strategy with regressions.
	 */
	public function index(): \WP_REST_Response {
		$results = $this->c->get( Results::class );
		$items   = $results->latest();
		return rest_ensure_response(
			array(
				'items'   => $items,
				'total'   => count( $items ),
				'summary' => $results->summary( $items ),
			)
		);
	}

	/**
	 * POST /performance/run { url, strategy }
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function run( \WP_REST_Request $request ) {
		$body     = $this->body( $request );
		$url      = (string) ( $body['url'] ?? '' );
		$strategy = sanitize_key( (string) ( $body['strategy'] ?? 'mobile' ) );
		if ( ! PsiClient::is_allowed_url( $url ) ) {
			return $this->error( 'psi_url', __( 'Only URLs on this site can be measured.', 'futurelabs-ai-seo' ), 400 );
		}
		$result = $this->c->get( Results::class )->run( $url, $strategy );
		if ( is_wp_error( $result ) ) {
			$data = (array) $result->get_error_data();
			return $this->error( str_replace( 'flseo_', '', (string) $result->get_error_code() ), $result->get_error_message(), (int) ( $data['status'] ?? 502 ) );
		}
		return rest_ensure_response( $result );
	}

	/**
	 * POST /performance/top-pages: queue mobile and desktop runs for the top pages.
	 *
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function top_pages() {
		if ( ! $this->c->get( PsiClient::class )->has_key() ) {
			return $this->error( 'psi_no_key', __( 'Add a PageSpeed Insights API key in FutureLabs AI SEO settings first.', 'futurelabs-ai-seo' ), 400 );
		}
		return rest_ensure_response( array( 'queued' => $this->c->get( Results::class )->queue_top_pages() ) );
	}
}
