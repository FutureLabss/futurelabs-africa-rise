<?php
/**
 * Archives: categories, tags, authors, dates.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();

// Feature the newest post across the full width on the first page.
$newstheme_hero = have_posts() && ! is_paged() && newstheme_get_mod( 'archive_hero' ) && ( is_category() || is_tag() || is_author() || is_tax() );
if ( $newstheme_hero ) {
	the_post();
	echo '<div class="nt-container nt-archive-hero-wrap">';
	newstheme_breadcrumbs();
	get_template_part( 'template-parts/content/archive-hero' );
	echo '</div>';
}

newstheme_layout_open( 'archive' );
get_template_part(
	'template-parts/content/archive-list',
	null,
	array(
		'title'       => get_the_archive_title(),
		'description' => get_the_archive_description(),
	)
);
newstheme_layout_close();

get_footer();
