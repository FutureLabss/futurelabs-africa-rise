<?php
/**
 * 404 page.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();
newstheme_layout_open( 'archive' );
?>
<section class="nt-card-box nt-404">
	<p class="nt-404__code" aria-hidden="true">404</p>
	<h1 class="nt-404__title"><?php esc_html_e( 'This page could not be found', 'newstheme' ); ?></h1>
	<p><?php esc_html_e( 'It may have moved, or the link may be broken. Try a search, or read one of the latest stories below.', 'newstheme' ); ?></p>
	<?php get_search_form(); ?>
</section>
<?php
newstheme_render_block(
	'news-grid',
	array(
		'title'   => __( 'Latest News', 'newstheme' ),
		'columns' => 3,
		'query'   => array( 'count' => 6 ),
	)
);
newstheme_layout_close();
get_footer();
