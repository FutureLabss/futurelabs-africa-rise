<?php
/**
 * NewsTheme Posts Carousel Widget.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Posts carousel: one overlay card at a time.
 */
class NewsTheme_Posts_Carousel_Widget extends NewsTheme_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->fields = array_merge(
			array(
				'title'    => array(
					'type'    => 'text',
					'label'   => __( 'Title', 'newstheme' ),
					'default' => __( 'Must Read', 'newstheme' ),
				),
				'autoplay' => array(
					'type'    => 'number',
					'label'   => __( 'Autoplay seconds (0 = off)', 'newstheme' ),
					'default' => 5,
					'min'     => 0,
					'max'     => 20,
				),
			),
			self::post_fields( 5 )
		);
		parent::__construct( 'posts_carousel', __( 'NewsTheme: Posts Carousel', 'newstheme' ), __( 'A sliding carousel of posts.', 'newstheme' ) );
	}

	/**
	 * Render.
	 *
	 * @param array $values Instance values.
	 */
	protected function render( array $values ) {
		$query = $this->posts_query( $values );
		if ( ! $query->have_posts() ) {
			return;
		}
		printf(
			'<div class="nt-carousel nt-wcarousel" data-nt-carousel data-loop%1$s role="region" aria-roledescription="%2$s" aria-label="%3$s"><div class="nt-carousel__track">',
			$values['autoplay'] ? ' data-autoplay="' . esc_attr( $values['autoplay'] * 1000 ) . '"' : '',
			esc_attr__( 'carousel', 'newstheme' ),
			esc_attr( $values['title'] ? $values['title'] : __( 'Posts', 'newstheme' ) )
		);
		while ( $query->have_posts() ) {
			$query->the_post();
			echo '<article class="nt-carousel__slide nt-overlay-card">';
			newstheme_post_thumb( 'newstheme-medium' );
			echo '<div class="nt-overlay-card__body">';
			newstheme_post_categories();
			newstheme_post_title( 'h3' );
			echo '</div></article>';
		}
		echo '</div>';
		get_template_part( 'template-parts/blocks/carousel-controls' );
		echo '</div>';
		wp_reset_postdata();
	}
}
