<?php
/**
 * GET/POST /settings
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Crypto;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Meta\NoindexGuard;
use FutureLabs\AISEO\Meta\Variables;

defined( 'ABSPATH' ) || exit;

/**
 * Settings read/write, including encrypted secrets (write-only).
 */
class SettingsController extends Controller {

	/**
	 * Secret fields accepted by POST and the option each is stored in.
	 */
	public const SECRETS = array(
		'gsc_client_id'      => 'flseo_gsc_client_id',
		'gsc_client_secret'  => 'flseo_gsc_client_secret',
		'ai_api_key'         => 'flseo_ai_key',
		'ai_openai_key'      => 'flseo_ai_key_openai',
		'ai_gemini_key'      => 'flseo_ai_key_gemini',
		'ai_compatible_key'  => 'flseo_ai_key_compatible',
		'embeddings_api_key' => 'flseo_embeddings_key',
	);

	/**
	 * Secret fields with add-on fields from `flseo_setting_secrets`.
	 *
	 * @return array<string, string> Field => option name.
	 */
	public static function secrets(): array {
		/**
		 * Filters the write-only secret fields on the settings screen (field => option).
		 * Values are stored encrypted. Add-ons can add fields, but not change core ones, and
		 * their options must start with `flseo_` or `flseopro_`.
		 *
		 * @param array<string, string> $extra Extra fields.
		 */
		$extra = apply_filters( 'flseo_setting_secrets', array() );
		$out   = self::SECRETS;
		foreach ( is_array( $extra ) ? $extra : array() as $field => $option ) {
			$field  = sanitize_key( (string) $field );
			$option = (string) $option;
			if ( '' !== $field && ! isset( $out[ $field ] ) && preg_match( '/^flseo(pro)?_[a-z0-9_]+$/', $option ) ) {
				$out[ $field ] = $option;
			}
		}
		return $out;
	}

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/settings', 'GET', array( $this, 'get' ), Capabilities::SETTINGS );
		$this->route( '/settings', 'POST', array( $this, 'save' ), Capabilities::SETTINGS );
	}

	/**
	 * Current settings plus context for the settings screen.
	 */
	public function get(): \WP_REST_Response {
		return rest_ensure_response( $this->payload() );
	}

	/**
	 * Settings payload. Secrets are reported only as set/unset.
	 *
	 * @return array<string, mixed>
	 */
	private function payload(): array {
		$settings = $this->c->get( Settings::class );
		$crypto   = $this->c->get( Crypto::class );
		$types    = array();
		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $type ) {
			if ( 'attachment' === $type->name ) {
				continue;
			}
			$types[ $type->name ] = array_merge( array( 'label' => $type->labels->name ), $settings->post_type( $type->name ) );
		}
		$taxonomies = array();
		foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $taxonomy ) {
			if ( 'post_format' === $taxonomy->name ) {
				continue;
			}
			$taxonomies[ $taxonomy->name ] = array_merge( array( 'label' => $taxonomy->labels->name ), $settings->taxonomy( $taxonomy->name ) );
		}
		$secrets = array();
		foreach ( self::secrets() as $field => $option ) {
			$secrets[ $field ] = $crypto->has_secret( $option );
		}
		return array(
			'settings'   => array_merge(
				$settings->all(),
				array(
					'post_types' => $types,
					'taxonomies' => $taxonomies,
				)
			),
			'secrets'    => $secrets,
			'variables'  => Variables::supported(),
			'encryption' => function_exists( 'sodium_crypto_secretbox' ),
		);
	}

	/**
	 * Save settings. Secrets are encrypted; empty secret strings are ignored, null clears them.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function save( \WP_REST_Request $request ) {
		$body     = $this->body( $request );
		$input    = isset( $body['settings'] ) && is_array( $body['settings'] ) ? $body['settings'] : $body;
		$settings = $this->c->get( Settings::class );

		if ( isset( $input['post_types'] ) && is_array( $input['post_types'] ) ) {
			$verdict = $this->c->get( NoindexGuard::class )->check_settings( $input['post_types'], (string) ( $body['confirmation'] ?? '' ) );
			if ( ! $verdict['allowed'] ) {
				return $this->error(
					'confirmation_required',
					/* translators: 1: projected noindexed pages, 2: published pages, 3: phrase. */
					sprintf( __( 'These settings would noindex %1$d of %2$d published pages. Type %3$s to confirm.', 'futurelabs-ai-seo' ), $verdict['projected'], $verdict['published'], $verdict['phrase'] ),
					409,
					$verdict
				);
			}
		}

		if ( isset( $body['secrets'] ) && is_array( $body['secrets'] ) ) {
			$crypto = $this->c->get( Crypto::class );
			if ( ! function_exists( 'sodium_crypto_secretbox' ) ) {
				return $this->error( 'no_encryption', __( 'This server cannot encrypt secrets (libsodium is missing), so keys were not saved.', 'futurelabs-ai-seo' ), 500 );
			}
			foreach ( self::secrets() as $field => $option ) {
				if ( ! array_key_exists( $field, $body['secrets'] ) ) {
					continue;
				}
				$value = $body['secrets'][ $field ];
				if ( null === $value ) {
					delete_option( $option );
				} elseif ( is_string( $value ) && '' !== trim( $value ) ) {
					$crypto->set_secret( $option, trim( $value ) );
				}
			}
		}
		$settings->update( $input );
		return rest_ensure_response( $this->payload() );
	}
}
