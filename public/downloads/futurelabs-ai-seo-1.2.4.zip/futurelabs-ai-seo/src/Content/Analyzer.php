<?php
/**
 * Content analyzer: batched, resumable site scan plus single-post rescans.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Content;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Links\Crawler;
use FutureLabs\AISEO\Links\Graph;

defined( 'ABSPATH' ) || exit;

/**
 * Scans published posts in public types into `flseo_content_scan`.
 *
 * Phases: `scan` walks posts by ascending ID (cursor stored in an option), `group`
 * computes near-duplicate groups, `recommend` refreshes recommendations, then the
 * link graph job is queued.
 */
class Analyzer implements Module {

	public const STATE_OPTION = 'flseo_scan_state';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'flseo_scan_batch', array( $this, 'run_batch' ) );
		add_action( 'flseo_scan_post', array( $this, 'scan_post_job' ) );
		add_action( 'save_post', array( $this, 'on_save' ), 30, 2 );
		add_action( 'deleted_post', array( $this, 'on_delete' ) );
		add_action( 'flseo_daily', array( $this, 'watchdog' ) );
	}

	/**
	 * Public post types that are scanned.
	 *
	 * @return array<int, string>
	 */
	public static function post_types(): array {
		return array_values( array_diff( get_post_types( array( 'public' => true ), 'names' ), array( 'attachment' ) ) );
	}

	/**
	 * Current scan state.
	 *
	 * @return array<string, mixed>
	 */
	private function state(): array {
		$state = get_option( self::STATE_OPTION, array() );
		return wp_parse_args(
			is_array( $state ) ? $state : array(),
			array(
				'status'      => 'idle',
				'phase'       => '',
				'cursor'      => 0,
				'processed'   => 0,
				'total'       => 0,
				'started_at'  => '',
				'finished_at' => '',
				'updated_at'  => 0,
			)
		);
	}

	/**
	 * Persist state.
	 *
	 * @param array<string, mixed> $state State.
	 */
	private function save_state( array $state ): void {
		$state['updated_at'] = time();
		update_option( self::STATE_OPTION, $state, false );
	}

	/**
	 * Start a full scan. A running scan is resumed rather than restarted unless forced.
	 *
	 * @param bool $force Restart from the beginning.
	 * @return array<string, mixed> Progress.
	 */
	public function start( bool $force = false ): array {
		$state = $this->state();
		if ( 'running' === $state['status'] && ! $force ) {
			$this->c->get( Queue::class )->async( 'flseo_scan_batch' );
			return $this->progress();
		}
		$this->save_state(
			array(
				'status'      => 'running',
				'phase'       => 'scan',
				'cursor'      => 0,
				'processed'   => 0,
				'total'       => $this->count_posts(),
				'started_at'  => gmdate( 'c' ),
				'finished_at' => '',
			)
		);
		$this->c->get( Queue::class )->async( 'flseo_scan_batch' );
		return $this->progress();
	}

	/**
	 * Scan progress for the admin UI.
	 *
	 * @return array{status: string, phase: string, processed: int, total: int, percent: int, started_at: string, finished_at: string}
	 */
	public function progress(): array {
		$state   = $this->state();
		$total   = (int) $state['total'];
		$done    = (int) $state['processed'];
		$percent = 'done' === $state['status'] ? 100 : ( $total > 0 ? min( 99, (int) floor( $done * 100 / $total ) ) : 0 );
		return array(
			'status'      => (string) $state['status'],
			'phase'       => (string) $state['phase'],
			'processed'   => $done,
			'total'       => $total,
			'percent'     => $percent,
			'started_at'  => (string) $state['started_at'],
			'finished_at' => (string) $state['finished_at'],
		);
	}

	/**
	 * Published posts in scanned types.
	 */
	private function count_posts(): int {
		global $wpdb;
		$types = self::post_types();
		if ( ! $types ) {
			return 0;
		}
		$in = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ({$in})", $types ) );
	}

	/**
	 * Batch size from settings.
	 */
	private function batch_size(): int {
		return max( 5, min( 500, (int) $this->c->get( Settings::class )->get( 'batch_size', 25 ) ) );
	}

	/**
	 * Process one batch, then re-queue until finished. Idempotent: rerunning a batch
	 * rescans the same posts and overwrites their rows.
	 */
	public function run_batch(): void {
		$state = $this->state();
		if ( 'running' !== $state['status'] ) {
			return;
		}
		try {
			switch ( $state['phase'] ) {
				case 'group':
					$this->c->get( Duplicate::class )->compute_groups();
					$state['phase']  = 'recommend';
					$state['cursor'] = 0;
					break;
				case 'recommend':
					$last = $this->recommend_batch( (int) $state['cursor'], $this->batch_size() * 4 );
					if ( $last <= 0 ) {
						$state['status']      = 'done';
						$state['phase']       = '';
						$state['finished_at'] = gmdate( 'c' );
						$state['processed']   = max( (int) $state['processed'], (int) $state['total'] );
					} else {
						$state['cursor'] = $last;
					}
					break;
				default:
					$ids = $this->next_ids( (int) $state['cursor'], $this->batch_size() );
					foreach ( $ids as $id ) {
						$this->scan_post( $id, false );
						$state['cursor'] = $id;
						++$state['processed'];
					}
					if ( count( $ids ) < $this->batch_size() ) {
						$state['phase']  = 'group';
						$state['cursor'] = 0;
					}
			}
		} catch ( \Throwable $e ) {
			$this->c->get( Logger::class )->error( 'Content scan batch failed.', array( 'error' => $e->getMessage() ) );
		}
		$this->save_state( $state );
		self::flush_memory();
		if ( 'running' === $state['status'] ) {
			$this->c->get( Queue::class )->async( 'flseo_scan_batch' );
		} else {
			$this->c->get( Queue::class )->async( 'flseo_graph_compute' );
			/**
			 * Fires when a full content scan finishes.
			 *
			 * @param array $progress Final progress.
			 */
			do_action( 'flseo_scan_complete', $this->progress() );
		}
	}

	/**
	 * Requeue a scan whose batch job was lost (for example after a fatal error).
	 */
	public function watchdog(): void {
		$state = $this->state();
		if ( 'running' === $state['status'] && (int) $state['updated_at'] < time() - HOUR_IN_SECONDS ) {
			$this->c->get( Queue::class )->async( 'flseo_scan_batch' );
		}
	}

	/**
	 * Next post IDs after a cursor.
	 *
	 * @param int $cursor Last processed ID.
	 * @param int $limit  Batch size.
	 * @return array<int, int>
	 */
	private function next_ids( int $cursor, int $limit ): array {
		global $wpdb;
		$types = self::post_types();
		if ( ! $types ) {
			return array();
		}
		$in   = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$args = array_merge( $types, array( $cursor, $limit ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ({$in}) AND ID > %d ORDER BY ID ASC LIMIT %d", $args ) ) );
	}

	/**
	 * Refresh recommendations for scanned rows after a cursor.
	 *
	 * @param int $cursor Last post ID handled.
	 * @param int $limit  Rows.
	 * @return int Last post ID handled, 0 when nothing was left.
	 */
	private function recommend_batch( int $cursor, int $limit ): int {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT s.* FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.post_id > %d ORDER BY s.post_id ASC LIMIT %d", $cursor, $limit ), ARRAY_A );
		$last = 0;
		foreach ( (array) $rows as $row ) {
			$this->apply_recommendation( (int) $row['post_id'], $row );
			$last = (int) $row['post_id'];
		}
		return $last;
	}

	/**
	 * Recompute and store the recommendation for one row.
	 *
	 * @param int                  $post_id Post ID.
	 * @param array<string, mixed> $row     Current row.
	 */
	private function apply_recommendation( int $post_id, array $row ): void {
		global $wpdb;
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return;
		}
		$result = $this->c->get( Recommender::class )->recommend( $row, $post );
		if ( ( $row['recommendation'] ?? '' ) === $result['recommendation'] && ( $row['reason'] ?? '' ) === $result['reason'] ) {
			return;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update(
			Migrations::table( 'content_scan' ),
			array(
				'recommendation' => $result['recommendation'],
				'reason'         => $result['reason'],
			),
			array( 'post_id' => $post_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Drop per-request caches between batches so long runs stay within memory.
	 */
	public static function flush_memory(): void {
		global $wpdb;
		if ( function_exists( 'wp_cache_flush_runtime' ) ) {
			wp_cache_flush_runtime();
		} elseif ( ! wp_using_ext_object_cache() ) {
			wp_cache_flush();
		}
		$wpdb->queries = array();
		$wpdb->flush();
		if ( function_exists( 'gc_collect_cycles' ) ) {
			gc_collect_cycles();
		}
	}

	/**
	 * Job handler for single-post rescans.
	 *
	 * @param int $post_id Post ID.
	 */
	public function scan_post_job( $post_id ): void {
		$post_id = absint( $post_id );
		if ( ! $post_id ) {
			return;
		}
		if ( 'publish' !== get_post_status( $post_id ) ) {
			$this->forget( $post_id );
			return;
		}
		$this->scan_post( $post_id, true );
	}

	/**
	 * Queue a rescan when a post is saved.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post.
	 */
	public function on_save( int $post_id, \WP_Post $post ): void {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ! in_array( $post->post_type, self::post_types(), true ) ) {
			return;
		}
		if ( 'publish' === $post->post_status ) {
			$this->c->get( Queue::class )->async( 'flseo_scan_post', array( $post_id ) );
		} else {
			$this->forget( $post_id );
		}
	}

	/**
	 * Remove a deleted post's rows.
	 *
	 * @param int $post_id Post ID.
	 */
	public function on_delete( int $post_id ): void {
		$this->forget( $post_id );
	}

	/**
	 * Delete scan and link rows for a post that left the published set.
	 *
	 * @param int $post_id Post ID.
	 */
	private function forget( int $post_id ): void {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT dup_group_id FROM {$table} WHERE post_id = %d", $post_id ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( $table, array( 'post_id' => $post_id ), array( '%d' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( Migrations::table( 'links' ), array( 'from_post_id' => $post_id ), array( '%d' ) );
		if ( $exists ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$members = (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$table} WHERE dup_group_id = %d LIMIT 1", $exists ) );
			if ( $members ) {
				$this->c->get( Duplicate::class )->update_for_post( (int) $members[0] );
			}
		}
	}

	/**
	 * Rendered HTML of a post. Uses the_content (without oEmbed fetches or shortcodes);
	 * for Elementor pages renders the builder content, and falls back to the stored
	 * Elementor data when post_content is empty and Elementor is inactive (OL-9).
	 *
	 * @param \WP_Post $post Post.
	 */
	public function content_html( \WP_Post $post ): string {
		$raw     = (string) $post->post_content;
		$builder = 'builder' === get_post_meta( $post->ID, '_elementor_edit_mode', true );
		if ( $builder && class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->frontend ) ) {
			try {
				$html = (string) \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $post->ID, true );
				if ( '' !== trim( wp_strip_all_tags( $html ) ) ) {
					return $html;
				}
			} catch ( \Throwable $e ) {
				$this->c->get( Logger::class )->warning( 'Elementor rendering failed during content scan.', array( 'post_id' => $post->ID ) );
			}
		}
		if ( '' === trim( wp_strip_all_tags( strip_shortcodes( $raw ) ) ) ) {
			$data = (string) get_post_meta( $post->ID, '_elementor_data', true );
			if ( '' !== $data ) {
				return self::elementor_data_html( $data );
			}
		}
		return $this->render_content( $post );
	}

	/**
	 * Apply the_content without remote embeds or shortcodes.
	 *
	 * @param \WP_Post $post Post.
	 */
	private function render_content( \WP_Post $post ): string {
		global $wp_embed;
		$previous        = $GLOBALS['post'] ?? null;
		$GLOBALS['post'] = $post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		setup_postdata( $post );
		$embed_hooks = array();
		if ( $wp_embed instanceof \WP_Embed ) {
			foreach ( array(
				'run_shortcode' => 8,
				'autoembed'     => 8,
			) as $method => $priority ) {
				if ( false !== has_filter( 'the_content', array( $wp_embed, $method ) ) ) {
					$embed_hooks[ $method ] = has_filter( 'the_content', array( $wp_embed, $method ) );
					remove_filter( 'the_content', array( $wp_embed, $method ), $embed_hooks[ $method ] );
				}
			}
		}
		try {
			$html = (string) apply_filters( 'the_content', strip_shortcodes( (string) $post->post_content ) ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
		} catch ( \Throwable $e ) {
			$html = (string) $post->post_content;
		}
		foreach ( $embed_hooks as $method => $priority ) {
			add_filter( 'the_content', array( $wp_embed, $method ), (int) $priority );
		}
		$GLOBALS['post'] = $previous; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		if ( $previous instanceof \WP_Post ) {
			setup_postdata( $previous );
		} else {
			wp_reset_postdata();
		}
		return $html;
	}

	/**
	 * Build HTML from stored Elementor JSON (headings, text editors, buttons, links).
	 *
	 * @param string $json `_elementor_data` value.
	 */
	public static function elementor_data_html( string $json ): string {
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) {
			return '';
		}
		$html = '';
		$walk = static function ( array $elements ) use ( &$walk, &$html ): void {
			foreach ( $elements as $element ) {
				if ( ! is_array( $element ) ) {
					continue;
				}
				$settings = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : array();
				$widget   = (string) ( $element['widgetType'] ?? '' );
				$link     = isset( $settings['link']['url'] ) ? (string) $settings['link']['url'] : '';
				if ( 'heading' === $widget && isset( $settings['title'] ) ) {
					$tag   = preg_match( '/^h[1-6]$/', (string) ( $settings['header_size'] ?? '' ) ) ? (string) $settings['header_size'] : 'h2';
					$html .= '<' . $tag . '>' . wp_kses_post( (string) $settings['title'] ) . '</' . $tag . '>';
				} else {
					foreach ( array( 'editor', 'text', 'description', 'html', 'title', 'testimonial_content', 'tab_content', 'item_description', 'inner_text' ) as $key ) {
						if ( isset( $settings[ $key ] ) && is_string( $settings[ $key ] ) && '' !== trim( $settings[ $key ] ) ) {
							$text  = wp_kses_post( $settings[ $key ] );
							$html .= '' !== $link && in_array( $key, array( 'text', 'title' ), true ) ? '<p><a href="' . esc_url( $link ) . '">' . $text . '</a></p>' : '<div>' . $text . '</div>';
							$link  = '';
						}
					}
					if ( '' !== $link ) {
						$html .= '<p><a href="' . esc_url( $link ) . '">' . esc_html( $link ) . '</a></p>';
					}
				}
				if ( isset( $element['elements'] ) && is_array( $element['elements'] ) ) {
					$walk( $element['elements'] );
				}
			}
		};
		$walk( $data );
		return $html;
	}

	/**
	 * Body text with link anchors removed (related-post links should not make a post
	 * look like an opportunity listing).
	 *
	 * @param array{text: string, links: array<int, array{href: string, anchor: string}>} $parsed Parsed HTML.
	 */
	public static function text_without_anchors( array $parsed ): string {
		$anchors = array_filter( array_column( $parsed['links'], 'anchor' ) );
		return $anchors ? str_replace( $anchors, ' ', $parsed['text'] ) : $parsed['text'];
	}

	/**
	 * Analyze a post without writing anything.
	 *
	 * @param \WP_Post $post Post.
	 * @return array<string, mixed>
	 */
	public function analyze( \WP_Post $post ): array {
		$html     = $this->content_html( $post );
		$parsed   = Crawler::parse_html( $html );
		$words    = Crawler::word_count( $parsed['text'] );
		$thin     = $this->c->get( Thin::class );
		$edition  = Template::edition( $post->post_title );
		$is_opp   = Template::is_opportunity( $post, self::text_without_anchors( $parsed ) );
		$sections = $is_opp ? Template::completeness( $post, $parsed['text'], $parsed['headings'], $parsed['links'] ) : array();
		$missing  = array();
		foreach ( $sections as $section ) {
			if ( ! $section['ok'] ) {
				$missing[] = $section['key'];
			}
		}
		$levels   = array_column( $parsed['headings'], 'level' );
		$skipped  = false;
		$previous = 1;
		foreach ( $levels as $level ) {
			if ( $level > $previous + 1 ) {
				$skipped = true;
			}
			$previous = $level;
		}
		return array(
			'html'             => $html,
			'text'             => $parsed['text'],
			'links'            => $parsed['links'],
			'headings'         => $parsed['headings'],
			'word_count'       => $words,
			'thin_score'       => $thin->score( $words ),
			'title_generic'    => Template::is_generic_title( $post->post_title ) ? 1 : 0,
			'simhash'          => $words >= Duplicate::MIN_WORDS ? Duplicate::simhash( $parsed['text'] ) : '',
			'template_sig'     => Template::signature( $post->post_title, (string) $post->post_content, $parsed['headings'] ),
			'edition_key'      => $edition['key'],
			'edition_year'     => $edition['year'],
			'is_opportunity'   => $is_opp ? 1 : 0,
			'sections'         => $sections,
			'missing_sections' => implode( ',', $missing ),
			'heading_skipped'  => $skipped,
			'h1_count'         => count( array_keys( $levels, 1, true ) ),
		);
	}

	/**
	 * Scan one post and store the result.
	 *
	 * @param int  $post_id Post ID.
	 * @param bool $single  True for an on-demand rescan (also updates duplicate grouping
	 *                      and the recommendation); false inside the batch job.
	 * @return array<string, mixed>|null Stored row, or null when the post is not scannable.
	 */
	public function scan_post( int $post_id, bool $single = true ): ?array {
		global $wpdb;
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status || ! in_array( $post->post_type, self::post_types(), true ) ) {
			return null;
		}
		$result = $this->analyze( $post );
		$table  = Migrations::table( 'content_scan' );
		$now    = current_time( 'mysql', true );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$table} (post_id, word_count, title_generic, headings, simhash, template_sig, edition_key, edition_year, thin_score, is_opportunity, missing_sections, recommendation, reason, scanned_at)
				VALUES (%d, %d, %d, %d, %s, %s, %s, %d, %d, %d, %s, 'ok', '', %s)
				ON DUPLICATE KEY UPDATE word_count = VALUES(word_count), title_generic = VALUES(title_generic), headings = VALUES(headings), simhash = VALUES(simhash), template_sig = VALUES(template_sig), edition_key = VALUES(edition_key), edition_year = VALUES(edition_year), thin_score = VALUES(thin_score), is_opportunity = VALUES(is_opportunity), missing_sections = VALUES(missing_sections), scanned_at = VALUES(scanned_at)",
				$post_id,
				$result['word_count'],
				$result['title_generic'],
				count( $result['headings'] ),
				$result['simhash'],
				$result['template_sig'],
				$result['edition_key'],
				$result['edition_year'],
				$result['thin_score'],
				$result['is_opportunity'],
				substr( $result['missing_sections'], 0, 255 ),
				$now
			)
		);
		// phpcs:enable
		$this->c->get( Graph::class )->store_content_links( $post_id, $result['links'] );
		if ( ! $single ) {
			// The batch job groups duplicates and refreshes recommendations in later phases.
			return array(
				'post_id'    => $post_id,
				'word_count' => $result['word_count'],
			);
		}
		$affected = $this->c->get( Duplicate::class )->update_for_post( $post_id );
		foreach ( array_slice( array_diff( $affected, array( $post_id ) ), 0, 50 ) as $member ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$member_row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE post_id = %d", $member ), ARRAY_A );
			if ( is_array( $member_row ) ) {
				$this->apply_recommendation( (int) $member, $member_row );
			}
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE post_id = %d", $post_id ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return null;
		}
		$this->apply_recommendation( $post_id, $row );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE post_id = %d", $post_id ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}
}
