<?php
/**
 * Headlines bar: a continuously scrolling strip of recent posts. The list is
 * rendered twice for a seamless loop; the copy is hidden from assistive tech
 * and the keyboard.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_posts = get_posts(
	array(
		'posts_per_page'      => (int) newstheme_get_mod( 'headlines_count' ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);
if ( ! $newstheme_posts ) {
	return;
}

$newstheme_item = static function ( $post, $copy ) {
	$attrs = $copy ? ' tabindex="-1"' : '';
	printf(
		'<li class="nt-headlines__item"><a href="%1$s"%2$s>%3$s<span class="nt-headlines__text"><span class="nt-headlines__title">%4$s</span><span class="nt-headlines__date">%5$s</span></span></a></li>',
		esc_url( get_permalink( $post ) ),
		$attrs, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static string.
		get_the_post_thumbnail(
			$post,
			'newstheme-thumb',
			array(
				'alt'     => '',
				'loading' => 'lazy',
			)
		), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core image markup.
		esc_html( get_the_title( $post ) ),
		/* translators: %s: time difference, e.g. "3 days". */
		esc_html( sprintf( __( '%s ago', 'newstheme' ), human_time_diff( get_post_time( 'U', true, $post ), time() ) ) )
	);
};
?>
<div class="nt-container">
	<div class="nt-headlines" data-nt-headlines role="region" aria-label="<?php echo esc_attr( newstheme_get_mod( 'headlines_label' ) ); ?>">
		<span class="nt-headlines__label"><?php newstheme_icon( 'zap' ); ?><span><?php echo esc_html( newstheme_get_mod( 'headlines_label' ) ); ?></span></span>
		<div class="nt-headlines__viewport">
			<ul class="nt-headlines__track">
				<?php
				foreach ( $newstheme_posts as $newstheme_post ) {
					$newstheme_item( $newstheme_post, false );
				}
				?>
			</ul>
			<ul class="nt-headlines__track" aria-hidden="true">
				<?php
				foreach ( $newstheme_posts as $newstheme_post ) {
					$newstheme_item( $newstheme_post, true );
				}
				?>
			</ul>
		</div>
		<button type="button" class="nt-headlines__pause" data-nt-headlines-pause aria-pressed="false" aria-label="<?php esc_attr_e( 'Pause headlines', 'newstheme' ); ?>"><?php newstheme_icon( 'pause' ); ?><?php newstheme_icon( 'play' ); ?></button>
	</div>
</div>
