<?php
/**
 * Small front-end features: random post redirect and live search endpoint.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * URL of the random-post redirect.
 *
 * @return string
 */
function newstheme_random_post_url() {
	return add_query_arg( 'newstheme_random', '1', home_url( '/' ) );
}

/**
 * Redirect ?newstheme_random=1 to a random published post.
 */
function newstheme_random_post_redirect() {
	if ( empty( $_GET['newstheme_random'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation.
		return;
	}

	$args       = array(
		'post_type'      => 'post',
		'posts_per_page' => 1,
		'orderby'        => 'rand',
		'fields'         => 'ids',
		'no_found_rows'  => true,
	);
	$categories = newstheme_get_mod( 'random_categories' );
	if ( $categories ) {
		$args['category__in'] = $categories;
	}

	$ids = get_posts( $args );
	nocache_headers();
	wp_safe_redirect( $ids ? get_permalink( $ids[0] ) : home_url( '/' ) );
	exit;
}
add_action( 'template_redirect', 'newstheme_random_post_redirect' );

/**
 * REST route for live search: GET /wp-json/newstheme/v1/search?s=term
 */
function newstheme_register_rest_routes() {
	register_rest_route(
		'newstheme/v1',
		'/search',
		array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'args'                => array(
				's' => array(
					'type'              => 'string',
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				),
			),
			'callback'            => 'newstheme_rest_search',
		)
	);
}
add_action( 'rest_api_init', 'newstheme_register_rest_routes' );

/**
 * Live search results: up to 5 posts with title, link, date and thumbnail.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response
 */
function newstheme_rest_search( $request ) {
	$term = $request->get_param( 's' );
	if ( mb_strlen( $term ) < 3 ) {
		return rest_ensure_response( array( 'results' => array() ) );
	}

	$query = new WP_Query(
		array(
			's'                   => $term,
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => 5,
			'ignore_sticky_posts' => true,
		)
	);

	$results = array();
	foreach ( $query->posts as $post ) {
		$results[] = array(
			'title' => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
			'url'   => get_permalink( $post ),
			'date'  => get_the_date( '', $post ),
			'thumb' => get_the_post_thumbnail_url( $post, 'newstheme-thumb' ),
		);
	}

	return rest_ensure_response(
		array(
			'results' => $results,
			'total'   => (int) $query->found_posts,
			'more'    => get_search_link( $term ),
		)
	);
}

/**
 * Basic meta description when no SEO plugin is handling it: the tagline on
 * the front page, the excerpt on posts/pages, the term description on
 * archives.
 */
function newstheme_meta_description() {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'FLSEO_VERSION' ) ) {
		return;
	}
	if ( ! apply_filters( 'newstheme_output_meta_description', true ) ) {
		return;
	}

	$text = '';
	if ( is_front_page() || is_home() ) {
		$text = get_bloginfo( 'description' );
	} elseif ( is_singular() ) {
		$text = get_the_excerpt( get_queried_object_id() );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$text = term_description();
	} elseif ( is_author() ) {
		$text = get_the_author_meta( 'description', (int) get_query_var( 'author' ) );
	}

	$text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $text ) ) );
	if ( '' !== $text ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( wp_html_excerpt( $text, 155, '…' ) ) );
	}
}
add_action( 'wp_head', 'newstheme_meta_description', 1 );
