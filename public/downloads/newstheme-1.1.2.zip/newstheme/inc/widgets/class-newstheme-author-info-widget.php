<?php
/**
 * NewsTheme Author Info Widget.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Author / about card.
 */
class NewsTheme_Author_Info_Widget extends NewsTheme_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->fields = array(
			'title' => array(
				'type'    => 'text',
				'label'   => __( 'Title', 'newstheme' ),
				'default' => __( 'About Me', 'newstheme' ),
			),
			'image' => array(
				'type'    => 'image',
				'label'   => __( 'Photo', 'newstheme' ),
				'default' => 0,
			),
			'name'  => array(
				'type'    => 'text',
				'label'   => __( 'Name', 'newstheme' ),
				'default' => '',
			),
			'role'  => array(
				'type'    => 'text',
				'label'   => __( 'Role / tagline', 'newstheme' ),
				'default' => '',
			),
			'bio'   => array(
				'type'    => 'textarea',
				'label'   => __( 'Bio', 'newstheme' ),
				'default' => '',
			),
			'url'   => array(
				'type'    => 'url',
				'label'   => __( 'Link URL', 'newstheme' ),
				'default' => '',
			),
		);
		parent::__construct( 'author_info', __( 'NewsTheme: Author Info', 'newstheme' ), __( 'A photo, name and short bio.', 'newstheme' ) );
	}

	/**
	 * Render.
	 *
	 * @param array $values Instance values.
	 */
	protected function render( array $values ) {
		if ( ! $values['name'] && ! $values['bio'] && ! $values['image'] ) {
			return;
		}
		echo '<div class="nt-wauthor">';
		if ( $values['image'] ) {
			echo wp_get_attachment_image( $values['image'], 'newstheme-thumb', false, array( 'class' => 'nt-wauthor__photo' ) );
		}
		if ( $values['name'] ) {
			$name = esc_html( $values['name'] );
			printf( '<p class="nt-wauthor__name">%s</p>', $values['url'] ? '<a href="' . esc_url( $values['url'] ) . '">' . $name . '</a>' : $name ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
		}
		if ( $values['role'] ) {
			printf( '<p class="nt-wauthor__role">%s</p>', esc_html( $values['role'] ) );
		}
		if ( $values['bio'] ) {
			printf( '<p class="nt-wauthor__bio">%s</p>', esc_html( $values['bio'] ) );
		}
		echo '</div>';
	}
}
