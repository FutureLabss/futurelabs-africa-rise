<?php
/**
 * Header element: rotating headline ticker.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_ticker = newstheme_ticker_posts();
if ( ! $newstheme_ticker ) {
	return;
}
?>
<div class="nt-ticker" data-nt-ticker data-interval="<?php echo esc_attr( (int) newstheme_get_mod( 'ticker_interval' ) * 1000 ); ?>" role="region" aria-roledescription="<?php esc_attr_e( 'carousel', 'newstheme' ); ?>" aria-label="<?php esc_attr_e( 'Latest headlines', 'newstheme' ); ?>">
	<div class="nt-ticker__viewport">
		<ul class="nt-ticker__list">
			<?php foreach ( $newstheme_ticker as $newstheme_index => $newstheme_post ) : ?>
				<li class="nt-ticker__item"<?php echo 0 === $newstheme_index ? '' : ' aria-hidden="true"'; ?>>
					<a href="<?php echo esc_url( get_permalink( $newstheme_post ) ); ?>"<?php echo 0 === $newstheme_index ? '' : ' tabindex="-1"'; ?>><?php echo esc_html( get_the_title( $newstheme_post ) ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<?php if ( count( $newstheme_ticker ) > 1 ) : ?>
		<div class="nt-ticker__controls">
			<button type="button" class="nt-ticker__btn" data-nt-ticker-prev aria-label="<?php esc_attr_e( 'Previous headline', 'newstheme' ); ?>"><?php newstheme_icon( 'chevron-left' ); ?></button>
			<button type="button" class="nt-ticker__btn nt-ticker__pause" data-nt-ticker-pause aria-pressed="false" aria-label="<?php esc_attr_e( 'Pause headlines', 'newstheme' ); ?>"><?php newstheme_icon( 'pause' ); ?><?php newstheme_icon( 'play' ); ?></button>
			<button type="button" class="nt-ticker__btn" data-nt-ticker-next aria-label="<?php esc_attr_e( 'Next headline', 'newstheme' ); ?>"><?php newstheme_icon( 'chevron-right' ); ?></button>
		</div>
	<?php endif; ?>
</div>
