<?php
/**
 * Edition detection (OL-3): the same programme published for different years.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Opportunity;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Meta\RobotsResolver;

defined( 'ABSPATH' ) || exit;

/**
 * Groups scanned posts by edition key (title without years and numbers) when the
 * group spans at least two years.
 */
class Editions {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Edition groups, largest first.
	 *
	 * @param int $page     Page.
	 * @param int $per_page Per page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function groups( int $page = 1, int $per_page = 50 ): array {
		global $wpdb;
		$table  = Migrations::table( 'content_scan' );
		$offset = ( max( 1, $page ) - 1 ) * $per_page;
		$base   = "FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.edition_key <> '' AND s.edition_year > 0 GROUP BY s.edition_key HAVING COUNT(DISTINCT s.edition_year) >= 2";
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM (SELECT s.edition_key {$base}) g" );
		$keys  = $wpdb->get_col( $wpdb->prepare( "SELECT s.edition_key {$base} ORDER BY COUNT(*) DESC, MAX(s.edition_year) DESC LIMIT %d OFFSET %d", $per_page, $offset ) );
		// phpcs:enable
		$items = array();
		foreach ( (array) $keys as $key ) {
			$group = $this->group( (string) $key );
			if ( $group ) {
				$items[] = $group;
			}
		}
		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * One edition group with a recommendation.
	 *
	 * @param string $key Edition key.
	 * @return array<string, mixed>|null
	 */
	public function group( string $key ): ?array {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT s.post_id, s.edition_year FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.edition_key = %s ORDER BY s.edition_year DESC, p.post_date DESC LIMIT 50", $key ) );
		if ( ! $rows || count( $rows ) < 2 ) {
			return null;
		}
		$robots    = $this->c->get( RobotsResolver::class );
		$members   = array();
		$indexable = 0;
		foreach ( $rows as $row ) {
			$post = get_post( (int) $row->post_id );
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}
			$is_indexable = $robots->is_indexable( $post );
			$indexable   += $is_indexable ? 1 : 0;
			$members[]    = array(
				'id'        => $post->ID,
				'title'     => html_entity_decode( get_the_title( $post ), ENT_QUOTES ),
				'url'       => (string) get_permalink( $post ),
				'edit_url'  => (string) get_edit_post_link( $post->ID, 'raw' ),
				'year'      => (int) $row->edition_year,
				'deadline'  => (string) get_post_meta( $post->ID, '_flseo_opp_deadline', true ),
				'status'    => (string) get_post_meta( $post->ID, '_flseo_opp_status', true ),
				'indexable' => $is_indexable,
				'action'    => 'keep',
			);
		}
		if ( count( $members ) < 2 ) {
			return null;
		}
		$newest = $members[0]['id'];
		foreach ( $members as $index => $member ) {
			if ( 0 !== $index ) {
				$members[ $index ]['action'] = $member['indexable'] ? 'redirect' : 'keep';
			}
		}
		$risk = $indexable >= 2;
		return array(
			'edition_key'          => $key,
			'title'                => $members[0]['title'],
			'years'                => array_values( array_unique( array_column( $members, 'year' ) ) ),
			'members'              => $members,
			'newest_id'            => $newest,
			'cannibalization_risk' => $risk,
			'recommendation'       => $risk ? 'consolidate' : 'ok',
			'reason'               => $risk
				? __( 'Several editions of this programme are indexable and may compete in search. Keep the newest edition (or update one URL each cycle) and redirect older editions to it.', 'futurelabs-ai-seo' )
				: __( 'Only one edition is indexable, so editions are unlikely to compete.', 'futurelabs-ai-seo' ),
		);
	}

	/**
	 * Newest published edition with a later year than the post, if any.
	 *
	 * @param int $post_id Post ID.
	 */
	public function newer_edition( int $post_id ): int {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT edition_key, edition_year FROM {$table} WHERE post_id = %d", $post_id ) );
		if ( ! $row || '' === (string) $row->edition_key || ! (int) $row->edition_year ) {
			return 0;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT s.post_id FROM {$table} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.edition_key = %s AND s.edition_year > %d AND s.post_id <> %d ORDER BY s.edition_year DESC, p.post_date DESC LIMIT 1", (string) $row->edition_key, (int) $row->edition_year, $post_id ) );
	}
}
