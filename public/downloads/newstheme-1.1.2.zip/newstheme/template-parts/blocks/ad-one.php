<?php
/**
 * Block: advertisement — an image banner with link, or ad code.
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args (see newstheme_block_types()).
 */

defined( 'ABSPATH' ) || exit;

if ( ! $args['image'] && '' === trim( $args['html'] ) ) {
	return;
}
?>
<aside class="nt-ad" aria-label="<?php echo esc_attr( $args['label'] ? $args['label'] : __( 'Advertisement', 'newstheme' ) ); ?>">
	<?php if ( $args['label'] ) : ?>
		<span class="nt-ad__label"><?php echo esc_html( $args['label'] ); ?></span>
	<?php endif; ?>
	<?php if ( $args['image'] ) : ?>
		<?php
		// Linked images need alt text; fall back to the ad's label.
		$newstheme_alt = trim( (string) get_post_meta( $args['image'], '_wp_attachment_image_alt', true ) );
		$newstheme_img = wp_get_attachment_image(
			$args['image'],
			'full',
			false,
			array(
				'loading' => 'lazy',
				'alt'     => $newstheme_alt ? $newstheme_alt : ( $args['label'] ? $args['label'] : __( 'Advertisement', 'newstheme' ) ),
			)
		);
		?>
		<?php if ( $args['url'] ) : ?>
			<a href="<?php echo esc_url( $args['url'] ); ?>" target="_blank" rel="sponsored noopener"><?php echo $newstheme_img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core image markup. ?></a>
		<?php else : ?>
			<?php echo $newstheme_img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core image markup. ?>
		<?php endif; ?>
	<?php else : ?>
		<?php echo $args['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ad code, sanitized on save (see newstheme_block_args()). ?>
	<?php endif; ?>
</aside>
