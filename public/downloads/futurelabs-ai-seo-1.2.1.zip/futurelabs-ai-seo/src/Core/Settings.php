<?php
/**
 * Settings store backed by the single `flseo_settings` option.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Reads, sanitizes and persists plugin settings.
 */
class Settings {

	public const OPTION = 'flseo_settings';

	/**
	 * Cached merged settings.
	 *
	 * @var array<string, mixed>|null
	 */
	private ?array $cache = null;

	/**
	 * Default values. Nested arrays are merged one level deep.
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults(): array {
		return array(
			// Head output.
			'output_title'         => true,
			'output_description'   => true,
			'output_canonical'     => true,
			'output_robots'        => true,
			'output_social'        => true,
			'output_schema'        => true,
			'title_separator'      => '|',
			'home_title'           => '',
			'home_description'     => '',
			'default_og_image'     => '',
			'twitter_site'         => '',
			// Robots rules.
			'noindex_paginated'    => true,
			'noindex_author'       => false,
			'noindex_date'         => true,
			'redirect_attachments' => true,
			'max_image_preview'    => true,
			// Per type settings: { name: { index: bool, title: string, description: string, schema: string } }.
			'post_types'           => array(),
			// Per taxonomy settings: { name: { index: bool, title: string, description: string } }.
			'taxonomies'           => array(),
			// Sitemap.
			'sitemap_images'       => false,
			'sitemap_max_urls'     => 1000,
			'sitemap_sample_size'  => 50,
			'sitemap_ping'         => true,
			'indexnow_enabled'     => false,
			// Redirects and 404s.
			'slug_redirects'       => 'auto',
			'log_404'              => true,
			'ignore_404_noise'     => true,
			'retention_404_days'   => 90,
			// Opportunity lifecycle.
			'expiry_grace'         => 30,
			'closing_soon_days'    => 7,
			'expiry_action'        => 'notice',
			// Editorial.
			'hard_checklist'       => false,
			'thin_words'           => 300,
			'duplicate_threshold'  => 80,
			'velocity_posts'       => 10,
			'velocity_similarity'  => 70,
			'batch_size'           => 25,
			// Schema.
			'schema_entity'        => 'Organization',
			'schema_name'          => '',
			'schema_logo'          => '',
			'schema_sitesearch'    => true,
			'local_business'       => array(
				'enabled'   => false,
				'type'      => 'LocalBusiness',
				'street'    => '',
				'locality'  => '',
				'region'    => '',
				'postcode'  => '',
				'country'   => '',
				'telephone' => '',
			),
			'course_post_types'    => array(),
			// Integrations (secrets are stored separately, encrypted).
			'ai_enabled'           => false,
			'ai_provider'          => 'anthropic',
			'ai_model'             => 'claude-opus-5-5',
			'ai_model_openai'      => '',
			'ai_model_gemini'      => '',
			'ai_model_compatible'  => '',
			'ai_compatible_url'    => '',
			'ai_compatible_vision' => false,
			'ai_embeddings'        => false,
			'ai_rate_limit'        => 30,
			'psi_top_pages'        => 10,
			'reports_enabled'      => false,
			'reports_cadence'      => 'weekly',
			'reports_recipients'   => '',
			// Lifecycle.
			'onboarding_complete'  => false,
			'delete_data'          => false,
			// Access: feature (settings, data, editor) → role slugs. Empty = defaults (see Capabilities).
			'role_access'          => array(),
		);
	}

	/**
	 * Get every setting merged with defaults.
	 *
	 * @return array<string, mixed>
	 */
	public function all(): array {
		if ( null === $this->cache ) {
			$stored      = get_option( self::OPTION, array() );
			$this->cache = $this->merge( self::defaults(), is_array( $stored ) ? $stored : array() );
		}
		return $this->cache;
	}

	/**
	 * Get one setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback when unknown.
	 * @return mixed
	 */
	public function get( string $key, $default = null ) {
		$all = $this->all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * Settings for one post type with defaults applied.
	 *
	 * @param string $type Post type name.
	 * @return array{index: bool, title: string, description: string, schema: string}
	 */
	public function post_type( string $type ): array {
		$all    = (array) $this->get( 'post_types', array() );
		$object = get_post_type_object( $type );
		$public = $object && $object->public && 'attachment' !== $type;
		return wp_parse_args(
			(array) ( $all[ $type ] ?? array() ),
			array(
				'index'       => $public,
				'title'       => '%title% %sep% %sitename%',
				'description' => '',
				'schema'      => 'post' === $type ? 'Article' : 'WebPage',
			)
		);
	}

	/**
	 * Settings for one taxonomy with defaults applied.
	 *
	 * @param string $taxonomy Taxonomy name.
	 * @return array{index: bool, title: string, description: string}
	 */
	public function taxonomy( string $taxonomy ): array {
		$all = (array) $this->get( 'taxonomies', array() );
		return wp_parse_args(
			(array) ( $all[ $taxonomy ] ?? array() ),
			array(
				'index'       => in_array( $taxonomy, array( 'category', 'post_tag' ), true ) || ( get_taxonomy( $taxonomy ) && get_taxonomy( $taxonomy )->public ),
				'title'       => '%title% %sep% %sitename%',
				'description' => '',
			)
		);
	}

	/**
	 * Sanitize and persist a partial update. Unknown keys are ignored.
	 *
	 * @param array<string, mixed> $input Partial settings.
	 * @return array<string, mixed> Saved settings.
	 */
	public function update( array $input ): array {
		$current = $this->all();
		$clean   = $this->sanitize( $input, $current );
		$merged  = $this->merge( $current, $clean );
		update_option( self::OPTION, $merged, true );
		$this->cache = null;
		/**
		 * Fires after FutureLabs AI SEO settings change (used to purge page caches).
		 *
		 * @param array $merged New settings.
		 */
		do_action( 'flseo_settings_updated', $merged );
		return $this->all();
	}

	/**
	 * Sanitize a partial update without saving and return the settings it would produce.
	 *
	 * @param array<string, mixed> $input Partial settings.
	 * @return array<string, mixed>
	 */
	public function preview( array $input ): array {
		return $this->merge( $this->all(), $this->sanitize( $input, $this->all() ) );
	}

	/**
	 * Replace the stored settings entirely (used by JSON import).
	 *
	 * @param array<string, mixed> $input Settings.
	 * @return array<string, mixed>
	 */
	public function replace( array $input ): array {
		$clean = $this->sanitize( $input, self::defaults() );
		update_option( self::OPTION, $this->merge( self::defaults(), $clean ), true );
		$this->cache = null;
		do_action( 'flseo_settings_updated', $this->all() );
		return $this->all();
	}

	/**
	 * Forget cached values (after direct option writes).
	 */
	public function flush(): void {
		$this->cache = null;
	}

	/**
	 * Sanitize input against default value types.
	 *
	 * @param array<string, mixed> $input   Raw input.
	 * @param array<string, mixed> $current Current values for type reference.
	 * @return array<string, mixed>
	 */
	private function sanitize( array $input, array $current ): array {
		$defaults = self::defaults();
		$clean    = array();
		foreach ( $input as $key => $value ) {
			if ( ! array_key_exists( $key, $defaults ) ) {
				continue;
			}
			$clean[ $key ] = $this->sanitize_value( (string) $key, $value, $defaults[ $key ] );
		}
		return $clean;
	}

	/**
	 * Sanitize one value.
	 *
	 * @param string $key     Key.
	 * @param mixed  $value   Raw value.
	 * @param mixed  $default Default (determines type).
	 * @return mixed
	 */
	private function sanitize_value( string $key, $value, $default ) {
		switch ( $key ) {
			case 'post_types':
				return $this->sanitize_type_map( $value, true );
			case 'taxonomies':
				return $this->sanitize_type_map( $value, false );
			case 'local_business':
				$out = array();
				foreach ( (array) $default as $field => $field_default ) {
					$raw           = is_array( $value ) ? ( $value[ $field ] ?? $field_default ) : $field_default;
					$out[ $field ] = is_bool( $field_default ) ? self::to_bool( $raw ) : sanitize_text_field( (string) $raw );
				}
				return $out;
			case 'role_access':
				$out   = array();
				$known = array_keys( wp_roles()->roles );
				foreach ( array_keys( Capabilities::CAPS ) as $feature ) {
					if ( is_array( $value ) && isset( $value[ $feature ] ) ) {
						$out[ $feature ] = array_values( array_intersect( array_map( 'sanitize_key', (array) $value[ $feature ] ), $known ) );
					}
				}
				return $out;
			case 'course_post_types':
				return array_values( array_filter( array_map( 'sanitize_key', (array) $value ) ) );
			case 'slug_redirects':
				return in_array( $value, array( 'auto', 'suggest', 'off' ), true ) ? $value : 'auto';
			case 'expiry_action':
				return in_array( $value, array( 'notice', 'noindex', 'redirect', 'none' ), true ) ? $value : 'notice';
			case 'ai_provider':
				return \FutureLabs\AISEO\Ai\AiClient::sanitize_id( $value );
			case 'ai_model_openai':
			case 'ai_model_compatible':
				return \FutureLabs\AISEO\Ai\OpenAiClient::clean_model( (string) $value );
			case 'ai_model_gemini':
				return \FutureLabs\AISEO\Ai\OpenAiClient::clean_model( (string) preg_replace( '#^models/#', '', trim( (string) $value ) ) );
			case 'ai_compatible_url':
				return \FutureLabs\AISEO\Ai\OpenAiCompatibleClient::clean_base_url( (string) $value );
			case 'reports_cadence':
				return 'monthly' === $value ? 'monthly' : 'weekly';
			case 'schema_entity':
				return 'Person' === $value ? 'Person' : 'Organization';
			case 'home_title':
			case 'home_description':
				return \FutureLabs\AISEO\Meta\PostMeta::sanitize_template( (string) $value );
			case 'default_og_image':
			case 'schema_logo':
				return esc_url_raw( (string) $value );
			case 'reports_recipients':
				$emails = preg_split( '/[,;\s]+/', (string) $value, -1, PREG_SPLIT_NO_EMPTY );
				$emails = array_filter( array_map( 'sanitize_email', (array) $emails ), 'is_email' );
				return implode( ', ', array_unique( $emails ) );
			case 'expiry_grace':
				return min( 365, max( 0, absint( $value ) ) );
			case 'retention_404_days':
				return min( 3650, max( 1, absint( $value ) ) );
			case 'sitemap_max_urls':
				return min( 50000, max( 100, absint( $value ) ) );
			case 'duplicate_threshold':
			case 'velocity_similarity':
				return min( 100, max( 50, absint( $value ) ) );
			case 'batch_size':
				return min( 500, max( 5, absint( $value ) ) );
		}
		if ( is_bool( $default ) ) {
			return self::to_bool( $value );
		}
		if ( is_int( $default ) ) {
			return max( 0, (int) $value );
		}
		if ( is_array( $default ) ) {
			return is_array( $value ) ? map_deep( $value, 'sanitize_text_field' ) : $default;
		}
		return sanitize_text_field( (string) $value );
	}

	/**
	 * Sanitize a post type or taxonomy settings map.
	 *
	 * @param mixed $value      Raw map.
	 * @param bool  $with_schema Whether entries carry a schema type.
	 * @return array<string, array<string, mixed>>
	 */
	private function sanitize_type_map( $value, bool $with_schema ): array {
		$out = array();
		foreach ( (array) $value as $name => $entry ) {
			$name = sanitize_key( (string) $name );
			if ( '' === $name || ! is_array( $entry ) ) {
				continue;
			}
			$item = array(
				'index'       => self::to_bool( $entry['index'] ?? true ),
				'title'       => \FutureLabs\AISEO\Meta\PostMeta::sanitize_template( (string) ( $entry['title'] ?? '' ) ),
				'description' => \FutureLabs\AISEO\Meta\PostMeta::sanitize_template( (string) ( $entry['description'] ?? '' ) ),
			);
			if ( $with_schema ) {
				$schema         = (string) ( $entry['schema'] ?? 'Article' );
				$item['schema'] = in_array( $schema, \FutureLabs\AISEO\Schema\Types::selectable(), true ) ? $schema : 'WebPage';
			}
			$out[ $name ] = $item;
		}
		return $out;
	}

	/**
	 * Merge stored values over defaults (one level deep for arrays of scalars).
	 *
	 * @param array<string, mixed> $base   Base.
	 * @param array<string, mixed> $values Overrides.
	 * @return array<string, mixed>
	 */
	private function merge( array $base, array $values ): array {
		foreach ( $values as $key => $value ) {
			if ( 'local_business' === $key && is_array( $value ) && isset( $base[ $key ] ) && is_array( $base[ $key ] ) ) {
				$base[ $key ] = array_merge( $base[ $key ], $value );
				continue;
			}
			$base[ $key ] = $value;
		}
		return $base;
	}

	/**
	 * Interpret common truthy representations.
	 *
	 * @param mixed $value Raw value.
	 */
	public static function to_bool( $value ): bool {
		return in_array( $value, array( true, 1, '1', 'true', 'on', 'yes' ), true );
	}
}
