<?php
/**
 * PageSpeed Insights v5 client.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Performance;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Crypto;
use FutureLabs\AISEO\Core\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Runs `runPagespeed` for URLs on this site with the administrator's API key.
 */
class PsiClient {

	public const ENDPOINT   = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
	public const KEY_OPTION = 'flseo_psi_key';
	public const STRATEGIES = array( 'mobile', 'desktop' );

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Whether a key is stored.
	 */
	public function has_key(): bool {
		return $this->c->get( Crypto::class )->has_secret( self::KEY_OPTION );
	}

	/**
	 * SSRF guard: only http(s) URLs whose host equals this site's host.
	 *
	 * @param string $url URL.
	 */
	public static function is_allowed_url( string $url ): bool {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) || ! in_array( strtolower( (string) ( $parts['scheme'] ?? '' ) ), array( 'http', 'https' ), true ) || isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
			return false;
		}
		$home = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
		return '' !== $home && strtolower( (string) $parts['host'] ) === $home;
	}

	/**
	 * Measure a URL.
	 *
	 * @param string $url      URL on this site.
	 * @param string $strategy mobile|desktop.
	 * @return array{url: string, strategy: string, lcp: float|null, inp: float|null, inp_source: string|null, cls: float|null, score: int|null}|\WP_Error
	 */
	public function run( string $url, string $strategy = 'mobile' ) {
		$url = esc_url_raw( trim( $url ) );
		if ( ! self::is_allowed_url( $url ) ) {
			return new \WP_Error( 'flseo_psi_url', __( 'Only URLs on this site can be measured.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$strategy = in_array( $strategy, self::STRATEGIES, true ) ? $strategy : 'mobile';
		$key      = $this->c->get( Crypto::class )->get_secret( self::KEY_OPTION );
		if ( '' === $key ) {
			return new \WP_Error( 'flseo_psi_no_key', __( 'Add a PageSpeed Insights API key in FutureLabs AI SEO settings first.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$endpoint = add_query_arg(
			array(
				'url'      => rawurlencode( $url ),
				'strategy' => $strategy,
				'category' => 'performance',
				'key'      => rawurlencode( $key ),
			),
			self::ENDPOINT
		);
		$response = wp_safe_remote_get( $endpoint, array( 'timeout' => 90 ) );
		if ( is_wp_error( $response ) ) {
			$this->c->get( Logger::class )->warning( 'PageSpeed Insights request failed.', array( 'status' => 0 ) );
			return new \WP_Error( 'flseo_psi_unreachable', __( 'Could not reach PageSpeed Insights. Try again later.', 'futurelabs-ai-seo' ), array( 'status' => 502 ) );
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		$data   = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $status || ! is_array( $data ) ) {
			// Log the status only: the request URL contains the key.
			$this->c->get( Logger::class )->warning( 'PageSpeed Insights returned an error.', array( 'status' => $status ) );
			switch ( $status ) {
				case 400:
					$message = __( 'PageSpeed Insights could not load this URL. Check that it is public and returns a page.', 'futurelabs-ai-seo' );
					break;
				case 403:
					$message = __( 'PageSpeed Insights rejected the API key, or the API is not enabled for it in Google Cloud.', 'futurelabs-ai-seo' );
					break;
				case 429:
					$message = __( 'PageSpeed Insights quota reached. Try again later.', 'futurelabs-ai-seo' );
					break;
				default:
					$message = __( 'PageSpeed Insights returned an error. Try again later.', 'futurelabs-ai-seo' );
			}
			return new \WP_Error(
				'flseo_psi_failed',
				$message,
				array(
					'status'     => 429 === $status ? 429 : 502,
					'api_status' => $status,
				)
			);
		}
		return array_merge(
			array(
				'url'      => $url,
				'strategy' => $strategy,
			),
			self::parse( $data )
		);
	}

	/**
	 * Extract metrics from a runPagespeed response.
	 *
	 * @param array<string, mixed> $data Response.
	 * @return array{lcp: float|null, inp: float|null, inp_source: string|null, cls: float|null, score: int|null}
	 */
	public static function parse( array $data ): array {
		$audits = (array) ( $data['lighthouseResult']['audits'] ?? array() );
		$number = static function ( $value ): ?float {
			return is_numeric( $value ) ? (float) $value : null;
		};
		$lcp    = $number( $audits['largest-contentful-paint']['numericValue'] ?? null );
		$cls    = $number( $audits['cumulative-layout-shift']['numericValue'] ?? null );
		$score  = $number( $data['lighthouseResult']['categories']['performance']['score'] ?? null );

		// INP is a field metric; Lighthouse lab runs rarely have it.
		$inp        = $number( $data['loadingExperience']['metrics']['INTERACTION_TO_NEXT_PAINT']['percentile'] ?? null );
		$inp_source = null !== $inp ? 'field' : null;
		if ( null === $inp ) {
			$inp        = $number( $audits['interaction-to-next-paint']['numericValue'] ?? null );
			$inp_source = null !== $inp ? 'lab' : null;
		}
		return array(
			'lcp'        => null !== $lcp ? round( $lcp / 1000, 3 ) : null,
			'inp'        => null !== $inp ? round( $inp, 1 ) : null,
			'inp_source' => $inp_source,
			'cls'        => null !== $cls ? round( $cls, 4 ) : null,
			'score'      => null !== $score ? (int) round( $score * 100 ) : null,
		);
	}
}
