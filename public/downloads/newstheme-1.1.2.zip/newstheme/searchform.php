<?php
/**
 * Search form. Used everywhere via get_search_form() (so plugins can filter
 * it); the header passes extra args for its dropdown and live results.
 *
 * @package NewsTheme
 *
 * @var array $args {
 *     Optional. Passed by get_search_form().
 *     @type string $nt_id_suffix Suffix for unique IDs (header copies).
 *     @type bool   $nt_live      Whether live results are enabled.
 *     @type string $nt_class     Form class.
 * }
 */

defined( 'ABSPATH' ) || exit;

$newstheme_args   = isset( $args ) && is_array( $args ) ? $args : array();
$newstheme_suffix = $newstheme_args['nt_id_suffix'] ?? null;
$newstheme_id     = null !== $newstheme_suffix ? 'nt-search-input' . $newstheme_suffix : wp_unique_id( 'nt-s-' );
$newstheme_live   = ! empty( $newstheme_args['nt_live'] );
$newstheme_status = 'nt-search-status' . ( $newstheme_suffix ?? '' );
?>
<form role="search" method="get" class="<?php echo esc_attr( $newstheme_args['nt_class'] ?? 'nt-search-form' ); ?>" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $newstheme_id ); ?>"><?php esc_html_e( 'Search for:', 'newstheme' ); ?></label>
	<input type="search" id="<?php echo esc_attr( $newstheme_id ); ?>" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search …', 'newstheme' ); ?>" autocomplete="off"<?php echo $newstheme_live ? ' aria-describedby="' . esc_attr( $newstheme_status ) . '"' : ''; ?>>
	<button type="submit" class="nt-button"><?php esc_html_e( 'Search', 'newstheme' ); ?></button>
</form>
