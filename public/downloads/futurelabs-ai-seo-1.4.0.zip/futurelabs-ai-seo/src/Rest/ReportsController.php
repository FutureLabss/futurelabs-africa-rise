<?php
/**
 * Reports endpoint: index history for the dashboard chart.
 *
 * The other report endpoints (digest test and preview, refresh list, keyword
 * suggestions) are in FutureLabs AI SEO Pro.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Reports\History;

defined( 'ABSPATH' ) || exit;

/**
 * /reports/history route.
 */
class ReportsController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/reports/history', 'GET', array( $this, 'history' ), Capabilities::DATA );
	}

	/**
	 * GET /reports/history?days=90
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function history( \WP_REST_Request $request ): \WP_REST_Response {
		$days  = min( 730, max( 1, absint( $request->get_param( 'days' ) ?: 90 ) ) );
		$items = $this->c->get( History::class )->series( $days );
		return rest_ensure_response(
			array(
				'items' => $items,
				'total' => count( $items ),
			)
		);
	}
}
