<?php
/**
 * Weekly or monthly digest email.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Reports;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Renders and sends the digest via the `flseo_digest` job.
 *
 * Each run is scheduled as a single action for the next send time (Monday 08:00 for weekly,
 * the 1st of the month 08:00 for monthly, site timezone) with that timestamp as its argument,
 * so the next run can be queued from inside the running one.
 */
class Digest implements Module {

	public const HOOK        = 'flseo_digest';
	public const LAST        = 'flseo_digest_last';
	public const NEXT        = 'flseo_digest_next';
	private const MAX_ISSUES = 5000;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( self::HOOK, array( $this, 'run' ) );
		add_action( 'flseo_daily', array( $this, 'ensure_schedule' ) );
		add_action( 'flseo_settings_updated', array( $this, 'reschedule' ) );
	}

	/**
	 * Whether digests are on and have recipients.
	 */
	public function active(): bool {
		return (bool) $this->c->get( Settings::class )->get( 'reports_enabled' ) && (bool) $this->c->get( Mailer::class )->recipients();
	}

	/**
	 * Next send time for the cadence.
	 *
	 * @param int|null $from Unix time to start from (now when null).
	 */
	public function next_time( ?int $from = null ): int {
		$tz   = wp_timezone();
		$now  = ( new \DateTimeImmutable( '@' . ( $from ?? time() ) ) )->setTimezone( $tz );
		$next = 'monthly' === $this->c->get( Settings::class )->get( 'reports_cadence' )
			? $now->modify( 'first day of next month' )->setTime( 8, 0 )
			: $now->modify( 'next monday' )->setTime( 8, 0 );
		return $next->getTimestamp();
	}

	/**
	 * Make sure exactly one future run is queued when active.
	 */
	public function ensure_schedule(): void {
		$queue = $this->c->get( Queue::class );
		if ( ! $this->active() ) {
			$queue->cancel( self::HOOK );
			delete_option( self::NEXT );
			return;
		}
		$next = (int) get_option( self::NEXT, 0 );
		if ( $next > time() && $queue->is_pending( self::HOOK, array( $next ) ) ) {
			return;
		}
		$this->schedule_next();
	}

	/**
	 * Settings changed: rebuild the schedule (cadence may have changed).
	 */
	public function reschedule(): void {
		$this->c->get( Queue::class )->cancel( self::HOOK );
		delete_option( self::NEXT );
		$this->ensure_schedule();
	}

	/**
	 * Queue the next run.
	 */
	private function schedule_next(): void {
		$next = $this->next_time();
		update_option( self::NEXT, $next, false );
		$this->c->get( Queue::class )->at( $next, self::HOOK, array( $next ) );
	}

	/**
	 * Job callback: send the digest, then queue the next one.
	 *
	 * @param int $scheduled_for Timestamp the run was scheduled for.
	 */
	public function run( $scheduled_for = 0 ): void {
		unset( $scheduled_for );
		if ( ! $this->active() ) {
			return;
		}
		$this->send();
		$this->schedule_next();
	}

	/**
	 * Send the digest (or a test) to the configured recipients.
	 *
	 * @param bool $test Test email (does not move the "since last digest" baseline).
	 * @return array{sent: bool, recipient_count: int}
	 */
	public function send( bool $test = false ): array {
		$mailer     = $this->c->get( Mailer::class );
		$recipients = $mailer->recipients();
		if ( ! $recipients ) {
			return array(
				'sent'            => false,
				'recipient_count' => 0,
			);
		}
		$digest = $this->render( $test );
		$sent   = $mailer->send( $recipients, $digest['subject'], $digest['html'], $digest['text'] );
		if ( $sent && ! $test ) {
			update_option(
				self::LAST,
				array(
					'sent_at' => current_time( 'mysql', true ),
					'numbers' => $digest['numbers'],
					'issues'  => array_slice( $this->issue_keys(), 0, self::MAX_ISSUES ),
				),
				false
			);
		}
		return array(
			'sent'            => $sent,
			'recipient_count' => count( $recipients ),
		);
	}

	/**
	 * Current open issue keys: content findings and non-indexed inspection reasons.
	 *
	 * @return array<int, string>
	 */
	public function issue_keys(): array {
		global $wpdb;
		$scan   = Migrations::table( 'content_scan' );
		$status = Migrations::table( 'index_status' );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$content = (array) $wpdb->get_col( "SELECT CONCAT('content:', s.post_id, ':', s.recommendation) FROM {$scan} s INNER JOIN {$wpdb->posts} p ON p.ID=s.post_id WHERE s.recommendation<>'ok' AND s.recommendation<>'' AND p.post_status='publish'" );
		$index   = (array) $wpdb->get_col( "SELECT CONCAT('index:', url_hash, ':', reason_code) FROM {$status} WHERE reason_code<>'' AND UPPER(verdict)<>'PASS'" );
		// phpcs:enable
		$keys = array_values( array_unique( array_map( 'strval', array_merge( $content, $index ) ) ) );
		sort( $keys );
		return $keys;
	}

	/**
	 * Top fixes: the indexing prioritizer's groups when available, else (or when it has none) content findings.
	 *
	 * @return array<int, array{label: string, count: int}>
	 */
	public function top_fixes(): array {
		$class = 'FutureLabs\\AISEO\\Indexing\\Prioritizer';
		if ( class_exists( $class ) && method_exists( $class, 'groups' ) ) {
			$out = array();
			foreach ( (array) $this->c->get( $class )->groups( 5, 1 ) as $group ) {
				$group = (array) $group;
				$label = (string) ( $group['reason_label'] ?? $group['label'] ?? $group['reason_code'] ?? '' );
				if ( ! empty( $group['post_type_label'] ) ) {
					$label .= ' (' . $group['post_type_label'] . ')';
				}
				$count = (int) ( $group['count'] ?? 0 );
				if ( '' !== $label && $count > 0 ) {
					$out[] = array(
						'label' => $label,
						'count' => $count,
					);
				}
			}
			if ( $out ) {
				return $out;
			}
		}
		global $wpdb;
		$scan = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( "SELECT s.recommendation, COUNT(*) total FROM {$scan} s INNER JOIN {$wpdb->posts} p ON p.ID=s.post_id WHERE s.recommendation<>'ok' AND s.recommendation<>'' AND p.post_status='publish' GROUP BY s.recommendation ORDER BY total DESC LIMIT 5" );
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'label' => self::finding_label( (string) $row->recommendation ),
				'count' => (int) $row->total,
			);
		}
		return $out;
	}

	/**
	 * Human label for a content scan recommendation.
	 *
	 * @param string $code Recommendation code.
	 */
	public static function finding_label( string $code ): string {
		$labels = array(
			'improve'  => __( 'Thin pages to improve', 'futurelabs-ai-seo' ),
			'expand'   => __( 'Thin pages to expand', 'futurelabs-ai-seo' ),
			'thin'     => __( 'Thin pages to improve', 'futurelabs-ai-seo' ),
			'merge'    => __( 'Duplicate pages to merge', 'futurelabs-ai-seo' ),
			'redirect' => __( 'Old editions to redirect', 'futurelabs-ai-seo' ),
			'noindex'  => __( 'Pages to consider for noindex', 'futurelabs-ai-seo' ),
			'rewrite'  => __( 'Templated pages to rewrite', 'futurelabs-ai-seo' ),
			'update'   => __( 'Outdated pages to update', 'futurelabs-ai-seo' ),
		);
		return $labels[ $code ] ?? ucfirst( str_replace( array( '_', '-' ), ' ', $code ) );
	}

	/**
	 * Build the digest.
	 *
	 * @param bool $test Whether this is a test send.
	 * @return array{subject: string, html: string, text: string, numbers: array<string, mixed>}
	 */
	public function render( bool $test = false ): array {
		$metrics = $this->c->get( History::class )->metrics();
		$last    = (array) get_option( self::LAST, array() );
		$current = $this->issue_keys();
		$has_old = isset( $last['issues'] ) && is_array( $last['issues'] );
		$old     = $has_old ? array_map( 'strval', $last['issues'] ) : array();
		$refresh = $this->c->get( RefreshAlerts::class )->alerts();
		$fixes   = $this->top_fixes();

		$numbers = array(
			'known'           => $metrics['known'],
			'inspected'       => $metrics['inspected'],
			'indexed'         => $metrics['indexed'],
			'indexed_percent' => $metrics['known'] > 0 && $metrics['inspected'] > 0 ? round( $metrics['indexed'] / $metrics['known'] * 100, 1 ) : null,
			'noindex'         => $metrics['noindex'],
			'flagged'         => $metrics['flagged'],
			'open_issues'     => count( $current ),
			'new_issues'      => $has_old ? count( array_diff( $current, $old ) ) : null,
			'resolved_issues' => $has_old ? count( array_diff( $old, $current ) ) : null,
			'refresh'         => $refresh['total'],
			'since'           => $has_old ? (string) ( $last['sent_at'] ?? '' ) : null,
		);

		$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$cadence = 'monthly' === $this->c->get( Settings::class )->get( 'reports_cadence' ) ? __( 'monthly', 'futurelabs-ai-seo' ) : __( 'weekly', 'futurelabs-ai-seo' );
		$subject = $test
			/* translators: %s: site name. */
			? sprintf( __( '[%s] FutureLabs AI SEO test digest', 'futurelabs-ai-seo' ), $site )
			/* translators: 1: site name, 2: weekly or monthly. */
			: sprintf( __( '[%1$s] FutureLabs AI SEO %2$s digest', 'futurelabs-ai-seo' ), $site, $cadence );

		$lines   = array();
		$lines[] = null === $numbers['indexed_percent']
			? __( 'Indexed pages: not measured yet. Connect Search Console and run URL Inspection to measure indexing.', 'futurelabs-ai-seo' )
			/* translators: 1: indexed pages, 2: published pages, 3: percent. */
			: sprintf( __( 'Indexed pages: %1$d of %2$d published (%3$s%%), based on URL Inspection results.', 'futurelabs-ai-seo' ), $numbers['indexed'], $numbers['known'], number_format_i18n( (float) $numbers['indexed_percent'], 1 ) );
		/* translators: %d: pages. */
		$lines[] = sprintf( __( 'Pages with an open content finding: %d', 'futurelabs-ai-seo' ), $numbers['flagged'] );
		/* translators: %d: pages. */
		$lines[] = sprintf( __( 'Pages marked noindex: %d', 'futurelabs-ai-seo' ), $numbers['noindex'] );
		if ( $has_old ) {
			/* translators: %d: issues. */
			$lines[] = sprintf( __( 'New issues since the last digest: %d', 'futurelabs-ai-seo' ), $numbers['new_issues'] );
			/* translators: %d: issues. */
			$lines[] = sprintf( __( 'Issues resolved since the last digest: %d', 'futurelabs-ai-seo' ), $numbers['resolved_issues'] );
		} else {
			/* translators: %d: issues. */
			$lines[] = sprintf( __( 'Open issues: %d (new and resolved counts start with the next digest).', 'futurelabs-ai-seo' ), $numbers['open_issues'] );
		}

		$fix_lines = array();
		foreach ( $fixes as $fix ) {
			$fix_lines[] = sprintf( '%s (%d)', $fix['label'], $fix['count'] );
		}
		$refresh_lines = array();
		foreach ( array_slice( $refresh['items'], 0, 10 ) as $item ) {
			$label           = '' !== $item['title'] ? $item['title'] : $item['url'];
			$change          = null !== $item['click_change_percent'] ? $item['click_change_percent'] : $item['impression_change_percent'];
			$refresh_lines[] = array(
				/* translators: 1: page, 2: percent change. */
				'text' => sprintf( __( '%1$s (%2$s%% vs previous period)', 'futurelabs-ai-seo' ), $label, number_format_i18n( (float) $change, 1 ) ),
				'url'  => $item['url'],
			);
		}
		$honest = __( 'FutureLabs AI SEO identifies blockers; it does not guarantee rankings.', 'futurelabs-ai-seo' );
		$admin  = admin_url( 'admin.php?page=futurelabs-ai-seo' );

		// Plain text.
		$text   = array( $subject, '' );
		$text   = array_merge( $text, $lines );
		$text[] = '';
		$text[] = __( 'Top fixes', 'futurelabs-ai-seo' );
		$text   = array_merge( $text, $fix_lines ? array_map( static fn( $l ) => '- ' . $l, $fix_lines ) : array( '- ' . __( 'No open fixes found.', 'futurelabs-ai-seo' ) ) );
		$text[] = '';
		$text[] = __( 'Refresh list', 'futurelabs-ai-seo' );
		$text   = array_merge( $text, $refresh_lines ? array_map( static fn( $l ) => '- ' . $l['text'] . ' ' . $l['url'], $refresh_lines ) : array( '- ' . ( '' !== $refresh['message'] ? $refresh['message'] : __( 'No pages lost 30% or more of their clicks or impressions.', 'futurelabs-ai-seo' ) ) ) );
		$text[] = '';
		/* translators: %s: admin URL. */
		$text[] = sprintf( __( 'Open FutureLabs AI SEO: %s', 'futurelabs-ai-seo' ), $admin );
		$text[] = $honest;

		// HTML.
		$html  = '<!DOCTYPE html><html><body style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#1e1e1e;max-width:640px;margin:0 auto;padding:16px">';
		$html .= '<h1 style="font-size:20px">' . esc_html( $subject ) . '</h1><ul>';
		foreach ( $lines as $line ) {
			$html .= '<li>' . esc_html( $line ) . '</li>';
		}
		$html .= '</ul><h2 style="font-size:16px">' . esc_html__( 'Top fixes', 'futurelabs-ai-seo' ) . '</h2><ul>';
		$html .= $fix_lines ? implode( '', array_map( static fn( $l ) => '<li>' . esc_html( $l ) . '</li>', $fix_lines ) ) : '<li>' . esc_html__( 'No open fixes found.', 'futurelabs-ai-seo' ) . '</li>';
		$html .= '</ul><h2 style="font-size:16px">' . esc_html__( 'Refresh list', 'futurelabs-ai-seo' ) . '</h2><ul>';
		if ( $refresh_lines ) {
			foreach ( $refresh_lines as $line ) {
				$html .= '<li><a href="' . esc_url( $line['url'] ) . '">' . esc_html( $line['text'] ) . '</a></li>';
			}
		} else {
			$html .= '<li>' . esc_html( '' !== $refresh['message'] ? $refresh['message'] : __( 'No pages lost 30% or more of their clicks or impressions.', 'futurelabs-ai-seo' ) ) . '</li>';
		}
		$html .= '</ul><p><a href="' . esc_url( $admin ) . '">' . esc_html__( 'Open FutureLabs AI SEO', 'futurelabs-ai-seo' ) . '</a></p>';
		$html .= '<p style="color:#757575;font-size:12px">' . esc_html( $honest ) . '</p></body></html>';

		return array(
			'subject' => $subject,
			'html'    => $html,
			'text'    => implode( "\n", $text ),
			'numbers' => $numbers,
		);
	}
}
