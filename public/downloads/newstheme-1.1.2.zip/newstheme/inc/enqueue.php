<?php
/**
 * Front-end and editor assets.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue front-end styles and scripts.
 */
function newstheme_enqueue_assets() {
	wp_enqueue_style(
		'newstheme-main',
		NEWSTHEME_URI . 'assets/css/main.css',
		array(),
		newstheme_asset_version( 'assets/css/main.css' )
	);

	wp_enqueue_script(
		'newstheme-theme',
		NEWSTHEME_URI . 'assets/js/theme.js',
		array(),
		newstheme_asset_version( 'assets/js/theme.js' ),
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);

	wp_localize_script(
		'newstheme-theme',
		'newsthemeData',
		array(
			'searchUrl' => esc_url_raw( rest_url( 'newstheme/v1/search' ) ),
			'restRoot'  => esc_url_raw( rest_url( 'newstheme/v1/' ) ),
			'deadline'  => newstheme_deadline_script_data(),
			'i18n'      => array(
				'noResults'   => __( 'No posts found.', 'newstheme' ),
				/* translators: %d: number of search results. */
				'results'     => __( '%d results found.', 'newstheme' ),
				'viewAll'     => __( 'View all results', 'newstheme' ),
				'pause'       => __( 'Pause headlines', 'newstheme' ),
				'play'        => __( 'Play headlines', 'newstheme' ),
				'showSubmenu' => __( 'Show sub-menu', 'newstheme' ),
				'hideSubmenu' => __( 'Hide sub-menu', 'newstheme' ),
				'playVideo'   => __( 'Play video', 'newstheme' ),
				'pauseVideo'  => __( 'Pause video', 'newstheme' ),
			),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'newstheme_enqueue_assets' );

/**
 * Preload the two fonts used above the fold so headings don't swap late.
 */
function newstheme_preload_fonts() {
	foreach ( array( 'roboto-latin-wght-normal.woff2', 'inter-latin-wght-normal.woff2' ) as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( NEWSTHEME_URI . 'assets/fonts/' . $font )
		);
	}
}
add_action( 'wp_head', 'newstheme_preload_fonts', 1 );
