<?php
/**
 * Base REST controller.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;

defined( 'ABSPATH' ) || exit;

/**
 * Shared helpers for `flseo/v1` controllers.
 *
 * Cookie-authenticated REST requests only carry a user when a valid `X-WP-Nonce`
 * is sent, so the capability check in every permission callback also enforces the nonce.
 */
abstract class Controller {

	public const NAMESPACE = 'flseo/v1';

	/**
	 * Service container.
	 *
	 * @var Container
	 */
	protected Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Register this controller's routes.
	 */
	abstract public function register_routes(): void;

	/**
	 * Register one route.
	 *
	 * @param string               $path     Route path.
	 * @param string|array<string> $methods  HTTP methods.
	 * @param callable             $callback Handler.
	 * @param string               $feature  Capability feature key.
	 * @param array<string, mixed> $args     Argument schema.
	 */
	protected function route( string $path, $methods, callable $callback, string $feature = Capabilities::DATA, array $args = array() ): void {
		register_rest_route(
			self::NAMESPACE,
			$path,
			array(
				'methods'             => $methods,
				'callback'            => $callback,
				'permission_callback' => static function () use ( $feature ): bool {
					return Capabilities::can( $feature );
				},
				'args'                => $args,
			)
		);
	}

	/**
	 * Error response.
	 *
	 * @param string               $code    Machine code.
	 * @param string               $message Human message.
	 * @param int                  $status  HTTP status.
	 * @param array<string, mixed> $data    Extra data.
	 */
	protected function error( string $code, string $message, int $status = 400, array $data = array() ): \WP_Error {
		return new \WP_Error( 'flseo_' . $code, $message, array_merge( array( 'status' => $status ), $data ) );
	}

	/**
	 * Request body as array (JSON or form params).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed>
	 */
	protected function body( \WP_REST_Request $request ): array {
		$json = $request->get_json_params();
		if ( is_array( $json ) && $json ) {
			return $json;
		}
		return (array) $request->get_body_params() + (array) $request->get_query_params();
	}

	/**
	 * Common pagination args.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @param int              $max     Max per page.
	 * @return array{0:int,1:int} page, per_page
	 */
	protected function paging( \WP_REST_Request $request, int $max = 100 ): array {
		$page     = max( 1, absint( $request->get_param( 'page' ) ?: 1 ) );
		$per_page = min( $max, max( 1, absint( $request->get_param( 'per_page' ) ?: 50 ) ) );
		return array( $page, $per_page );
	}
}
