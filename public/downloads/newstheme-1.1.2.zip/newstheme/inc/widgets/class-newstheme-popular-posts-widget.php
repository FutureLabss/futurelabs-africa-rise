<?php
/**
 * NewsTheme Popular Posts Widget.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

require_once NEWSTHEME_DIR . 'inc/widgets/class-newstheme-posts-list-widget.php';

/**
 * Popular posts: the posts list with rank numbers, ordered by comments.
 */
class NewsTheme_Popular_Posts_Widget extends NewsTheme_Posts_List_Widget {

	/**
	 * Default list style.
	 *
	 * @var string
	 */
	protected $default_style = 'numbered';

	/**
	 * Default order.
	 *
	 * @var string
	 */
	protected $default_orderby = 'comment_count';

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct( 'popular_posts', __( 'NewsTheme: Popular Posts', 'newstheme' ), __( 'Most-commented posts with rank numbers.', 'newstheme' ) );
		$this->fields['title']['default'] = __( 'Popular News', 'newstheme' );
	}
}
