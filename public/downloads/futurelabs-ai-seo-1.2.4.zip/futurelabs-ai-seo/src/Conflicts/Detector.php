<?php
/**
 * Detects other SEO plugins and stack components that may emit overlapping metadata.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Conflicts;

use FutureLabs\AISEO\Core\Container;

defined( 'ABSPATH' ) || exit;

/**
 * Plugin-slug based detection plus site-level warnings.
 */
class Detector {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Full SEO plugins FutureLabs AI SEO can import from or replace.
	 *
	 * @return array<string, array{name: string, importer: string}>
	 */
	public static function seo_plugins(): array {
		return array(
			'wordpress-seo/wp-seo.php'                    => array(
				'name'     => 'Yoast SEO',
				'importer' => 'yoast',
			),
			'wordpress-seo-premium/wp-seo-premium.php'    => array(
				'name'     => 'Yoast SEO Premium',
				'importer' => 'yoast',
			),
			'all-in-one-seo-pack/all_in_one_seo_pack.php' => array(
				'name'     => 'All in One SEO',
				'importer' => 'aioseo',
			),
			'all-in-one-seo-pack-pro/all_in_one_seo_pack.php' => array(
				'name'     => 'All in One SEO Pro',
				'importer' => 'aioseo',
			),
			'seo-by-rank-math/rank-math.php'              => array(
				'name'     => 'Rank Math',
				'importer' => 'rankmath',
			),
			'wp-seopress/seopress.php'                    => array(
				'name'     => 'SEOPress',
				'importer' => '',
			),
			'autodescription/autodescription.php'         => array(
				'name'     => 'The SEO Framework',
				'importer' => '',
			),
		);
	}

	/**
	 * Components that may output social, canonical or schema tags (OL-9). Never altered by FutureLabs AI SEO.
	 *
	 * @return array<string, array{name: string, outputs: array<int, string>}>
	 */
	public static function overlapping_plugins(): array {
		return array(
			'shareaholic/shareaholic.php'         => array(
				'name'    => 'Shareaholic',
				'outputs' => array( 'open_graph', 'twitter', 'canonical' ),
			),
			'google-site-kit/google-site-kit.php' => array(
				'name'    => 'Site Kit by Google',
				'outputs' => array( 'analytics' ),
			),
			'elementor/elementor.php'             => array(
				'name'    => 'Elementor',
				'outputs' => array( 'builder' ),
			),
			'jetpack/jetpack.php'                 => array(
				'name'    => 'Jetpack',
				'outputs' => array( 'open_graph', 'twitter' ),
			),
			'wonderm00ns-simple-facebook-open-graph-tags/wonderm00n-open-graph.php' => array(
				'name'    => 'Open Graph for Facebook, Google+ and Twitter Card Tags',
				'outputs' => array( 'open_graph', 'twitter' ),
			),
			'schema-and-structured-data-for-wp/structured-data-for-wordpress.php' => array(
				'name'    => 'Schema & Structured Data for WP',
				'outputs' => array( 'schema' ),
			),
			'wp-rocket/wp-rocket.php'             => array(
				'name'    => 'WP Rocket',
				'outputs' => array( 'cache' ),
			),
			'litespeed-cache/litespeed-cache.php' => array(
				'name'    => 'LiteSpeed Cache',
				'outputs' => array( 'cache' ),
			),
		);
	}

	/**
	 * Active plugin basenames on this site, including network-activated ones.
	 *
	 * @return array<int, string>
	 */
	public function active_plugins(): array {
		$active = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}
		return array_values( array_unique( array_map( 'strval', $active ) ) );
	}

	/**
	 * Active full SEO plugins.
	 *
	 * @return array<int, array{slug: string, name: string, importer: string}>
	 */
	public function active_seo_plugins(): array {
		$found  = array();
		$active = $this->active_plugins();
		foreach ( self::seo_plugins() as $slug => $info ) {
			if ( in_array( $slug, $active, true ) ) {
				$found[] = array_merge( array( 'slug' => $slug ), $info );
			}
		}
		return $found;
	}

	/**
	 * Active overlapping components.
	 *
	 * @return array<int, array{slug: string, name: string, outputs: array<int, string>}>
	 */
	public function active_overlaps(): array {
		$found  = array();
		$active = $this->active_plugins();
		foreach ( self::overlapping_plugins() as $slug => $info ) {
			if ( in_array( $slug, $active, true ) ) {
				$found[] = array_merge( array( 'slug' => $slug ), $info );
			}
		}
		return $found;
	}

	/**
	 * Full conflict report.
	 *
	 * @return array<string, mixed>
	 */
	public function report(): array {
		$theme = wp_get_theme();
		return array(
			'active_seo_plugins'        => $this->active_seo_plugins(),
			'overlapping_plugins'       => $this->active_overlaps(),
			'discourage_search_engines' => '0' === (string) get_option( 'blog_public' ),
			'theme'                     => array(
				'name'           => $theme->get( 'Name' ),
				'supports_title' => current_theme_supports( 'title-tag' ),
			),
			'last_probe'                => get_option( FrontendProbe::OPTION, array() ),
		);
	}
}
