<?php
/**
 * Thin Search Console API client.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Gsc;

use FutureLabs\AISEO\Core\Container;

defined( 'ABSPATH' ) || exit;

/**
 * Authenticated requests to the Search Console APIs. Returns arrays or WP_Error, never tokens.
 */
class Client {

	public const INSPECT_URL = 'https://searchconsole.googleapis.com/v1/urlInspection/index:inspect';
	public const API_BASE    = 'https://www.googleapis.com/webmasters/v3/';

	/**
	 * Maximum rows Google returns per Search Analytics request.
	 */
	public const MAX_ROWS = 25000;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Inspect one URL.
	 *
	 * @param string $url      URL to inspect.
	 * @param string $property Property the URL belongs to.
	 * @return array<string, mixed>|\WP_Error Full API response (`inspectionResult` …).
	 */
	public function inspect( string $url, string $property ) {
		return $this->request(
			'POST',
			self::INSPECT_URL,
			array(
				'inspectionUrl' => $url,
				'siteUrl'       => $property,
				'languageCode'  => 'en-US',
			)
		);
	}

	/**
	 * Properties the connected account can access.
	 *
	 * @return array<int, array{site_url: string, type: string, label: string, permission_level: string}>|\WP_Error
	 */
	public function sites() {
		$data = $this->request( 'GET', self::API_BASE . 'sites' );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$out = array();
		foreach ( (array) ( $data['siteEntry'] ?? array() ) as $entry ) {
			$site  = (string) ( $entry['siteUrl'] ?? '' );
			$level = (string) ( $entry['permissionLevel'] ?? '' );
			if ( '' === $site || 'siteUnverifiedUser' === $level ) {
				continue;
			}
			$domain = str_starts_with( $site, 'sc-domain:' );
			$out[]  = array(
				'site_url'         => $site,
				'type'             => $domain ? 'domain' : 'url_prefix',
				'label'            => $domain ? substr( $site, strlen( 'sc-domain:' ) ) : $site,
				'permission_level' => $level,
			);
		}
		usort(
			$out,
			static function ( array $a, array $b ): int {
				return strcmp( $a['label'], $b['label'] );
			}
		);
		return $out;
	}

	/**
	 * One page of Search Analytics rows.
	 *
	 * @param string             $property   Property.
	 * @param string             $start      Y-m-d.
	 * @param string             $end        Y-m-d.
	 * @param array<int, string> $dimensions Dimensions, e.g. page, query.
	 * @param int                $row_limit  Rows per page (max 25,000).
	 * @param int                $start_row  Offset.
	 * @return array<int, array{keys: array<int, string>, clicks: float, impressions: float, ctr: float, position: float}>|\WP_Error
	 */
	public function search_analytics( string $property, string $start, string $end, array $dimensions, int $row_limit = self::MAX_ROWS, int $start_row = 0 ) {
		$data = $this->request(
			'POST',
			self::API_BASE . 'sites/' . rawurlencode( $property ) . '/searchAnalytics/query',
			array(
				'startDate'  => $start,
				'endDate'    => $end,
				'dimensions' => array_values( $dimensions ),
				'rowLimit'   => max( 1, min( self::MAX_ROWS, $row_limit ) ),
				'startRow'   => max( 0, $start_row ),
				'dataState'  => 'final',
			)
		);
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		return array_values( (array) ( $data['rows'] ?? array() ) );
	}

	/**
	 * Submit (or resubmit) a sitemap.
	 *
	 * @param string $property    Property.
	 * @param string $sitemap_url Absolute sitemap URL.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function submit_sitemap( string $property, string $sitemap_url ) {
		return $this->request( 'PUT', self::API_BASE . 'sites/' . rawurlencode( $property ) . '/sitemaps/' . rawurlencode( $sitemap_url ) );
	}

	/**
	 * Authenticated JSON request. Retries once with a refreshed token on 401.
	 *
	 * @param string                    $method HTTP method.
	 * @param string                    $url    Endpoint.
	 * @param array<string, mixed>|null $body   JSON body.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function request( string $method, string $url, ?array $body = null ) {
		$oauth = $this->c->get( OAuth::class );
		$token = $oauth->access_token();
		for ( $attempt = 0; $attempt < 2; $attempt++ ) {
			if ( is_wp_error( $token ) ) {
				return $token;
			}
			$args = array(
				'method'  => $method,
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/json',
				),
			);
			if ( null !== $body ) {
				$args['headers']['Content-Type'] = 'application/json';
				$args['body']                    = (string) wp_json_encode( $body );
			} elseif ( 'PUT' === $method || 'POST' === $method ) {
				$args['headers']['Content-Length'] = '0';
				$args['body']                      = '';
			}
			$response = wp_remote_request( $url, $args );
			if ( is_wp_error( $response ) ) {
				return new \WP_Error( 'flseo_gsc_http', __( 'Could not reach Google Search Console.', 'futurelabs-ai-seo' ), array( 'status' => 502 ) );
			}
			$code = (int) wp_remote_retrieve_response_code( $response );
			if ( 401 === $code && 0 === $attempt ) {
				$token = $oauth->access_token( true );
				continue;
			}
			$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
			if ( $code >= 400 ) {
				$message = is_array( $data ) ? (string) ( $data['error']['message'] ?? '' ) : '';
				$reason  = is_array( $data ) ? (string) ( $data['error']['status'] ?? '' ) : '';
				return new \WP_Error(
					429 === $code || 'RESOURCE_EXHAUSTED' === $reason ? 'flseo_gsc_quota' : 'flseo_gsc_api',
					'' !== $message ? sanitize_text_field( \FutureLabs\AISEO\Core\Logger::scrub( $message ) ) : __( 'Search Console returned an error.', 'futurelabs-ai-seo' ),
					array(
						'status'      => 429 === $code ? 429 : 502,
						'http_status' => $code,
					)
				);
			}
			return is_array( $data ) ? $data : array();
		}
		return new \WP_Error( 'flseo_gsc_auth', __( 'Search Console rejected the access token. Please reconnect.', 'futurelabs-ai-seo' ), array( 'status' => 401 ) );
	}
}
