<?php
/**
 * Archive card: heading, posts (list or grid), pagination.
 *
 * @package NewsTheme
 *
 * @var array $args { title (HTML), description (HTML), search_form (bool) }
 */

defined( 'ABSPATH' ) || exit;

$newstheme_grid    = 'grid' === newstheme_get_mod( 'archive_layout' );
$newstheme_excerpt = (int) newstheme_get_mod( 'archive_excerpt' );
?>
<section class="nt-block nt-archive nt-archive--<?php echo $newstheme_grid ? 'grid' : 'list'; ?>">
	<header class="nt-block__head nt-archive__head">
		<h1 class="nt-block-title"><span><?php echo wp_kses_post( $args['title'] ); ?></span></h1>
	</header>
	<?php if ( ! empty( $args['description'] ) ) : ?>
		<div class="nt-archive__description"><?php echo wp_kses_post( $args['description'] ); ?></div>
	<?php endif; ?>
	<?php if ( is_author() ) : ?>
		<?php get_template_part( 'template-parts/content/author-box' ); ?>
	<?php endif; ?>
	<?php if ( ! empty( $args['search_form'] ) ) : ?>
		<div class="nt-archive__search"><?php get_search_form(); ?></div>
	<?php endif; ?>

	<?php if ( have_posts() ) : ?>
		<div class="nt-grid nt-grid--<?php echo $newstheme_grid ? 2 : 1; ?> nt-archive__posts">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( $newstheme_grid ? 'nt-post nt-post--grid' : 'nt-post nt-post--row' ); ?> data-nt-animate>
					<?php newstheme_post_thumb( 'newstheme-medium', array( 'badge' => true ) ); ?>
					<div class="nt-post__body">
						<?php
						newstheme_post_title( 'h2' );
						newstheme_post_meta( array( 'author', 'date', 'comments' ) );
						if ( $newstheme_excerpt ) {
							newstheme_post_excerpt( $newstheme_excerpt );
						}
						if ( ! $newstheme_grid ) {
							newstheme_read_more();
						}
						?>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
		<?php
		the_posts_pagination(
			array(
				'mid_size'  => 1,
				'prev_text' => newstheme_get_icon( 'chevron-left' ) . '<span class="screen-reader-text">' . esc_html__( 'Previous page', 'newstheme' ) . '</span>',
				'next_text' => '<span class="screen-reader-text">' . esc_html__( 'Next page', 'newstheme' ) . '</span>' . newstheme_get_icon( 'chevron-right' ),
			)
		);
		?>
	<?php else : ?>
		<p class="nt-empty">
			<?php
			is_search()
				? esc_html_e( 'Nothing matched your search. Try different words.', 'newstheme' )
				: esc_html_e( 'No posts here yet.', 'newstheme' );
			?>
		</p>
	<?php endif; ?>
</section>
