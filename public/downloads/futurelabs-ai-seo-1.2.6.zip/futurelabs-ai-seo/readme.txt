=== FutureLabs AI SEO ===
Contributors: futurelabs
Tags: seo, indexing, sitemap, redirects, search console
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.2.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Find what stops your pages from being indexed, fix it inside WordPress, and spot weak or duplicate content. No ranking promises.

== Description ==

FutureLabs AI SEO is an indexing-first SEO plugin. It helps site owners find and remove common blockers to indexing and highlights pages that look thin, duplicated or hard to reach. It is built for busy publishing sites with many authors and time-limited content such as scholarships, grants, jobs and events.

FutureLabs AI SEO does not guarantee indexing or rankings. Search engines make their own decisions; FutureLabs AI SEO shows you what it can measure and what you can change.

= Metadata, robots and canonical =

* One title, meta description, canonical, robots tag, Open Graph and X (Twitter) card per page.
* Title and description templates per post type and taxonomy, with variables such as %title%, %sitename%, %sep%, %category%, %date%, %author% and %page%.
* Per-post and per-term overrides, including noindex and canonical URL.
* Sensible defaults: search results, 404s, attachments and paginated archives are noindexed; `max-image-preview:large` is kept for Google Discover.
* Safety check: a change that would noindex more than half of your published pages needs a typed confirmation.
* Fail safe: if FutureLabs AI SEO hits an internal error it prints no robots or canonical tag rather than a wrong one.

= Conflict detection =

* Detects Yoast SEO, All in One SEO, Rank Math, SEOPress and The SEO Framework, plus overlapping output from social, builder and theme components.
* Probes your rendered pages and warns about duplicate titles, robots, canonical, Open Graph and schema tags.
* One click to turn off FutureLabs AI SEO output, or import from the other plugin and deactivate it.
* Never alters AdSense, Google Tag Manager or Site Kit output.

= XML sitemap =

* `/sitemap_index.xml` with paginated sitemaps per post type and taxonomy, replacing the WordPress core sitemap.
* Lists only published, indexable, self-canonical URLs. Noindexed, password-protected, redirected and known-404 URLs are left out.
* Validation against the sitemaps.org schema and a sample crawl that reports non-200 and noindexed URLs.

= Redirects and 404s =

* 301, 302, 307 and 410 rules, exact or regular expression, with loop and chain detection.
* Automatic redirects when a published post's URL changes or it is trashed (or suggestions for review).
* 404 log that groups hits, ignores bot and static-file noise, purges old entries and suggests the closest live page.
* CSV import and export.

= Search Console (optional) =

* Connect your own Google Cloud OAuth client to inspect URLs within the daily quota, see Google's reason for pages that are not indexed, compare Google's canonical with yours, and submit the sitemap.
* "Fix this first" groups non-indexed pages by reason, template and post type.
* Tracks days to index for new posts and flags posts still unindexed after seven days.

= Content and links =

* Background scans flag thin pages, near-duplicates (grouped), generic titles and missing sections in opportunity posts.
* Internal link graph: orphan pages, weak pages, click depth from the home page, broken internal links, categories missing from navigation.
* Internal link suggestions in the block editor.

= Opportunity publishing =

* Deadline, status, funding, level, region and official source fields.
* Daily job marks opportunities closed after a grace period and adds one visible "closed" notice. Pages stay published and indexable unless you choose otherwise.
* Edition detection for programmes that repeat every year, and a publishing velocity warning for bursts of near-identical posts.
* Team publishing checklist (soft or required before publishing).

= Bulk changes with undo =

Bulk noindex, index, canonical, redirect, template and merge actions on filtered lists. Every change is logged and can be undone for 30 days.

= Schema =

Organization or Person, WebSite, WebPage, Article, BreadcrumbList, FAQPage (only when a visible FAQ block exists), Course, Product (WooCommerce), LocalBusiness and VideoObject, in one JSON-LD graph, with per-post overrides.

= Optional AI assistance =

Bring your own API key from Anthropic (Claude), OpenAI, Google Gemini or any OpenAI-compatible service (OpenRouter, Groq, DeepSeek, Mistral, Together, or a local Ollama / LM Studio server) to get title, description, alt-text and improvement suggestions. AI is off by default. Every suggestion is saved for review and nothing is published until an editor approves it.

== External services ==

FutureLabs AI SEO works without any external service. These integrations only run after an administrator turns them on and provides credentials:

* **Google Search Console API** (Google LLC) — sends the URLs you choose to inspect, sitemap submissions and Search Analytics requests for your verified property. [Terms](https://developers.google.com/terms) · [Privacy](https://policies.google.com/privacy)
* **Google PageSpeed Insights API** (Google LLC) — sends public page URLs from your site to measure Core Web Vitals. [Terms](https://developers.google.com/terms) · [Privacy](https://policies.google.com/privacy)
* **AI provider** — only the one an administrator selects. It receives the post title and up to about 12,000 characters of text, or the selected image, when an editor requests a suggestion:
  * Anthropic API (Anthropic PBC). [Terms](https://www.anthropic.com/legal/commercial-terms) · [Privacy](https://www.anthropic.com/legal/privacy)
  * OpenAI API (OpenAI). [Terms](https://openai.com/policies/services-agreement/) · [Privacy](https://openai.com/policies/privacy-policy/)
  * Google Gemini API (Google LLC). [Terms](https://ai.google.dev/gemini-api/terms) · [Privacy](https://policies.google.com/privacy)
  * An OpenAI-compatible service at the base URL the administrator enters; that service's own terms and privacy policy apply.
* **Voyage AI API** (optional embeddings for link suggestions) — sends post text when embeddings are enabled. [Terms](https://www.voyageai.com/terms-of-service) · [Privacy](https://www.voyageai.com/privacy)

API keys and tokens are encrypted in your database with a key derived from your WordPress salts and are never shown again after saving.

== Installation ==

1. Upload the release zip in Plugins → Add New → Upload Plugin, or extract it to `/wp-content/plugins/futurelabs-ai-seo/`.
2. Activate FutureLabs AI SEO. The setup wizard opens under FutureLabs AI SEO in the admin menu.
3. Review the compatibility check. If another SEO plugin is active, import from it or turn off FutureLabs AI SEO output.
4. Optionally connect Search Console, then run the first content scan.

== Frequently Asked Questions ==

= Does FutureLabs AI SEO guarantee indexing or rankings? =

No. It removes common technical blockers and points out weak content. Google decides what to crawl, index and rank.

= Can I use it alongside Yoast SEO or Rank Math? =

Running two SEO plugins usually prints duplicate tags. FutureLabs AI SEO warns you and offers to import from the other plugin, or to switch its own output off.

= What happens when an opportunity deadline passes? =

After the grace period (30 days by default) FutureLabs AI SEO marks it closed and adds a visible notice at the top. The page stays published and indexable unless you choose noindex, a redirect, or updating it for the next cycle.

= Where is my data stored? Is it removed when I delete the plugin? =

Everything is stored in your WordPress database. Data is kept on uninstall unless you turn on "Delete data on uninstall" in Settings.

= Does it work on multisite? =

Yes. Each site has its own settings, tables and Search Console connection. Network admins get an overview of all sites.

== Changelog ==

= 1.2.6 =
* New: the publishing checklist also checks length (the thin-content word count), eligibility / benefits / how-to-apply sections on opportunities, broken internal links, AI copy-paste leftovers (utm_source=chatgpt.com, oaicite and 【†】 markers, "[Insert …]" placeholders) and near copies (90%+) of published posts.
* New: with "Block publishing until the checklist is complete" on, Elementor publishes are checked too, and the editor shows which items are missing.
* Improved: "Check again" on Dashboard → Updates fetches the latest FutureLabs AI SEO release immediately.

= 1.2.5 =
* Fix: the link checker no longer reports internal links as broken when they carry tracking parameters (?utm_source=chatgpt.com, fbclid and similar) or use http:// instead of https://.

= 1.2.4 =
* New: one-click updates. The plugin checks futurelabs.africa twice a day and shows the usual WordPress "new version available" notice when a release is out. Define FLSEO_DISABLE_UPDATER to turn this off.

= 1.2.3 =
* Fix: Jetpack printed its own Open Graph and Twitter card tags as well, so pages had two sets. While FutureLabs AI SEO outputs social tags, Jetpack's are now switched off; turn social output off here and Jetpack's return.

= 1.2.2 =
* New: "Alternate names" setting (Settings → Schema). Other names the site is known by, such as "Opportunity Lab", are added as alternateName to the WebSite and Organization schema, which Google uses to recognise site names.

= 1.2.1 =
* Editor: empty Social title and Social description fields now show, in grey, the SEO title and meta description they inherit, and the Social image help says which image will be shared (chosen, featured, or the site default). The preview card also uses the site default image.

= 1.2.0 =
* New: choose the AI provider: Anthropic (Claude), OpenAI, Google Gemini, or any OpenAI-compatible service such as OpenRouter, Groq, DeepSeek, Mistral, Together or a local Ollama server.
* New: "Load models" lists the models your key can use, and checks the key without spending tokens.
* Alt text suggestions are offered only when the chosen provider and model can read images.
* Error messages name the provider and include its own reason.

= 1.1.2 =
* Fix: behind Cloudflare and similar proxies, AI suggestions and other external-service errors showed only "error code: 502". These errors are now sent as HTTP 424 so the plugin's message reaches the editor.
* AI errors now include the Claude API's own reason (for example a low credit balance), with any keys removed.

= 1.1.1 =
* Fix: the Sitemap screen showed "Submission on function at() { [native code] } failed" before any sitemap had been submitted to Search Console.

= 1.1.0 =
* Rebuilt on a modular architecture with background jobs (Action Scheduler).
* New React admin, block-editor sidebar, Search Console indexing dashboard, content and link graph scans, bulk actions with undo, importers, schema graph, AI suggestions with approval, Core Web Vitals, digest reports and multisite support.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.1.0 =
Database tables are migrated automatically. Review Settings after upgrading.
