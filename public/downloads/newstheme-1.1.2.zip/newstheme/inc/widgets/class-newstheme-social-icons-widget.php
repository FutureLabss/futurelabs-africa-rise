<?php
/**
 * NewsTheme Social Icons Widget.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Social icons from Customizer → Global Options → Social Links.
 */
class NewsTheme_Social_Icons_Widget extends NewsTheme_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->fields = array(
			'title' => array(
				'type'    => 'text',
				'label'   => __( 'Title', 'newstheme' ),
				'default' => __( 'Find Me On', 'newstheme' ),
			),
			'style' => array(
				'type'        => 'select',
				'label'       => __( 'Style', 'newstheme' ),
				'default'     => 'filled',
				'choices'     => array(
					'filled' => __( 'Brand color squares', 'newstheme' ),
					'plain'  => __( 'Plain icons', 'newstheme' ),
				),
				'description' => __( 'Profiles are set in Customizer → Global Options → Social Links.', 'newstheme' ),
			),
		);
		parent::__construct( 'social_icons', __( 'NewsTheme: Social Icons', 'newstheme' ), __( 'Links to your social profiles.', 'newstheme' ) );
	}

	/**
	 * Render.
	 *
	 * @param array $values Instance values.
	 */
	protected function render( array $values ) {
		get_template_part( 'template-parts/social-links', null, array( 'class' => 'nt-social--widget nt-social--' . $values['style'] ) );
	}
}
