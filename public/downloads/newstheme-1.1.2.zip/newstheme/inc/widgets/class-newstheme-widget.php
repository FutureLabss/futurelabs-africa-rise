<?php
/**
 * Base class for NewsTheme widgets: subclasses declare $fields and render(),
 * and get the admin form, saving and sanitizing for free.
 *
 * Field types: text, textarea, url, number, checkbox, select, category (one,
 * with "All"), categories (checkbox list), image (media library ID).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * NewsTheme widget base.
 */
abstract class NewsTheme_Widget extends WP_Widget {

	/**
	 * Field definitions: key => [ type, label, default, choices?, min?, max?, description? ].
	 *
	 * @var array
	 */
	protected $fields = array();

	/**
	 * Register the widget.
	 *
	 * @param string $id          Base ID (without prefix).
	 * @param string $name        Widget name.
	 * @param string $description Widget description.
	 */
	public function __construct( $id, $name, $description ) {
		parent::__construct(
			'newstheme_' . $id,
			$name,
			array(
				'classname'                   => 'nt-widget nt-widget--' . $id,
				'description'                 => $description,
				'customize_selective_refresh' => true,
				'show_instance_in_rest'       => true,
			)
		);
	}

	/**
	 * Instance values merged over field defaults.
	 *
	 * @param array $instance Saved instance.
	 * @return array
	 */
	protected function values( $instance ) {
		$values = array();
		foreach ( $this->fields as $key => $field ) {
			$values[ $key ] = array_key_exists( $key, (array) $instance ) ? $instance[ $key ] : $field['default'];
		}
		return $values;
	}

	/**
	 * Front-end output.
	 *
	 * @param array $args     Sidebar args.
	 * @param array $instance Saved instance.
	 */
	public function widget( $args, $instance ) {
		$values = $this->values( $instance );

		ob_start();
		$this->render( $values );
		$body = ob_get_clean();
		if ( '' === trim( $body ) ) {
			return;
		}

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sidebar markup.
		if ( ! empty( $values['title'] ) ) {
			echo $args['before_title'] . esc_html( apply_filters( 'widget_title', $values['title'], $instance, $this->id_base ) ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sidebar markup.
		}
		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rendered by render(), which escapes.
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sidebar markup.
	}

	/**
	 * Widget body.
	 *
	 * @param array $values Instance values.
	 */
	abstract protected function render( array $values );

	/**
	 * Sanitize on save.
	 *
	 * @param array $new_instance New values.
	 * @param array $old_instance Old values.
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$clean = array();
		foreach ( $this->fields as $key => $field ) {
			$raw = $new_instance[ $key ] ?? null;
			switch ( $field['type'] ) {
				case 'checkbox':
					$clean[ $key ] = ! empty( $raw );
					break;
				case 'number':
					$clean[ $key ] = max( $field['min'] ?? 0, min( $field['max'] ?? 100, (int) $raw ) );
					break;
				case 'select':
					$clean[ $key ] = array_key_exists( (string) $raw, $field['choices'] ) ? (string) $raw : $field['default'];
					break;
				case 'category':
				case 'image':
					$clean[ $key ] = absint( $raw );
					break;
				case 'categories':
					$clean[ $key ] = newstheme_sanitize_id_list( (array) $raw );
					break;
				case 'url':
					$clean[ $key ] = esc_url_raw( (string) $raw );
					break;
				case 'textarea':
					$clean[ $key ] = sanitize_textarea_field( (string) $raw );
					break;
				default:
					$clean[ $key ] = sanitize_text_field( (string) $raw );
			}
		}
		return $clean;
	}

	/**
	 * Admin form.
	 *
	 * @param array $instance Saved instance.
	 * @return string
	 */
	public function form( $instance ) {
		$values = $this->values( $instance );
		echo '<div class="nt-widget-form">';
		foreach ( $this->fields as $key => $field ) {
			$id    = $this->get_field_id( $key );
			$name  = $this->get_field_name( $key );
			$value = $values[ $key ];
			echo '<p>';
			switch ( $field['type'] ) {
				case 'checkbox':
					printf(
						'<input type="checkbox" class="checkbox" id="%1$s" name="%2$s" value="1" %3$s> <label for="%1$s">%4$s</label>',
						esc_attr( $id ),
						esc_attr( $name ),
						checked( (bool) $value, true, false ),
						esc_html( $field['label'] )
					);
					break;
				case 'select':
					printf( '<label for="%1$s">%2$s</label><select class="widefat" id="%1$s" name="%3$s">', esc_attr( $id ), esc_html( $field['label'] ), esc_attr( $name ) );
					foreach ( $field['choices'] as $choice => $label ) {
						printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $choice ), selected( (string) $value, (string) $choice, false ), esc_html( $label ) );
					}
					echo '</select>';
					break;
				case 'category':
					printf( '<label for="%1$s">%2$s</label>', esc_attr( $id ), esc_html( $field['label'] ) );
					wp_dropdown_categories(
						array(
							'show_option_all' => __( 'All categories', 'newstheme' ),
							'hide_empty'      => false,
							'id'              => $id,
							'name'            => $name,
							'selected'        => (int) $value,
							'class'           => 'widefat',
						)
					);
					break;
				case 'categories':
					printf( '<span>%s</span>', esc_html( $field['label'] ) );
					echo '<span class="nt-widget-checklist">';
					foreach ( get_categories( array( 'hide_empty' => false ) ) as $term ) {
						printf(
							'<label><input type="checkbox" name="%1$s[]" value="%2$d" %3$s> %4$s</label>',
							esc_attr( $name ),
							(int) $term->term_id,
							checked( in_array( (int) $term->term_id, array_map( 'intval', (array) $value ), true ), true, false ),
							esc_html( $term->name )
						);
					}
					echo '</span>';
					break;
				case 'image':
					$src = $value ? wp_get_attachment_image_url( (int) $value, 'thumbnail' ) : '';
					printf(
						'<span>%1$s</span><span class="nt-widget-media"><img src="%2$s" alt="" %3$s><input type="hidden" id="%4$s" name="%5$s" value="%6$s"><button type="button" class="button nt-widget-media__select">%7$s</button> <button type="button" class="button-link nt-widget-media__remove" %8$s>%9$s</button></span>',
						esc_html( $field['label'] ),
						esc_url( (string) $src ),
						$src ? '' : 'hidden',
						esc_attr( $id ),
						esc_attr( $name ),
						esc_attr( (string) $value ),
						esc_html__( 'Select image', 'newstheme' ),
						$src ? '' : 'hidden',
						esc_html__( 'Remove', 'newstheme' )
					);
					break;
				case 'textarea':
					printf( '<label for="%1$s">%2$s</label><textarea class="widefat" rows="4" id="%1$s" name="%3$s">%4$s</textarea>', esc_attr( $id ), esc_html( $field['label'] ), esc_attr( $name ), esc_textarea( (string) $value ) );
					break;
				default:
					printf(
						'<label for="%1$s">%2$s</label><input class="%3$s" type="%4$s" id="%1$s" name="%5$s" value="%6$s"%7$s>',
						esc_attr( $id ),
						esc_html( $field['label'] ),
						'number' === $field['type'] ? 'tiny-text' : 'widefat',
						esc_attr( in_array( $field['type'], array( 'number', 'url' ), true ) ? $field['type'] : 'text' ),
						esc_attr( $name ),
						esc_attr( (string) $value ),
						'number' === $field['type'] ? sprintf( ' min="%d" max="%d"', (int) ( $field['min'] ?? 0 ), (int) ( $field['max'] ?? 100 ) ) : ''
					);
			}
			if ( ! empty( $field['description'] ) ) {
				printf( '<br><small class="description">%s</small>', esc_html( $field['description'] ) );
			}
			echo '</p>';
		}
		echo '</div>';
		return '';
	}

	/**
	 * Posts query from common widget fields (category, count, orderby, offset).
	 *
	 * @param array $values Instance values.
	 * @return WP_Query
	 */
	protected function posts_query( array $values ) {
		return new WP_Query(
			array(
				'post_type'           => 'post',
				'posts_per_page'      => (int) ( $values['count'] ?? 4 ),
				'cat'                 => (int) ( $values['category'] ?? 0 ),
				'orderby'             => $values['orderby'] ?? 'date',
				'offset'              => (int) ( $values['offset'] ?? 0 ),
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);
	}

	/**
	 * Shared fields for post-listing widgets.
	 *
	 * @param int $count Default post count.
	 * @return array
	 */
	protected static function post_fields( $count = 4 ) {
		return array(
			'category' => array(
				'type'    => 'category',
				'label'   => __( 'Category', 'newstheme' ),
				'default' => 0,
			),
			'count'    => array(
				'type'    => 'number',
				'label'   => __( 'Number of posts', 'newstheme' ),
				'default' => $count,
				'min'     => 1,
				'max'     => 12,
			),
			'orderby'  => array(
				'type'    => 'select',
				'label'   => __( 'Order by', 'newstheme' ),
				'default' => 'date',
				'choices' => array(
					'date'          => __( 'Newest first', 'newstheme' ),
					'comment_count' => __( 'Most commented', 'newstheme' ),
					'rand'          => __( 'Random', 'newstheme' ),
				),
			),
			'offset'   => array(
				'type'    => 'number',
				'label'   => __( 'Skip first N posts', 'newstheme' ),
				'default' => 0,
				'min'     => 0,
				'max'     => 50,
			),
		);
	}
}
