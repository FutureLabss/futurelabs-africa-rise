<?php
/**
 * Phase 7 extras: video playlist, opinions, headlines marquee, preloader,
 * related-post source. See inc/customizer/config.php for the format.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

return array(
	'partials' => array(
		'section-video' => array(
			'selector' => '.nt-section--video',
			'render'   => static function () {
				newstheme_render_homepage_section( 'video' );
			},
		),
		'opinions'      => array(
			'selector' => '.nt-opinions-wrap',
			'render'   => 'newstheme_render_opinions_wrap',
		),
		'headlines'     => array(
			'selector' => '.nt-headlines-wrap',
			'render'   => 'newstheme_render_headlines_wrap',
		),
	),
	'sections' => array(
		'newstheme_home_video' => array(
			'title' => __( 'Video Playlist', 'newstheme' ),
			'panel' => 'newstheme_homepage',
		),
		'newstheme_opinions'   => array(
			'title' => __( 'Opinions', 'newstheme' ),
			'panel' => 'newstheme_homepage',
		),
		'newstheme_headlines'  => array(
			'title' => __( 'Headlines Bar', 'newstheme' ),
			'panel' => 'newstheme_header',
		),
		'newstheme_preloader'  => array(
			'title' => __( 'Preloader', 'newstheme' ),
			'panel' => 'newstheme_global',
		),
		'newstheme_deadlines'  => array(
			'title'       => __( 'Opportunity Deadlines', 'newstheme' ),
			'panel'       => 'newstheme_global',
			'description' => __( 'Deadlines are entered per post in the FutureLabs AI SEO panel.', 'newstheme' ),
		),
	),
	'settings' => array(
		// Opportunity deadlines.
		'deadline_badges'    => array(
			'section'     => 'newstheme_deadlines',
			'control'     => 'toggle',
			'label'       => __( 'Show deadline badges on post images', 'newstheme' ),
			'description' => __( 'For example "Closes in 3 days" or "Closed".', 'newstheme' ),
			'default'     => true,
		),
		'deadline_soon_days' => array(
			'section'     => 'newstheme_deadlines',
			'control'     => 'number',
			'label'       => __( 'Highlight When Closing Within (Days)', 'newstheme' ),
			'description' => __( 'Closer deadlines get the highlighted badge and count down in days.', 'newstheme' ),
			'default'     => 7,
			'min'         => 1,
			'max'         => 30,
		),
		// Video playlist.
		'video_items'        => array(
			'section'     => 'newstheme_home_video',
			'control'     => 'repeater',
			'label'       => __( 'Videos', 'newstheme' ),
			'description' => __( 'YouTube links. Titles are fetched automatically if left empty. Nothing loads from YouTube until a visitor presses play (thumbnails excepted).', 'newstheme' ),
			'item_label'  => __( 'Video', 'newstheme' ),
			'fields'      => array(
				'url'      => array(
					'type'    => 'url',
					'label'   => __( 'YouTube URL', 'newstheme' ),
					'default' => '',
				),
				'title'    => array(
					'type'    => 'text',
					'label'   => __( 'Title (optional)', 'newstheme' ),
					'default' => '',
				),
				'duration' => array(
					'type'    => 'text',
					'label'   => __( 'Duration, e.g. 4:05 (optional)', 'newstheme' ),
					'default' => '',
				),
			),
			'default'     => array(),
			'partial'     => 'section-video',
		),

		// Opinions.
		'opinions_location'  => array(
			'section' => 'newstheme_opinions',
			'control' => 'buttons',
			'label'   => __( 'Show', 'newstheme' ),
			'default' => 'footer',
			'choices' => array(
				'footer'   => __( 'Above footer, every page', 'newstheme' ),
				'homepage' => __( 'Homepage section', 'newstheme' ),
			),
		),
		'opinions_title'     => array(
			'section' => 'newstheme_opinions',
			'control' => 'text',
			'label'   => __( 'Title', 'newstheme' ),
			'default' => __( 'Your Opinions', 'newstheme' ),
			'partial' => 'opinions',
		),
		'opinion_items'      => array(
			'section'    => 'newstheme_opinions',
			'control'    => 'repeater',
			'label'      => __( 'Opinions', 'newstheme' ),
			'item_label' => __( 'Opinion', 'newstheme' ),
			'fields'     => array(
				'title'  => array(
					'type'    => 'text',
					'label'   => __( 'Headline', 'newstheme' ),
					'default' => '',
				),
				'author' => array(
					'type'    => 'text',
					'label'   => __( 'Author', 'newstheme' ),
					'default' => '',
				),
				'url'    => array(
					'type'    => 'url',
					'label'   => __( 'Link', 'newstheme' ),
					'default' => '',
				),
				'image'  => array(
					'type'    => 'image',
					'label'   => __( 'Photo', 'newstheme' ),
					'default' => 0,
				),
			),
			'default'    => array(),
			'partial'    => 'opinions',
		),

		// Headlines marquee.
		'headlines_show'     => array(
			'section'     => 'newstheme_headlines',
			'control'     => 'buttons',
			'label'       => __( 'Show On', 'newstheme' ),
			'description' => __( 'A scrolling strip of headlines with thumbnails, below the header.', 'newstheme' ),
			'default'     => 'inner',
			'choices'     => array(
				'inner' => __( 'Inner pages', 'newstheme' ),
				'all'   => __( 'All pages', 'newstheme' ),
				'off'   => __( 'Off', 'newstheme' ),
			),
		),
		'headlines_label'    => array(
			'section' => 'newstheme_headlines',
			'control' => 'text',
			'label'   => __( 'Label', 'newstheme' ),
			'default' => __( 'Headlines', 'newstheme' ),
			'partial' => 'headlines',
		),
		'headlines_count'    => array(
			'section' => 'newstheme_headlines',
			'control' => 'number',
			'label'   => __( 'Number of Posts', 'newstheme' ),
			'default' => 8,
			'min'     => 3,
			'max'     => 20,
			'partial' => 'headlines',
		),
		'headlines_speed'    => array(
			'section'     => 'newstheme_headlines',
			'control'     => 'number',
			'label'       => __( 'Seconds Per Loop', 'newstheme' ),
			'description' => __( 'Higher is slower.', 'newstheme' ),
			'default'     => 45,
			'min'         => 10,
			'max'         => 120,
			'css'         => array(
				'var'  => '--nt-headlines-speed',
				'unit' => 's',
			),
		),

		// Preloader.
		'preloader'          => array(
			'section'     => 'newstheme_preloader',
			'control'     => 'select',
			'label'       => __( 'Preloader', 'newstheme' ),
			'description' => __( 'Shown until the page has loaded. Skipped for visitors who prefer reduced motion.', 'newstheme' ),
			'default'     => 'off',
			'choices'     => array(
				'off'     => __( 'Off', 'newstheme' ),
				'spinner' => __( 'Spinner', 'newstheme' ),
				'ring'    => __( 'Double ring', 'newstheme' ),
				'dots'    => __( 'Bouncing dots', 'newstheme' ),
				'bars'    => __( 'Equalizer bars', 'newstheme' ),
				'pulse'   => __( 'Pulse', 'newstheme' ),
				'bar'     => __( 'Top progress bar', 'newstheme' ),
				'title'   => __( 'Site title', 'newstheme' ),
			),
		),

		// Related posts source (single post section).
		'single_related_by'  => array(
			'section' => 'newstheme_single',
			'control' => 'buttons',
			'label'   => __( 'Related By', 'newstheme' ),
			'default' => 'categories',
			'choices' => array(
				'categories' => __( 'Category', 'newstheme' ),
				'tags'       => __( 'Tags', 'newstheme' ),
				'both'       => __( 'Either', 'newstheme' ),
			),
			'show_if' => array( 'single_related', 'true' ),
		),
	),
);
