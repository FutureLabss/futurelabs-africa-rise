<?php
/**
 * Template variable replacement for titles and descriptions.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Meta;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Replaces %title% %sitename% %sep% %excerpt% %category% %date% %author% %page% and friends.
 */
class Variables {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Supported variables with descriptions (shown in the UI).
	 *
	 * @return array<string, string>
	 */
	public static function supported(): array {
		return array(
			'%title%'    => __( 'Post, term or archive title', 'futurelabs-ai-seo' ),
			'%sitename%' => __( 'Site title', 'futurelabs-ai-seo' ),
			'%tagline%'  => __( 'Site tagline', 'futurelabs-ai-seo' ),
			'%sep%'      => __( 'Title separator', 'futurelabs-ai-seo' ),
			'%excerpt%'  => __( 'Excerpt or first words of content', 'futurelabs-ai-seo' ),
			'%category%' => __( 'Primary category', 'futurelabs-ai-seo' ),
			'%date%'     => __( 'Publish date', 'futurelabs-ai-seo' ),
			'%author%'   => __( 'Author display name', 'futurelabs-ai-seo' ),
			'%page%'     => __( 'Page number when paginated', 'futurelabs-ai-seo' ),
		);
	}

	/**
	 * Replace variables for a subject.
	 *
	 * @param string                          $template Template text.
	 * @param \WP_Post|\WP_Term|\WP_User|null $subject  Subject; null for site-level contexts.
	 * @param string                          $fallback_title Title used when the subject has none (archives).
	 */
	public function replace( string $template, $subject = null, string $fallback_title = '' ): string {
		if ( ! str_contains( $template, '%' ) ) {
			return $this->clean( $template );
		}
		$values = $this->values( $subject, $fallback_title );
		return $this->clean( strtr( $template, $values ) );
	}

	/**
	 * Values for each variable.
	 *
	 * @param \WP_Post|\WP_Term|\WP_User|null $subject        Subject.
	 * @param string                          $fallback_title Title fallback.
	 * @return array<string, string>
	 */
	public function values( $subject, string $fallback_title = '' ): array {
		$settings = $this->c->get( Settings::class );
		$page     = max( (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
		$values   = array(
			'%sitename%' => wp_strip_all_tags( get_bloginfo( 'name' ) ),
			'%tagline%'  => wp_strip_all_tags( get_bloginfo( 'description' ) ),
			'%sep%'      => (string) $settings->get( 'title_separator', '|' ),
			'%page%'     => $page > 1 ? sprintf( /* translators: %d: page number. */ __( 'Page %d', 'futurelabs-ai-seo' ), $page ) : '',
			'%title%'    => $fallback_title,
			'%excerpt%'  => '',
			'%category%' => '',
			'%date%'     => '',
			'%author%'   => '',
		);
		if ( $subject instanceof \WP_Post ) {
			$terms                = get_the_category( $subject->ID );
			$values['%title%']    = wp_strip_all_tags( get_the_title( $subject ) );
			$values['%excerpt%']  = self::excerpt( $subject );
			$values['%category%'] = $terms ? $terms[0]->name : '';
			$values['%date%']     = (string) get_the_date( '', $subject );
			$values['%author%']   = (string) get_the_author_meta( 'display_name', (int) $subject->post_author );
		} elseif ( $subject instanceof \WP_Term ) {
			$values['%title%']    = $subject->name;
			$values['%excerpt%']  = wp_trim_words( wp_strip_all_tags( $subject->description ), 25, '' );
			$values['%category%'] = $subject->name;
		} elseif ( $subject instanceof \WP_User ) {
			$values['%title%']  = $subject->display_name;
			$values['%author%'] = $subject->display_name;
		}
		return $values;
	}

	/**
	 * Plain-text excerpt for a post: manual excerpt or the first 28 words of content.
	 * Password-protected posts have no excerpt, so their text never reaches meta or schema.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function excerpt( \WP_Post $post ): string {
		if ( '' !== (string) $post->post_password ) {
			return '';
		}
		if ( '' !== trim( $post->post_excerpt ) ) {
			return trim( wp_strip_all_tags( $post->post_excerpt ) );
		}
		$content = excerpt_remove_blocks( $post->post_content );
		$content = wp_strip_all_tags( strip_shortcodes( $content ) );
		return wp_trim_words( $content, 28, '' );
	}

	/**
	 * Collapse whitespace and dangling separators left by empty variables.
	 *
	 * @param string $text Text.
	 */
	private function clean( string $text ): string {
		$sep  = preg_quote( (string) $this->c->get( Settings::class )->get( 'title_separator', '|' ), '/' );
		$text = (string) preg_replace( '/\s+/u', ' ', $text );
		$text = (string) preg_replace( '/(\s*' . $sep . '\s*){2,}/u', ' ' . stripslashes( $sep ) . ' ', $text );
		$text = (string) preg_replace( '/^\s*' . $sep . '\s*|\s*' . $sep . '\s*$/u', '', $text );
		return trim( $text );
	}
}
