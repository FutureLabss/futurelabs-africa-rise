<?php
/**
 * Opinions strip: quote cards with a round photo, headline and author.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_opinions = newstheme_opinion_items();
if ( ! $newstheme_opinions ) {
	return;
}
$newstheme_id = wp_unique_id( 'nt-opinions-' );
?>
<div class="nt-container">
	<section class="nt-block nt-opinions" aria-labelledby="<?php echo esc_attr( $newstheme_id ); ?>-title">
		<?php newstheme_block_heading( (string) newstheme_get_mod( 'opinions_title' ), $newstheme_id ); ?>
		<ul class="nt-opinions__list">
			<?php foreach ( $newstheme_opinions as $newstheme_item ) : ?>
				<li class="nt-opinion">
					<?php if ( ! empty( $newstheme_item['image'] ) ) : ?>
						<?php
						echo wp_get_attachment_image(
							(int) $newstheme_item['image'],
							'newstheme-thumb',
							false,
							array(
								'class' => 'nt-opinion__photo',
								'alt'   => '',
							)
						);
						?>
					<?php endif; ?>
					<div class="nt-opinion__body">
						<h3 class="nt-opinion__title">
							<?php if ( ! empty( $newstheme_item['url'] ) ) : ?>
								<a href="<?php echo esc_url( $newstheme_item['url'] ); ?>"><?php echo esc_html( $newstheme_item['title'] ); ?></a>
							<?php else : ?>
								<?php echo esc_html( $newstheme_item['title'] ); ?>
							<?php endif; ?>
						</h3>
						<?php if ( ! empty( $newstheme_item['author'] ) ) : ?>
							<p class="nt-opinion__author"><?php newstheme_icon( 'quote' ); ?><?php echo esc_html( $newstheme_item['author'] ); ?></p>
						<?php endif; ?>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
	</section>
</div>
