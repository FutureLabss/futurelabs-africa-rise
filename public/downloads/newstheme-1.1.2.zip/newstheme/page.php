<?php
/**
 * Page.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();
newstheme_layout_open( 'page' );

while ( have_posts() ) :
	the_post();
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'nt-card-box nt-single nt-single--page' ); ?>>
		<?php the_title( '<h1 class="nt-single__title">', '</h1>' ); ?>
		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="nt-single__image"><?php the_post_thumbnail( 'newstheme-large', array( 'alt' => newstheme_thumbnail_alt() ) ); ?></figure>
		<?php endif; ?>
		<div class="nt-entry-content">
			<?php
			the_content();
			wp_link_pages();
			?>
		</div>
	</article>
	<?php
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
endwhile;

newstheme_layout_close();
get_footer();
