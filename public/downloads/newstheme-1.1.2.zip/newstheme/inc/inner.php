<?php
/**
 * Inner pages: sidebar layouts, breadcrumbs and single-post helpers.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Effective sidebar layout for a context, degraded when a needed widget
 * area is empty (so there's never an empty column).
 *
 * @param string $context 'archive', 'single' or 'page'.
 * @return string right | left | both | right-both | none
 */
function newstheme_sidebar_layout( $context ) {
	$layout = (string) newstheme_get_mod( $context . '_sidebar' );
	$layout = apply_filters( 'newstheme_sidebar_layout', $layout, $context );
	$right  = is_active_sidebar( 'sidebar' );
	$left   = is_active_sidebar( 'left-sidebar' );

	switch ( $layout ) {
		case 'both':
		case 'right-both':
			if ( $right && $left ) {
				return $layout;
			}
			return $right ? 'right' : ( $left ? 'left' : 'none' );
		case 'right':
			return $right ? 'right' : 'none';
		case 'left':
			return $left ? 'left' : 'none';
		default:
			return 'none';
	}
}

/**
 * Open the page container and sidebar layout grid.
 *
 * @param string $context 'archive', 'single' or 'page'.
 */
function newstheme_layout_open( $context ) {
	$GLOBALS['newstheme_layout'] = newstheme_sidebar_layout( $context ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- theme-prefixed global.
	echo '<div class="nt-container nt-page">';
	if ( ! did_action( 'newstheme_breadcrumbs_printed' ) ) {
		newstheme_breadcrumbs();
	}
	printf( '<div class="nt-page__layout nt-page__layout--%s">', esc_attr( $GLOBALS['newstheme_layout'] ) );
	echo '<div class="nt-page__main">';
}

/**
 * Close the main column, print sidebars, close the layout.
 */
function newstheme_layout_close() {
	$layout = $GLOBALS['newstheme_layout'] ?? 'none';
	echo '</div>';

	$areas = array(
		'left-sidebar' => in_array( $layout, array( 'left', 'both', 'right-both' ), true ),
		'sidebar'      => in_array( $layout, array( 'right', 'both', 'right-both' ), true ),
	);
	foreach ( $areas as $area => $show ) {
		if ( $show ) {
			printf(
				'<aside class="nt-sidebar nt-sidebar--%1$s" aria-label="%2$s">',
				'sidebar' === $area ? 'right' : 'left',
				esc_attr( 'sidebar' === $area ? __( 'Sidebar', 'newstheme' ) : __( 'Secondary sidebar', 'newstheme' ) )
			);
			dynamic_sidebar( $area );
			echo '</aside>';
		}
	}
	echo '</div></div>';
}

/**
 * Breadcrumb trail. Defers to FutureLabs AI SEO, Yoast SEO or Rank Math when active.
 */
function newstheme_breadcrumbs() {
	if ( ! newstheme_get_mod( 'breadcrumbs' ) || is_front_page() ) {
		return;
	}
	do_action( 'newstheme_breadcrumbs_printed' );

	// FutureLabs AI SEO: same trail as its BreadcrumbList structured data.
	if ( function_exists( 'flseo_get_breadcrumbs' ) ) {
		echo flseo_get_breadcrumbs( array( 'class' => 'nt-breadcrumbs' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by the plugin.
		return;
	}
	if ( function_exists( 'yoast_breadcrumb' ) && class_exists( 'WPSEO_Options' ) && WPSEO_Options::get( 'breadcrumbs-enable' ) ) {
		yoast_breadcrumb( '<nav class="nt-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'newstheme' ) . '">', '</nav>' );
		return;
	}
	if ( function_exists( 'rank_math_the_breadcrumbs' ) ) {
		echo '<nav class="nt-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'newstheme' ) . '">';
		rank_math_the_breadcrumbs();
		echo '</nav>';
		return;
	}

	$crumbs = array( array( __( 'Home', 'newstheme' ), home_url( '/' ) ) );

	if ( is_singular( 'post' ) ) {
		$category = get_the_category();
		if ( $category ) {
			foreach ( array_reverse( get_ancestors( $category[0]->term_id, 'category' ) ) as $ancestor ) {
				$crumbs[] = array( get_cat_name( $ancestor ), get_category_link( $ancestor ) );
			}
			$crumbs[] = array( $category[0]->name, get_category_link( $category[0] ) );
		}
		$crumbs[] = array( get_the_title(), '' );
	} elseif ( is_page() ) {
		foreach ( array_reverse( get_post_ancestors( get_the_ID() ) ) as $ancestor ) {
			$crumbs[] = array( get_the_title( $ancestor ), get_permalink( $ancestor ) );
		}
		$crumbs[] = array( get_the_title(), '' );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$term = get_queried_object();
		if ( $term->parent ) {
			foreach ( array_reverse( get_ancestors( $term->term_id, $term->taxonomy ) ) as $ancestor ) {
				$crumbs[] = array( get_term( $ancestor )->name, get_term_link( $ancestor ) );
			}
		}
		$crumbs[] = array( single_term_title( '', false ), '' );
	} elseif ( is_author() ) {
		$crumbs[] = array( get_the_author_meta( 'display_name', (int) get_query_var( 'author' ) ), '' );
	} elseif ( is_search() ) {
		/* translators: %s: search query. */
		$crumbs[] = array( sprintf( __( 'Search results for "%s"', 'newstheme' ), get_search_query() ), '' );
	} elseif ( is_404() ) {
		$crumbs[] = array( __( 'Page not found', 'newstheme' ), '' );
	} elseif ( is_date() ) {
		$crumbs[] = array( wp_strip_all_tags( get_the_archive_title() ), '' );
	} elseif ( is_home() ) {
		$crumbs[] = array( single_post_title( '', false ), '' );
	}

	if ( is_paged() ) {
		/* translators: %d: page number. */
		$crumbs[] = array( sprintf( __( 'Page %d', 'newstheme' ), (int) get_query_var( 'paged' ) ), '' );
	}

	echo '<nav class="nt-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'newstheme' ) . '"><ol>';
	$last = count( $crumbs ) - 1;
	foreach ( $crumbs as $i => list( $label, $url ) ) {
		if ( $url && $i !== $last ) {
			printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( $url ), esc_html( $label ) );
		} else {
			printf( '<li aria-current="page">%s</li>', esc_html( $label ) );
		}
	}
	echo '</ol></nav>';
}

/**
 * Estimated reading time in minutes (200 words per minute).
 *
 * @param int|null $post_id Post ID.
 * @return int
 */
function newstheme_reading_time( $post_id = null ) {
	$words = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ? $post_id : get_the_ID() ) ) );
	return max( 1, (int) ceil( $words / 200 ) );
}

/**
 * Single post meta row, in the order configured in the Customizer.
 */
function newstheme_single_meta() {
	echo '<div class="nt-meta nt-meta--single">';
	foreach ( (array) newstheme_get_mod( 'single_meta' ) as $item ) {
		if ( empty( $item['enabled'] ) ) {
			continue;
		}
		switch ( $item['id'] ) {
			case 'author':
				newstheme_posted_by( null, true );
				break;
			case 'date':
				newstheme_posted_on( null, true );
				break;
			case 'comments':
				newstheme_comment_count();
				break;
			case 'reading-time':
				$minutes = newstheme_reading_time();
				printf(
					'<span class="nt-meta__item nt-meta__reading">%1$s%2$s</span>',
					newstheme_get_icon( 'clock' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in newstheme_get_icon().
					/* translators: %d: minutes. */
					esc_html( sprintf( _n( '%d min read', '%d min read', $minutes, 'newstheme' ), $minutes ) )
				);
				break;
		}
	}
	echo '</div>';
}

/**
 * Share links for the current post. Plain links (no third-party scripts);
 * "copy link" is enhanced by JS.
 */
function newstheme_share_links() {
	$url   = rawurlencode( get_permalink() );
	$title = rawurlencode( html_entity_decode( get_the_title(), ENT_QUOTES, 'UTF-8' ) );
	$links = apply_filters(
		'newstheme_share_links',
		array(
			'facebook' => array( 'Facebook', "https://www.facebook.com/sharer/sharer.php?u={$url}" ),
			'x'        => array( 'X', "https://x.com/intent/post?url={$url}&text={$title}" ),
			'linkedin' => array( 'LinkedIn', "https://www.linkedin.com/sharing/share-offsite/?url={$url}" ),
			'whatsapp' => array( 'WhatsApp', "https://wa.me/?text={$title}%20{$url}" ),
			'telegram' => array( 'Telegram', "https://t.me/share/url?url={$url}&text={$title}" ),
			'mail'     => array( __( 'Email', 'newstheme' ), "mailto:?subject={$title}&body={$url}" ),
		)
	);
	?>
	<div class="nt-share">
		<span class="nt-share__label"><?php esc_html_e( 'Share', 'newstheme' ); ?></span>
		<ul class="nt-share__list">
			<?php foreach ( $links as $network => list( $label, $href ) ) : ?>
				<li>
					<a class="nt-share__link nt-share__link--<?php echo esc_attr( $network ); ?>" href="<?php echo esc_url( $href ); ?>" target="_blank" rel="noopener nofollow">
						<?php newstheme_icon( $network ); ?>
						<?php /* translators: %s: network name. */ ?>
						<span class="screen-reader-text"><?php echo esc_html( sprintf( __( 'Share on %s', 'newstheme' ), $label ) ); ?></span>
					</a>
				</li>
			<?php endforeach; ?>
			<li>
				<button type="button" class="nt-share__link nt-share__copy" data-nt-copy="<?php echo esc_url( get_permalink() ); ?>" data-copied="<?php esc_attr_e( 'Link copied', 'newstheme' ); ?>">
					<?php newstheme_icon( 'link' ); ?>
					<span class="screen-reader-text"><?php esc_html_e( 'Copy link', 'newstheme' ); ?></span>
				</button>
			</li>
		</ul>
		<span class="nt-share__status screen-reader-text" role="status"></span>
	</div>
	<?php
}

/**
 * Related posts query: same categories, excluding the current post.
 *
 * @return WP_Query
 */
function newstheme_related_query() {
	$args = array(
		'post_type'           => 'post',
		'posts_per_page'      => (int) newstheme_get_mod( 'single_related_count' ),
		'post__not_in'        => array( get_the_ID() ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);
	$cats = wp_get_post_categories( get_the_ID() );
	$tags = wp_get_post_tags( get_the_ID(), array( 'fields' => 'ids' ) );

	switch ( newstheme_get_mod( 'single_related_by' ) ) {
		case 'tags':
			$args['tag__in'] = $tags ? $tags : array( 0 );
			break;
		case 'both':
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- small, indexed query.
			$args['tax_query'] = array(
				'relation' => 'OR',
				array(
					'taxonomy' => 'category',
					'terms'    => $cats ? $cats : array( 0 ),
				),
				array(
					'taxonomy' => 'post_tag',
					'terms'    => $tags ? $tags : array( 0 ),
				),
			);
			break;
		default:
			$args['category__in'] = $cats;
	}

	return new WP_Query( apply_filters( 'newstheme_related_query_args', $args ) );
}

/**
 * Archive title without the "Category:" prefix unless enabled.
 *
 * @param string $title  Archive title.
 * @param string $plain  Title without prefix.
 * @param string $prefix Prefix.
 * @return string
 */
function newstheme_archive_title( $title, $plain, $prefix ) {
	return newstheme_get_mod( 'archive_title_prefix' ) || ! $prefix ? $title : $plain;
}
add_filter( 'get_the_archive_title', 'newstheme_archive_title', 10, 3 );
