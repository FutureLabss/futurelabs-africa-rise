<?php
/**
 * Title: Newsletter call to action
 * Slug: newstheme/newsletter-cta
 * Categories: newstheme, call-to-action
 * Description: A boxed invitation to subscribe, with a button.
 *
 * @package NewsTheme
 */

?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"}}},"backgroundColor":"background","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background-background-color has-background" style="padding-top:28px;padding-right:28px;padding-bottom:28px;padding-left:28px"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php esc_html_e( 'Get the morning briefing', 'newstheme' ); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'The five stories you need to know, in your inbox before breakfast. Free, and you can unsubscribe any time.', 'newstheme' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"accent","textColor":"surface"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-surface-color has-accent-background-color has-text-color has-background wp-element-button"><?php esc_html_e( 'Subscribe', 'newstheme' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
