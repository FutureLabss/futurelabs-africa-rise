<?php
/**
 * Customizer bootstrap: registers panels/sections/settings from the config
 * and loads the control + preview scripts.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

require NEWSTHEME_DIR . 'inc/customizer/fonts.php';
require NEWSTHEME_DIR . 'inc/customizer/config.php';
require NEWSTHEME_DIR . 'inc/customizer/values.php';
require NEWSTHEME_DIR . 'inc/customizer/sanitize.php';
require NEWSTHEME_DIR . 'inc/customizer/css.php';

/**
 * Register everything with the Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function newstheme_customize_register( $wp_customize ) {
	require_once NEWSTHEME_DIR . 'inc/customizer/class-newstheme-control.php';

	// Not registered via register_control_type(): that switches WordPress to
	// JS-template rendering and drops the PHP markup from render_content().

	$config = newstheme_customizer_config();

	foreach ( $config['panels'] as $id => $panel ) {
		$wp_customize->add_panel( $id, $panel );
	}
	foreach ( $config['sections'] as $id => $section ) {
		$wp_customize->add_section( $id, $section );
	}

	$priority = 10;
	foreach ( newstheme_all_settings() as $key => $setting ) {
		$id = 'newstheme_' . $key;
		++$priority;

		if ( 'heading' !== $setting['control'] ) {
			$live = ! empty( $setting['css'] ) || ! empty( $setting['body_class'] ) || ! empty( $setting['partial'] );
			$wp_customize->add_setting(
				$id,
				array(
					'default'           => $setting['default'] ?? '',
					'transport'         => $live ? 'postMessage' : 'refresh',
					'sanitize_callback' => newstheme_sanitizer_for( $setting ),
				)
			);
		}

		$wp_customize->add_control(
			new NewsTheme_Control(
				$wp_customize,
				$id,
				array(
					'label'       => $setting['label'] ?? '',
					'description' => $setting['description'] ?? '',
					'section'     => $setting['section'],
					'priority'    => $priority,
					'settings'    => 'heading' === $setting['control'] ? array() : $id,
					'nf'          => $setting,
				)
			)
		);
	}

	// Selective refresh: re-render just the affected part of the preview.
	$partial_settings = array();
	foreach ( newstheme_all_settings() as $key => $setting ) {
		if ( ! empty( $setting['partial'] ) ) {
			$partial_settings[ $setting['partial'] ][] = 'newstheme_' . $key;
		}
	}
	foreach ( $config['partials'] as $id => $partial ) {
		if ( empty( $partial_settings[ $id ] ) ) {
			continue;
		}
		$wp_customize->selective_refresh->add_partial(
			'newstheme_' . $id,
			array(
				'selector'            => $partial['selector'],
				'settings'            => $partial_settings[ $id ],
				'render_callback'     => $partial['render'],
				'container_inclusive' => true,
				'fallback_refresh'    => true,
			)
		);
	}

	// Site title/tagline update live via the preview script.
	$wp_customize->get_setting( 'blogname' )->transport        = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
}
add_action( 'customize_register', 'newstheme_customize_register' );

/**
 * Control-pane assets.
 */
function newstheme_customize_controls_assets() {
	wp_enqueue_media();
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_style(
		'newstheme-customizer-controls',
		NEWSTHEME_URI . 'assets/customizer/controls.css',
		array(),
		newstheme_asset_version( 'assets/customizer/controls.css' )
	);
	wp_enqueue_script(
		'newstheme-customizer-controls',
		NEWSTHEME_URI . 'assets/customizer/controls.js',
		array( 'customize-controls', 'wp-color-picker', 'jquery-ui-sortable' ),
		newstheme_asset_version( 'assets/customizer/controls.js' ),
		true
	);

	$fonts = array();
	foreach ( newstheme_font_families() as $slug => $font ) {
		$fonts[ $slug ] = $font['label'];
	}

	$categories = array();
	foreach ( get_categories( array( 'hide_empty' => false ) ) as $term ) {
		$categories[] = array(
			'id'    => (int) $term->term_id,
			'label' => $term->name,
		);
	}

	wp_localize_script(
		'newstheme-customizer-controls',
		'newsthemeControls',
		array(
			'fonts'      => $fonts,
			'categories' => $categories,
			'gradients'  => array(
				'linear-gradient(135deg, #1b8415 0%, #0f5c0b 100%)',
				'linear-gradient(135deg, #0f2027 0%, #2c5364 100%)',
				'linear-gradient(135deg, #f7971e 0%, #ffd200 100%)',
				'linear-gradient(135deg, #ee0979 0%, #ff6a00 100%)',
				'linear-gradient(135deg, #4776e6 0%, #8e54e9 100%)',
				'linear-gradient(180deg, #f0f1f2 0%, #ffffff 100%)',
			),
			'restUrl'    => esc_url_raw( rest_url( 'wp/v2/' ) ),
			'nonce'      => wp_create_nonce( 'wp_rest' ),
			'i18n'       => array(
				'desktop'    => __( 'Desktop', 'newstheme' ),
				'tablet'     => __( 'Tablet', 'newstheme' ),
				'mobile'     => __( 'Mobile', 'newstheme' ),
				'solid'      => __( 'Solid', 'newstheme' ),
				'gradient'   => __( 'Gradient', 'newstheme' ),
				'angle'      => __( 'Angle', 'newstheme' ),
				'reset'      => __( 'Reset', 'newstheme' ),
				'family'     => __( 'Font Family', 'newstheme' ),
				'weight'     => __( 'Weight', 'newstheme' ),
				'size'       => __( 'Size (px)', 'newstheme' ),
				'lineHeight' => __( 'Line Height (px)', 'newstheme' ),
				'spacing'    => __( 'Letter Spacing (px)', 'newstheme' ),
				'transform'  => __( 'Transform', 'newstheme' ),
				'decoration' => __( 'Decoration', 'newstheme' ),
				'add'        => __( 'Add', 'newstheme' ),
				'remove'     => __( 'Remove', 'newstheme' ),
				'moveUp'     => __( 'Move up', 'newstheme' ),
				'moveDown'   => __( 'Move down', 'newstheme' ),
				'search'     => __( 'Search…', 'newstheme' ),
				'noResults'  => __( 'No results', 'newstheme' ),
				'selectImg'  => __( 'Select image', 'newstheme' ),
				'addBlock'   => __( 'Add Block', 'newstheme' ),
				'blockType'  => __( 'Block type', 'newstheme' ),
				'duplicate'  => __( 'Duplicate', 'newstheme' ),
				'noBlocks'   => __( 'No blocks yet. Add one below.', 'newstheme' ),
				'moveTo'     => __( 'Move to', 'newstheme' ),
				'notUsed'    => __( '— Not used —', 'newstheme' ),
				'available'  => __( 'Available elements', 'newstheme' ),
				'columns'    => __( 'Columns', 'newstheme' ),
			),
		)
	);
}
add_action( 'customize_controls_enqueue_scripts', 'newstheme_customize_controls_assets' );

/**
 * Preview-frame assets: live CSS regeneration for postMessage settings.
 */
function newstheme_customize_preview_assets() {
	wp_enqueue_script(
		'newstheme-customizer-preview',
		NEWSTHEME_URI . 'assets/customizer/preview.js',
		array( 'customize-preview' ),
		newstheme_asset_version( 'assets/customizer/preview.js' ),
		true
	);

	$schema = array();
	foreach ( newstheme_all_settings() as $key => $setting ) {
		if ( empty( $setting['css'] ) && empty( $setting['body_class'] ) ) {
			continue;
		}
		$schema[ $key ] = array_intersect_key( $setting, array_flip( array( 'control', 'default', 'css', 'body_class' ) ) );
	}

	$fonts = array();
	foreach ( newstheme_font_families() as $slug => $font ) {
		$fonts[ $slug ] = array( 'stack' => $font['stack'] );
	}

	wp_localize_script(
		'newstheme-customizer-preview',
		'newsthemePreview',
		array(
			'settings' => $schema,
			'fonts'    => $fonts,
		)
	);
}
add_action( 'customize_preview_init', 'newstheme_customize_preview_assets' );
