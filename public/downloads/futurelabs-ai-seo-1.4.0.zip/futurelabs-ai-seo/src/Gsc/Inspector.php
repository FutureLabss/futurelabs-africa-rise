<?php
/**
 * Throttled URL Inspection queue with a per-property daily quota.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Gsc;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Indexing\Reasons;
use FutureLabs\AISEO\Meta\CanonicalResolver;
use FutureLabs\AISEO\Meta\RobotsResolver;

defined( 'ABSPATH' ) || exit;

/**
 * Queues inspections in `flseo_index_status` (queued_at + priority) and processes them in batches.
 */
class Inspector implements Module {

	public const QUEUE_HOOK   = 'flseo_inspection_queue';
	public const URL_HOOK     = 'flseo_inspect_url';
	public const QUOTA_OPTION = 'flseo_gsc_quota';
	public const RUN_OPTION   = 'flseo_gsc_inspection_run';
	public const PAUSE_OPTION = 'flseo_gsc_inspection_paused';

	/**
	 * Default URL Inspection API quota per property per day.
	 */
	public const DEFAULT_DAILY_QUOTA = 2000;

	/**
	 * Priority weights. Each outranks the sum of the ones below it.
	 */
	public const PRIORITY_REQUESTED = 1000;
	public const PRIORITY_SITEMAP   = 160;
	public const PRIORITY_RECENT    = 80;
	public const PRIORITY_HIGH      = 40;
	public const PRIORITY_UNINDEXED = 20;
	public const PRIORITY_NEVER     = 10;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( self::QUEUE_HOOK, array( $this, 'process_batch' ) );
		add_action( self::URL_HOOK, array( $this, 'scheduled_inspection' ), 10, 2 );
		add_action( 'flseo_sitemap_changed', array( $this, 'on_sitemap_changed' ), 10, 3 );
	}

	/**
	 * Index status table.
	 */
	private static function table(): string {
		return Migrations::table( 'index_status' );
	}

	/**
	 * Current UTC date.
	 */
	protected function today(): string {
		return gmdate( 'Y-m-d' );
	}

	/**
	 * Start of the next UTC day.
	 */
	protected function next_day(): int {
		return (int) strtotime( $this->today() . ' 00:00:00 UTC +1 day' );
	}

	/**
	 * Daily inspection quota for a property.
	 *
	 * @param string $property Property.
	 */
	public function quota_limit( string $property ): int {
		/**
		 * Filter the daily URL Inspection quota for a property.
		 *
		 * @param int    $limit    Inspections per day.
		 * @param string $property Property.
		 */
		return max( 0, (int) apply_filters( 'flseo_inspection_daily_quota', self::DEFAULT_DAILY_QUOTA, $property ) );
	}

	/**
	 * Inspections used today for a property.
	 *
	 * @param string $property Property.
	 */
	public function quota_used( string $property ): int {
		$all  = get_option( self::QUOTA_OPTION, array() );
		$item = is_array( $all ) ? ( $all[ $property ] ?? array() ) : array();
		if ( ! is_array( $item ) || ( $item['date'] ?? '' ) !== $this->today() ) {
			return 0;
		}
		return (int) ( $item['used'] ?? 0 );
	}

	/**
	 * Inspections left today.
	 *
	 * @param string $property Property.
	 */
	public function quota_remaining( string $property ): int {
		return max( 0, $this->quota_limit( $property ) - $this->quota_used( $property ) );
	}

	/**
	 * Set today's used count for a property.
	 *
	 * @param string $property Property.
	 * @param int    $used     Used count.
	 */
	public function set_quota_used( string $property, int $used ): void {
		$all = get_option( self::QUOTA_OPTION, array() );
		$all = is_array( $all ) ? $all : array();
		// Drop stale days for other properties to keep the option small.
		foreach ( $all as $key => $item ) {
			if ( ! is_array( $item ) || ( $item['date'] ?? '' ) !== $this->today() ) {
				unset( $all[ $key ] );
			}
		}
		$all[ $property ] = array(
			'date' => $this->today(),
			'used' => max( 0, $used ),
		);
		update_option( self::QUOTA_OPTION, $all, false );
	}

	/**
	 * Quota summary for the status endpoint.
	 *
	 * @param string $property Property.
	 * @return array{date: string, limit: int, used: int, remaining: int}
	 */
	public function quota( string $property ): array {
		return array(
			'date'      => $this->today(),
			'limit'     => $this->quota_limit( $property ),
			'used'      => $this->quota_used( $property ),
			'remaining' => $this->quota_remaining( $property ),
		);
	}

	/**
	 * Priority score for a post.
	 *
	 * @param \WP_Post                  $post     Post.
	 * @param array<string, mixed>|null $existing Existing status row.
	 * @param bool                      $requested Explicitly requested by a user or a publish follow-up.
	 * @return array{priority: int, in_sitemap: bool}
	 */
	public function priority_for( \WP_Post $post, ?array $existing, bool $requested = false ): array {
		$score      = $requested ? self::PRIORITY_REQUESTED : 0;
		$in_sitemap = $this->in_sitemap( $post );
		if ( $in_sitemap ) {
			$score += self::PRIORITY_SITEMAP;
		}
		$modified = strtotime( $post->post_modified_gmt . ' UTC' );
		if ( $modified && $modified >= time() - 7 * DAY_IN_SECONDS ) {
			$score += self::PRIORITY_RECENT;
		}
		$opp_status = (string) get_post_meta( $post->ID, '_flseo_opp_status', true );
		/**
		 * Filter whether a post is high priority for inspection. Open and closing-soon opportunities are by default.
		 *
		 * @param bool     $high Whether high priority.
		 * @param \WP_Post $post Post.
		 */
		if ( apply_filters( 'flseo_inspection_high_priority', in_array( $opp_status, array( 'open', 'closing-soon' ), true ), $post ) ) {
			$score += self::PRIORITY_HIGH;
		}
		if ( ! $existing || empty( $existing['inspected_at'] ) ) {
			$score += self::PRIORITY_NEVER;
		} elseif ( Reasons::INDEXED !== (string) $existing['reason_code'] ) {
			$score += self::PRIORITY_UNINDEXED;
		}
		return array(
			'priority'   => $score,
			'in_sitemap' => $in_sitemap,
		);
	}

	/**
	 * Whether a post is eligible for the sitemap (indexable and self-canonical).
	 *
	 * @param \WP_Post $post Post.
	 */
	public function in_sitemap( \WP_Post $post ): bool {
		if ( 'publish' !== $post->post_status || '' !== $post->post_password ) {
			return false;
		}
		try {
			return $this->c->get( RobotsResolver::class )->is_indexable( $post ) && $this->c->get( CanonicalResolver::class )->is_self_canonical( $post );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Status row for a post.
	 *
	 * @param int $post_id Post id.
	 * @return array<string, mixed>|null
	 */
	public function row_for_post( int $post_id ): ?array {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE post_id=%d ORDER BY id DESC LIMIT 1", $post_id ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	/**
	 * Create or update the status row for a post's current URL. Removes rows for old URLs of the post.
	 *
	 * @param \WP_Post             $post   Post.
	 * @param array<string, mixed> $fields Columns to set.
	 * @return string The URL tracked.
	 */
	private function upsert( \WP_Post $post, array $fields ): string {
		global $wpdb;
		$table = self::table();
		$url   = (string) get_permalink( $post );
		$hash  = hash( 'sha256', $url );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE post_id=%d AND url_hash<>%s", $post->ID, $hash ) );
		$exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE url_hash=%s", $hash ) );
		// phpcs:enable
		if ( $exists ) {
			$wpdb->update( $table, $fields + array( 'post_id' => $post->ID ), array( 'id' => $exists ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		} else {
			$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$table,
				$fields + array(
					'post_id'  => $post->ID,
					'url_hash' => $hash,
					'url'      => $url,
				)
			);
		}
		return $url;
	}

	/**
	 * Queue one post for inspection.
	 *
	 * @param int  $post_id   Post id.
	 * @param bool $requested Explicit request (jumps ahead of background refreshes).
	 */
	public function queue_post( int $post_id, bool $requested = false ): bool {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status || ! is_post_type_viewable( $post->post_type ) ) {
			return false;
		}
		$existing = $this->row_for_post( $post_id );
		$score    = $this->priority_for( $post, $existing, $requested );
		$fields   = array(
			'priority'   => $score['priority'],
			'in_sitemap' => $score['in_sitemap'] ? 1 : 0,
		);
		if ( ! $existing || empty( $existing['queued_at'] ) ) {
			$fields['queued_at'] = current_time( 'mysql', true );
		} elseif ( (int) $existing['priority'] > $score['priority'] ) {
			$fields['priority'] = (int) $existing['priority'];
		}
		if ( ! $existing || empty( $existing['published_at'] ) ) {
			$fields['published_at'] = $post->post_date_gmt;
		}
		$this->upsert( $post, $fields );
		return true;
	}

	/**
	 * Queue several posts and start the queue.
	 *
	 * @param array<int, int> $post_ids  Post ids.
	 * @param bool            $requested Explicit request.
	 * @return int Number queued.
	 */
	public function queue_posts( array $post_ids, bool $requested = true ): int {
		$count = 0;
		foreach ( array_chunk( array_unique( array_map( 'absint', $post_ids ) ), 200 ) as $chunk ) {
			_prime_post_caches( $chunk, false, true );
			foreach ( $chunk as $id ) {
				if ( $id && $this->queue_post( $id, $requested ) ) {
					++$count;
				}
			}
		}
		if ( $count ) {
			$this->start_run();
		}
		return $count;
	}

	/**
	 * Queue every published post of the sitemap post types.
	 *
	 * @return int Number queued.
	 */
	public function queue_all(): int {
		global $wpdb;
		$types = $this->c->get( \FutureLabs\AISEO\Sitemap\Builder::class )->post_types();
		if ( ! $types ) {
			return 0;
		}
		$in = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_status='publish' AND post_password='' AND post_type IN ($in) ORDER BY post_modified_gmt DESC", $types ) ) );
		return $this->queue_posts( $ids, false );
	}

	/**
	 * Record the run size for the progress bar and kick the queue.
	 */
	private function start_run(): void {
		$queued = $this->queued_count();
		$run    = get_option( self::RUN_OPTION, array() );
		if ( ! is_array( $run ) || empty( $run['total'] ) || (int) ( $run['done'] ?? 0 ) >= (int) $run['total'] ) {
			$run = array(
				'started_at' => gmdate( 'c' ),
				'total'      => $queued,
				'done'       => 0,
			);
		} else {
			$run['total'] = (int) $run['done'] + $queued;
		}
		update_option( self::RUN_OPTION, $run, false );
		$this->kick();
	}

	/**
	 * Schedule the queue job: immediately, or at the next UTC day when paused for quota.
	 */
	public function kick(): void {
		$queue  = $this->c->get( Queue::class );
		$paused = (int) get_option( self::PAUSE_OPTION, 0 );
		if ( $paused > time() ) {
			$queue->at( $paused, self::QUEUE_HOOK );
			return;
		}
		$queue->async( self::QUEUE_HOOK );
	}

	/**
	 * Number of rows waiting.
	 */
	public function queued_count(): int {
		global $wpdb;
		$table = self::table();
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE queued_at IS NOT NULL" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Process one batch of the highest-priority queued rows, then re-queue.
	 *
	 * @return array{inspected: int, failed: int, paused: bool, remaining: int}
	 */
	public function process_batch(): array {
		$oauth    = $this->c->get( OAuth::class );
		$property = $oauth->property();
		$result   = array(
			'inspected' => 0,
			'failed'    => 0,
			'paused'    => false,
			'remaining' => $this->queued_count(),
		);
		if ( ! $oauth->ready() || 0 === $result['remaining'] ) {
			return $result;
		}
		$remaining_quota = $this->quota_remaining( $property );
		if ( $remaining_quota <= 0 ) {
			$this->pause( $property );
			$result['paused'] = true;
			return $result;
		}
		delete_option( self::PAUSE_OPTION );

		global $wpdb;
		$table = self::table();
		$size  = min( $remaining_quota, max( 1, (int) $this->c->get( Settings::class )->get( 'batch_size', 25 ) ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows    = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE queued_at IS NOT NULL ORDER BY priority DESC, queued_at ASC, id ASC LIMIT %d", $size ), ARRAY_A );
		$client  = $this->c->get( Client::class );
		$logger  = $this->c->get( Logger::class );
		$stopped = false;

		foreach ( $rows as $row ) {
			$post = (int) $row['post_id'] ? get_post( (int) $row['post_id'] ) : null;
			if ( (int) $row['post_id'] && ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status ) ) {
				$this->dequeue( (int) $row['id'] );
				continue;
			}
			$response = $client->inspect( (string) $row['url'], $property );
			if ( is_wp_error( $response ) ) {
				$code = $response->get_error_code();
				if ( 'flseo_gsc_quota' === $code ) {
					$this->set_quota_used( $property, $this->quota_limit( $property ) );
					$this->pause( $property );
					$result['paused'] = true;
					break;
				}
				if ( in_array( $code, array( 'flseo_gsc_not_connected', 'flseo_gsc_auth', 'flseo_gsc_token', 'flseo_gsc_http' ), true ) ) {
					// Connection problem: keep the queue intact and stop.
					$logger->warning( 'URL inspection stopped: Search Console request failed.', array( 'error' => $code ) );
					$stopped = true;
					break;
				}
				$this->set_quota_used( $property, $this->quota_used( $property ) + 1 );
				$this->dequeue( (int) $row['id'] );
				$this->advance_run();
				++$result['failed'];
				$logger->warning(
					'URL inspection failed.',
					array(
						'url'   => (string) $row['url'],
						'error' => $response->get_error_message(),
					)
				);
				continue;
			}
			$this->set_quota_used( $property, $this->quota_used( $property ) + 1 );
			$this->store_result( (int) $row['id'], $response );
			$this->advance_run();
			++$result['inspected'];
		}

		$result['remaining'] = $this->queued_count();
		if ( ! $result['paused'] && $result['remaining'] > 0 && ! $stopped && $rows ) {
			if ( $this->quota_remaining( $property ) <= 0 ) {
				$this->pause( $property );
				$result['paused'] = true;
			} else {
				$this->c->get( Queue::class )->async( self::QUEUE_HOOK );
			}
		}
		return $result;
	}

	/**
	 * Pause until the next UTC day and schedule the resume.
	 *
	 * @param string $property Property.
	 */
	private function pause( string $property ): void {
		$resume = $this->next_day() + 60;
		update_option( self::PAUSE_OPTION, $resume, false );
		$queue = $this->c->get( Queue::class );
		$queue->cancel( self::QUEUE_HOOK );
		$queue->at( $resume, self::QUEUE_HOOK );
		$this->c->get( Logger::class )->info(
			'Daily URL Inspection quota reached; inspections resume tomorrow (UTC).',
			array(
				'property'  => $property,
				'resume_at' => gmdate( 'c', $resume ),
			)
		);
	}

	/**
	 * Remove a row from the queue.
	 *
	 * @param int $id Row id.
	 */
	private function dequeue( int $id ): void {
		global $wpdb;
		$table = self::table();
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET queued_at=NULL, priority=0 WHERE id=%d", $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Count one finished item in the progress run.
	 */
	private function advance_run(): void {
		$run = get_option( self::RUN_OPTION, array() );
		if ( is_array( $run ) && ! empty( $run['total'] ) ) {
			$run['done'] = min( (int) $run['total'], (int) ( $run['done'] ?? 0 ) + 1 );
			update_option( self::RUN_OPTION, $run, false );
		}
	}

	/**
	 * Save an inspection response onto a status row and dequeue it.
	 *
	 * @param int                  $row_id   Row id.
	 * @param array<string, mixed> $response API response.
	 */
	public function store_result( int $row_id, array $response ): void {
		global $wpdb;
		$table  = self::table();
		$status = Reasons::index_status( $response );
		$reason = $this->c->get( Reasons::class )->from_result( $response );
		$now    = current_time( 'mysql', true );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$current = $wpdb->get_row( $wpdb->prepare( "SELECT indexed_at FROM {$table} WHERE id=%d", $row_id ), ARRAY_A );
		$verdict = strtoupper( sanitize_key( (string) ( $status['verdict'] ?? '' ) ) );
		$fields  = array(
			'verdict'          => '' !== $verdict ? $verdict : 'unknown',
			'coverage_state'   => substr( sanitize_text_field( (string) ( $status['coverageState'] ?? '' ) ), 0, 191 ),
			'google_canonical' => esc_url_raw( (string) ( $status['googleCanonical'] ?? '' ) ),
			'user_canonical'   => esc_url_raw( (string) ( $status['userCanonical'] ?? '' ) ),
			'robots_state'     => substr( sanitize_text_field( (string) ( $status['robotsTxtState'] ?? '' ) ), 0, 64 ),
			'page_fetch_state' => substr( sanitize_text_field( (string) ( $status['pageFetchState'] ?? '' ) ), 0, 64 ),
			'last_crawl'       => self::to_datetime( (string) ( $status['lastCrawlTime'] ?? '' ) ),
			'inspected_at'     => $now,
			'reason_code'      => $reason,
			'queued_at'        => null,
			'priority'         => 0,
		);
		if ( 'PASS' === $verdict && is_array( $current ) && empty( $current['indexed_at'] ) ) {
			$fields['indexed_at'] = $now;
		}
		$wpdb->update( $table, $fields, array( 'id' => $row_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		/**
		 * Fires after an inspection result was stored.
		 *
		 * @param int    $row_id Status row id.
		 * @param string $reason Reason code.
		 */
		do_action( 'flseo_inspection_stored', $row_id, $reason );
	}

	/**
	 * RFC 3339 time to MySQL UTC datetime.
	 *
	 * @param string $time Time string.
	 */
	private static function to_datetime( string $time ): ?string {
		$ts = '' !== $time ? strtotime( $time ) : false;
		return $ts ? gmdate( 'Y-m-d H:i:s', $ts ) : null;
	}

	/**
	 * OL-10: on publish record published_at and schedule inspections at +24h and +72h.
	 *
	 * @param \WP_Post $post       Post.
	 * @param string   $new_status New status.
	 * @param string   $old_status Old status.
	 */
	public function on_sitemap_changed( $post, $new_status, $old_status ): void {
		unset( $old_status );
		if ( ! $post instanceof \WP_Post ) {
			return;
		}
		if ( 'publish' !== $new_status ) {
			$row = $this->row_for_post( $post->ID );
			if ( $row && ! empty( $row['queued_at'] ) ) {
				$this->dequeue( (int) $row['id'] );
			}
			return;
		}
		if ( ! is_post_type_viewable( $post->post_type ) || '' !== $post->post_password ) {
			return;
		}
		$existing = $this->row_for_post( $post->ID );
		$fields   = array( 'in_sitemap' => $this->in_sitemap( $post ) ? 1 : 0 );
		if ( ! $existing || empty( $existing['published_at'] ) ) {
			$fields['published_at'] = '0000-00-00 00:00:00' !== $post->post_date_gmt ? $post->post_date_gmt : current_time( 'mysql', true );
		}
		$this->upsert( $post, $fields );
		if ( ! $this->c->get( OAuth::class )->is_connected() ) {
			return;
		}
		$queue = $this->c->get( Queue::class );
		$now   = time();
		$queue->at( $now + DAY_IN_SECONDS, self::URL_HOOK, array( $post->ID, 24 ) );
		$queue->at( $now + 3 * DAY_IN_SECONDS, self::URL_HOOK, array( $post->ID, 72 ) );
	}

	/**
	 * Run a follow-up inspection for a new post (OL-10) through the quota-aware queue.
	 *
	 * @param int $post_id Post id.
	 * @param int $stage   Hours after publish (24 or 72).
	 */
	public function scheduled_inspection( $post_id, $stage = 0 ): void {
		unset( $stage );
		$post_id = absint( $post_id );
		$row     = $this->row_for_post( $post_id );
		if ( $row && Reasons::INDEXED === (string) $row['reason_code'] ) {
			return;
		}
		if ( $this->queue_post( $post_id, true ) ) {
			$this->start_run();
		}
	}

	/**
	 * Progress numbers for the dashboard progress bar.
	 *
	 * @return array<string, mixed>
	 */
	public function progress(): array {
		$property = $this->c->get( OAuth::class )->property();
		$run      = get_option( self::RUN_OPTION, array() );
		$run      = is_array( $run ) ? $run : array();
		$total    = (int) ( $run['total'] ?? 0 );
		$done     = min( $total, (int) ( $run['done'] ?? 0 ) );
		$paused   = (int) get_option( self::PAUSE_OPTION, 0 );
		return array(
			'queued'     => $this->queued_count(),
			'run_total'  => $total,
			'run_done'   => $done,
			'percent'    => $total > 0 ? round( $done / $total * 100, 1 ) : 0.0,
			'started_at' => (string) ( $run['started_at'] ?? '' ),
			'paused'     => $paused > time(),
			'resumes_at' => $paused > time() ? gmdate( 'c', $paused ) : null,
			'quota'      => $this->quota( $property ),
			'running'    => $this->c->get( Queue::class )->is_pending( self::QUEUE_HOOK ),
		);
	}
}
