<?php
/**
 * Orphan and weakly linked post lists.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Links;

use FutureLabs\AISEO\Content\Analyzer;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Lists indexable published posts with no (orphan) or fewer than two (weak) internal links in.
 */
class Orphans {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Post types whose posts are indexable by type setting.
	 *
	 * @return array<int, string>
	 */
	public function indexable_types(): array {
		$settings = $this->c->get( Settings::class );
		return array_values( array_filter( Analyzer::post_types(), static fn( $type ) => (bool) $settings->post_type( $type )['index'] ) );
	}

	/**
	 * List posts below an inbound threshold.
	 *
	 * @param string $kind     orphan (inbound = 0) or weak (inbound < 2).
	 * @param int    $page     Page.
	 * @param int    $per_page Per page.
	 * @param string $post_type Optional post type filter.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function list( string $kind = 'orphan', int $page = 1, int $per_page = 50, string $post_type = '' ): array {
		global $wpdb;
		$types = $this->indexable_types();
		if ( '' !== $post_type ) {
			$types = array_values( array_intersect( $types, array( $post_type ) ) );
		}
		if ( ! $types ) {
			return array(
				'items' => array(),
				'total' => 0,
			);
		}
		$stats  = Migrations::table( 'link_stats' );
		$max    = 'weak' === $kind ? Graph::WEAK : 1;
		$in     = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$skip   = array_values( array_filter( array( (int) get_option( 'page_on_front' ), (int) get_option( 'page_for_posts' ) ) ) );
		$skip[] = 0;
		$not_in = implode( ',', array_map( 'absint', $skip ) );
		$where  = "p.post_status = 'publish' AND p.post_password = '' AND p.post_type IN ({$in}) AND s.inbound < %d AND p.ID NOT IN ({$not_in}) AND ni.meta_id IS NULL";
		$join   = "INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id LEFT JOIN {$wpdb->postmeta} ni ON ni.post_id = p.ID AND ni.meta_key = '_flseo_noindex' AND ni.meta_value = '1'";
		$args   = array_merge( $types, array( $max ) );
		$offset = ( max( 1, $page ) - 1 ) * $per_page;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$stats} s {$join} WHERE {$where}", $args ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT s.post_id, s.inbound, s.outbound, s.click_depth, p.post_title, p.post_type, p.post_date FROM {$stats} s {$join} WHERE {$where} ORDER BY s.inbound ASC, p.post_date DESC LIMIT %d OFFSET %d", array_merge( $args, array( $per_page, $offset ) ) ) );
		// phpcs:enable
		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = self::item( $row );
		}
		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * IDs of orphaned indexable posts (used by tests and digests).
	 *
	 * @return array<int, int>
	 */
	public function ids(): array {
		$out  = array();
		$page = 1;
		do {
			$batch = $this->list( 'orphan', $page, 500 );
			foreach ( $batch['items'] as $item ) {
				$out[] = (int) $item['id'];
			}
			++$page;
		} while ( 500 === count( $batch['items'] ) ); // phpcs:ignore Squiz.PHP.DisallowSizeFunctionsInLoops.Found -- size of the batch just fetched.
		return $out;
	}

	/**
	 * Shape a row for REST.
	 *
	 * @param object $row Row with post_id, inbound, outbound, click_depth, post_title, post_type.
	 * @return array<string, mixed>
	 */
	public static function item( object $row ): array {
		$id = (int) $row->post_id;
		return array(
			'id'          => $id,
			'title'       => (string) $row->post_title,
			'url'         => (string) get_permalink( $id ),
			'edit_url'    => (string) get_edit_post_link( $id, 'raw' ),
			'post_type'   => (string) $row->post_type,
			'inbound'     => (int) $row->inbound,
			'outbound'    => (int) $row->outbound,
			'click_depth' => (int) $row->click_depth >= Graph::MAX_DEPTH ? null : (int) $row->click_depth,
		);
	}
}
