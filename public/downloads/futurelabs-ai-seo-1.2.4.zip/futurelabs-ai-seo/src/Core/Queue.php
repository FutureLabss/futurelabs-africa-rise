<?php
/**
 * Background job queue backed by Action Scheduler, with a WP-Cron fallback.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Enqueues idempotent jobs in the `futurelabs-ai-seo` group.
 */
class Queue {

	public const GROUP = 'futurelabs-ai-seo';

	/**
	 * Whether Action Scheduler is loaded.
	 */
	public function has_action_scheduler(): bool {
		return function_exists( 'as_enqueue_async_action' ) && function_exists( 'as_schedule_single_action' );
	}

	/**
	 * Run a job as soon as possible unless an identical one is already pending.
	 *
	 * @param string       $hook Hook name.
	 * @param array<mixed> $args Arguments.
	 */
	public function async( string $hook, array $args = array() ): void {
		if ( $this->is_pending( $hook, $args ) ) {
			return;
		}
		if ( $this->has_action_scheduler() ) {
			as_enqueue_async_action( $hook, $args, self::GROUP );
			return;
		}
		wp_schedule_single_event( time(), $hook, $args );
	}

	/**
	 * Run a job at a timestamp unless an identical one is already pending.
	 *
	 * @param int          $timestamp Unix time.
	 * @param string       $hook      Hook name.
	 * @param array<mixed> $args      Arguments.
	 */
	public function at( int $timestamp, string $hook, array $args = array() ): void {
		if ( $this->is_pending( $hook, $args ) ) {
			return;
		}
		if ( $this->has_action_scheduler() ) {
			as_schedule_single_action( $timestamp, $hook, $args, self::GROUP );
			return;
		}
		wp_schedule_single_event( $timestamp, $hook, $args );
	}

	/**
	 * Schedule a recurring job once.
	 *
	 * @param int    $interval Seconds.
	 * @param string $hook     Hook name.
	 */
	public function recurring( int $interval, string $hook ): void {
		if ( $this->has_action_scheduler() && function_exists( 'as_schedule_recurring_action' ) ) {
			if ( ! as_has_scheduled_action( $hook, array(), self::GROUP ) ) {
				as_schedule_recurring_action( time() + 60, $interval, $hook, array(), self::GROUP );
			}
			return;
		}
		if ( ! wp_next_scheduled( $hook ) ) {
			$recurrence = $interval >= WEEK_IN_SECONDS ? 'weekly' : ( $interval >= DAY_IN_SECONDS ? 'daily' : 'hourly' );
			wp_schedule_event( time() + 60, $recurrence, $hook );
		}
	}

	/**
	 * Whether an identical job is pending.
	 *
	 * @param string       $hook Hook name.
	 * @param array<mixed> $args Arguments.
	 */
	public function is_pending( string $hook, array $args = array() ): bool {
		if ( $this->has_action_scheduler() && function_exists( 'as_get_scheduled_actions' ) ) {
			// Only pending actions count. as_has_scheduled_action() also counts the in-progress
			// action, which made a running batch skip queuing its own continuation.
			$ids = as_get_scheduled_actions(
				array(
					'hook'     => $hook,
					'args'     => $args,
					'group'    => self::GROUP,
					'status'   => \ActionScheduler_Store::STATUS_PENDING,
					'per_page' => 1,
				),
				'ids'
			);
			return ! empty( $ids );
		}
		return (bool) wp_next_scheduled( $hook, $args );
	}

	/**
	 * Count pending jobs for a hook (used for progress bars).
	 *
	 * @param string $hook Hook name.
	 */
	public function pending_count( string $hook ): int {
		if ( $this->has_action_scheduler() && function_exists( 'as_get_scheduled_actions' ) ) {
			$ids = as_get_scheduled_actions(
				array(
					'hook'     => $hook,
					'group'    => self::GROUP,
					'status'   => \ActionScheduler_Store::STATUS_PENDING,
					'per_page' => 5000,
				),
				'ids'
			);
			return count( (array) $ids );
		}
		$count = 0;
		foreach ( (array) _get_cron_array() as $events ) {
			if ( isset( $events[ $hook ] ) ) {
				$count += count( $events[ $hook ] );
			}
		}
		return $count;
	}

	/**
	 * Cancel all jobs for a hook.
	 *
	 * @param string $hook Hook name.
	 */
	public function cancel( string $hook ): void {
		if ( $this->has_action_scheduler() && function_exists( 'as_unschedule_all_actions' ) ) {
			// Without args or group, Action Scheduler cancels every action for the hook.
			as_unschedule_all_actions( $hook );
		}
		wp_clear_scheduled_hook( $hook );
	}
}
