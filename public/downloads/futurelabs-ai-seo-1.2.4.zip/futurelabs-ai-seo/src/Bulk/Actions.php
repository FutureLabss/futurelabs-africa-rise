<?php
/**
 * Bulk actions on posts with audit logging and undo support.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Bulk;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Url;
use FutureLabs\AISEO\Meta\NoindexGuard;
use FutureLabs\AISEO\Meta\PostMeta;
use FutureLabs\AISEO\Redirects\Rules;

defined( 'ABSPATH' ) || exit;

/**
 * Applies one action to 1–500 posts. Every change writes one audit row per object
 * in a single batch so `Undo::undo( batch_id )` can restore it.
 */
class Actions {

	public const MAX_POSTS = 500;
	public const SAMPLE    = 10;
	public const ACTIONS   = array( 'noindex', 'index', 'canonical', 'redirect', 'apply_template', 'merge', 'opportunity' );

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Run (or preview) a bulk action.
	 *
	 * Arguments: action, post_ids, confirmation, dry_run, and per action:
	 * canonical {url}; redirect {target, type, unpublish}; apply_template {field, template};
	 * merge {target_id}; opportunity {opportunity_action, target}.
	 *
	 * @param array<string, mixed> $args Arguments.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function run( array $args ) {
		$action = sanitize_key( (string) ( $args['action'] ?? '' ) );
		if ( ! in_array( $action, self::ACTIONS, true ) ) {
			return $this->error( 'bulk_action', __( 'Unsupported bulk action.', 'futurelabs-ai-seo' ) );
		}
		$ids = array_values( array_unique( array_filter( array_map( 'absint', (array) ( $args['post_ids'] ?? array() ) ) ) ) );
		if ( ! $ids || count( $ids ) > self::MAX_POSTS ) {
			/* translators: %d: maximum number of posts. */
			return $this->error( 'bulk_count', sprintf( __( 'Choose between 1 and %d posts.', 'futurelabs-ai-seo' ), self::MAX_POSTS ) );
		}
		if ( in_array( $action, array( 'redirect', 'merge' ), true ) && ! Capabilities::can( Capabilities::DATA ) ) {
			return $this->error( 'bulk_forbidden', __( 'Only administrators can create redirects.', 'futurelabs-ai-seo' ), 403 );
		}
		$params = $this->params( $action, $args );
		if ( is_wp_error( $params ) ) {
			return $params;
		}
		if ( 'merge' === $action ) {
			$ids = array_values( array_diff( $ids, array( $params['target_id'] ) ) );
		}

		$skipped  = array();
		$editable = array();
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post instanceof \WP_Post || 'revision' === $post->post_type ) {
				$skipped[] = array(
					'id'     => $id,
					'reason' => __( 'Post not found.', 'futurelabs-ai-seo' ),
				);
			} elseif ( ! current_user_can( 'edit_post', $id ) ) {
				$skipped[] = array(
					'id'     => $id,
					'reason' => __( 'You are not allowed to edit this post.', 'futurelabs-ai-seo' ),
				);
			} else {
				$editable[] = $post;
			}
		}

		$confirmation = sanitize_text_field( (string) ( $args['confirmation'] ?? '' ) );
		$verdict      = null;
		$guarded = 'noindex' === $action || ( 'opportunity' === $action && 'noindex' === ( $params['opportunity_action'] ?? '' ) );
		if ( $guarded && $editable ) {
			$verdict = $this->c->get( NoindexGuard::class )->check_posts( wp_list_pluck( $editable, 'ID' ), $confirmation );
		}
		$dry_run = ! empty( $args['dry_run'] ) && 'false' !== $args['dry_run'];

		if ( $dry_run ) {
			$preview = array(
				'dry_run' => true,
				'action'  => $action,
				'count'   => count( $editable ),
				'sample'  => $this->sample( $editable ),
				'skipped' => $skipped,
			);
			if ( $verdict ) {
				$preview['confirmation'] = array(
					'required'  => ! $this->c->get( NoindexGuard::class )->check_posts( wp_list_pluck( $editable, 'ID' ) )['allowed'],
					'phrase'    => $verdict['phrase'],
					'projected' => $verdict['projected'],
					'published' => $verdict['published'],
				);
			}
			return $preview;
		}

		if ( $verdict && ! $verdict['allowed'] ) {
			return array(
				'confirmation_required' => true,
				'action'                => $action,
				'count'                 => count( $editable ),
				'projected'             => $verdict['projected'],
				'published'             => $verdict['published'],
				'phrase'                => $verdict['phrase'],
				'sample'                => $this->sample( $editable ),
				'message'               => sprintf(
					/* translators: 1: projected noindexed pages, 2: published pages, 3: confirmation phrase. */
					__( 'This would leave %1$d of %2$d published pages noindexed. Type %3$s to confirm.', 'futurelabs-ai-seo' ),
					$verdict['projected'],
					$verdict['published'],
					$verdict['phrase']
				),
			);
		}

		$audit   = $this->c->get( AuditLog::class );
		$batch   = $audit->new_batch();
		$changed = 0;
		$errors  = array();
		foreach ( $editable as $post ) {
			$result = $this->apply_one( $action, $post, $params, $batch );
			if ( is_wp_error( $result ) ) {
				$errors[] = array(
					'id'    => $post->ID,
					'title' => get_the_title( $post ),
					'error' => $result->get_error_message(),
				);
			} elseif ( $result ) {
				++$changed;
			} else {
				$skipped[] = array(
					'id'     => $post->ID,
					'reason' => __( 'Already set; nothing to change.', 'futurelabs-ai-seo' ),
				);
			}
		}
		if ( $changed ) {
			/**
			 * Fires after a bulk action changed posts.
			 *
			 * @param string $batch   Batch id.
			 * @param string $action  Action.
			 * @param int    $changed Changed objects.
			 */
			do_action( 'flseo_bulk_applied', $batch, $action, $changed );
		}
		return array(
			'batch_id' => $changed ? $batch : null,
			'action'   => $action,
			'changed'  => $changed,
			'skipped'  => $skipped,
			'errors'   => $errors,
		);
	}

	/**
	 * Validate per-action parameters.
	 *
	 * @param string               $action Action.
	 * @param array<string, mixed> $args   Raw args.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function params( string $action, array $args ) {
		switch ( $action ) {
			case 'canonical':
				$raw = trim( (string) ( $args['url'] ?? '' ) );
				$url = PostMeta::sanitize( 'url', $raw );
				if ( '' !== $raw && '' === $url ) {
					return $this->error( 'bulk_url', __( 'Enter a valid canonical URL, or leave it empty to clear the override.', 'futurelabs-ai-seo' ) );
				}
				return array( 'url' => $url );
			case 'redirect':
				$type   = absint( $args['type'] ?? 301 );
				$target = trim( (string) ( $args['target'] ?? '' ) );
				if ( str_starts_with( $target, '/' ) ) {
					$target = home_url( $target );
				}
				if ( ! in_array( $type, Rules::TYPES, true ) ) {
					return $this->error( 'bulk_redirect_type', __( 'Choose 301, 302, 307 or 410.', 'futurelabs-ai-seo' ) );
				}
				if ( 410 !== $type && ! Url::is_valid( $target ) ) {
					return $this->error( 'bulk_redirect_target', __( 'Enter a valid target URL.', 'futurelabs-ai-seo' ) );
				}
				return array(
					'target'    => 410 === $type ? '' : esc_url_raw( $target ),
					'type'      => $type,
					'unpublish' => ! empty( $args['unpublish'] ) && 'false' !== $args['unpublish'],
				);
			case 'apply_template':
				$field = (string) ( $args['field'] ?? '' );
				if ( ! in_array( $field, array( 'title', 'description' ), true ) ) {
					return $this->error( 'bulk_field', __( 'Choose the title or description field.', 'futurelabs-ai-seo' ) );
				}
				return array(
					'key'      => '_flseo_' . $field,
					'template' => PostMeta::sanitize_template( (string) ( $args['template'] ?? '' ) ),
				);
			case 'merge':
				$target = get_post( absint( $args['target_id'] ?? 0 ) );
				if ( ! $target instanceof \WP_Post || 'publish' !== $target->post_status ) {
					return $this->error( 'bulk_merge_target', __( 'Choose a published post to merge into.', 'futurelabs-ai-seo' ) );
				}
				return array(
					'target_id' => $target->ID,
					'target'    => (string) get_permalink( $target ),
				);
			case 'opportunity':
				$class = '\\FutureLabs\\AISEO\\Opportunity\\Lifecycle';
				if ( ! class_exists( $class ) || ! method_exists( $class, 'apply_action' ) ) {
					return $this->error( 'bulk_opportunity', __( 'Opportunity lifecycle actions are not available.', 'futurelabs-ai-seo' ) );
				}
				$opp = sanitize_key( (string) ( $args['opportunity_action'] ?? '' ) );
				if ( ! in_array( $opp, \FutureLabs\AISEO\Opportunity\Lifecycle::ACTIONS, true ) ) {
					return $this->error( 'bulk_opportunity_action', __( 'Choose update, notice, noindex or redirect.', 'futurelabs-ai-seo' ) );
				}
				// Noindex and redirects change site-wide indexing, so they need the data capability.
				if ( in_array( $opp, array( 'noindex', 'redirect' ), true ) && ! Capabilities::can( Capabilities::DATA ) ) {
					return $this->error( 'bulk_forbidden', __( 'Only administrators can noindex or redirect opportunities.', 'futurelabs-ai-seo' ), 403 );
				}
				$target = trim( (string) ( $args['target'] ?? '' ) );
				if ( 'redirect' === $opp && '' !== $target ) {
					if ( str_starts_with( $target, '/' ) && ! str_starts_with( $target, '//' ) ) {
						$target = home_url( $target );
					}
					$target = esc_url_raw( $target );
					if ( ! \FutureLabs\AISEO\Opportunity\Lifecycle::is_internal( $target ) ) {
						return $this->error( 'bulk_redirect_target', __( 'Opportunity redirects must point to a page on this site.', 'futurelabs-ai-seo' ) );
					}
				}
				return array(
					'class'              => $class,
					'opportunity_action' => $opp,
					'target'             => 'redirect' === $opp ? $target : '',
				);
		}
		return array();
	}

	/**
	 * Apply an action to one post.
	 *
	 * @param string               $action Action.
	 * @param \WP_Post             $post   Post.
	 * @param array<string, mixed> $params Validated params.
	 * @param string               $batch  Batch id.
	 * @return bool|\WP_Error True when changed, false when unchanged.
	 */
	private function apply_one( string $action, \WP_Post $post, array $params, string $batch ) {
		switch ( $action ) {
			case 'noindex':
				return $this->set_meta( $action, $post->ID, '_flseo_noindex', '1', $batch );
			case 'index':
				return $this->set_meta( $action, $post->ID, '_flseo_noindex', '', $batch );
			case 'canonical':
				return $this->set_meta( $action, $post->ID, '_flseo_canonical', $params['url'], $batch );
			case 'apply_template':
				return $this->set_meta( $action, $post->ID, $params['key'], $params['template'], $batch );
			case 'redirect':
				$created = $this->redirect( $action, $post, $params['target'], (int) $params['type'], $batch );
				if ( is_wp_error( $created ) ) {
					return $created;
				}
				if ( $params['unpublish'] ) {
					$this->set_status( $action, $post, 'draft', $batch );
				}
				return true;
			case 'merge':
				$created = $this->redirect( $action, $post, $params['target'], 301, $batch );
				if ( is_wp_error( $created ) ) {
					return $created;
				}
				$this->set_status( $action, $post, 'draft', $batch );
				return true;
			case 'opportunity':
				$lifecycle = $this->c->get( \FutureLabs\AISEO\Opportunity\Lifecycle::class );
				// Lifecycle changes join this audit batch; run() already applied the noindex guard to the whole selection.
				$result = $lifecycle->apply_action( $post->ID, $params['opportunity_action'], $params['target'], $batch, '', true, true );
				if ( is_wp_error( $result ) ) {
					return $result;
				}
				return false !== $result;
		}
		return false;
	}

	/**
	 * Set or delete one meta value and log it.
	 *
	 * @param string $action  Action.
	 * @param int    $post_id Post ID.
	 * @param string $key     Meta key.
	 * @param string $value   New value ('' deletes).
	 * @param string $batch   Batch id.
	 */
	private function set_meta( string $action, int $post_id, string $key, string $value, string $batch ): bool {
		$old = (string) get_post_meta( $post_id, $key, true );
		if ( $old === $value ) {
			return false;
		}
		$this->c->get( AuditLog::class )->record_single( $action, $post_id, $key, $old, $value, $batch );
		if ( '' === $value ) {
			delete_post_meta( $post_id, $key );
		} else {
			update_post_meta( $post_id, $key, $value );
		}
		return true;
	}

	/**
	 * Create (or replace) a redirect from a post's URL and log the previous rule.
	 *
	 * @param string   $action Action.
	 * @param \WP_Post $post   Post.
	 * @param string   $target Target URL.
	 * @param int      $type   Redirect type.
	 * @param string   $batch  Batch id.
	 * @return int|\WP_Error Rule id.
	 */
	private function redirect( string $action, \WP_Post $post, string $target, int $type, string $batch ) {
		$source = (string) get_permalink( $post );
		if ( 'publish' !== $post->post_status || '' === $source ) {
			return $this->error( 'bulk_redirect_source', __( 'Only published posts have a URL to redirect.', 'futurelabs-ai-seo' ) );
		}
		$rules = $this->c->get( Rules::class );
		$old   = self::rule_by_source( $source );
		$id    = $rules->save(
			array(
				'source' => $source,
				'target' => $target,
				'type'   => $type,
			),
			0,
			'bulk'
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$this->c->get( AuditLog::class )->write(
			$batch,
			$action,
			'redirect',
			$id,
			array(
				'kind' => 'redirect',
				'row'  => $old,
			),
			array(
				'kind'    => 'redirect',
				'row'     => $rules->get( $id ),
				'post_id' => $post->ID,
			)
		);
		return $id;
	}

	/**
	 * Change a post status and log it.
	 *
	 * @param string   $action Action.
	 * @param \WP_Post $post   Post.
	 * @param string   $status New status.
	 * @param string   $batch  Batch id.
	 */
	private function set_status( string $action, \WP_Post $post, string $status, string $batch ): void {
		if ( $post->post_status === $status ) {
			return;
		}
		$this->c->get( AuditLog::class )->write(
			$batch,
			$action,
			'post',
			$post->ID,
			array(
				'kind'  => 'post_status',
				'value' => $post->post_status,
			),
			array(
				'kind'  => 'post_status',
				'value' => $status,
			)
		);
		wp_update_post(
			array(
				'ID'          => $post->ID,
				'post_status' => $status,
			)
		);
	}

	/**
	 * Existing exact rule for a source URL.
	 *
	 * @param string $source Source URL or path.
	 * @return array<string, mixed>|null
	 */
	public static function rule_by_source( string $source ): ?array {
		global $wpdb;
		$table = Rules::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE source_hash=%s", Rules::hash( $source ) ), ARRAY_A );
		return $row ? $row : null;
	}

	/**
	 * Up to ten sample posts for the confirmation dialog.
	 *
	 * @param array<int, \WP_Post> $posts Posts.
	 * @return array<int, array{id: int, title: string, status: string}>
	 */
	private function sample( array $posts ): array {
		$out = array();
		foreach ( array_slice( $posts, 0, self::SAMPLE ) as $post ) {
			$out[] = array(
				'id'     => $post->ID,
				'title'  => wp_strip_all_tags( get_the_title( $post ) ),
				'status' => $post->post_status,
			);
		}
		return $out;
	}

	/**
	 * Error helper.
	 *
	 * @param string $code    Code.
	 * @param string $message Message.
	 * @param int    $status  HTTP status.
	 */
	private function error( string $code, string $message, int $status = 400 ): \WP_Error {
		return new \WP_Error( 'flseo_' . $code, $message, array( 'status' => $status ) );
	}
}
