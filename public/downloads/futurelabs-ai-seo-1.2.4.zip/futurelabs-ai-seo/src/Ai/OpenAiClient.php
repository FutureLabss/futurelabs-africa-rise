<?php
/**
 * OpenAI Chat Completions client over the WordPress HTTP API.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Ai;

use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Sends one-shot requests to POST {base}/chat/completions.
 */
class OpenAiClient extends Provider {

	public const BASE_URL   = 'https://api.openai.com/v1';
	public const KEY_OPTION = 'flseo_ai_key_openai';

	/**
	 * Output budget. Reasoning models spend part of it thinking, so it is larger than the Claude budget.
	 */
	public const MAX_TOKENS = 4000;

	/**
	 * Image types accepted as data URLs.
	 */
	public const IMAGE_TYPES = array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' );

	/**
	 * Provider ID.
	 */
	public function id(): string {
		return 'openai';
	}

	/**
	 * Service name.
	 */
	public function label(): string {
		return 'OpenAI';
	}

	/**
	 * Key option.
	 */
	public function key_option(): string {
		return self::KEY_OPTION;
	}

	/**
	 * Base URL without a trailing slash.
	 */
	protected function base_url(): string {
		return self::BASE_URL;
	}

	/**
	 * Setting that stores the model ID.
	 */
	protected function model_setting(): string {
		return 'ai_model_openai';
	}

	/**
	 * Configured model ID ('' when none is chosen).
	 */
	public function model(): string {
		return self::clean_model( (string) $this->c->get( Settings::class )->get( $this->model_setting(), '' ) );
	}

	/**
	 * Keep model IDs to safe characters (they are sent in JSON or a URL path).
	 *
	 * @param string $model Raw model ID.
	 */
	public static function clean_model( string $model ): string {
		$model = trim( $model );
		return preg_match( '/^[A-Za-z0-9][A-Za-z0-9._:\/@\-]{0,127}$/', $model ) ? $model : '';
	}

	/**
	 * Image types.
	 *
	 * @return array<int, string>
	 */
	public function image_types(): array {
		return self::IMAGE_TYPES;
	}

	/**
	 * Name of the output-length field. OpenAI's current models require
	 * `max_completion_tokens`; most compatible servers only know `max_tokens`.
	 */
	protected function max_tokens_field(): string {
		return 'max_completion_tokens';
	}

	/**
	 * Request headers.
	 *
	 * @param string $key API key ('' for servers that need none).
	 * @return array<string, string>
	 */
	protected function headers( string $key ): array {
		$headers = array( 'content-type' => 'application/json' );
		if ( '' !== $key ) {
			$headers['authorization'] = 'Bearer ' . $key;
		}
		return $headers;
	}

	/**
	 * Request body.
	 *
	 * @param string                                              $system System prompt.
	 * @param string                                              $text   User text.
	 * @param array<int, array{media_type: string, data: string}> $images Base64 images, placed before the text.
	 * @return array<string, mixed>
	 */
	public function body( string $system, string $text, array $images = array() ): array {
		$content = array();
		foreach ( $images as $image ) {
			$content[] = array(
				'type'      => 'image_url',
				'image_url' => array( 'url' => 'data:' . $image['media_type'] . ';base64,' . $image['data'] ),
			);
		}
		$content[] = array(
			'type' => 'text',
			'text' => $text,
		);
		return array(
			'model'                   => $this->model(),
			$this->max_tokens_field() => static::MAX_TOKENS,
			'messages'                => array(
				array(
					'role'    => 'system',
					'content' => $system,
				),
				array(
					'role'    => 'user',
					// Plain string when there is no image: some compatible servers reject content arrays.
					'content' => $images ? $content : $text,
				),
			),
		);
	}

	/**
	 * HTTP request.
	 *
	 * @param string                                              $system System prompt.
	 * @param string                                              $text   User text.
	 * @param array<int, array{media_type: string, data: string}> $images Images.
	 * @param string                                              $key    API key.
	 * @return array{url: string, args: array<string, mixed>}
	 */
	protected function request( string $system, string $text, array $images, string $key ): array {
		return array(
			'url'  => $this->base_url() . '/chat/completions',
			'args' => array(
				'headers' => $this->headers( $key ),
				'body'    => (string) wp_json_encode( $this->body( $system, $text, $images ) ),
			),
		);
	}

	/**
	 * Read a 200 response.
	 *
	 * @param array<string, mixed> $data Decoded body.
	 * @return array{text: string, stop_reason: string, truncated: bool}|\WP_Error
	 */
	protected function parse( array $data ) {
		$choice  = is_array( $data['choices'][0] ?? null ) ? $data['choices'][0] : array();
		$message = is_array( $choice['message'] ?? null ) ? $choice['message'] : array();
		$finish  = (string) ( $choice['finish_reason'] ?? '' );
		if ( 'content_filter' === $finish || ( is_string( $message['refusal'] ?? null ) && '' !== trim( $message['refusal'] ) ) ) {
			return $this->refusal( 'content_filter' === $finish ? 'content_filter' : '' );
		}
		$content = $message['content'] ?? '';
		$text    = '';
		if ( is_string( $content ) ) {
			$text = $content;
		} elseif ( is_array( $content ) ) {
			foreach ( $content as $part ) {
				if ( is_array( $part ) && 'text' === ( $part['type'] ?? '' ) ) {
					$text .= (string) ( $part['text'] ?? '' );
				}
			}
		}
		// Some reasoning models served through compatible APIs wrap their reasoning in <think> tags.
		$text = (string) preg_replace( '/<think>.*?<\/think>/s', '', $text );
		return array(
			'text'        => trim( $text ),
			'stop_reason' => $finish,
			'truncated'   => 'length' === $finish,
		);
	}

	/**
	 * Models the key can use, from GET {base}/models.
	 *
	 * @return array<int, string>|\WP_Error
	 */
	public function list_models() {
		$key  = $this->c->get( \FutureLabs\AISEO\Core\Crypto::class )->get_secret( $this->key_option() );
		$data = $this->get_json( $this->base_url() . '/models', $this->headers( $key ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$ids = array();
		foreach ( (array) ( $data['data'] ?? array() ) as $model ) {
			$id = is_array( $model ) ? self::clean_model( (string) ( $model['id'] ?? '' ) ) : '';
			if ( '' !== $id && $this->is_text_model( $id ) ) {
				$ids[] = $id;
			}
		}
		sort( $ids );
		return $ids;
	}

	/**
	 * Whether a listed model can write text replies (OpenAI lists audio, image and embedding models too).
	 *
	 * @param string $id Model ID.
	 */
	protected function is_text_model( string $id ): bool {
		return (bool) preg_match( '/^(gpt-|o\d|chatgpt-)/', $id )
			&& ! preg_match( '/(audio|realtime|transcribe|tts|image|search|embedding|moderation|instruct)/', $id );
	}
}
