<?php
/**
 * Multisite support: per-site setup, table cleanup and a network overview.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Admin;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * Every site keeps its own settings and tables; the network screen summarizes them.
 */
class Network implements Module {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		if ( ! is_multisite() ) {
			return;
		}
		add_action( 'wp_initialize_site', array( $this, 'initialize_site' ), 100 );
		add_filter( 'wpmu_drop_tables', array( $this, 'drop_tables' ), 10, 2 );
		add_action( 'network_admin_menu', array( $this, 'menu' ) );
	}

	/**
	 * Whether FutureLabs AI SEO is network-activated.
	 */
	public static function is_network_active(): bool {
		if ( ! function_exists( 'is_plugin_active_for_network' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return is_plugin_active_for_network( plugin_basename( FLSEO_FILE ) );
	}

	/**
	 * Set up tables and defaults on a new site when network-activated.
	 *
	 * @param \WP_Site $site New site.
	 */
	public function initialize_site( \WP_Site $site ): void {
		if ( ! self::is_network_active() ) {
			return;
		}
		switch_to_blog( (int) $site->blog_id );
		Plugin::activate_site();
		restore_current_blog();
	}

	/**
	 * Drop a deleted site's FutureLabs AI SEO tables.
	 *
	 * @param array<int, string> $tables  Tables WordPress will drop.
	 * @param int                $site_id Site being deleted.
	 * @return array<int, string>
	 */
	public function drop_tables( array $tables, int $site_id ): array {
		global $wpdb;
		$prefix = $wpdb->get_blog_prefix( $site_id );
		foreach ( Migrations::TABLES as $suffix ) {
			$tables[] = $prefix . 'flseo_' . $suffix;
		}
		return $tables;
	}

	/**
	 * Network admin page.
	 */
	public function menu(): void {
		add_menu_page(
			__( 'FutureLabs AI SEO network overview', 'futurelabs-ai-seo' ),
			__( 'FutureLabs AI SEO', 'futurelabs-ai-seo' ),
			'manage_network_options',
			'flseo-network',
			array( $this, 'render' ),
			'dashicons-search',
			58
		);
	}

	/**
	 * Per-site summary rows.
	 *
	 * @param int $limit Max sites.
	 * @return array<int, array<string, mixed>>
	 */
	public function overview( int $limit = 200 ): array {
		global $wpdb;
		$rows = array();
		foreach ( get_sites(
			array(
				'number'   => $limit,
				'deleted'  => 0,
				'archived' => 0,
			)
		) as $site ) {
			switch_to_blog( (int) $site->blog_id );
			$installed = (int) get_option( Migrations::OPTION, 0 ) > 0;
			$row       = array(
				'id'        => (int) $site->blog_id,
				'name'      => get_bloginfo( 'name' ),
				'url'       => home_url( '/' ),
				'admin'     => admin_url( 'admin.php?page=futurelabs-ai-seo' ),
				'installed' => $installed,
				'published' => 0,
				'noindex'   => 0,
				'indexed'   => 0,
				'inspected' => 0,
				'flagged'   => 0,
				'redirects' => 0,
				'not_found' => 0,
				'public'    => '0' !== (string) get_option( 'blog_public' ),
			);
			if ( $installed ) {
				// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$row['published'] = (int) $wpdb->get_var( "SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ('post','page')" );
				$row['noindex']   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key=%s AND meta_value='1'", '_flseo_noindex' ) );
				$status           = Migrations::table( 'index_status' );
				$row['inspected'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$status}" );
				$row['indexed']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$status} WHERE verdict='PASS'" );
				$scan             = Migrations::table( 'content_scan' );
				$row['flagged']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$scan} WHERE recommendation <> 'ok'" );
				$redirects        = Migrations::table( 'redirects' );
				$log              = Migrations::table( 'log_404' );
				$row['redirects'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$redirects}" );
				$row['not_found'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$log} WHERE ignored=0" );
				// phpcs:enable
			}
			restore_current_blog();
			$rows[] = $row;
		}
		return $rows;
	}

	/**
	 * Render the overview.
	 */
	public function render(): void {
		if ( ! current_user_can( 'manage_network_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to view this page.', 'futurelabs-ai-seo' ), 403 );
		}
		echo '<div class="wrap"><h1>' . esc_html__( 'FutureLabs AI SEO network overview', 'futurelabs-ai-seo' ) . '</h1>';
		echo '<p>' . esc_html__( 'Each site keeps its own FutureLabs AI SEO settings, Search Console connection and data. Indexed counts only include URLs inspected through Search Console.', 'futurelabs-ai-seo' ) . '</p>';
		echo '<table class="widefat striped"><thead><tr>';
		$headers = array( __( 'Site', 'futurelabs-ai-seo' ), __( 'Published', 'futurelabs-ai-seo' ), __( 'Noindex', 'futurelabs-ai-seo' ), __( 'Indexed / inspected', 'futurelabs-ai-seo' ), __( 'Content findings', 'futurelabs-ai-seo' ), __( 'Redirects', 'futurelabs-ai-seo' ), __( 'Open 404s', 'futurelabs-ai-seo' ), __( 'Status', 'futurelabs-ai-seo' ) );
		foreach ( $headers as $header ) {
			echo '<th scope="col">' . esc_html( $header ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $this->overview() as $row ) {
			$status = ! $row['installed'] ? __( 'Not activated', 'futurelabs-ai-seo' ) : ( $row['public'] ? __( 'Active', 'futurelabs-ai-seo' ) : __( 'Search engines discouraged', 'futurelabs-ai-seo' ) );
			printf(
				'<tr><td><a href="%1$s"><strong>%2$s</strong></a><br /><span class="description">%3$s</span></td><td>%4$s</td><td>%5$s</td><td>%6$s / %7$s</td><td>%8$s</td><td>%9$s</td><td>%10$s</td><td>%11$s</td></tr>',
				esc_url( (string) $row['admin'] ),
				esc_html( (string) $row['name'] ),
				esc_html( (string) $row['url'] ),
				esc_html( number_format_i18n( (int) $row['published'] ) ),
				esc_html( number_format_i18n( (int) $row['noindex'] ) ),
				esc_html( number_format_i18n( (int) $row['indexed'] ) ),
				esc_html( number_format_i18n( (int) $row['inspected'] ) ),
				esc_html( number_format_i18n( (int) $row['flagged'] ) ),
				esc_html( number_format_i18n( (int) $row['redirects'] ) ),
				esc_html( number_format_i18n( (int) $row['not_found'] ) ),
				esc_html( $status )
			);
		}
		echo '</tbody></table></div>';
	}
}
