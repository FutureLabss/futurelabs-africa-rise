<?php
/**
 * "Fix this first": groups non-indexed pages by reason, template and post type.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Indexing;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Sitemap\Builder;

defined( 'ABSPATH' ) || exit;

/**
 * Orders problem groups by the number of affected pages so one fix covers the most URLs.
 */
class Prioritizer {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Problem groups.
	 *
	 * @param int $limit   Max groups.
	 * @param int $samples Sample URLs per group.
	 * @return array<int, array<string, mixed>>
	 */
	public function groups( int $limit = 20, int $samples = 5 ): array {
		global $wpdb;
		$types = $this->c->get( Builder::class )->post_types();
		if ( ! $types ) {
			return array();
		}
		$skip = array();
		foreach ( Reasons::all() as $code => $info ) {
			if ( ! $info['actionable'] ) {
				$skip[] = $code;
			}
		}
		$s    = Migrations::table( 'index_status' );
		$cs   = Migrations::table( 'content_scan' );
		$tin  = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$sin  = implode( ',', array_fill( 0, count( $skip ), '%s' ) );
		$sig  = "COALESCE(NULLIF(cs.template_sig,''),'none')";
		$base = "FROM {$s} s INNER JOIN {$wpdb->posts} p ON p.ID=s.post_id LEFT JOIN {$cs} cs ON cs.post_id=p.ID
			WHERE p.post_status='publish' AND p.post_password='' AND p.post_type IN ($tin) AND s.inspected_at IS NOT NULL AND s.reason_code<>'' AND s.reason_code NOT IN ($sin)";
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$groups = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT s.reason_code, {$sig} tpl, p.post_type, COUNT(*) n {$base}
				GROUP BY s.reason_code, tpl, p.post_type ORDER BY n DESC, s.reason_code ASC LIMIT %d",
				array_merge( $types, $skip, array( max( 1, $limit ) ) )
			),
			ARRAY_A
		);
		$out    = array();
		foreach ( $groups as $group ) {
			$rows   = (array) $wpdb->get_results(
				$wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- Placeholders are built dynamically above.
					"SELECT p.ID, p.post_title, s.url {$base} AND s.reason_code=%s AND {$sig}=%s AND p.post_type=%s ORDER BY s.priority DESC, p.post_modified_gmt DESC LIMIT %d",
					array_merge( $types, $skip, array( $group['reason_code'], $group['tpl'], $group['post_type'], max( 1, $samples ) ) )
				),
				ARRAY_A
			);
			$object = get_post_type_object( (string) $group['post_type'] );
			$out[]  = array(
				'reason_code'     => (string) $group['reason_code'],
				'reason_label'    => Reasons::label( (string) $group['reason_code'] ),
				'fix'             => Reasons::fix( (string) $group['reason_code'] ),
				'template_sig'    => (string) $group['tpl'],
				'post_type'       => (string) $group['post_type'],
				'post_type_label' => $object ? (string) $object->labels->name : (string) $group['post_type'],
				'count'           => (int) $group['n'],
				'samples'         => array_map(
					static function ( array $row ): array {
						return array(
							'id'    => (int) $row['ID'],
							'title' => html_entity_decode( (string) $row['post_title'], ENT_QUOTES, 'UTF-8' ),
							'url'   => (string) $row['url'],
						);
					},
					$rows
				),
			);
		}
		// phpcs:enable
		return $out;
	}
}
