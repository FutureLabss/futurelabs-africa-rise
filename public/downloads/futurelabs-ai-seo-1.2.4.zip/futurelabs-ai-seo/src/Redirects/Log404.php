<?php
/**
 * 404 log: deduplicated by URL hash, filters bot and static-asset noise, purges old rows.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Redirects;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Records 404 hits and serves list/ignore operations.
 */
class Log404 implements Module {

	/**
	 * Most rows kept in the 404 log.
	 */
	public const MAX_ROWS = 50000;

	/**
	 * New URLs are followed by a size check roughly once in this many inserts.
	 */
	public const CHECK_EVERY = 50;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'template_redirect', array( $this, 'maybe_log' ), 99 );
		add_action( 'flseo_daily', array( $this, 'purge' ) );
	}

	/**
	 * Table name.
	 */
	public static function table(): string {
		return Migrations::table( 'log_404' );
	}

	/**
	 * Log the current request when it is a 404.
	 */
	public function maybe_log(): void {
		if ( ! is_404() || Router::$gone || is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		$settings = $this->c->get( Settings::class );
		if ( ! $settings->get( 'log_404' ) ) {
			return;
		}
		$path     = Router::request_path();
		$agent    = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		$referrer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
		$class    = self::classify_agent( $agent );
		if ( $settings->get( 'ignore_404_noise' ) && self::is_noise( $path, $class ) ) {
			return;
		}
		$this->record( $path, $referrer, $class );
	}

	/**
	 * Insert or increment a 404 row.
	 *
	 * @param string $path     Request path.
	 * @param string $referrer Referrer URL.
	 * @param string $class    User agent class.
	 */
	public function record( string $path, string $referrer = '', string $class = 'unknown' ): void {
		global $wpdb;
		$table = self::table();
		$path  = Rules::normalize_path( $path );
		$now   = current_time( 'mysql', true );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$affected = $wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$table} (url_hash, url, hits, referrer, user_agent_class, first_seen, last_seen, ignored) VALUES (%s, %s, 1, %s, %s, %s, %s, 0)
				ON DUPLICATE KEY UPDATE hits = hits + 1, last_seen = VALUES(last_seen), referrer = IF(VALUES(referrer) = '', referrer, VALUES(referrer)), user_agent_class = VALUES(user_agent_class)",
				hash( 'sha256', $path ),
				substr( home_url( $path ), 0, 2048 ),
				substr( $referrer, 0, 2048 ),
				$class,
				$now,
				$now
			)
		);
		// phpcs:enable
		// MySQL reports 1 affected row for a new URL and 2 for an increment.
		if ( 1 === $affected && 1 === wp_rand( 1, self::CHECK_EVERY ) ) {
			$this->enforce_cap();
		}
	}

	/**
	 * Keep the log under a row cap by deleting the least-hit, oldest rows.
	 *
	 * @param int $max Row cap.
	 * @return int Deleted rows.
	 */
	public function enforce_cap( int $max = self::MAX_ROWS ): int {
		global $wpdb;
		$table = self::table();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$excess = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) - max( 0, $max );
		if ( $excess <= 0 ) {
			return 0;
		}
		$deleted = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} ORDER BY hits ASC, last_seen ASC, id ASC LIMIT %d", $excess ) );
		// phpcs:enable
		return $deleted;
	}

	/**
	 * Classify a user agent.
	 *
	 * @param string $agent User agent.
	 */
	public static function classify_agent( string $agent ): string {
		if ( '' === trim( $agent ) ) {
			return 'empty';
		}
		if ( preg_match( '/googlebot|bingbot|duckduckbot|yandex|baiduspider|applebot|slurp/i', $agent ) ) {
			return 'search_bot';
		}
		if ( preg_match( '/bot|crawl|spider|scan|curl|wget|python|go-http|java\/|httpclient|ahrefs|semrush|mj12|dotbot|petalbot|bytespider/i', $agent ) ) {
			return 'bot';
		}
		return 'browser';
	}

	/**
	 * Whether a hit is noise: static assets, probes for common exploits, or non-search bots.
	 *
	 * @param string $path  Path.
	 * @param string $class Agent class.
	 */
	public static function is_noise( string $path, string $class ): bool {
		if ( in_array( $class, array( 'bot', 'empty' ), true ) ) {
			return true;
		}
		if ( preg_match( '~\.(?:js|css|map|png|jpe?g|gif|webp|avif|svg|ico|woff2?|ttf|eot|otf|mp4|webm|mp3|zip|gz|txt|xml\.gz)$~i', $path ) ) {
			return true;
		}
		return (bool) preg_match( '~(?:^/(?:wp-login|xmlrpc|wp-admin|cgi-bin|phpmyadmin|vendor/|\.git|\.env|\.well-known/(?!security\.txt))|wp-config|\.php$|/(?:admin|backup|old|test)\.(?:zip|sql|tar))~i', $path );
	}

	/**
	 * Paginated list of 404 rows with suggestions.
	 *
	 * @param array<string, mixed> $args page, per_page, ignored, search.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function list( array $args = array() ): array {
		global $wpdb;
		$table    = self::table();
		$per_page = min( 200, max( 1, (int) ( $args['per_page'] ?? 50 ) ) );
		$offset   = ( max( 1, (int) ( $args['page'] ?? 1 ) ) - 1 ) * $per_page;
		$ignored  = ! empty( $args['ignored'] ) ? 1 : 0;
		$where    = 'ignored = %d';
		$params   = array( $ignored );
		if ( ! empty( $args['search'] ) ) {
			$where   .= ' AND url LIKE %s';
			$params[] = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
		}
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where}", $params ) );
		$rows  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, url, hits, referrer, user_agent_class, first_seen, last_seen, ignored FROM {$table} WHERE {$where} ORDER BY hits DESC, last_seen DESC LIMIT %d OFFSET %d", array_merge( $params, array( $per_page, $offset ) ) ), ARRAY_A );
		// phpcs:enable
		$suggester = $this->c->get( Suggester::class );
		foreach ( $rows as &$row ) {
			$row['suggestions'] = ! empty( $args['suggest'] ) ? $suggester->suggest( (string) $row['url'], 3 ) : array();
		}
		return array(
			'items' => $rows,
			'total' => $total,
		);
	}

	/**
	 * Get one row.
	 *
	 * @param int $id Row id.
	 * @return array<string, mixed>|null
	 */
	public function get( int $id ): ?array {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d", $id ), ARRAY_A );
		return $row ?: null;
	}

	/**
	 * Mark a row ignored or not.
	 *
	 * @param int  $id      Row id.
	 * @param bool $ignored Ignored flag.
	 */
	public function set_ignored( int $id, bool $ignored ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return false !== $wpdb->update( self::table(), array( 'ignored' => $ignored ? 1 : 0 ), array( 'id' => $id ), array( '%d' ), array( '%d' ) );
	}

	/**
	 * Delete a row (e.g. once redirected).
	 *
	 * @param int $id Row id.
	 */
	public function delete( int $id ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return (bool) $wpdb->delete( self::table(), array( 'id' => $id ), array( '%d' ) );
	}

	/**
	 * Remove rows older than the retention period, then apply the row cap.
	 */
	public function purge(): int {
		global $wpdb;
		$days  = (int) $this->c->get( Settings::class )->get( 'retention_404_days', 90 );
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$deleted = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE last_seen < %s", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
		return $deleted + $this->enforce_cap();
	}
}
