<?php
/**
 * Header element: light/dark mode toggle.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<button type="button" class="nt-icon-btn nt-mode-toggle" data-nt-mode-toggle aria-pressed="false" aria-label="<?php esc_attr_e( 'Dark mode', 'newstheme' ); ?>">
	<?php newstheme_icon( 'moon', 'nt-mode-toggle__moon' ); ?>
	<?php newstheme_icon( 'sun', 'nt-mode-toggle__sun' ); ?>
</button>
