<?php
/**
 * Footer element: widget area "Footer - Column 3".
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

echo '<div class="nt-footer__widgets">';
dynamic_sidebar( 'footer-3' );
echo '</div>';
