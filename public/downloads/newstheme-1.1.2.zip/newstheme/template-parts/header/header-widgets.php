<?php
/**
 * Header element: the "Header Builder - Widget Area" widget area.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

echo '<div class="nt-header-widgets">';
dynamic_sidebar( 'header-builder' );
echo '</div>';
