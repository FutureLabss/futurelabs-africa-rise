<?php
/**
 * GET/POST /schema/{post_id}.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Bulk\AuditLog;
use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Meta\Context;
use FutureLabs\AISEO\Schema\Graph;
use FutureLabs\AISEO\Schema\Overrides;
use FutureLabs\AISEO\Schema\Types;

defined( 'ABSPATH' ) || exit;

/**
 * Per-post schema type, JSON overrides, generated preview and validation problems.
 */
class SchemaController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/schema/(?P<post_id>\d+)', 'GET', array( $this, 'show' ), Capabilities::EDITOR );
		$this->route( '/schema/(?P<post_id>\d+)', 'POST', array( $this, 'save' ), Capabilities::EDITOR );
	}

	/**
	 * Resolve and authorize the post.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_Post|\WP_Error
	 */
	private function post( \WP_REST_Request $request ) {
		$post = get_post( absint( $request['post_id'] ) );
		if ( ! $post instanceof \WP_Post || ! current_user_can( 'edit_post', $post->ID ) ) {
			return $this->error( 'not_found', __( 'Post not found.', 'futurelabs-ai-seo' ), 404 );
		}
		return $post;
	}

	/**
	 * Current schema settings and a generated preview.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function show( \WP_REST_Request $request ) {
		$post = $this->post( $request );
		return is_wp_error( $post ) ? $post : rest_ensure_response( $this->payload( $post ) );
	}

	/**
	 * Save schema type and overrides. Malformed override JSON is rejected with 400.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function save( \WP_REST_Request $request ) {
		$post = $this->post( $request );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$body    = $this->body( $request );
		$updates = array();
		if ( array_key_exists( 'schema_type', $body ) ) {
			$type = (string) $body['schema_type'];
			if ( '' !== $type && ! in_array( $type, Types::selectable(), true ) ) {
				return $this->error( 'schema_type', __( 'Choose one of the listed schema types.', 'futurelabs-ai-seo' ), 400, array( 'types' => Types::selectable() ) );
			}
			$updates['_flseo_schema_type'] = $type;
		}
		if ( array_key_exists( 'overrides', $body ) ) {
			$raw = $body['overrides'];
			if ( is_array( $raw ) ) {
				$raw = (string) wp_json_encode( $raw );
			} elseif ( ! is_string( $raw ) && null !== $raw ) {
				return $this->error( 'schema_overrides', __( 'Schema overrides must be valid JSON.', 'futurelabs-ai-seo' ) );
			}
			$parsed = Overrides::parse( (string) $raw );
			if ( ! $parsed['valid'] ) {
				return $this->error( 'schema_overrides', $parsed['error'] );
			}
			$updates['_flseo_schema_overrides'] = Overrides::sanitize( (string) $raw );
		}
		$audit = $this->c->get( AuditLog::class );
		$batch = null;
		foreach ( $updates as $key => $value ) {
			$old = (string) get_post_meta( $post->ID, $key, true );
			if ( $old === $value ) {
				continue;
			}
			$batch = $audit->record_single( 'schema_update', $post->ID, $key, $old, $value, $batch );
			if ( '' === $value ) {
				delete_post_meta( $post->ID, $key );
			} else {
				update_post_meta( $post->ID, $key, $value );
			}
		}
		return rest_ensure_response(
			array_merge(
				array(
					'saved'    => true,
					'batch_id' => $batch,
				),
				$this->payload( $post )
			)
		);
	}

	/**
	 * Response payload.
	 *
	 * @param \WP_Post $post Post.
	 * @return array<string, mixed>
	 */
	private function payload( \WP_Post $post ): array {
		$graph    = $this->c->get( Graph::class );
		$doc      = $graph->build( new Context( 'singular', $post ) );
		$problems = array();
		foreach ( (array) ( $doc['@graph'] ?? array() ) as $node ) {
			$issues = is_array( $node ) ? Types::validate( $node ) : array( __( 'Invalid node', 'futurelabs-ai-seo' ) );
			if ( $issues ) {
				$problems[] = array(
					'@id'      => is_array( $node ) ? (string) ( $node['@id'] ?? '' ) : '',
					'@type'    => is_array( $node ) && is_string( $node['@type'] ?? null ) ? $node['@type'] : '',
					'problems' => $issues,
				);
			}
		}
		return array(
			'post_id'      => $post->ID,
			'schema_type'  => (string) get_post_meta( $post->ID, '_flseo_schema_type', true ),
			'default_type' => (string) $this->c->get( Settings::class )->post_type( $post->post_type )['schema'],
			'effective'    => $graph->main_type( $post ),
			'types'        => Types::selectable(),
			'overrides'    => (string) get_post_meta( $post->ID, '_flseo_schema_overrides', true ),
			'enabled'      => (bool) $this->c->get( Settings::class )->get( 'output_schema' ),
			'graph'        => $doc,
			'problems'     => $problems,
		);
	}
}
