<?php
/**
 * GET /audit · GET /audit/{batch}.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Bulk\AuditLog;
use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Migrations;

defined( 'ABSPATH' ) || exit;

/**
 * Audit log browsing (administrators).
 */
class AuditController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/audit', 'GET', array( $this, 'index' ), Capabilities::DATA );
		$this->route( '/audit/(?P<batch>[a-f0-9-]{36})', 'GET', array( $this, 'batch' ), Capabilities::DATA );
	}

	/**
	 * Batches, newest first.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function index( \WP_REST_Request $request ): \WP_REST_Response {
		list( $page, $per_page ) = $this->paging( $request, 100 );
		$result                  = $this->c->get( AuditLog::class )->batches( $page, $per_page );
		$response                = rest_ensure_response( $result );
		$response->header( 'X-WP-Total', (string) $result['total'] );
		return $response;
	}

	/**
	 * Rows of one batch, including undone rows.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function batch( \WP_REST_Request $request ) {
		global $wpdb;
		$batch = (string) $request['batch'];
		$table = Migrations::table( 'audit_log' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE batch_id=%s ORDER BY id ASC LIMIT 2000", $batch ), ARRAY_A );
		if ( ! $rows ) {
			return $this->error( 'not_found', __( 'Batch not found.', 'futurelabs-ai-seo' ), 404 );
		}
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - AuditLog::RETENTION_DAYS * DAY_IN_SECONDS );
		$items  = array();
		foreach ( $rows as $row ) {
			$old     = json_decode( (string) $row['old_value'], true );
			$new     = json_decode( (string) $row['new_value'], true );
			$user    = get_userdata( (int) $row['user_id'] );
			$items[] = array(
				'id'          => (int) $row['id'],
				'action'      => $row['action'],
				'object_type' => $row['object_type'],
				'object_id'   => (int) $row['object_id'],
				'label'       => $this->label( (string) $row['object_type'], (int) $row['object_id'], is_array( $old ) ? $old : array(), is_array( $new ) ? $new : array() ),
				'old'         => $old,
				'new'         => $new,
				'user'        => $user ? $user->display_name : '',
				'undone'      => (bool) $row['undone'],
				'undoable'    => ! $row['undone'] && $row['created_at'] >= $cutoff,
				'created_at'  => $row['created_at'],
			);
		}
		return rest_ensure_response(
			array(
				'batch_id' => $batch,
				'items'    => $items,
				'total'    => count( $items ),
			)
		);
	}

	/**
	 * Human label for an object.
	 *
	 * @param string               $type Object type.
	 * @param int                  $id   Object id.
	 * @param array<string, mixed> $old  Old state.
	 * @param array<string, mixed> $after New state.
	 */
	private function label( string $type, int $id, array $old, array $after ): string {
		switch ( $type ) {
			case 'post':
			case 'attachment':
				$post = get_post( $id );
				return $post ? wp_strip_all_tags( get_the_title( $post ) ) : '';
			case 'term':
				$term = get_term( $id );
				return $term instanceof \WP_Term ? $term->name : '';
			case 'redirect':
				$row = is_array( $after['row'] ?? null ) ? $after['row'] : ( $old['row'] ?? array() );
				return is_array( $row ) ? (string) ( $row['source'] ?? '' ) : '';
			case 'settings':
				return __( 'Settings', 'futurelabs-ai-seo' );
		}
		return '';
	}
}
