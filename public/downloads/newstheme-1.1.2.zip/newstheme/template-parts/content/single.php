<?php
/**
 * Single post article.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'nt-card-box nt-single' ); ?>>
	<header class="nt-single__header">
		<?php newstheme_post_categories( null, 3 ); ?>
		<?php the_title( '<h1 class="nt-single__title">', '</h1>' ); ?>
		<?php newstheme_single_meta(); ?>
	</header>

	<?php if ( newstheme_get_mod( 'single_image' ) && has_post_thumbnail() ) : ?>
		<figure class="nt-single__image">
			<?php
			the_post_thumbnail(
				'newstheme-large',
				array(
					'alt'           => newstheme_thumbnail_alt(),
					'loading'       => 'eager',
					'fetchpriority' => 'high',
				)
			);
			?>
			<?php echo newstheme_deadline_badge(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in newstheme_deadline_badge(). ?>
			<?php if ( get_the_post_thumbnail_caption() ) : ?>
				<figcaption><?php the_post_thumbnail_caption(); ?></figcaption>
			<?php endif; ?>
		</figure>
	<?php endif; ?>

	<div class="nt-entry-content">
		<?php
		the_content();
		wp_link_pages(
			array(
				'before' => '<nav class="nt-page-links" aria-label="' . esc_attr__( 'Post pages', 'newstheme' ) . '">' . esc_html__( 'Pages:', 'newstheme' ),
				'after'  => '</nav>',
			)
		);
		?>
	</div>

	<?php if ( newstheme_get_mod( 'single_tags' ) && has_tag() ) : ?>
		<div class="nt-single__tags">
			<?php newstheme_icon( 'tag' ); ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Tags:', 'newstheme' ); ?></span>
			<?php the_tags( '<ul class="nt-tag-list"><li>', '</li><li>', '</li></ul>' ); ?>
		</div>
	<?php endif; ?>

	<?php
	if ( newstheme_get_mod( 'single_share' ) ) {
		newstheme_share_links();
	}

	if ( newstheme_get_mod( 'single_author_box' ) ) {
		get_template_part( 'template-parts/content/author-box' );
	}

	if ( newstheme_get_mod( 'single_post_nav' ) ) {
		the_post_navigation(
			array(
				'class'     => 'nt-post-nav',
				'prev_text' => '<span class="nt-post-nav__label">' . newstheme_get_icon( 'chevrons-left' ) . esc_html__( 'Previous', 'newstheme' ) . '</span><span class="nt-post-nav__title">%title</span>',
				'next_text' => '<span class="nt-post-nav__label">' . esc_html__( 'Next', 'newstheme' ) . newstheme_get_icon( 'chevrons-right' ) . '</span><span class="nt-post-nav__title">%title</span>',
			)
		);
	}
	?>
</article>
