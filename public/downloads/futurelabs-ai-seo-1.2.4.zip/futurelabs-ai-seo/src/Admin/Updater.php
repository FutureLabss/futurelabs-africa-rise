<?php
/**
 * Updates from futurelabs.africa while the plugin isn't distributed through WordPress.org.
 *
 * Reads a release manifest published with each release (bin/publish-site.sh) and feeds it
 * to WordPress's own update system, so sites see the usual "new version available" notice
 * and one-click update. Remove this module from the free plugin before submitting it to
 * WordPress.org (directory rules forbid self-updating); keep it in the Pro add-on.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Admin;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * WordPress update integration for the self-hosted release channel.
 */
class Updater implements Module {

	public const MANIFEST_URL = 'https://futurelabs.africa/downloads/futurelabs-ai-seo.json';
	public const SLUG         = 'futurelabs-ai-seo';
	public const CACHE_KEY    = 'flseo_update_manifest';

	/**
	 * Only packages from these hosts are offered for install.
	 */
	private const ALLOWED_HOSTS = array( 'futurelabs.africa', 'www.futurelabs.africa' );

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		if ( defined( 'FLSEO_DISABLE_UPDATER' ) && FLSEO_DISABLE_UPDATER ) {
			return;
		}
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update' ) );
		add_filter( 'plugins_api', array( $this, 'plugin_info' ), 10, 3 );
		add_action( 'upgrader_process_complete', array( $this, 'clear_cache' ), 10, 0 );
	}

	/**
	 * Plugin basename, e.g. futurelabs-ai-seo/futurelabs-ai-seo.php.
	 */
	public function basename(): string {
		return plugin_basename( FLSEO_FILE );
	}

	/**
	 * Release manifest, cached for 12 hours (1 hour after a failed fetch).
	 *
	 * @param bool $force Skip the cache.
	 * @return array<string, mixed>|null
	 */
	public function manifest( bool $force = false ): ?array {
		$cached = get_site_transient( self::CACHE_KEY );
		if ( ! $force && is_array( $cached ) ) {
			return $cached['manifest'] ?? null;
		}
		/**
		 * Address of the release manifest.
		 *
		 * @param string $url Manifest URL.
		 */
		$url      = (string) apply_filters( 'flseo_update_manifest_url', self::MANIFEST_URL );
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 10,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);
		$manifest = null;
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$manifest = $this->validate( json_decode( (string) wp_remote_retrieve_body( $response ), true ) );
		}
		set_site_transient( self::CACHE_KEY, array( 'manifest' => $manifest ), $manifest ? 12 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
		return $manifest;
	}

	/**
	 * Accept only a well-formed manifest whose package is an https URL on an allowed host.
	 *
	 * @param mixed $data Decoded JSON.
	 * @return array<string, mixed>|null
	 */
	public function validate( $data ): ?array {
		if ( ! is_array( $data ) || self::SLUG !== ( $data['slug'] ?? '' ) ) {
			return null;
		}
		$version = (string) ( $data['version'] ?? '' );
		$package = (string) ( $data['download_url'] ?? '' );
		if ( ! preg_match( '/^\d+\.\d+(\.\d+)?$/', $version ) ) {
			return null;
		}
		$parts = wp_parse_url( $package );
		if ( ! is_array( $parts ) || 'https' !== ( $parts['scheme'] ?? '' ) || ! in_array( strtolower( (string) ( $parts['host'] ?? '' ) ), self::ALLOWED_HOSTS, true ) ) {
			return null;
		}
		return $data;
	}

	/**
	 * Add our release to WordPress's update list when it's newer than the installed version.
	 *
	 * @param mixed $transient The update_plugins transient.
	 * @return mixed
	 */
	public function inject_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$manifest = $this->manifest();
		if ( ! $manifest ) {
			return $transient;
		}
		$item = (object) array(
			'id'           => self::SLUG,
			'slug'         => self::SLUG,
			'plugin'       => $this->basename(),
			'new_version'  => (string) $manifest['version'],
			'url'          => (string) ( $manifest['homepage'] ?? 'https://futurelabs.africa/studio' ),
			'package'      => (string) $manifest['download_url'],
			'requires'     => (string) ( $manifest['requires'] ?? '' ),
			'requires_php' => (string) ( $manifest['requires_php'] ?? '' ),
			'tested'       => (string) ( $manifest['tested'] ?? '' ),
			'icons'        => array(),
		);
		if ( version_compare( (string) $manifest['version'], FLSEO_VERSION, '>' ) ) {
			$transient->response                      = is_array( $transient->response ?? null ) ? $transient->response : array();
			$transient->response[ $this->basename() ] = $item;
		} else {
			$transient->no_update                      = is_array( $transient->no_update ?? null ) ? $transient->no_update : array();
			$transient->no_update[ $this->basename() ] = $item;
		}
		return $transient;
	}

	/**
	 * Details for the "View version x details" window.
	 *
	 * @param mixed  $result Default result.
	 * @param string $action plugins_api action.
	 * @param object $args   Request arguments.
	 * @return mixed
	 */
	public function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! is_object( $args ) || self::SLUG !== ( $args->slug ?? '' ) ) {
			return $result;
		}
		$manifest = $this->manifest();
		if ( ! $manifest ) {
			return $result;
		}
		$sections = array();
		foreach ( (array) ( $manifest['sections'] ?? array() ) as $name => $html ) {
			$sections[ sanitize_key( (string) $name ) ] = wp_kses_post( (string) $html );
		}
		return (object) array(
			'name'          => (string) ( $manifest['name'] ?? 'FutureLabs AI SEO' ),
			'slug'          => self::SLUG,
			'version'       => (string) $manifest['version'],
			'author'        => '<a href="https://futurelabs.africa">FutureLabs</a>',
			'homepage'      => (string) ( $manifest['homepage'] ?? 'https://futurelabs.africa/studio' ),
			'download_link' => (string) $manifest['download_url'],
			'requires'      => (string) ( $manifest['requires'] ?? '' ),
			'requires_php'  => (string) ( $manifest['requires_php'] ?? '' ),
			'tested'        => (string) ( $manifest['tested'] ?? '' ),
			'last_updated'  => (string) ( $manifest['last_updated'] ?? '' ),
			'sections'      => $sections,
		);
	}

	/**
	 * Forget the cached manifest after an update.
	 */
	public function clear_cache(): void {
		delete_site_transient( self::CACHE_KEY );
	}
}
