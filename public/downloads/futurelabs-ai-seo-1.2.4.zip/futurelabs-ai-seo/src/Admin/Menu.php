<?php
/**
 * Admin menu and React app shell.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Admin;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the FutureLabs AI SEO menu. Screens are client-side routes (#/route) of one React app.
 */
class Menu implements Module {

	public const SLUG = 'futurelabs-ai-seo';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Screens: route => label.
	 *
	 * @return array<string, string>
	 */
	public static function screens(): array {
		return array(
			'dashboard'     => __( 'Dashboard', 'futurelabs-ai-seo' ),
			'indexing'      => __( 'Indexing', 'futurelabs-ai-seo' ),
			'content'       => __( 'Content', 'futurelabs-ai-seo' ),
			'opportunities' => __( 'Opportunities', 'futurelabs-ai-seo' ),
			'links'         => __( 'Links', 'futurelabs-ai-seo' ),
			'redirects'     => __( 'Redirects & 404s', 'futurelabs-ai-seo' ),
			'sitemap'       => __( 'Sitemap', 'futurelabs-ai-seo' ),
			'images'        => __( 'Images', 'futurelabs-ai-seo' ),
			'reports'       => __( 'Reports', 'futurelabs-ai-seo' ),
			'audit'         => __( 'Change log', 'futurelabs-ai-seo' ),
			'import'        => __( 'Import & export', 'futurelabs-ai-seo' ),
			'settings'      => __( 'Settings', 'futurelabs-ai-seo' ),
		);
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( FLSEO_FILE ), array( $this, 'action_links' ) );
	}

	/**
	 * Add the menu and submenu entries.
	 */
	public function menu(): void {
		$cap = Capabilities::cap( Capabilities::DATA );
		add_menu_page(
			__( 'FutureLabs AI SEO', 'futurelabs-ai-seo' ),
			__( 'FutureLabs AI SEO', 'futurelabs-ai-seo' ),
			$cap,
			self::SLUG,
			array( $this, 'render' ),
			'dashicons-search',
			58
		);
		foreach ( self::screens() as $route => $label ) {
			add_submenu_page(
				self::SLUG,
				$label . ' ‹ FutureLabs AI SEO',
				$label,
				$cap,
				'dashboard' === $route ? self::SLUG : self::SLUG . '#/' . $route,
				'dashboard' === $route ? array( $this, 'render' ) : '__return_null'
			);
		}
	}

	/**
	 * Plugins screen links.
	 *
	 * @param array<int|string, string> $links Links.
	 * @return array<int|string, string>
	 */
	public function action_links( array $links ): array {
		array_unshift( $links, sprintf( '<a href="%s">%s</a>', esc_url( admin_url( 'admin.php?page=' . self::SLUG . '#/settings' ) ), esc_html__( 'Settings', 'futurelabs-ai-seo' ) ) );
		return $links;
	}

	/**
	 * App root.
	 */
	public function render(): void {
		if ( ! Capabilities::can( Capabilities::DATA ) ) {
			wp_die( esc_html__( 'You are not allowed to view FutureLabs AI SEO.', 'futurelabs-ai-seo' ), 403 );
		}
		echo '<div class="wrap flseo-wrap"><div id="flseo-admin" class="flseo-admin">';
		if ( ! file_exists( FLSEO_DIR . 'build/admin/index.js' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'The FutureLabs AI SEO admin interface has not been built. Install the release zip, or run npm run build.', 'futurelabs-ai-seo' ) . '</p></div>';
		} else {
			echo '<p class="flseo-loading">' . esc_html__( 'Loading FutureLabs AI SEO…', 'futurelabs-ai-seo' ) . '</p>';
		}
		echo '<noscript>' . esc_html__( 'FutureLabs AI SEO needs JavaScript enabled in your browser.', 'futurelabs-ai-seo' ) . '</noscript></div></div>';
	}

	/**
	 * Enqueue the admin app on FutureLabs AI SEO screens.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function assets( string $hook ): void {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}
		$asset_file = FLSEO_DIR . 'build/admin/index.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;
		wp_enqueue_script( 'flseo-admin', FLSEO_URL . 'build/admin/index.js', $asset['dependencies'], $asset['version'], true );
		wp_set_script_translations( 'flseo-admin', 'futurelabs-ai-seo', FLSEO_DIR . 'languages' );
		wp_enqueue_style( 'wp-components' );
		if ( file_exists( FLSEO_DIR . 'build/admin/index.css' ) ) {
			wp_enqueue_style( 'flseo-admin', FLSEO_URL . 'build/admin/index.css', array( 'wp-components' ), $asset['version'] );
		}
		wp_add_inline_script( 'flseo-admin', 'window.flseo = ' . wp_json_encode( $this->boot_data() ) . ';', 'before' );
	}

	/**
	 * Data the app needs before its first REST call.
	 *
	 * @return array<string, mixed>
	 */
	public function boot_data(): array {
		$settings = $this->c->get( Settings::class );
		return array(
			'version'     => FLSEO_VERSION,
			'restRoot'    => esc_url_raw( rest_url( 'flseo/v1/' ) ),
			'nonce'       => wp_create_nonce( 'wp_rest' ),
			'siteUrl'     => home_url( '/' ),
			'adminUrl'    => admin_url(),
			'sitemapUrl'  => \FutureLabs\AISEO\Sitemap\Router::index_url(),
			'screens'     => self::screens(),
			'onboarded'   => (bool) $settings->get( 'onboarding_complete' ),
			'gscCallback' => admin_url( 'admin-post.php?action=flseo_gsc_callback' ),
			'caps'        => array(
				'settings'        => Capabilities::can( Capabilities::SETTINGS ),
				'activatePlugins' => current_user_can( 'activate_plugins' ),
			),
			'aiModels'    => array( 'claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-5-5' ),
			'schemaTypes' => \FutureLabs\AISEO\Schema\Types::selectable(),
			'roles'       => array_map( 'translate_user_role', wp_roles()->get_names() ),
			'access'      => array(
				'defaults'       => Capabilities::default_roles(),
				'alwaysSettings' => Capabilities::roles_with( 'manage_options' ),
			),
			'helpUrl'     => 'https://opportunitylab.net/',
		);
	}
}
