<?php
/**
 * Breadcrumb trail shared by the BreadcrumbList schema and the visible
 * breadcrumbs (template function, shortcode and block), so both always match.
 *
 * @package FutureLabs\AISEO
 */

namespace FutureLabs\AISEO\Schema;

defined( 'ABSPATH' ) || exit;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Meta\Context;

/**
 * Builds the trail and renders it as accessible HTML.
 */
final class Breadcrumbs implements Module {

	public const SHORTCODE = 'flseo_breadcrumbs';
	public const BLOCK     = 'futurelabs-ai-seo/breadcrumbs';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Register the shortcode and block.
	 */
	public function register(): void {
		add_shortcode( self::SHORTCODE, array( $this, 'shortcode' ) );
		add_action( 'init', array( $this, 'register_block' ) );
	}

	/**
	 * Server-rendered block; the editor script only previews it.
	 */
	public function register_block(): void {
		wp_register_script(
			'flseo-breadcrumbs-block',
			FLSEO_URL . 'assets/js/breadcrumbs-block.js',
			array( 'wp-blocks', 'wp-block-editor', 'wp-element', 'wp-i18n', 'wp-server-side-render' ),
			FLSEO_VERSION,
			true
		);
		wp_set_script_translations( 'flseo-breadcrumbs-block', 'futurelabs-ai-seo' );
		register_block_type(
			self::BLOCK,
			array(
				'api_version'     => '3',
				'title'           => __( 'Breadcrumbs', 'futurelabs-ai-seo' ),
				'category'        => 'theme',
				'editor_script'   => 'flseo-breadcrumbs-block',
				'render_callback' => fn() => $this->render(),
				'supports'        => array(
					'html'  => false,
					'align' => array( 'wide', 'full' ),
				),
			)
		);
	}

	/**
	 * Shortcode callback: `[flseo_breadcrumbs separator="/"]`.
	 *
	 * @param array<string, string>|string $atts Attributes.
	 */
	public function shortcode( $atts ): string {
		$atts = shortcode_atts( array( 'separator' => '' ), is_array( $atts ) ? $atts : array(), self::SHORTCODE );
		return $this->render( null, array( 'separator' => (string) $atts['separator'] ) );
	}

	/**
	 * The trail from home to the current page.
	 *
	 * @param Context $context     Page context.
	 * @param string  $current_url URL of the current archive page (posts always use their permalink).
	 * @return array<int, array{name: string, url: string}> Empty on the front page or when there is nothing between home and the page.
	 */
	public function trail( Context $context, string $current_url = '' ): array {
		if ( 'front' === $context->kind ) {
			return array();
		}
		$trail  = array( array( __( 'Home', 'futurelabs-ai-seo' ), trailingslashit( home_url( '/' ) ) ) );
		$object = $context->object;
		if ( 'singular' === $context->kind && $object instanceof \WP_Post ) {
			$trail = array_merge( $trail, $this->post_trail( $object ) );
		} elseif ( 'term' === $context->kind && $object instanceof \WP_Term ) {
			foreach ( array_reverse( get_ancestors( $object->term_id, $object->taxonomy, 'taxonomy' ) ) as $ancestor ) {
				$term = get_term( $ancestor, $object->taxonomy );
				$link = $term instanceof \WP_Term ? get_term_link( $term ) : '';
				if ( $term instanceof \WP_Term && is_string( $link ) ) {
					$trail[] = array( $term->name, $link );
				}
			}
			$link    = get_term_link( $object );
			$trail[] = array( $object->name, '' !== $current_url ? $current_url : ( is_string( $link ) ? $link : '' ) );
		} elseif ( 'author' === $context->kind && $object instanceof \WP_User ) {
			$trail[] = array( $object->display_name, '' !== $current_url ? $current_url : get_author_posts_url( $object->ID ) );
		} elseif ( 'post_type_archive' === $context->kind && $object instanceof \WP_Post_Type ) {
			$trail[] = array( $object->labels->name, '' !== $current_url ? $current_url : (string) get_post_type_archive_link( $object->name ) );
		} elseif ( 'home' === $context->kind && $object instanceof \WP_Post ) {
			$trail[] = array( wp_strip_all_tags( get_the_title( $object ) ), '' !== $current_url ? $current_url : (string) get_permalink( $object ) );
		}
		if ( count( $trail ) < 2 ) {
			return array();
		}
		$items = array();
		foreach ( $trail as $crumb ) {
			$items[] = array(
				// Titles are stored HTML-encoded (& as &amp;); decode once so neither
				// the escaped HTML nor the JSON-LD shows entities.
				'name' => html_entity_decode( wp_strip_all_tags( (string) $crumb[0] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
				'url'  => (string) $crumb[1],
			);
		}
		return (array) apply_filters( 'flseo_breadcrumb_trail', $items, $context );
	}

	/**
	 * Visible breadcrumbs: a labelled nav with an ordered list; the last item
	 * is the current page (not a link).
	 *
	 * @param Context|null         $context Page context (default: current request).
	 * @param array<string, mixed> $args    `separator` (default "»", hidden from assistive tech), `class`.
	 */
	public function render( ?Context $context = null, array $args = array() ): string {
		$trail = $this->trail( $context ?? Context::current() );
		if ( ! $trail ) {
			return '';
		}
		$separator = '' !== (string) ( $args['separator'] ?? '' ) ? (string) $args['separator'] : '»';
		$class     = trim( 'flseo-breadcrumbs ' . (string) ( $args['class'] ?? '' ) );
		$last      = count( $trail ) - 1;
		$items     = array();
		foreach ( $trail as $i => $crumb ) {
			$item = $i === $last || '' === $crumb['url']
				? sprintf( '<span%s>%s</span>', $i === $last ? ' aria-current="page"' : '', esc_html( $crumb['name'] ) )
				: sprintf( '<a href="%s">%s</a>', esc_url( $crumb['url'] ), esc_html( $crumb['name'] ) );
			if ( $i < $last ) {
				$item .= sprintf( ' <span class="flseo-breadcrumbs__sep" aria-hidden="true">%s</span> ', esc_html( $separator ) );
			}
			$items[] = '<li>' . $item . '</li>';
		}
		return sprintf(
			'<nav class="%s" aria-label="%s"><ol>%s</ol></nav>',
			esc_attr( $class ),
			esc_attr__( 'Breadcrumb', 'futurelabs-ai-seo' ),
			implode( '', $items )
		);
	}

	/**
	 * Trail between home and a post: archive, category chain or page ancestors.
	 *
	 * @param \WP_Post $post Post.
	 * @return array<int, array{0: string, 1: string}>
	 */
	private function post_trail( \WP_Post $post ): array {
		$trail = array();
		$type  = get_post_type_object( $post->post_type );
		if ( 'post' !== $post->post_type && $type && $type->has_archive ) {
			$link = get_post_type_archive_link( $post->post_type );
			if ( $link ) {
				$trail[] = array( $type->labels->name, $link );
			}
		}
		if ( is_post_type_hierarchical( $post->post_type ) ) {
			foreach ( array_reverse( get_post_ancestors( $post ) ) as $ancestor ) {
				$trail[] = array( get_the_title( $ancestor ), (string) get_permalink( $ancestor ) );
			}
		} elseif ( 'post' === $post->post_type ) {
			$cats = get_the_category( $post->ID );
			if ( $cats ) {
				$cat = $cats[0];
				foreach ( array_reverse( get_ancestors( $cat->term_id, 'category', 'taxonomy' ) ) as $ancestor ) {
					$term = get_term( $ancestor, 'category' );
					if ( $term instanceof \WP_Term ) {
						$trail[] = array( $term->name, (string) get_term_link( $term ) );
					}
				}
				$trail[] = array( $cat->name, (string) get_term_link( $cat ) );
			}
		}
		$trail[] = array( get_the_title( $post ), (string) get_permalink( $post ) );
		return $trail;
	}
}
