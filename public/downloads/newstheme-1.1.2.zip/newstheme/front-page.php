<?php
/**
 * Front page: homepage sections when showing latest posts; a normal page
 * template when a static front page is set (unless sections are forced on).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

if ( 'page' === get_option( 'show_on_front' ) && ! apply_filters( 'newstheme_sections_on_static_front', false ) ) {
	$newstheme_template = get_page_template();
	require $newstheme_template ? $newstheme_template : locate_template( array( 'singular.php', 'index.php' ) );
	return;
}

get_header();
newstheme_render_homepage();
get_footer();
