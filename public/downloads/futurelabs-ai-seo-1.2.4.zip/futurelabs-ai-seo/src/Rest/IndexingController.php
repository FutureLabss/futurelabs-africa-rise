<?php
/**
 * Indexing dashboard endpoints.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Gsc\Inspector;
use FutureLabs\AISEO\Gsc\OAuth;
use FutureLabs\AISEO\Indexing\Prioritizer;
use FutureLabs\AISEO\Indexing\Repository;

defined( 'ABSPATH' ) || exit;

/**
 * `/indexing/*`.
 */
class IndexingController extends Controller {

	/**
	 * Routes.
	 */
	public function register_routes(): void {
		$this->route( '/indexing/summary', 'GET', array( $this, 'summary' ) );
		$this->route( '/indexing/pages', 'GET', array( $this, 'pages' ) );
		$this->route( '/indexing/pages/(?P<id>\d+)', 'GET', array( $this, 'page' ) );
		$this->route( '/indexing/refresh', 'POST', array( $this, 'refresh' ) );
		$this->route( '/indexing/progress', 'GET', array( $this, 'progress' ) );
		$this->route( '/indexing/fix-first', 'GET', array( $this, 'fix_first' ) );
		$this->route( '/indexing/authors', 'GET', array( $this, 'authors' ) );
		$this->route( '/indexing/unindexed', 'GET', array( $this, 'unindexed' ) );
	}

	/**
	 * Summary cards.
	 */
	public function summary(): \WP_REST_Response {
		$data                   = $this->c->get( Repository::class )->summary();
		$data['search_console'] = $this->c->get( OAuth::class )->ready();
		return rest_ensure_response( $data );
	}

	/**
	 * Filtered page list.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function pages( \WP_REST_Request $request ): \WP_REST_Response {
		list( $page, $per_page ) = $this->paging( $request );
		$filters                 = array(
			'page'     => $page,
			'per_page' => $per_page,
		);
		foreach ( array( 'reason', 'post_type', 'in_sitemap', 'min_words', 'max_words', 'min_inbound', 'max_inbound', 'author', 'search', 'orderby', 'order' ) as $key ) {
			$value = $request->get_param( $key );
			if ( null !== $value && '' !== $value ) {
				$filters[ $key ] = is_scalar( $value ) ? (string) $value : '';
			}
		}
		return rest_ensure_response( $this->c->get( Repository::class )->pages( $filters ) );
	}

	/**
	 * One page's detail.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function page( \WP_REST_Request $request ) {
		$detail = $this->c->get( Repository::class )->detail( absint( $request['id'] ) );
		if ( null === $detail ) {
			return $this->error( 'not_found', __( 'That page is not published or does not exist.', 'futurelabs-ai-seo' ), 404 );
		}
		return rest_ensure_response( $detail );
	}

	/**
	 * Queue inspections for given post ids, or all known pages by priority.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function refresh( \WP_REST_Request $request ) {
		if ( ! $this->c->get( OAuth::class )->ready() ) {
			return $this->error( 'gsc_not_ready', __( 'Connect Search Console and choose a property first.', 'futurelabs-ai-seo' ), 400 );
		}
		$body      = $this->body( $request );
		$inspector = $this->c->get( Inspector::class );
		if ( ! empty( $body['post_ids'] ) && is_array( $body['post_ids'] ) ) {
			$queued = $inspector->queue_posts( array_map( 'absint', $body['post_ids'] ), true );
		} elseif ( ! empty( $body['all'] ) ) {
			$queued = $inspector->queue_all();
		} else {
			return $this->error( 'invalid_request', __( 'Send post_ids or all=true.', 'futurelabs-ai-seo' ) );
		}
		return rest_ensure_response(
			array(
				'queued'   => $queued,
				'progress' => $inspector->progress(),
			)
		);
	}

	/**
	 * Inspection progress.
	 */
	public function progress(): \WP_REST_Response {
		return rest_ensure_response( $this->c->get( Inspector::class )->progress() );
	}

	/**
	 * "Fix this first" groups.
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function fix_first( \WP_REST_Request $request ): \WP_REST_Response {
		$limit = min( 100, max( 1, absint( $request->get_param( 'limit' ) ?: 20 ) ) );
		$items = $this->c->get( Prioritizer::class )->groups( $limit );
		return rest_ensure_response(
			array(
				'items' => $items,
				'total' => count( $items ),
			)
		);
	}

	/**
	 * OL-5 author indexed-rate table.
	 */
	public function authors(): \WP_REST_Response {
		$items = $this->c->get( Repository::class )->authors();
		return rest_ensure_response(
			array(
				'items' => $items,
				'total' => count( $items ),
			)
		);
	}

	/**
	 * OL-10 posts unindexed after N days (default 7).
	 *
	 * @param \WP_REST_Request $request Request.
	 */
	public function unindexed( \WP_REST_Request $request ): \WP_REST_Response {
		$days = min( 365, max( 1, absint( $request->get_param( 'days' ) ?: 7 ) ) );
		$max  = min( 3650, max( $days, absint( $request->get_param( 'max_days' ) ?: 90 ) ) );
		return rest_ensure_response( $this->c->get( Repository::class )->unindexed_after( $days, $max, 200 ) + array( 'days' => $days ) );
	}
}
