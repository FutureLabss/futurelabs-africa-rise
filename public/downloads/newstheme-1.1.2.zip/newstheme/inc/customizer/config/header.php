<?php
/**
 * Header options. See inc/customizer/config.php for the setting format.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

return array(
	'partials' => array(
		'header' => array(
			'selector' => '#nt-masthead',
			'render'   => 'newstheme_render_masthead',
		),
	),
	'sections' => array(
		'newstheme_header_builder'    => array(
			'title'    => __( 'Header Builder', 'newstheme' ),
			'panel'    => 'newstheme_header',
			'priority' => 1,
		),
		'newstheme_header_elements'   => array(
			'title' => __( 'Button, Ad & Widgets', 'newstheme' ),
			'panel' => 'newstheme_header',
		),
		'newstheme_header_general'    => array(
			'title' => __( 'General & Colors', 'newstheme' ),
			'panel' => 'newstheme_header',
		),
		'newstheme_top_bar'           => array(
			'title' => __( 'Top Bar & Date', 'newstheme' ),
			'panel' => 'newstheme_header',
		),
		'newstheme_ticker'            => array(
			'title' => __( 'Ticker News', 'newstheme' ),
			'panel' => 'newstheme_header',
		),
		'newstheme_header_newsletter' => array(
			'title' => __( 'Newsletter Button', 'newstheme' ),
			'panel' => 'newstheme_header',
		),
		'newstheme_header_random'     => array(
			'title' => __( 'Random News Button', 'newstheme' ),
			'panel' => 'newstheme_header',
		),
		'newstheme_header_search'     => array(
			'title' => __( 'Search', 'newstheme' ),
			'panel' => 'newstheme_header',
		),
		'newstheme_theme_mode'        => array(
			'title' => __( 'Dark Mode', 'newstheme' ),
			'panel' => 'newstheme_header',
		),
	),

	'settings' => array(
		// Builder.
		'header_layout'          => array(
			'section'     => 'newstheme_header_builder',
			'control'     => 'builder',
			'builder'     => 'header',
			'label'       => __( 'Desktop & Tablet', 'newstheme' ),
			'description' => __( 'Drag elements between columns, or use each element’s menu. Unused elements wait below.', 'newstheme' ),
			'default'     => newstheme_builder_default( 'header' ),
			'partial'     => 'header',
		),
		'header_mobile_layout'   => array(
			'section'     => 'newstheme_header_builder',
			'control'     => 'builder',
			'builder'     => 'header_mobile',
			'label'       => __( 'Phone (768px and narrower)', 'newstheme' ),
			'description' => __( 'Main-row columns stack vertically on phones.', 'newstheme' ),
			'default'     => newstheme_builder_default( 'header_mobile' ),
			'partial'     => 'header',
		),

		// New elements.
		'custom_button_label'    => array(
			'section'     => 'newstheme_header_elements',
			'control'     => 'text',
			'label'       => __( 'Custom Button Text', 'newstheme' ),
			'description' => __( 'Add the "Custom Button" element in the Header Builder to show it.', 'newstheme' ),
			'default'     => __( 'Subscribe', 'newstheme' ),
			'partial'     => 'header',
		),
		'custom_button_url'      => array(
			'section' => 'newstheme_header_elements',
			'control' => 'url',
			'label'   => __( 'Custom Button Link', 'newstheme' ),
			'default' => '',
			'partial' => 'header',
		),
		'custom_button_new_tab'  => array(
			'section' => 'newstheme_header_elements',
			'control' => 'toggle',
			'label'   => __( 'Open in a new tab', 'newstheme' ),
			'default' => false,
			'partial' => 'header',
		),
		'header_ad_image'        => array(
			'section'     => 'newstheme_header_elements',
			'control'     => 'image',
			'label'       => __( 'Header Ad Image', 'newstheme' ),
			'description' => __( 'Shown by the "Ad Banner" element (e.g. 728×90).', 'newstheme' ),
			'default'     => 0,
			'partial'     => 'header',
		),
		'header_ad_url'          => array(
			'section' => 'newstheme_header_elements',
			'control' => 'url',
			'label'   => __( 'Header Ad Link', 'newstheme' ),
			'default' => '',
			'partial' => 'header',
		),

		// General & colors.
		'header_sticky'          => array(
			'section'     => 'newstheme_header_general',
			'control'     => 'toggle',
			'label'       => __( 'Sticky menu bar', 'newstheme' ),
			'description' => __( 'Keeps the menu row visible while scrolling.', 'newstheme' ),
			'default'     => false,
			'body_class'  => 'nt-sticky-nav',
		),
		'show_tagline'           => array(
			'section'    => 'newstheme_header_general',
			'control'    => 'toggle',
			'label'      => __( 'Show site tagline', 'newstheme' ),
			'default'    => false,
			'body_class' => 'nt-show-tagline',
		),
		'site_title_color'       => array(
			'section'     => 'newstheme_header_general',
			'control'     => 'color',
			'label'       => __( 'Site Title Color', 'newstheme' ),
			'description' => __( 'Empty uses the accent color (a lighter tint in dark mode).', 'newstheme' ),
			'default'     => '',
			'css'         => array( 'var' => '--nt-site-title-color' ),
		),
		'header_bg'              => array(
			'section'  => 'newstheme_header_general',
			'control'  => 'color',
			'label'    => __( 'Header Background', 'newstheme' ),
			'default'  => '#ffffff',
			'gradient' => true,
			'css'      => array( 'var' => '--nt-header-bg' ),
		),
		'header_icon_color'      => array(
			'section' => 'newstheme_header_general',
			'control' => 'color',
			'label'   => __( 'Header Icons & Buttons', 'newstheme' ),
			'default' => '#525252',
			'css'     => array( 'var' => '--nt-header-icon' ),
		),
		'menu_color'             => array(
			'section' => 'newstheme_header_general',
			'control' => 'color',
			'label'   => __( 'Menu Text', 'newstheme' ),
			'default' => '#000000',
			'css'     => array( 'var' => '--nt-menu-color' ),
		),
		'menu_active_color'      => array(
			'section'     => 'newstheme_header_general',
			'control'     => 'color',
			'label'       => __( 'Menu Active & Hover', 'newstheme' ),
			'description' => __( 'Empty uses the accent color.', 'newstheme' ),
			'default'     => '',
			'css'         => array( 'var' => '--nt-menu-active' ),
		),
		'heading_header_dark'    => array(
			'section' => 'newstheme_header_general',
			'control' => 'heading',
			'label'   => __( 'Dark Mode', 'newstheme' ),
		),
		'dark_header_bg'         => array(
			'section' => 'newstheme_header_general',
			'control' => 'color',
			'label'   => __( 'Header Background', 'newstheme' ),
			'default' => '#000000',
			'css'     => array(
				'var'   => '--nt-header-bg',
				'scope' => 'dark',
			),
		),
		'dark_header_icon_color' => array(
			'section' => 'newstheme_header_general',
			'control' => 'color',
			'label'   => __( 'Header Icons & Buttons', 'newstheme' ),
			'default' => '#ffffff',
			'css'     => array(
				'var'   => '--nt-header-icon',
				'scope' => 'dark',
			),
		),
		'dark_menu_color'        => array(
			'section' => 'newstheme_header_general',
			'control' => 'color',
			'label'   => __( 'Menu Text', 'newstheme' ),
			'default' => '#ffffff',
			'css'     => array(
				'var'   => '--nt-menu-color',
				'scope' => 'dark',
			),
		),

		// Top bar.
		'show_date'              => array(
			'section' => 'newstheme_top_bar',
			'control' => 'toggle',
			'label'   => __( 'Show date', 'newstheme' ),
			'default' => true,
			'partial' => 'header',
		),
		'show_time'              => array(
			'section' => 'newstheme_top_bar',
			'control' => 'toggle',
			'label'   => __( 'Show live clock', 'newstheme' ),
			'default' => true,
			'partial' => 'header',
		),
		'top_bar_bg'             => array(
			'section'     => 'newstheme_top_bar',
			'control'     => 'color',
			'label'       => __( 'Background', 'newstheme' ),
			'description' => __( 'Empty uses the accent color.', 'newstheme' ),
			'default'     => '',
			'gradient'    => true,
			'css'         => array( 'var' => '--nt-topbar-bg' ),
		),
		'top_bar_text'           => array(
			'section' => 'newstheme_top_bar',
			'control' => 'color',
			'label'   => __( 'Text Color', 'newstheme' ),
			'default' => '#ffffff',
			'css'     => array( 'var' => '--nt-topbar-text' ),
		),
		'dark_top_bar_bg'        => array(
			'section' => 'newstheme_top_bar',
			'control' => 'color',
			'label'   => __( 'Background (Dark Mode)', 'newstheme' ),
			'default' => '#000000',
			'css'     => array(
				'var'   => '--nt-topbar-bg',
				'scope' => 'dark',
			),
		),

		// Ticker.
		'ticker_source'          => array(
			'section' => 'newstheme_ticker',
			'control' => 'buttons',
			'label'   => __( 'Show Posts From', 'newstheme' ),
			'default' => 'latest',
			'choices' => array(
				'latest'     => __( 'Latest', 'newstheme' ),
				'categories' => __( 'Categories', 'newstheme' ),
				'posts'      => __( 'Hand-picked', 'newstheme' ),
			),
			'partial' => 'header',
		),
		'ticker_categories'      => array(
			'section' => 'newstheme_ticker',
			'control' => 'multiselect',
			'label'   => __( 'Categories', 'newstheme' ),
			'source'  => 'categories',
			'default' => array(),
			'show_if' => array( 'ticker_source', 'categories' ),
			'partial' => 'header',
		),
		'ticker_posts'           => array(
			'section' => 'newstheme_ticker',
			'control' => 'multiselect',
			'label'   => __( 'Posts', 'newstheme' ),
			'source'  => 'posts',
			'default' => array(),
			'show_if' => array( 'ticker_source', 'posts' ),
			'partial' => 'header',
		),
		'ticker_count'           => array(
			'section' => 'newstheme_ticker',
			'control' => 'number',
			'label'   => __( 'Number of Posts', 'newstheme' ),
			'default' => 8,
			'min'     => 1,
			'max'     => 30,
			'show_if' => array( 'ticker_source', array( 'latest', 'categories' ) ),
			'partial' => 'header',
		),
		'ticker_interval'        => array(
			'section' => 'newstheme_ticker',
			'control' => 'number',
			'label'   => __( 'Seconds Per Headline', 'newstheme' ),
			'default' => 4,
			'min'     => 2,
			'max'     => 15,
			'partial' => 'header',
		),

		// Newsletter.
		'newsletter_label'       => array(
			'section' => 'newstheme_header_newsletter',
			'control' => 'text',
			'label'   => __( 'Button Label', 'newstheme' ),
			'default' => __( 'Newsletter', 'newstheme' ),
			'partial' => 'header',
		),
		'newsletter_heading'     => array(
			'section' => 'newstheme_header_newsletter',
			'control' => 'text',
			'label'   => __( 'Popup Heading', 'newstheme' ),
			'default' => __( 'Subscribe to our newsletter', 'newstheme' ),
		),
		'newsletter_text'        => array(
			'section' => 'newstheme_header_newsletter',
			'control' => 'text',
			'label'   => __( 'Popup Text', 'newstheme' ),
			'default' => __( 'Get the top stories delivered to your inbox every morning.', 'newstheme' ),
		),
		'newsletter_shortcode'   => array(
			'section'     => 'newstheme_header_newsletter',
			'control'     => 'text',
			'label'       => __( 'Form Shortcode', 'newstheme' ),
			'description' => __( 'Paste the shortcode from your newsletter plugin (MailPoet, Mailchimp for WP, Fluent Forms…).', 'newstheme' ),
			'default'     => '',
		),
		'newsletter_url'         => array(
			'section'     => 'newstheme_header_newsletter',
			'control'     => 'url',
			'label'       => __( 'Or Link To URL', 'newstheme' ),
			'description' => __( 'Used instead of the popup when set.', 'newstheme' ),
			'default'     => '',
			'partial'     => 'header',
		),

		// Random news.
		'random_label'           => array(
			'section' => 'newstheme_header_random',
			'control' => 'text',
			'label'   => __( 'Button Label', 'newstheme' ),
			'default' => __( 'Random News', 'newstheme' ),
			'partial' => 'header',
		),
		'random_categories'      => array(
			'section'     => 'newstheme_header_random',
			'control'     => 'multiselect',
			'label'       => __( 'Limit To Categories', 'newstheme' ),
			'description' => __( 'Leave empty to pick from all posts.', 'newstheme' ),
			'source'      => 'categories',
			'default'     => array(),
		),

		// Search.
		'live_search'            => array(
			'section'     => 'newstheme_header_search',
			'control'     => 'toggle',
			'label'       => __( 'Live results while typing', 'newstheme' ),
			'default'     => true,
			'description' => __( 'Shows matching posts after 3 characters.', 'newstheme' ),
			'partial'     => 'header',
		),

		// Dark mode.
		'default_mode'           => array(
			'section'     => 'newstheme_theme_mode',
			'control'     => 'buttons',
			'label'       => __( 'Default Mode', 'newstheme' ),
			'description' => __( 'A visitor’s own choice (from the toggle) always wins.', 'newstheme' ),
			'default'     => 'light',
			'choices'     => array(
				'light'  => __( 'Light', 'newstheme' ),
				'dark'   => __( 'Dark', 'newstheme' ),
				'system' => __( 'Follow System', 'newstheme' ),
			),
		),
	),
);
