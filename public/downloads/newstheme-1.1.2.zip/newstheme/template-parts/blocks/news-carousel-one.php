<?php
/**
 * Block: news carousel — image with an overlapping text card.
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args (see newstheme_block_types()).
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="nt-block nt-block--carousel nt-block--carousel-one" <?php echo $args['title'] ? 'aria-labelledby="' . esc_attr( $args['id'] ) . '-title"' : ''; ?>>
	<?php newstheme_block_heading( $args['title'], $args['id'] ); ?>
	<div class="nt-carousel" data-nt-carousel data-loop<?php echo $args['autoplay'] ? ' data-autoplay="' . esc_attr( $args['autoplay'] * 1000 ) . '"' : ''; ?> style="--nt-per-view: <?php echo (int) $args['columns']; ?>" role="region" aria-roledescription="<?php esc_attr_e( 'carousel', 'newstheme' ); ?>" aria-label="<?php echo esc_attr( $args['title'] ? $args['title'] : __( 'Posts', 'newstheme' ) ); ?>">
		<div class="nt-carousel__track">
			<?php
			while ( $args['loop']->have_posts() ) :
				$args['loop']->the_post();
				?>
				<article <?php post_class( 'nt-carousel__slide nt-post nt-post--overlap' ); ?> aria-roledescription="<?php esc_attr_e( 'slide', 'newstheme' ); ?>">
					<?php newstheme_post_thumb( 'newstheme-medium' ); ?>
					<div class="nt-post__card">
						<?php
						newstheme_post_categories( null, 1, 'text' );
						newstheme_post_title( 'h3' );
						newstheme_post_meta( $args['meta'] );
						?>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
		<?php
		if ( $args['arrows'] ) {
			get_template_part( 'template-parts/blocks/carousel-controls' );
		}
		?>
	</div>
</section>
