# NewsTheme — Getting Started

This guide walks you from a fresh install to a finished news site. Everything below happens in **Appearance → Customize**, where changes show in a live preview before you press **Publish**.

## 1. Install

1. **Appearance → Themes → Add New → Upload Theme**, choose `newstheme-1.0.0.zip`, then **Activate**.
2. Set your site title and logo in **Customize → Site Identity**.
3. Create your menus in **Appearance → Menus** and assign them to **Primary Menu**, **Secondary (Top Bar) Menu** and **Footer Menu**.

> Tip: give a top-level menu item a **Description** (enable it under *Screen Options* in the Menus screen) and it shows as a small badge, e.g. "NEW".

### Demo content (optional)
If your copy of NewsTheme comes with a hosted demo, install the **One Click Demo Import** plugin, then go to **Appearance → Import Demo Data**. Import into a new, empty site: it adds sample posts, images, menus, widgets and category colors. Images download during the import, so it can take a few minutes.

## 2. Colors and fonts — *Global Options*

- **Colors:** pick your **Theme / Accent Color** first; buttons, badges, the top bar and links follow it. Dark-mode colors are set separately below the light ones. Leave *Accent Text* empty and it follows your accent automatically (a lighter tint in dark mode, so it stays readable).
- **Category Colors:** give each category its own badge color. Text on the badge switches between black and white automatically for contrast.
- **Typography:** 11 text styles (site title, post titles, menu, body text…), each with font, weight, size per device, line height and spacing.
- **More fonts:** install any Google Font in **Appearance → Fonts**. WordPress stores it on your site (nothing loads from Google), and it appears in every Font Family list.
- **Layout:** content width, full-width or boxed site, spacing between cards and sections, image corner radius.

Use the **Desktop / Tablet / Mobile** buttons at the bottom of the Customizer to set sizes per device.

## 3. Header — *Header → Header Builder*

The header has three rows (**Top**, **Main**, **Bottom**), each with **Left / Center / Right** columns.

- **Drag** an element by its handle to another column, or use the small **▾ menu** on each element to choose where it goes (works with the keyboard).
- Elements you don't use wait in **Available elements**; move one into a column to show it.
- The **Phone** layout (768px and narrower) is separate, so mobile can be arranged differently. Editing it switches the preview to mobile.

Element settings live in the other Header sections: **Top Bar & Date**, **Ticker News** (which posts, how fast), **Newsletter Button**, **Random News Button**, **Button, Ad & Widgets** (custom button, header ad, widget area), **Search**, **Dark Mode** and **Headlines Bar** (the scrolling strip under the header).

### Newsletter popup
Install a newsletter plugin with a shortcode (MailPoet, Mailchimp for WP, Fluent Forms…), then paste its shortcode in **Header → Newsletter Button**. Or enter a URL to link to a signup page instead.

## 4. Homepage — *Homepage Sections*

The homepage is made of sections. In **Sections Order**, drag sections up and down and untick any you don't want.

Each section has its own panel with a list of **blocks**:

| Block | What it shows |
|---|---|
| Main Banner | Slider + side cards (two layouts) |
| News Grid | Cards in 1–4 columns (two layouts) |
| News List | Rows with excerpt, or compact rows |
| News Filter | Category tabs that load posts on click (two layouts) |
| News Carousel | Sliding cards (two layouts) |
| Advertisement | An image with link, or ad code |

For each block: **Add Block**, open it to edit, use the arrows or drag handle to reorder, **Duplicate** or **Remove**. Choose which posts it shows — *Latest*, from *Categories*, or *Hand-picked* — plus how many, how many to skip (avoids repeats between blocks) and the order.

Sections with a sidebar (**Content With Sidebar**, **Sidebar With Content**) take their widgets from the **Frontpage – Middle Right/Left Sidebar** widget areas, and can put the sidebar left, right or nowhere.

**Video Playlist:** paste YouTube links (titles fill in automatically). The player only loads when a visitor presses play.

**Opinions:** quote cards with photo, headline and author — above the footer on every page, or as a homepage section.

> The homepage sections are used when **Settings → Reading** shows "Your latest posts". With a static front page, your chosen page is shown instead.

## 5. Posts and pages — *Posts & Pages*

- **Sidebar layout** for archives, single posts and pages: right, left, both sides, two on the right, or none.
- **Blog & Archives:** list or grid, feature the newest post as a large hero, excerpt length.
- **Single Post:** reorder or hide the meta (author, date, comments, reading time); show or hide the featured image, tags, share buttons, author box, previous/next links and related posts (by category, tags or either).
- **Breadcrumbs:** uses FutureLabs AI SEO's breadcrumbs when that plugin is active (they match the breadcrumb data Google reads), or Yoast SEO / Rank Math breadcrumbs when those have them enabled.

## 6. Opportunity deadlines — *Global Options → Opportunity Deadlines*

When a post has a deadline (set in the **FutureLabs AI SEO** panel while editing the post), its image shows a badge:

| Badge | When |
|---|---|
| **Closes today** / **Closes tomorrow** / **Closes in 3 days** (red) | Within the highlight window (7 days by default) |
| **Closes 13 Oct** (dark) | Further away |
| **Closed** (grey, image muted) | After the deadline, or when the post is marked closed |
| **Rolling deadline** | No fixed date |

The countdown is recalculated in each visitor's browser, so it stays correct even when your host or a caching plugin serves an older copy of the page. Turn badges off, or change the highlight window (1–30 days), under *Opportunity Deadlines*.

**"Closing soon" sections:** in any homepage block (News Grid, News List, Carousel…), set *Posts* to **Closing soon**. It lists posts whose deadline is today or later, soonest first.

## 7. Footer — *Footer → Footer Builder*

Two rows — **Widgets** and **Bottom Bar** — each with 1–4 columns. Place footer widget areas, copyright, footer menu, social icons or your logo. Set the copyright text in **Footer → Bottom Bar** (`{year}` and `{site}` are filled in for you; links are allowed).

## 8. Widgets — *Appearance → Widgets*

NewsTheme adds nine widgets: **Posts List**, **Popular Posts** (numbered), **Posts Grid**, **Posts Carousel**, **Banner Ad**, **Social Icons**, **Author Info**, **Category Collection** and **Widget Title**.

Widget areas: Sidebar, Left Sidebar, Frontpage Middle Right/Left, Header Toggle Sidebar (the ☰ off-canvas panel), Header Builder Widget Area and Footer Columns 1–4.

Social profile links are set once in **Global Options → Social Links** and used by the header, footer and Social Icons widget.

## 9. Extras

- **Dark mode:** visitors switch with the moon icon; their choice is remembered. Set the default (light, dark or follow system) in **Header → Dark Mode**.
- **Preloader:** seven styles in **Global Options → Preloader** (off by default).
- **Animations:** cards fade in on scroll; turn off in **Global Options → Animations & Hover Effects**. Visitors who prefer reduced motion never see animations or auto-playing sliders.

## 10. Accessibility and performance

- Tested against WCAG 2.2 AA: keyboard-operable menus, sliders, tabs and dialogs; visible focus; contrast-checked defaults; reduced-motion support.
- No jQuery on the front end; fonts are self-hosted; images lazy-load below the fold.
- If you pick your own colors, keep text readable — aim for strong contrast between text and its background.

## For developers

- Child-theme friendly: every header/footer element and block is a template part (`template-parts/header/*`, `template-parts/footer/*`, `template-parts/blocks/*`, `template-parts/sections/*`).
- Hooks: `newstheme_before_header`, `newstheme_after_header`, `newstheme_before_footer`, `newstheme_before_homepage_section`, `newstheme_after_homepage_section`.
- Filters: `newstheme_opportunity` (deadline data for a post), `newstheme_demo_url`, `newstheme_output_meta_description`, `newstheme_customizer_config`, `newstheme_font_families`, `newstheme_block_types`, `newstheme_block_fields`, `newstheme_block_query_args`, `newstheme_homepage_section_defs`, `newstheme_builders`, `newstheme_builder_layout`, `newstheme_sidebar_layout`, `newstheme_related_query_args`, `newstheme_ticker_query_args`, `newstheme_share_links`.
- Render a block anywhere: `newstheme_render_block( 'news-grid', array( 'title' => 'Latest', 'columns' => 3 ) );`
