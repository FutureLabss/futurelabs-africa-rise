<?php
/**
 * Previous/next buttons for [data-nt-carousel] sliders.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="nt-carousel__controls">
	<button type="button" class="nt-carousel__btn nt-carousel__btn--prev" data-nt-carousel-prev aria-label="<?php esc_attr_e( 'Previous', 'newstheme' ); ?>"><?php newstheme_icon( 'chevron-left' ); ?></button>
	<button type="button" class="nt-carousel__btn nt-carousel__btn--next" data-nt-carousel-next aria-label="<?php esc_attr_e( 'Next', 'newstheme' ); ?>"><?php newstheme_icon( 'chevron-right' ); ?></button>
</div>
