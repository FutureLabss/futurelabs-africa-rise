<?php
/**
 * Header element: custom call-to-action button.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_url = newstheme_get_mod( 'custom_button_url' );
?>
<a class="nt-button nt-custom-button" href="<?php echo esc_url( $newstheme_url ? $newstheme_url : home_url( '/' ) ); ?>"<?php echo newstheme_get_mod( 'custom_button_new_tab' ) ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo esc_html( newstheme_get_mod( 'custom_button_label' ) ); ?></a>
