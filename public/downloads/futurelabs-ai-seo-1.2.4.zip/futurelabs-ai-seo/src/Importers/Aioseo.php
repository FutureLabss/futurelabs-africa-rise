<?php
/**
 * All in One SEO importer.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Importers;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the `{prefix}aioseo_posts`, `{prefix}aioseo_terms` and `{prefix}aioseo_redirects`
 * tables (AIOSEO 4) plus legacy `_aioseo_*` / `_aioseop_*` post meta.
 */
class Aioseo extends Importer {

	public const LEGACY_KEYS = array(
		'_aioseo_title',
		'_aioseo_description',
		'_aioseo_og_title',
		'_aioseo_og_description',
		'_aioseo_twitter_title',
		'_aioseo_twitter_description',
		'_aioseop_title',
		'_aioseop_description',
		'_aioseop_custom_link',
		'_aioseop_noindex',
	);

	/**
	 * Tags FutureLabs AI SEO cannot represent; they are removed. Other #words are left as text.
	 */
	private const UNSUPPORTED_TAGS = array( 'current_year', 'current_month', 'current_day', 'current_date', 'author_first_name', 'author_last_name', 'author_bio', 'post_content', 'permalink', 'post_link', 'post_link_alt', 'post_day', 'post_month', 'post_year', 'parent_title', 'tax_name', 'search_term', 'archive_title', 'archive_date', 'custom_field', 'tax_parent_name', 'attachment_caption', 'alt_tag' );

	/**
	 * Cached table rows per post for the current page.
	 *
	 * @var array<int, array<string, mixed>>
	 */
	private array $rows = array();

	/**
	 * Slug.
	 */
	public function slug(): string {
		return 'aioseo';
	}

	/**
	 * Label.
	 */
	public function label(): string {
		return 'All in One SEO';
	}

	/**
	 * Table name.
	 *
	 * @param string $suffix posts, terms, redirects.
	 */
	private static function table( string $suffix ): string {
		global $wpdb;
		return $wpdb->prefix . 'aioseo_' . $suffix;
	}

	/**
	 * SQL selecting post IDs with data (table rows plus legacy meta).
	 *
	 * @return array{0: string, 1: array<int, string>} SQL and params.
	 */
	private function post_id_sql(): array {
		global $wpdb;
		$in    = implode( ',', array_fill( 0, count( self::LEGACY_KEYS ), '%s' ) );
		$parts = array( "SELECT m.post_id AS id FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID=m.post_id WHERE m.meta_key IN ($in) AND m.meta_value<>'' AND p.post_type NOT IN ('revision','nav_menu_item')" );
		if ( self::table_exists( self::table( 'posts' ) ) ) {
			$posts   = self::table( 'posts' );
			$parts[] = "SELECT a.post_id AS id FROM {$posts} a INNER JOIN {$wpdb->posts} p2 ON p2.ID=a.post_id WHERE p2.post_type NOT IN ('revision','nav_menu_item')";
		}
		return array( implode( ' UNION ', $parts ), self::LEGACY_KEYS );
	}

	/**
	 * Counts.
	 *
	 * @return array{posts: int, terms: int, redirects: int, settings: int}
	 */
	public function count(): array {
		global $wpdb;
		list( $sql, $params ) = $this->post_id_sql();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$posts          = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM ({$sql}) ids", $params ) );
		$terms_table    = self::table( 'terms' );
		$redirect_table = self::table( 'redirects' );
		$terms          = self::table_exists( $terms_table ) ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$terms_table}" ) : 0;
		$redirects      = self::table_exists( $redirect_table ) ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$redirect_table} WHERE enabled=1" ) : 0;
		// phpcs:enable
		return array(
			'posts'     => $posts,
			'terms'     => $terms,
			'redirects' => $redirects,
			'settings'  => $this->settings_fields() ? 1 : 0,
		);
	}

	/**
	 * Site-wide settings: separator and home title/description from
	 * `aioseo_options`, per-type settings from `aioseo_options_dynamic`.
	 * Titles and descriptions marked "localized" in AIOSEO live in the matching
	 * `*_localized` option (keys such as `searchAppearance_global_siteTitle`)
	 * and take precedence, as they do in AIOSEO itself.
	 *
	 * @return array<string, mixed>
	 */
	protected function settings_fields(): array {
		$options = self::json_option( 'aioseo_options' );
		$dynamic = self::json_option( 'aioseo_options_dynamic' );
		if ( ! $options && ! $dynamic ) {
			return array();
		}
		$localized         = (array) get_option( 'aioseo_options_localized', array() );
		$dynamic_localized = (array) get_option( 'aioseo_options_dynamic_localized', array() );
		$global            = (array) ( $options['searchAppearance']['global'] ?? array() );
		$pick              = static function ( array $store, string $key, $fallback ): string {
			$value = $store[ $key ] ?? '';
			return '' !== (string) $value ? (string) $value : (string) self::leaf( $fallback );
		};

		$out = array(
			'title_separator'  => html_entity_decode( (string) self::leaf( $global['separator'] ?? '' ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
			'home_title'       => $pick( $localized, 'searchAppearance_global_siteTitle', $global['siteTitle'] ?? '' ),
			'home_description' => $pick( $localized, 'searchAppearance_global_metaDescription', $global['metaDescription'] ?? '' ),
			'post_types'       => array(),
			'taxonomies'       => array(),
		);
		foreach ( array(
			'postTypes'  => 'post_types',
			'taxonomies' => 'taxonomies',
		) as $group => $target ) {
			foreach ( (array) ( $dynamic['searchAppearance'][ $group ] ?? array() ) as $name => $entry ) {
				if ( ! is_array( $entry ) ) {
					continue;
				}
				$prefix = 'searchAppearance_' . $group . '_' . $name . '_';
				$robots = (array) ( $entry['advanced']['robotsMeta'] ?? array() );
				$hidden = false === self::leaf( $entry['show'] ?? true )
					|| ( false === self::leaf( $robots['default'] ?? true ) && true === self::leaf( $robots['noindex'] ?? false ) );

				$out[ $target ][ sanitize_key( (string) $name ) ] = array(
					'title'       => $pick( $dynamic_localized, $prefix . 'title', $entry['title'] ?? '' ),
					'description' => $pick( $dynamic_localized, $prefix . 'metaDescription', $entry['metaDescription'] ?? '' ),
					'index'       => ! $hidden,
				);
			}
		}
		return $out;
	}

	/**
	 * A JSON-encoded AIOSEO option as an array (AIOSEO tolerates rows stored as arrays too).
	 *
	 * @param string $name Option name.
	 * @return array<string, mixed>
	 */
	private static function json_option( string $name ): array {
		$raw = get_option( $name, '' );
		if ( is_array( $raw ) ) {
			return $raw;
		}
		$decoded = json_decode( (string) $raw, true );
		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * An option leaf: stored values are plain, but tolerate `{ "value": … }` wrappers.
	 *
	 * @param mixed $value Leaf.
	 * @return mixed
	 */
	private static function leaf( $value ) {
		return is_array( $value ) && array_key_exists( 'value', $value ) ? $value['value'] : $value;
	}

	/**
	 * Post IDs.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, int>
	 */
	protected function post_ids( int $offset, int $limit ): array {
		global $wpdb;
		list( $sql, $params ) = $this->post_id_sql();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$ids        = array_map( 'absint', (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM ({$sql}) ids ORDER BY id ASC LIMIT %d OFFSET %d", array_merge( $params, array( $limit, $offset ) ) ) ) );
		$this->rows = array();
		if ( $ids && self::table_exists( self::table( 'posts' ) ) ) {
			$in    = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
			$table = self::table( 'posts' );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE post_id IN ($in)", $ids ), ARRAY_A );
			foreach ( $rows as $row ) {
				$this->rows[ (int) $row['post_id'] ] = $row;
			}
		}
		return $ids;
	}

	/**
	 * Post fields: table values first, legacy meta as fallback.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string, string>
	 */
	protected function post_fields( int $post_id ): array {
		$row    = $this->rows[ $post_id ] ?? array();
		$meta   = static fn( string $key ): string => (string) get_post_meta( $post_id, $key, true );
		$first  = static function ( string ...$values ): string {
			foreach ( $values as $value ) {
				if ( '' !== trim( $value ) ) {
					return $value;
				}
			}
			return '';
		};
		$col    = static fn( string $key ): string => is_scalar( $row[ $key ] ?? null ) ? (string) $row[ $key ] : '';
		$fields = $this->row_fields( $row );

		$fields['title']          = $first( $fields['title'], $meta( '_aioseo_title' ), $meta( '_aioseop_title' ) );
		$fields['description']    = $first( $fields['description'], $meta( '_aioseo_description' ), $meta( '_aioseop_description' ) );
		$fields['canonical']      = $first( $fields['canonical'], $meta( '_aioseop_custom_link' ) );
		$fields['og_title']       = $first( $fields['og_title'], $meta( '_aioseo_og_title' ), $meta( '_aioseo_twitter_title' ) );
		$fields['og_description'] = $first( $fields['og_description'], $meta( '_aioseo_og_description' ), $meta( '_aioseo_twitter_description' ) );
		if ( '' === $fields['noindex'] && 'on' === $meta( '_aioseop_noindex' ) ) {
			$fields['noindex'] = '1';
		}
		$keyphrases            = json_decode( $col( 'keyphrases' ), true );
		$fields['focus_topic'] = is_array( $keyphrases ) ? (string) ( $keyphrases['focus']['keyphrase'] ?? '' ) : '';
		$fields['schema_type'] = $this->schema_from_row( $row );
		return $fields;
	}

	/**
	 * Fields shared by the posts and terms tables.
	 *
	 * @param array<string, mixed> $row Row.
	 * @return array<string, string>
	 */
	private function row_fields( array $row ): array {
		$col = static fn( string $key ): string => is_scalar( $row[ $key ] ?? null ) ? (string) $row[ $key ] : '';
		// robots_default=1 means "use the global default", so only an explicit noindex counts.
		$noindex = '0' === $col( 'robots_default' ) && '1' === $col( 'robots_noindex' ) ? '1' : '';
		return array(
			'title'          => $col( 'title' ),
			'description'    => $col( 'description' ),
			'canonical'      => $col( 'canonical_url' ),
			'noindex'        => $noindex,
			'og_title'       => '' !== $col( 'og_title' ) ? $col( 'og_title' ) : $col( 'twitter_title' ),
			'og_description' => '' !== $col( 'og_description' ) ? $col( 'og_description' ) : $col( 'twitter_description' ),
			'og_image'       => '' !== $col( 'og_image_custom_url' ) ? $col( 'og_image_custom_url' ) : $col( 'twitter_image_custom_url' ),
		);
	}

	/**
	 * Schema type from schema_type/schema_type_options or the newer `schema` JSON column.
	 *
	 * @param array<string, mixed> $row Row.
	 */
	private function schema_from_row( array $row ): string {
		$schema = json_decode( is_string( $row['schema'] ?? null ) ? $row['schema'] : '', true );
		if ( is_array( $schema ) && ! empty( $schema['default']['graphName'] ) ) {
			$graph = (string) $schema['default']['graphName'];
			$sub   = (string) ( $schema['default']['data'][ $graph ]['articleType'] ?? '' );
			return self::schema_type( 'Article' === $graph && '' !== $sub ? $sub : $graph );
		}
		$type = is_string( $row['schema_type'] ?? null ) ? $row['schema_type'] : '';
		if ( '' === $type || 'default' === $type ) {
			return '';
		}
		if ( 'Article' === $type ) {
			$options = json_decode( is_string( $row['schema_type_options'] ?? null ) ? $row['schema_type_options'] : '', true );
			$sub     = is_array( $options ) ? (string) ( $options['article']['articleType'] ?? '' ) : '';
			return self::schema_type( '' !== $sub ? $sub : 'Article' );
		}
		return self::schema_type( $type );
	}

	/**
	 * Term IDs.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, int>
	 */
	protected function term_ids( int $offset, int $limit ): array {
		global $wpdb;
		if ( ! self::table_exists( self::table( 'terms' ) ) ) {
			return array();
		}
		$table = self::table( 'terms' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY term_id ASC LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_A );
		$ids  = array();
		foreach ( $rows as $row ) {
			$this->rows[ -1 * (int) $row['term_id'] ] = $row;
			$ids[]                                    = (int) $row['term_id'];
		}
		return $ids;
	}

	/**
	 * Term fields.
	 *
	 * @param int $term_id Term ID.
	 * @return array<string, string>
	 */
	protected function term_fields( int $term_id ): array {
		return $this->row_fields( $this->rows[ -1 * $term_id ] ?? array() );
	}

	/**
	 * Redirect rows.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, array{source: string, target: string, type: int, is_regex: bool}>
	 */
	protected function redirect_rows( int $offset, int $limit ): array {
		global $wpdb;
		if ( ! self::table_exists( self::table( 'redirects' ) ) ) {
			return array();
		}
		$table = self::table( 'redirects' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT source_url, target_url, type, regex FROM {$table} WHERE enabled=1 ORDER BY id ASC LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_A );
		$out  = array();
		foreach ( $rows as $row ) {
			$out[] = array(
				'source'   => (string) $row['source_url'],
				'target'   => (string) $row['target_url'],
				'type'     => absint( $row['type'] ),
				'is_regex' => ! empty( $row['regex'] ),
			);
		}
		return $out;
	}

	/**
	 * Posts excluded from the AIOSEO sitemap (aioseo_options JSON).
	 *
	 * @return array<int, int>
	 */
	public function sitemap_excluded(): array {
		$options = json_decode( (string) get_option( 'aioseo_options', '' ), true );
		$list    = is_array( $options ) ? (array) ( $options['sitemap']['general']['advancedSettings']['excludePosts'] ?? array() ) : array();
		$ids     = array();
		foreach ( $list as $item ) {
			$item = is_string( $item ) ? json_decode( $item, true ) : $item;
			if ( is_array( $item ) && ! empty( $item['value'] ) ) {
				$ids[] = absint( $item['value'] );
			}
		}
		return array_values( array_filter( $ids ) );
	}

	/**
	 * Variable pattern: #tag or #custom_field-name.
	 */
	protected function variable_pattern(): string {
		return '/#(custom_field-[a-z0-9_\-]+|[a-z_]+)/i';
	}

	/**
	 * Leave unknown #words (hashtags, "#1") as text.
	 *
	 * @param string $token Token.
	 */
	protected function unknown_variable( string $token ): string {
		if ( 0 === stripos( $token, '#custom_field-' ) ) {
			$this->unsupported[ $token ] = true;
			return '';
		}
		return $token;
	}

	/**
	 * Variable map.
	 *
	 * @return array<string, string>
	 */
	protected function variable_map(): array {
		$map = array(
			'post_title'           => '%title%',
			'site_title'           => '%sitename%',
			'separator_sa'         => '%sep%',
			'tagline'              => '%tagline%',
			'post_excerpt'         => '%excerpt%',
			'post_excerpt_only'    => '%excerpt%',
			'categories'           => '%category%',
			'taxonomy_title'       => '%title%',
			'category_title'       => '%title%',
			'term_title'           => '%title%',
			// On term archives %excerpt% is the term description.
			'taxonomy_description' => '%excerpt%',
			'category_description' => '%excerpt%',
			'term_description'     => '%excerpt%',
			'post_date'            => '%date%',
			'author_name'          => '%author%',
			'page_number'          => '%page%',
		);
		foreach ( self::UNSUPPORTED_TAGS as $tag ) {
			$map[ $tag ] = '';
		}
		return $map;
	}
}
