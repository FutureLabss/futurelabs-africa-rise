<?php
/**
 * Decides robots directives for a request or a post.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Meta;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Rule order: object override → type/taxonomy setting → global default.
 */
class RobotsResolver {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Resolve directives for a context.
	 *
	 * @param Context $context Context.
	 * @return array{index: bool, follow: bool, reason: string}
	 */
	public function resolve( Context $context ): array {
		$settings = $this->c->get( Settings::class );
		$result   = $this->base( $context, $settings );
		/**
		 * Filter the resolved robots decision.
		 *
		 * @param array   $result  { index, follow, reason }.
		 * @param Context $context Context.
		 */
		$filtered = apply_filters( 'flseo_robots', $result, $context );
		return is_array( $filtered ) && isset( $filtered['index'] ) ? array_merge( $result, $filtered ) : $result;
	}

	/**
	 * Rule evaluation without filters.
	 *
	 * @param Context  $context  Context.
	 * @param Settings $settings Settings.
	 * @return array{index: bool, follow: bool, reason: string}
	 */
	private function base( Context $context, Settings $settings ): array {
		if ( '0' === (string) get_option( 'blog_public' ) ) {
			return array(
				'index'  => false,
				'follow' => false,
				'reason' => 'site_discouraged',
			);
		}
		switch ( $context->kind ) {
			case 'search':
				return self::no( 'search' );
			case '404':
				return self::no( 'not_found' );
		}
		if ( $context->is_paged_archive() && $settings->get( 'noindex_paginated' ) ) {
			return self::no( 'paginated' );
		}
		switch ( $context->kind ) {
			case 'singular':
			case 'front':
			case 'home':
				if ( $context->object instanceof \WP_Post ) {
					return $this->for_post( $context->object );
				}
				return self::yes( 'home' );
			case 'term':
				return $context->object instanceof \WP_Term ? $this->for_term( $context->object ) : self::yes( 'default' );
			case 'author':
				if ( $settings->get( 'noindex_author' ) ) {
					return self::no( 'author_setting' );
				}
				if ( $context->object instanceof \WP_User && 0 === (int) count_user_posts( $context->object->ID, 'post', true ) ) {
					return self::no( 'author_empty' );
				}
				return self::yes( 'default' );
			case 'date':
				return $settings->get( 'noindex_date' ) ? self::no( 'date_setting' ) : self::yes( 'default' );
			case 'post_type_archive':
				if ( $context->object instanceof \WP_Post_Type ) {
					return $settings->post_type( $context->object->name )['index'] ? self::yes( 'type_setting' ) : self::no( 'type_setting' );
				}
				return self::yes( 'default' );
		}
		return self::yes( 'default' );
	}

	/**
	 * Robots decision for a post, independent of the current query.
	 *
	 * @param \WP_Post $post Post.
	 * @return array{index: bool, follow: bool, reason: string}
	 */
	public function for_post( \WP_Post $post ): array {
		if ( 'attachment' === $post->post_type ) {
			return self::no( 'attachment' );
		}
		if ( '' !== $post->post_password ) {
			return self::no( 'password' );
		}
		if ( 'publish' !== get_post_status( $post ) ) {
			return self::no( 'not_published' );
		}
		$override = get_post_meta( $post->ID, '_flseo_noindex', true );
		if ( in_array( $override, array( '1', 1, true ), true ) ) {
			return self::no( 'post_override' );
		}
		if ( 'index' === $override ) {
			return self::yes( 'post_override' );
		}
		$type = $this->c->get( Settings::class )->post_type( $post->post_type );
		return $type['index'] ? self::yes( 'type_setting' ) : self::no( 'type_setting' );
	}

	/**
	 * Robots decision for a term archive (first page).
	 *
	 * @param \WP_Term $term Term.
	 * @return array{index: bool, follow: bool, reason: string}
	 */
	public function for_term( \WP_Term $term ): array {
		$override = get_term_meta( $term->term_id, '_flseo_noindex', true );
		if ( in_array( $override, array( '1', 1, true ), true ) ) {
			return self::no( 'term_override' );
		}
		if ( 'index' === $override ) {
			return self::yes( 'term_override' );
		}
		$tax = $this->c->get( Settings::class )->taxonomy( $term->taxonomy );
		return $tax['index'] ? self::yes( 'taxonomy_setting' ) : self::no( 'taxonomy_setting' );
	}

	/**
	 * Whether a post is indexable (used by the sitemap and bulk tools).
	 *
	 * @param \WP_Post $post Post.
	 */
	public function is_indexable( \WP_Post $post ): bool {
		return $this->for_post( $post )['index'];
	}

	/**
	 * Build the robots meta content value.
	 *
	 * @param array{index: bool, follow: bool} $decision Decision.
	 */
	public function content( array $decision ): string {
		$parts = array( $decision['index'] ? 'index' : 'noindex', $decision['follow'] ? 'follow' : 'nofollow' );
		if ( $decision['index'] && $this->c->get( Settings::class )->get( 'max_image_preview' ) ) {
			$parts[] = 'max-image-preview:large';
			$parts[] = 'max-snippet:-1';
			$parts[] = 'max-video-preview:-1';
		}
		return implode( ', ', $parts );
	}

	/**
	 * Indexable decision.
	 *
	 * @param string $reason Reason code.
	 * @return array{index: bool, follow: bool, reason: string}
	 */
	private static function yes( string $reason ): array {
		return array(
			'index'  => true,
			'follow' => true,
			'reason' => $reason,
		);
	}

	/**
	 * Noindex, follow decision.
	 *
	 * @param string $reason Reason code.
	 * @return array{index: bool, follow: bool, reason: string}
	 */
	private static function no( string $reason ): array {
		return array(
			'index'  => false,
			'follow' => true,
			'reason' => $reason,
		);
	}
}
