<?php
/**
 * Shared behaviour for AI providers (Anthropic, OpenAI, Google Gemini, OpenAI-compatible).
 *
 * Each provider builds its own request and reads its own response; the gating, retry,
 * error and logging rules live here so they stay identical across providers.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Ai;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Crypto;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * One AI provider over the WordPress HTTP API.
 *
 * Hard guard: when the `ai_enabled` setting is off, no HTTP request is made.
 */
abstract class Provider {

	/**
	 * Longest `retry-after` an interactive request waits before giving up.
	 */
	protected const MAX_INTERACTIVE_WAIT = 10;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	protected Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Provider ID stored in the `ai_provider` setting.
	 */
	abstract public function id(): string;

	/**
	 * Human name of the service, used in messages ("the OpenAI API").
	 */
	abstract public function label(): string;

	/**
	 * Option holding the encrypted API key.
	 */
	abstract public function key_option(): string;

	/**
	 * Configured model ID ('' when none is chosen).
	 */
	abstract public function model(): string;

	/**
	 * Image MIME types this provider accepts (empty: no image input).
	 *
	 * @return array<int, string>
	 */
	abstract public function image_types(): array;

	/**
	 * Build the HTTP request.
	 *
	 * @param string                                              $system System prompt.
	 * @param string                                              $text   User text.
	 * @param array<int, array{media_type: string, data: string}> $images Base64 images.
	 * @param string                                              $key    API key.
	 * @return array{url: string, args: array<string, mixed>}
	 */
	abstract protected function request( string $system, string $text, array $images, string $key ): array;

	/**
	 * Read a 200 response.
	 *
	 * @param array<string, mixed> $data Decoded body.
	 * @return array{text: string, stop_reason: string, truncated: bool}|\WP_Error
	 */
	abstract protected function parse( array $data );

	/**
	 * Model IDs offered as suggestions in settings (ID => label).
	 *
	 * @return array<string, string>
	 */
	public function suggested_models(): array {
		return array();
	}

	/**
	 * Fetch the models the key can use from the provider (ID list), or an error.
	 *
	 * @return array<int, string>|\WP_Error
	 */
	public function list_models() {
		return array_keys( $this->suggested_models() );
	}

	/**
	 * Whether the administrator turned AI assist on.
	 */
	public function enabled(): bool {
		return (bool) $this->c->get( Settings::class )->get( 'ai_enabled' );
	}

	/**
	 * Whether an API key is stored.
	 */
	public function has_key(): bool {
		return $this->c->get( Crypto::class )->has_secret( $this->key_option() );
	}

	/**
	 * Whether this provider can be used without a key (e.g. a local server).
	 */
	protected function key_optional(): bool {
		return false;
	}

	/**
	 * Whether alt-text suggestions (image input) are available.
	 */
	public function supports_images(): bool {
		return array() !== $this->image_types();
	}

	/**
	 * Send a message and return the concatenated text.
	 *
	 * @param string                                              $system      System prompt.
	 * @param string                                              $text        User text.
	 * @param array<int, array{media_type: string, data: string}> $images      Images.
	 * @param bool                                                $interactive Retry once on 429/5xx (an admin is waiting); background jobs fail fast instead.
	 * @return array{text: string, stop_reason: string, truncated: bool}|\WP_Error
	 */
	public function send( string $system, string $text, array $images = array(), bool $interactive = true ) {
		if ( ! $this->enabled() ) {
			return new \WP_Error( 'flseo_ai_disabled', __( 'AI assist is turned off. An administrator can enable it in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), array( 'status' => 403 ) );
		}
		$key = $this->c->get( Crypto::class )->get_secret( $this->key_option() );
		if ( '' === $key && ! $this->key_optional() ) {
			/* translators: %s: service name, e.g. "OpenAI". */
			return new \WP_Error( 'flseo_ai_no_key', sprintf( __( 'Add your %s API key in FutureLabs AI SEO settings to use AI assist.', 'futurelabs-ai-seo' ), $this->label() ), array( 'status' => 400 ) );
		}
		if ( '' === $this->model() ) {
			return new \WP_Error( 'flseo_ai_no_model', __( 'Choose a model in FutureLabs AI SEO settings to use AI assist.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( $images && ! $this->supports_images() ) {
			return new \WP_Error( 'flseo_ai_no_images', __( 'The selected AI provider or model cannot read images, so alt text suggestions are not available.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$request = $this->request( $system, $text, $images, $key );
		$args    = array_merge( array( 'timeout' => 60 ), $request['args'] );

		$attempt = 0;
		while ( true ) {
			++$attempt;
			$response = wp_remote_post( $request['url'], $args );
			if ( is_wp_error( $response ) ) {
				$this->log( 0, 'transport' );
				/* translators: %s: service name. */
				return new \WP_Error( 'flseo_ai_unreachable', sprintf( __( 'Could not reach the %s API. Check that this server can make outbound HTTPS requests and try again.', 'futurelabs-ai-seo' ), $this->label() ), array( 'status' => 502 ) );
			}
			$status = (int) wp_remote_retrieve_response_code( $response );
			if ( 200 === $status ) {
				$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
				if ( ! is_array( $data ) ) {
					$this->log( 200, 'invalid_json' );
					/* translators: %s: service name. */
					return new \WP_Error( 'flseo_ai_bad_response', sprintf( __( 'The %s API returned a response FutureLabs AI SEO could not read. Try again.', 'futurelabs-ai-seo' ), $this->label() ), array( 'status' => 502 ) );
				}
				return $this->parse( $data );
			}
			$retry_after = $this->retry_after( $response, $attempt );
			$retryable   = 429 === $status || 529 === $status || $status >= 500;
			if ( $interactive && $retryable && 1 === $attempt && $retry_after <= self::MAX_INTERACTIVE_WAIT ) {
				$this->pause( $retry_after );
				continue;
			}
			return $this->error( $status, (string) wp_remote_retrieve_body( $response ), $retry_after );
		}
	}

	/**
	 * Refusal error (nothing is saved).
	 *
	 * @param string $category Provider category, if any.
	 */
	protected function refusal( string $category = '' ): \WP_Error {
		$this->log( 200, 'refusal' );
		return new \WP_Error(
			'flseo_ai_refusal',
			__( 'The AI declined to make a suggestion for this content, so nothing was saved. You can edit the page manually or try a different page.', 'futurelabs-ai-seo' ),
			array(
				'status'   => 422,
				'category' => $category,
			)
		);
	}

	/**
	 * Friendly error for a non-200 status.
	 *
	 * @param int    $status      HTTP status.
	 * @param string $raw         Body.
	 * @param int    $retry_after Seconds suggested by the API.
	 */
	protected function error( int $status, string $raw, int $retry_after ): \WP_Error {
		$data  = json_decode( $raw, true );
		$error = is_array( $data ) ? ( $data['error'] ?? null ) : null;
		// Anthropic and OpenAI send {error: {type, message}}; Gemini sends {error: {status, message}}; some servers send a bare string.
		$type   = is_array( $error ) ? sanitize_key( (string) ( $error['type'] ?? $error['status'] ?? $error['code'] ?? '' ) ) : '';
		$detail = is_array( $error ) ? (string) ( $error['message'] ?? '' ) : ( is_string( $error ) ? $error : '' );
		$this->log( $status, $type );
		$label = $this->label();
		switch ( true ) {
			case 401 === $status:
				$code = 'flseo_ai_bad_key';
				/* translators: %s: service name. */
				$message = sprintf( __( 'The %s API rejected the API key. Check the key in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), $label );
				break;
			case 403 === $status:
				$code = 'flseo_ai_forbidden';
				/* translators: %s: service name. */
				$message = sprintf( __( 'This API key is not allowed to use the selected model or feature. Check the key permissions in your %s account.', 'futurelabs-ai-seo' ), $label );
				break;
			case 404 === $status:
				$code = 'flseo_ai_model';
				/* translators: %s: service name. */
				$message = sprintf( __( 'The selected %s model was not found. Choose another model in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), $label );
				break;
			case 429 === $status:
				$code = 'flseo_ai_rate_limited';
				/* translators: %s: service name. */
				$message = sprintf( __( 'The %s API rate limit was reached. Wait a minute and try again.', 'futurelabs-ai-seo' ), $label );
				break;
			case 529 === $status || $status >= 500:
				$code = 'flseo_ai_overloaded';
				/* translators: %s: service name. */
				$message = sprintf( __( 'The %s API is temporarily overloaded or unavailable. Try again in a few minutes.', 'futurelabs-ai-seo' ), $label );
				break;
			case 413 === $status:
				$code    = 'flseo_ai_too_large';
				$message = __( 'The content is too large to send. Try a smaller image or a shorter page.', 'futurelabs-ai-seo' );
				break;
			default:
				$code = 'flseo_ai_invalid_request';
				/* translators: %s: service name. */
				$message = sprintf( __( 'The %s API could not process this request. Check the selected model in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), $label );
		}
		// Add the API's own explanation (e.g. "Your credit balance is too low…") so the
		// cause is visible without server access. It never contains the key or prompt; scrub anyway.
		$detail = trim( $detail );
		if ( '' !== $detail && $status < 500 && 429 !== $status ) {
			$detail = Logger::scrub( wp_strip_all_tags( $detail ) );
			if ( mb_strlen( $detail ) > 300 ) {
				$detail = mb_substr( $detail, 0, 300 ) . '…';
			}
			/* translators: 1: friendly error, 2: service name, 3: message from the API. */
			$message = sprintf( __( '%1$s %2$s API said: %3$s', 'futurelabs-ai-seo' ), $message, $label, $detail );
		}
		return new \WP_Error(
			$code,
			$message,
			array(
				'status'      => 429 === $status ? 429 : 502,
				'api_status'  => $status,
				'api_error'   => $type,
				'retry_after' => $retry_after,
			)
		);
	}

	/**
	 * GET a JSON endpoint (used to list models).
	 *
	 * @param string                $url     URL.
	 * @param array<string, string> $headers Headers.
	 * @return array<string, mixed>|\WP_Error
	 */
	protected function get_json( string $url, array $headers ) {
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 20,
				'headers' => $headers,
			)
		);
		if ( is_wp_error( $response ) ) {
			/* translators: %s: service name. */
			return new \WP_Error( 'flseo_ai_unreachable', sprintf( __( 'Could not reach the %s API. Check that this server can make outbound HTTPS requests and try again.', 'futurelabs-ai-seo' ), $this->label() ), array( 'status' => 502 ) );
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status ) {
			return $this->error( $status, (string) wp_remote_retrieve_body( $response ), 0 );
		}
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Seconds to wait before retrying: `retry-after` when present, else backoff.
	 *
	 * @param array<string, mixed> $response Response.
	 * @param int                  $attempt  Attempt number.
	 */
	protected function retry_after( array $response, int $attempt ): int {
		$header = wp_remote_retrieve_header( $response, 'retry-after' );
		if ( is_array( $header ) ) {
			$header = (string) reset( $header );
		}
		if ( is_numeric( $header ) ) {
			return max( 0, (int) ceil( (float) $header ) );
		}
		/**
		 * Backoff in seconds before retrying an overloaded request.
		 *
		 * @param int $seconds Default delay.
		 * @param int $attempt Attempt that failed.
		 */
		return max( 0, (int) apply_filters( 'flseo_ai_retry_delay', 2 * $attempt, $attempt ) );
	}

	/**
	 * Sleep between attempts.
	 *
	 * @param int $seconds Seconds.
	 */
	protected function pause( int $seconds ): void {
		if ( $seconds > 0 ) {
			sleep( $seconds );
		}
	}

	/**
	 * Log provider, status and error type only (never the key, prompt or response text).
	 *
	 * @param int    $status HTTP status (0 for transport errors).
	 * @param string $type   Error type.
	 */
	protected function log( int $status, string $type ): void {
		$this->c->get( Logger::class )->warning(
			'AI provider request did not produce a suggestion.',
			array(
				'provider' => $this->id(),
				'status'   => $status,
				'type'     => $type,
			)
		);
	}
}
