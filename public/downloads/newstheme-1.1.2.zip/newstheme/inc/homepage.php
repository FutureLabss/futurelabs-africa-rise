<?php
/**
 * Homepage sections. Each section is a list of blocks (see inc/blocks.php),
 * optionally beside a widget-area sidebar. Order/visibility come from the
 * "Sections Order" control; each section's blocks and sidebar position are
 * edited in Customizer → Homepage Sections (inc/customizer/config/homepage.php).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Section definitions.
 *
 * @return array<string, array{label: string, sidebar: ?string, position: string, types: string[], blocks: array}>
 */
function newstheme_homepage_section_defs() {
	static $defs = null;
	if ( null !== $defs ) {
		return $defs;
	}

	$cat = static function ( $slug ) {
		$term = get_category_by_slug( $slug );
		return $term ? (int) $term->term_id : 0;
	};

	$content_types = array( 'news-grid', 'news-list', 'news-filter', 'news-carousel', 'ad' );

	$defs = array(
		'ticker'                => array(
			'label'    => __( 'Ticker News Bar', 'newstheme' ),
			'sidebar'  => null,
			'position' => 'none',
			'types'    => array(),
			'blocks'   => array(),
		),
		'banner'                => array(
			'label'    => __( 'Main Banner', 'newstheme' ),
			'sidebar'  => null,
			'position' => 'none',
			'types'    => array( 'banner', 'ad' ),
			'blocks'   => array(
				array( 'type' => 'banner' ),
			),
		),
		'content-right-sidebar' => array(
			'label'    => __( 'Content With Sidebar', 'newstheme' ),
			'sidebar'  => 'home-middle-right',
			'position' => 'right',
			'types'    => $content_types,
			'blocks'   => array(
				array(
					'type'    => 'news-grid',
					'title'   => __( 'Trending Now', 'newstheme' ),
					'columns' => 3,
					'query'   => array(
						'count'   => 3,
						'orderby' => 'comment_count',
					),
				),
				array(
					'type'  => 'news-filter',
					'title' => __( 'Random News', 'newstheme' ),
					'tabs'  => array_values( array_filter( array( $cat( 'fashion' ), $cat( 'lifestyle' ), $cat( 'sports' ) ) ) ),
					'query' => array(
						'count'   => 6,
						'orderby' => 'rand',
					),
				),
				array( 'type' => 'ad' ),
				array(
					'type'  => 'news-list',
					'title' => __( 'Latest News', 'newstheme' ),
					'query' => array( 'count' => 3 ),
				),
			),
		),
		'full-width'            => array(
			'label'    => __( 'Full Width', 'newstheme' ),
			'sidebar'  => null,
			'position' => 'none',
			'types'    => array_merge( array( 'banner' ), $content_types ),
			'blocks'   => array(
				array(
					'type'    => 'news-list',
					'title'   => __( "Editor's Choice", 'newstheme' ),
					'layout'  => 'two',
					'columns' => 3,
					'meta'    => array( 'author', 'comments' ),
					'query'   => array(
						'count'  => 9,
						'offset' => 3,
					),
				),
			),
		),
		'left-sidebar-content'  => array(
			'label'    => __( 'Sidebar With Content', 'newstheme' ),
			'sidebar'  => 'home-middle-left',
			'position' => 'left',
			'types'    => $content_types,
			'blocks'   => array(
				array(
					'type'    => 'news-grid',
					'title'   => __( 'Featured Story', 'newstheme' ),
					'layout'  => 'two',
					'columns' => 2,
					'meta'    => array( 'author', 'date', 'comments' ),
					'query'   => array(
						'count'  => 4,
						'offset' => 12,
					),
				),
			),
		),
		'video'                 => array(
			'label'    => __( 'Video Playlist', 'newstheme' ),
			'sidebar'  => null,
			'position' => 'none',
			'types'    => array(),
			'blocks'   => array(),
		),
		'bottom-full-width'     => array(
			'label'    => __( 'Bottom Full Width', 'newstheme' ),
			'sidebar'  => null,
			'position' => 'none',
			'types'    => array_merge( array( 'banner' ), $content_types ),
			'blocks'   => array(
				array(
					'type'  => 'news-carousel',
					'title' => __( 'Latest Posts', 'newstheme' ),
					'query' => array( 'count' => 8 ),
				),
			),
		),
		'opinions'              => array(
			'label'    => __( 'Opinions (when set to homepage)', 'newstheme' ),
			'sidebar'  => null,
			'position' => 'none',
			'types'    => array(),
			'blocks'   => array(),
		),
	);

	$defs = apply_filters( 'newstheme_homepage_section_defs', $defs );
	return $defs;
}

/**
 * Placeholder shown in an ad block with nothing configured — only to users who
 * can fix it, so visitors never see an empty "ad here" box.
 *
 * @return string
 */
function newstheme_placeholder_ad_html() {
	if ( ! current_user_can( 'edit_theme_options' ) && ! apply_filters( 'newstheme_show_placeholder_ads', false ) ) {
		return '';
	}
	return '<div class="nt-ad__placeholder"><strong>' . esc_html__( 'Your Ad Here', 'newstheme' ) . '</strong><span>' . esc_html__( 'Set an image or ad code in Customizer → Homepage Sections', 'newstheme' ) . '</span></div>';
}

/**
 * Render one homepage section. Always prints the wrapper (even when empty) so
 * the Customizer's selective refresh can find it.
 *
 * @param string $id Section ID.
 */
function newstheme_render_homepage_section( $id ) {
	$defs = newstheme_homepage_section_defs();
	if ( ! isset( $defs[ $id ] ) ) {
		return;
	}
	$def = $defs[ $id ];

	if ( 'video' === $id ) {
		echo '<div class="nt-section nt-section--video">';
		get_template_part( 'template-parts/sections/video' );
		echo '</div>';
		return;
	}
	if ( 'opinions' === $id ) {
		if ( 'homepage' === newstheme_get_mod( 'opinions_location' ) ) {
			echo '<div class="nt-section nt-section--opinions">';
			newstheme_render_opinions_wrap();
			echo '</div>';
		}
		return;
	}

	if ( 'ticker' === $id ) {
		echo '<div class="nt-section nt-section--ticker"><div class="nt-container"><div class="nt-ticker-bar">';
		get_template_part( 'template-parts/header/ticker' );
		echo '</div></div></div>';
		return;
	}

	$blocks      = (array) newstheme_get_mod( "section_{$id}_blocks" );
	$position    = $def['sidebar'] ? newstheme_get_mod( "section_{$id}_sidebar" ) : 'none';
	$has_sidebar = 'none' !== $position && is_active_sidebar( $def['sidebar'] );
	$position    = $has_sidebar ? $position : 'none';

	do_action( 'newstheme_before_homepage_section', $id );
	printf( '<div class="nt-section nt-section--%s">', esc_attr( $id ) );
	if ( $blocks || $has_sidebar ) {
		echo '<div class="nt-container">';
		printf( '<div class="nt-section__layout nt-section__layout--sidebar-%s">', esc_attr( $position ) );

		echo '<div class="nt-section__main">';
		foreach ( $blocks as $block ) {
			$type = $block['type'] ?? '';
			if ( 'ad' === $type && empty( $block['image'] ) && '' === trim( (string) ( $block['html'] ?? '' ) ) ) {
				$block['html'] = newstheme_placeholder_ad_html();
			}
			newstheme_render_block( $type, $block );
		}
		echo '</div>';

		if ( $has_sidebar ) {
			echo '<aside class="nt-section__sidebar" aria-label="' . esc_attr__( 'Sidebar', 'newstheme' ) . '">';
			dynamic_sidebar( $def['sidebar'] );
			echo '</aside>';
		}

		echo '</div></div>';
	}
	echo '</div>';
	do_action( 'newstheme_after_homepage_section', $id );
}

/**
 * Render all enabled homepage sections in the configured order.
 */
function newstheme_render_homepage() {
	echo '<div class="nt-homepage">';
	// Sanitizing appends sections added since the order was saved (e.g. new
	// theme versions), so they appear without re-saving the Customizer.
	$order = newstheme_sanitize_sortable( newstheme_get_mod( 'homepage_sections' ), newstheme_all_settings()['homepage_sections'] );
	foreach ( $order as $item ) {
		if ( ! empty( $item['enabled'] ) ) {
			newstheme_render_homepage_section( $item['id'] ?? '' );
		}
	}
	echo '</div>';
}
