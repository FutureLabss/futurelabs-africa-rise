<?php
/**
 * Homepage section: video playlist. The player is a poster image until a
 * visitor presses play; only then is the (privacy-enhanced) YouTube iframe added.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_videos = newstheme_video_items();
if ( ! $newstheme_videos ) {
	if ( current_user_can( 'edit_theme_options' ) ) {
		printf(
			'<div class="nt-container"><p class="nt-ad__placeholder">%s</p></div>',
			esc_html__( 'Add YouTube links in Customizer → Homepage Sections → Video Playlist.', 'newstheme' )
		);
	}
	return;
}
$newstheme_first = $newstheme_videos[0];
?>
<div class="nt-video-band">
	<div class="nt-container">
		<div class="nt-video" data-nt-video>
			<div class="nt-video__player">
				<button type="button" class="nt-video__poster" data-nt-video-play aria-label="<?php echo esc_attr( sprintf( /* translators: %s: video title. */ __( 'Play video: %s', 'newstheme' ), $newstheme_first['title'] ) ); ?>">
					<img src="<?php echo esc_url( $newstheme_first['poster'] ); ?>" alt="" loading="lazy" width="480" height="360">
					<span class="nt-video__play" aria-hidden="true"><?php newstheme_icon( 'play' ); ?></span>
				</button>
			</div>
			<div class="nt-video__side">
				<div class="nt-video__now">
					<button type="button" class="nt-video__toggle" data-nt-video-toggle aria-pressed="false" aria-label="<?php esc_attr_e( 'Play', 'newstheme' ); ?>"><?php newstheme_icon( 'play' ); ?><?php newstheme_icon( 'pause' ); ?></button>
					<div>
						<p class="nt-video__now-title" data-nt-video-title><?php echo esc_html( $newstheme_first['title'] ); ?></p>
						<span class="nt-video__duration" data-nt-video-duration><?php echo esc_html( $newstheme_first['duration'] ); ?></span>
					</div>
				</div>
				<ol class="nt-video__list" aria-label="<?php esc_attr_e( 'Playlist', 'newstheme' ); ?>">
					<?php foreach ( $newstheme_videos as $newstheme_i => $newstheme_video ) : ?>
						<li>
							<button type="button" class="nt-video__item<?php echo 0 === $newstheme_i ? ' is-active' : ''; ?>" <?php echo 0 === $newstheme_i ? 'aria-current="true"' : ''; ?> data-id="<?php echo esc_attr( $newstheme_video['id'] ); ?>" data-title="<?php echo esc_attr( $newstheme_video['title'] ); ?>" data-duration="<?php echo esc_attr( $newstheme_video['duration'] ); ?>" data-poster="<?php echo esc_url( $newstheme_video['poster'] ); ?>">
								<img src="<?php echo esc_url( $newstheme_video['thumb'] ); ?>" alt="" loading="lazy" width="320" height="180">
								<span class="nt-video__item-text">
									<span class="nt-video__item-title"><?php echo esc_html( $newstheme_video['title'] ); ?></span>
									<?php if ( $newstheme_video['duration'] ) : ?>
										<span class="nt-video__duration"><?php echo esc_html( $newstheme_video['duration'] ); ?></span>
									<?php endif; ?>
								</span>
							</button>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>
		</div>
	</div>
</div>
