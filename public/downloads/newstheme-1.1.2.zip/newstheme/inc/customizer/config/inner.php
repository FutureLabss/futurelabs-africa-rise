<?php
/**
 * Options for inner pages: archives, single posts, pages, breadcrumbs.
 * See inc/customizer/config.php for the setting format.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_sidebar_choices = array(
	'right'      => __( 'Right', 'newstheme' ),
	'left'       => __( 'Left', 'newstheme' ),
	'both'       => __( 'Both Sides', 'newstheme' ),
	'right-both' => __( 'Two on Right', 'newstheme' ),
	'none'       => __( 'None', 'newstheme' ),
);
$newstheme_sidebar_help    = __( '"Right" uses the Sidebar widget area; "Left" uses Left Sidebar; the two-sidebar layouts use both.', 'newstheme' );

return array(
	'panels'   => array(
		'newstheme_inner' => array(
			'title'    => __( 'Posts & Pages', 'newstheme' ),
			'priority' => 23,
		),
	),
	'sections' => array(
		'newstheme_archive'     => array(
			'title' => __( 'Blog & Archives', 'newstheme' ),
			'panel' => 'newstheme_inner',
		),
		'newstheme_single'      => array(
			'title' => __( 'Single Post', 'newstheme' ),
			'panel' => 'newstheme_inner',
		),
		'newstheme_page'        => array(
			'title' => __( 'Pages', 'newstheme' ),
			'panel' => 'newstheme_inner',
		),
		'newstheme_breadcrumbs' => array(
			'title' => __( 'Breadcrumbs', 'newstheme' ),
			'panel' => 'newstheme_inner',
		),
	),
	'settings' => array(
		// Archives.
		'archive_sidebar'       => array(
			'section'     => 'newstheme_archive',
			'control'     => 'select',
			'label'       => __( 'Sidebar Layout', 'newstheme' ),
			'description' => $newstheme_sidebar_help,
			'default'     => 'right-both',
			'choices'     => $newstheme_sidebar_choices,
		),
		'archive_layout'        => array(
			'section' => 'newstheme_archive',
			'control' => 'buttons',
			'label'   => __( 'Post Layout', 'newstheme' ),
			'default' => 'list',
			'choices' => array(
				'list' => __( 'List', 'newstheme' ),
				'grid' => __( 'Grid', 'newstheme' ),
			),
		),
		'archive_hero'          => array(
			'section'     => 'newstheme_archive',
			'control'     => 'toggle',
			'label'       => __( 'Feature the newest post at the top', 'newstheme' ),
			'description' => __( 'First page of category, tag and author archives.', 'newstheme' ),
			'default'     => true,
		),
		'archive_excerpt'       => array(
			'section' => 'newstheme_archive',
			'control' => 'number',
			'label'   => __( 'Excerpt Length (words)', 'newstheme' ),
			'default' => 14,
			'min'     => 0,
			'max'     => 60,
		),
		'archive_title_prefix'  => array(
			'section'     => 'newstheme_archive',
			'control'     => 'toggle',
			'label'       => __( 'Show title prefix', 'newstheme' ),
			'description' => __( 'e.g. "Category: Fashion" instead of "Fashion".', 'newstheme' ),
			'default'     => false,
		),

		// Single post.
		'single_sidebar'        => array(
			'section'     => 'newstheme_single',
			'control'     => 'select',
			'label'       => __( 'Sidebar Layout', 'newstheme' ),
			'description' => $newstheme_sidebar_help,
			'default'     => 'right-both',
			'choices'     => $newstheme_sidebar_choices,
		),
		'single_meta'           => array(
			'section'     => 'newstheme_single',
			'control'     => 'sortable',
			'label'       => __( 'Post Meta', 'newstheme' ),
			'description' => __( 'Drag to reorder. Untick to hide.', 'newstheme' ),
			'choices'     => array(
				'author'       => __( 'Author', 'newstheme' ),
				'date'         => __( 'Date', 'newstheme' ),
				'comments'     => __( 'Comments', 'newstheme' ),
				'reading-time' => __( 'Reading Time', 'newstheme' ),
			),
			'default'     => array(
				array(
					'id'      => 'author',
					'enabled' => true,
				),
				array(
					'id'      => 'date',
					'enabled' => true,
				),
				array(
					'id'      => 'comments',
					'enabled' => true,
				),
				array(
					'id'      => 'reading-time',
					'enabled' => true,
				),
			),
		),
		'single_image'          => array(
			'section' => 'newstheme_single',
			'control' => 'toggle',
			'label'   => __( 'Show featured image', 'newstheme' ),
			'default' => true,
		),
		'single_tags'           => array(
			'section' => 'newstheme_single',
			'control' => 'toggle',
			'label'   => __( 'Show tags', 'newstheme' ),
			'default' => true,
		),
		'single_share'          => array(
			'section' => 'newstheme_single',
			'control' => 'toggle',
			'label'   => __( 'Show share buttons', 'newstheme' ),
			'default' => true,
		),
		'single_author_box'     => array(
			'section' => 'newstheme_single',
			'control' => 'toggle',
			'label'   => __( 'Show author box', 'newstheme' ),
			'default' => true,
		),
		'single_post_nav'       => array(
			'section' => 'newstheme_single',
			'control' => 'toggle',
			'label'   => __( 'Show previous/next links', 'newstheme' ),
			'default' => true,
		),
		'heading_related'       => array(
			'section' => 'newstheme_single',
			'control' => 'heading',
			'label'   => __( 'Related Posts', 'newstheme' ),
		),
		'single_related'        => array(
			'section' => 'newstheme_single',
			'control' => 'toggle',
			'label'   => __( 'Show related posts', 'newstheme' ),
			'default' => true,
		),
		'single_related_title'  => array(
			'section' => 'newstheme_single',
			'control' => 'text',
			'label'   => __( 'Title', 'newstheme' ),
			'default' => __( 'Related News', 'newstheme' ),
			'show_if' => array( 'single_related', 'true' ),
		),
		'single_related_count'  => array(
			'section' => 'newstheme_single',
			'control' => 'number',
			'label'   => __( 'Number of Posts', 'newstheme' ),
			'default' => 4,
			'min'     => 1,
			'max'     => 12,
			'show_if' => array( 'single_related', 'true' ),
		),
		'single_related_layout' => array(
			'section' => 'newstheme_single',
			'control' => 'buttons',
			'label'   => __( 'Layout', 'newstheme' ),
			'default' => 'list',
			'choices' => array(
				'list' => __( 'List', 'newstheme' ),
				'grid' => __( 'Grid', 'newstheme' ),
			),
			'show_if' => array( 'single_related', 'true' ),
		),

		// Pages.
		'page_sidebar'          => array(
			'section'     => 'newstheme_page',
			'control'     => 'select',
			'label'       => __( 'Sidebar Layout', 'newstheme' ),
			'description' => $newstheme_sidebar_help,
			'default'     => 'right',
			'choices'     => $newstheme_sidebar_choices,
		),

		// Breadcrumbs.
		'breadcrumbs'           => array(
			'section'     => 'newstheme_breadcrumbs',
			'control'     => 'toggle',
			'label'       => __( 'Show breadcrumbs', 'newstheme' ),
			'description' => __( 'Uses Yoast SEO or Rank Math breadcrumbs when those plugins have them enabled.', 'newstheme' ),
			'default'     => true,
		),
	),
);
