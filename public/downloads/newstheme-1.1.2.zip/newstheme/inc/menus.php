<?php
/**
 * Menu enhancements: sub-menu toggle buttons and description badges.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Add a toggle button after parent items in the primary menu, so sub-menus
 * work with keyboard and touch (hover alone isn't enough).
 *
 * @param string   $output Item output.
 * @param WP_Post  $item   Menu item.
 * @param int      $depth  Depth.
 * @param stdClass $args   wp_nav_menu() args.
 * @return string
 */
function newstheme_submenu_toggle( $output, $item, $depth, $args ) {
	if ( 'primary' !== ( $args->theme_location ?? '' ) || ! in_array( 'menu-item-has-children', (array) $item->classes, true ) ) {
		return $output;
	}

	$label = sprintf(
		/* translators: %s: menu item title. */
		__( 'Show sub-menu for %s', 'newstheme' ),
		wp_strip_all_tags( $item->title )
	);

	return $output . sprintf(
		'<button class="nt-submenu-toggle" type="button" aria-expanded="false" aria-label="%s">%s</button>',
		esc_attr( $label ),
		newstheme_get_icon( 'chevron-down' )
	);
}
add_filter( 'walker_nav_menu_start_el', 'newstheme_submenu_toggle', 10, 4 );

/**
 * Show a top-level menu item's description as a small badge (e.g. "New").
 *
 * @param string   $title Item title.
 * @param WP_Post  $item  Menu item.
 * @param stdClass $args  wp_nav_menu() args.
 * @param int      $depth Depth.
 * @return string
 */
function newstheme_menu_badge( $title, $item, $args, $depth ) {
	if ( 0 === $depth && 'primary' === ( $args->theme_location ?? '' ) && ! empty( $item->description ) ) {
		$title .= '<span class="nt-menu-badge">' . esc_html( $item->description ) . '</span>';
	}
	return $title;
}
add_filter( 'nav_menu_item_title', 'newstheme_menu_badge', 10, 4 );
