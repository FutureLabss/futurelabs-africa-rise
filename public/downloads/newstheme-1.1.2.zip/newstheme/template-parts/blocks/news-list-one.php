<?php
/**
 * Block: news list — large rows with excerpt and "read more".
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args (see newstheme_block_types()).
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="nt-block nt-block--list nt-block--list-one" <?php echo $args['title'] ? 'aria-labelledby="' . esc_attr( $args['id'] ) . '-title"' : ''; ?>>
	<?php newstheme_block_heading( $args['title'], $args['id'] ); ?>
	<div class="nt-grid nt-grid--<?php echo (int) $args['columns']; ?>">
		<?php
		while ( $args['loop']->have_posts() ) :
			$args['loop']->the_post();
			?>
			<article <?php post_class( 'nt-post nt-post--row' ); ?> data-nt-animate>
				<?php newstheme_post_thumb( 'newstheme-medium', array( 'badge' => true ) ); ?>
				<div class="nt-post__body">
					<?php
					newstheme_post_title( 'h3' );
					newstheme_post_meta( $args['meta'] );
					if ( $args['excerpt'] ) {
						newstheme_post_excerpt( $args['excerpt'] );
					}
					if ( $args['read_more'] ) {
						newstheme_read_more();
					}
					?>
				</div>
			</article>
		<?php endwhile; ?>
	</div>
</section>
