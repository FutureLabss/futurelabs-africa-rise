<?php
/**
 * Small, dependency-free helpers used across the theme.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Version string for a theme asset.
 *
 * Uses the file's modification time while developing so browsers never serve
 * stale CSS/JS, and the theme version in production.
 *
 * @param string $relative_path Path relative to the theme root.
 * @return string
 */
function newstheme_asset_version( $relative_path ) {
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		$file = NEWSTHEME_DIR . ltrim( $relative_path, '/' );
		if ( file_exists( $file ) ) {
			return (string) filemtime( $file );
		}
	}
	return NEWSTHEME_VERSION;
}
