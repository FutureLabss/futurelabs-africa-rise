<?php
/**
 * Search results.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();
newstheme_layout_open( 'archive' );
get_template_part(
	'template-parts/content/archive-list',
	null,
	array(
		/* translators: %s: search query. */
		'title'       => sprintf( __( 'Search results for: %s', 'newstheme' ), '<span class="nt-search-term">' . esc_html( get_search_query() ) . '</span>' ),
		'description' => '',
		'search_form' => true,
	)
);
newstheme_layout_close();
get_footer();
