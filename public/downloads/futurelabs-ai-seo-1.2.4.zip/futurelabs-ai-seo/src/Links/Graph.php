<?php
/**
 * Internal link graph: content, menu and widget links, inbound/outbound counts and click depth.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Links;

use FutureLabs\AISEO\Content\Analyzer;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;

defined( 'ABSPATH' ) || exit;

/**
 * Stores links in `flseo_links` and computes `flseo_link_stats`.
 *
 * Content links are written by the content analyzer as it renders each post, so a
 * post is rendered once per scan. The graph job rebuilds menu and widget links,
 * then computes counts and click depth from the home page.
 */
class Graph implements Module {

	public const STATE_OPTION = 'flseo_graph_state';
	public const MAX_DEPTH    = 99;
	public const DEEP         = 4;
	public const WEAK         = 2;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'flseo_graph_compute', array( $this, 'compute' ) );
		add_action( 'flseo_daily', array( $this, 'schedule' ) );
	}

	/**
	 * Queue a graph computation.
	 */
	public function schedule(): void {
		$this->c->get( Queue::class )->async( 'flseo_graph_compute' );
	}

	/**
	 * Last computation summary.
	 *
	 * @return array<string, mixed>
	 */
	public function state(): array {
		$state = get_option( self::STATE_OPTION, array() );
		return wp_parse_args(
			is_array( $state ) ? $state : array(),
			array(
				'computed_at' => '',
				'posts'       => 0,
				'links'       => 0,
				'orphans'     => 0,
				'weak'        => 0,
				'deep'        => 0,
				'unreachable' => 0,
				'broken'      => 0,
				'status'      => 'idle',
			)
		);
	}

	/**
	 * Replace the content links of one post.
	 *
	 * @param int                                             $post_id Source post.
	 * @param array<int, array{href: string, anchor: string}> $links   Links found in its content.
	 */
	public function store_content_links( int $post_id, array $links ): void {
		global $wpdb;
		$table = Migrations::table( 'links' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete(
			$table,
			array(
				'from_post_id' => $post_id,
				'source'       => 'content',
			),
			array( '%d', '%s' )
		);
		$crawler = $this->c->get( Crawler::class );
		$rows    = array();
		$seen    = array();
		foreach ( $links as $link ) {
			if ( count( $rows ) >= 500 ) {
				break;
			}
			if ( ! Crawler::is_internal( $link['href'] ) ) {
				continue;
			}
			$target = $crawler->resolve( $link['href'] );
			if ( 'post' === $target['kind'] && $target['post_id'] > 0 && $target['post_id'] !== $post_id ) {
				$key = 'p' . $target['post_id'];
				$url = '';
			} elseif ( 'broken' === $target['kind'] ) {
				$url = esc_url_raw( Crawler::absolute( $link['href'] ) );
				$key = 'u' . $url;
			} else {
				continue;
			}
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$rows[]       = $wpdb->prepare( '(%d, %d, %s, %s, %s)', $post_id, 'post' === $target['kind'] ? $target['post_id'] : 0, substr( $url, 0, 2048 ), self::trim_anchor( $link['anchor'] ), 'content' );
		}
		if ( $rows ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared -- rows are prepared above.
			$wpdb->query( "INSERT INTO {$table} (from_post_id, to_post_id, to_url, anchor, source) VALUES " . implode( ',', $rows ) );
		}
	}

	/**
	 * Anchor text limited to the column size.
	 *
	 * @param string $anchor Anchor.
	 */
	private static function trim_anchor( string $anchor ): string {
		$anchor = sanitize_text_field( $anchor );
		return function_exists( 'mb_substr' ) ? mb_substr( $anchor, 0, 500 ) : substr( $anchor, 0, 500 );
	}

	/**
	 * Full computation: refresh stale content links, rebuild navigation links, then
	 * write inbound/outbound counts and click depth for every published post.
	 */
	public function compute(): void {
		try {
			$this->c->get( Crawler::class )->reset();
			if ( ! $this->refresh_stale() ) {
				return;
			}
			$nav = $this->navigation_targets();
			$this->store_navigation_links( $nav );
			$this->clean();
			$this->write_stats( $nav );
		} catch ( \Throwable $e ) {
			$this->c->get( Logger::class )->error( 'Link graph computation failed.', array( 'error' => $e->getMessage() ) );
		}
	}

	/**
	 * Scan posts whose content links are missing or older than the post.
	 *
	 * @return bool False when a full content scan was started instead (it queues this job when done).
	 */
	private function refresh_stale(): bool {
		global $wpdb;
		$types = Analyzer::post_types();
		if ( ! $types ) {
			return true;
		}
		$scan = Migrations::table( 'content_scan' );
		$in   = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$stale = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p LEFT JOIN {$scan} s ON s.post_id = p.ID WHERE p.post_status = 'publish' AND p.post_type IN ({$in}) AND (s.post_id IS NULL OR s.scanned_at < p.post_modified_gmt) ORDER BY p.ID ASC LIMIT 201", $types ) ) );
		if ( count( $stale ) > 200 ) {
			$analyzer = $this->c->get( Analyzer::class );
			if ( 'running' !== $analyzer->progress()['status'] ) {
				$analyzer->start();
			}
			$state           = $this->state();
			$state['status'] = 'waiting_for_scan';
			update_option( self::STATE_OPTION, $state, false );
			return false;
		}
		$analyzer = $this->c->get( Analyzer::class );
		foreach ( $stale as $id ) {
			$analyzer->scan_post( $id, true );
		}
		return true;
	}

	/**
	 * Remove links from posts that are no longer published.
	 */
	private function clean(): void {
		global $wpdb;
		$table = Migrations::table( 'links' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$wpdb->query( "DELETE l FROM {$table} l LEFT JOIN {$wpdb->posts} p ON p.ID = l.from_post_id WHERE l.from_post_id > 0 AND (p.ID IS NULL OR p.post_status <> 'publish')" );
	}

	/**
	 * Everything linked from site-wide navigation: assigned menu locations, navigation
	 * blocks, and widgets in active sidebars.
	 *
	 * @return array{posts: array<int, string>, terms: array<int, array<int, string>>, all_categories: string, all_pages: string, recent: array<int, string>, broken: array<int, array{url: string, anchor: string, source: string}>, locations: array<int, array<string, mixed>>}
	 */
	public function navigation_targets(): array {
		$nav        = array(
			'posts'          => array(),
			'terms'          => array(),
			'all_categories' => '',
			'all_pages'      => '',
			'recent'         => array(),
			'broken'         => array(),
			'locations'      => array(),
		);
		$registered = get_registered_nav_menus();
		foreach ( (array) get_nav_menu_locations() as $location => $menu_id ) {
			$menu = $menu_id ? wp_get_nav_menu_object( (int) $menu_id ) : false;
			if ( ! $menu ) {
				continue;
			}
			$nav['locations'][] = array(
				'location'  => (string) $location,
				'label'     => (string) ( $registered[ $location ] ?? $location ),
				'menu_id'   => (int) $menu->term_id,
				'menu_name' => (string) $menu->name,
			);
			$this->collect_menu( (int) $menu->term_id, 'menu:' . $location, 'menu', $nav );
		}
		$navigations = get_posts(
			array(
				'post_type'      => 'wp_navigation',
				'post_status'    => 'publish',
				'posts_per_page' => 20,
				'no_found_rows'  => true,
			)
		);
		foreach ( $navigations as $navigation ) {
			$this->collect_blocks( parse_blocks( (string) $navigation->post_content ), 'navigation_block', 'menu', $nav );
		}
		$this->collect_widgets( $nav );
		return $nav;
	}

	/**
	 * Add one classic menu's items.
	 *
	 * @param int                  $menu_id Menu term ID.
	 * @param string               $via     Label of where the link appears.
	 * @param string               $source  links.source value.
	 * @param array<string, mixed> $nav     Accumulator.
	 */
	private function collect_menu( int $menu_id, string $via, string $source, array &$nav ): void {
		$items = wp_get_nav_menu_items( $menu_id, array( 'update_post_term_cache' => false ) );
		foreach ( is_array( $items ) ? $items : array() as $item ) {
			$type   = (string) ( $item->type ?? '' );
			$object = (int) ( $item->object_id ?? 0 );
			if ( 'post_type' === $type && $object ) {
				$this->add_post_target( $object, $via, $nav );
			} elseif ( 'taxonomy' === $type && $object ) {
				$nav['terms'][ $object ][] = $via;
			} else {
				$this->add_url_target( (string) ( $item->url ?? '' ), (string) ( $item->title ?? '' ), $via, $source, $nav );
			}
		}
	}

	/**
	 * Add a post target if published.
	 *
	 * @param int                  $post_id Post ID.
	 * @param string               $via     Where it appears.
	 * @param array<string, mixed> $nav     Accumulator.
	 */
	private function add_post_target( int $post_id, string $via, array &$nav ): void {
		if ( 'publish' === get_post_status( $post_id ) && ! isset( $nav['posts'][ $post_id ] ) ) {
			$nav['posts'][ $post_id ] = $via;
		}
	}

	/**
	 * Resolve and add a URL target.
	 *
	 * @param string               $url    URL.
	 * @param string               $anchor Anchor.
	 * @param string               $via    Where it appears.
	 * @param string               $source links.source value.
	 * @param array<string, mixed> $nav    Accumulator.
	 */
	private function add_url_target( string $url, string $anchor, string $via, string $source, array &$nav ): void {
		if ( '' === $url || ! Crawler::is_internal( $url ) ) {
			return;
		}
		$crawler = $this->c->get( Crawler::class );
		$target  = $crawler->resolve( $url );
		if ( 'post' === $target['kind'] && $target['post_id'] ) {
			$this->add_post_target( $target['post_id'], $via, $nav );
		} elseif ( 'term' === $target['kind'] ) {
			$term = $crawler->term_for_url( Crawler::absolute( $url ) );
			if ( $term ) {
				$nav['terms'][ (int) $term->term_id ][] = $via;
			}
		} elseif ( 'broken' === $target['kind'] ) {
			$nav['broken'][] = array(
				'url'    => esc_url_raw( Crawler::absolute( $url ) ),
				'anchor' => self::trim_anchor( $anchor ),
				'source' => $source,
			);
		}
	}

	/**
	 * Walk navigation or widget blocks.
	 *
	 * @param array<int, array<string, mixed>> $blocks Parsed blocks.
	 * @param string                           $via    Where they appear.
	 * @param string                           $source links.source value.
	 * @param array<string, mixed>             $nav    Accumulator.
	 */
	private function collect_blocks( array $blocks, string $via, string $source, array &$nav ): void {
		foreach ( $blocks as $block ) {
			$name  = (string) ( $block['blockName'] ?? '' );
			$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
			switch ( $name ) {
				case 'core/navigation-link':
				case 'core/navigation-submenu':
					$id   = (int) ( $attrs['id'] ?? 0 );
					$kind = (string) ( $attrs['kind'] ?? '' );
					if ( $id && 'post-type' === $kind ) {
						$this->add_post_target( $id, $via, $nav );
					} elseif ( $id && 'taxonomy' === $kind ) {
						$nav['terms'][ $id ][] = $via;
					} else {
						$this->add_url_target( (string) ( $attrs['url'] ?? '' ), (string) ( $attrs['label'] ?? '' ), $via, $source, $nav );
					}
					break;
				case 'core/categories':
					$nav['all_categories'] = $nav['all_categories'] ? $nav['all_categories'] : $via;
					break;
				case 'core/page-list':
					$nav['all_pages'] = $nav['all_pages'] ? $nav['all_pages'] : $via;
					break;
				case 'core/latest-posts':
					foreach ( $this->recent_posts( (int) ( $attrs['postsToShow'] ?? 5 ) ) as $id ) {
						$this->add_post_target( $id, $via, $nav );
					}
					break;
				case 'core/navigation':
					$ref = (int) ( $attrs['ref'] ?? 0 );
					if ( $ref && 'publish' === get_post_status( $ref ) ) {
						$this->collect_blocks( parse_blocks( (string) get_post_field( 'post_content', $ref ) ), $via, $source, $nav );
					}
					break;
				default:
					if ( ! empty( $block['innerHTML'] ) ) {
						foreach ( Crawler::parse_html( (string) $block['innerHTML'] )['links'] as $link ) {
							$this->add_url_target( $link['href'], $link['anchor'], $via, $source, $nav );
						}
					}
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$this->collect_blocks( $block['innerBlocks'], $via, $source, $nav );
			}
		}
	}

	/**
	 * Widgets in active sidebars.
	 *
	 * @param array<string, mixed> $nav Accumulator.
	 */
	private function collect_widgets( array &$nav ): void {
		$sidebars = get_option( 'sidebars_widgets', array() );
		if ( ! is_array( $sidebars ) ) {
			return;
		}
		foreach ( $sidebars as $sidebar => $widgets ) {
			if ( 'wp_inactive_widgets' === $sidebar || 'array_version' === $sidebar || ! is_array( $widgets ) ) {
				continue;
			}
			$via = 'widget:' . $sidebar;
			foreach ( $widgets as $widget_id ) {
				if ( ! preg_match( '/^(.+)-(\d+)$/', (string) $widget_id, $m ) ) {
					continue;
				}
				$base     = $m[1];
				$number   = (int) $m[2];
				$options  = get_option( 'widget_' . $base, array() );
				$instance = is_array( $options ) && isset( $options[ $number ] ) && is_array( $options[ $number ] ) ? $options[ $number ] : array();
				switch ( $base ) {
					case 'text':
					case 'custom_html':
						$html = (string) ( $instance['text'] ?? $instance['content'] ?? '' );
						foreach ( Crawler::parse_html( $html )['links'] as $link ) {
							$this->add_url_target( $link['href'], $link['anchor'], $via, 'widget', $nav );
						}
						break;
					case 'block':
						$this->collect_blocks( parse_blocks( (string) ( $instance['content'] ?? '' ) ), $via, 'widget', $nav );
						break;
					case 'categories':
						$nav['all_categories'] = $nav['all_categories'] ? $nav['all_categories'] : $via;
						break;
					case 'pages':
						$nav['all_pages'] = $nav['all_pages'] ? $nav['all_pages'] : $via;
						break;
					case 'recent-posts':
						foreach ( $this->recent_posts( (int) ( $instance['number'] ?? 5 ) ) as $id ) {
							$this->add_post_target( $id, $via, $nav );
						}
						break;
					case 'nav_menu':
						if ( ! empty( $instance['nav_menu'] ) ) {
							$this->collect_menu( (int) $instance['nav_menu'], $via, 'widget', $nav );
						}
						break;
				}
			}
		}
	}

	/**
	 * Most recent published posts.
	 *
	 * @param int $limit Count.
	 * @return array<int, int>
	 */
	private function recent_posts( int $limit ): array {
		global $wpdb;
		$limit = max( 1, min( 50, $limit ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'post' AND post_status = 'publish' ORDER BY post_date DESC, ID DESC LIMIT %d", $limit ) ) );
	}

	/**
	 * Rewrite menu and widget rows.
	 *
	 * @param array<string, mixed> $nav Navigation targets.
	 */
	private function store_navigation_links( array $nav ): void {
		global $wpdb;
		$table = Migrations::table( 'links' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$wpdb->query( "DELETE FROM {$table} WHERE source IN ('menu', 'widget')" );
		$rows = array();
		foreach ( $nav['posts'] as $post_id => $via ) {
			$rows[] = $wpdb->prepare( '(0, %d, %s, %s, %s)', $post_id, '', substr( (string) $via, 0, 500 ), str_starts_with( (string) $via, 'widget' ) ? 'widget' : 'menu' );
		}
		foreach ( $nav['broken'] as $broken ) {
			$rows[] = $wpdb->prepare( '(0, 0, %s, %s, %s)', substr( $broken['url'], 0, 2048 ), $broken['anchor'], $broken['source'] );
		}
		foreach ( array_chunk( $rows, 500 ) as $chunk ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared -- rows are prepared above.
			$wpdb->query( "INSERT INTO {$table} (from_post_id, to_post_id, to_url, anchor, source) VALUES " . implode( ',', $chunk ) );
		}
	}

	/**
	 * Compute and store inbound, outbound and click depth.
	 *
	 * @param array<string, mixed> $nav Navigation targets.
	 */
	private function write_stats( array $nav ): void {
		global $wpdb;
		$links = Migrations::table( 'links' );
		$stats = Migrations::table( 'link_stats' );
		$now   = current_time( 'mysql', true );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$inbound = array();
		foreach ( (array) $wpdb->get_results( "SELECT l.to_post_id id, COUNT(DISTINCT CONCAT(l.source, ':', l.from_post_id)) n FROM {$links} l LEFT JOIN {$wpdb->posts} p ON p.ID = l.from_post_id WHERE l.to_post_id > 0 AND l.to_post_id <> l.from_post_id AND (l.from_post_id = 0 OR p.post_status = 'publish') GROUP BY l.to_post_id" ) as $row ) {
			$inbound[ (int) $row->id ] = (int) $row->n;
		}
		$outbound = array();
		foreach ( (array) $wpdb->get_results( "SELECT from_post_id id, COUNT(DISTINCT to_post_id) n FROM {$links} WHERE source = 'content' AND to_post_id > 0 AND to_post_id <> from_post_id GROUP BY from_post_id" ) as $row ) {
			$outbound[ (int) $row->id ] = (int) $row->n;
		}
		// phpcs:enable
		$depth = $this->depths( $nav );
		$types = Analyzer::post_types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$last  = 0;
		$total = 0;
		$count = array(
			'orphans'     => 0,
			'weak'        => 0,
			'deep'        => 0,
			'unreachable' => 0,
		);
		$skip  = array_filter( array( (int) get_option( 'page_on_front' ), (int) get_option( 'page_for_posts' ) ) );
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$ids  = $types ? array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ({$in}) AND ID > %d ORDER BY ID ASC LIMIT 1000", array_merge( $types, array( $last ) ) ) ) ) : array();
			$rows = array();
			foreach ( $ids as $id ) {
				$i      = $inbound[ $id ] ?? 0;
				$d      = $depth[ $id ] ?? self::MAX_DEPTH;
				$rows[] = $wpdb->prepare( '(%d, %d, %d, %d, %s)', $id, $i, $outbound[ $id ] ?? 0, $d, $now );
				$last   = $id;
				++$total;
				if ( ! in_array( $id, $skip, true ) ) {
					$count['orphans']     += 0 === $i ? 1 : 0;
					$count['weak']        += $i < self::WEAK ? 1 : 0;
					$count['deep']        += ( $d > self::DEEP && $d < self::MAX_DEPTH ) ? 1 : 0;
					$count['unreachable'] += $d >= self::MAX_DEPTH ? 1 : 0;
				}
			}
			if ( $rows ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared -- rows are prepared above.
				$wpdb->query( "REPLACE INTO {$stats} (post_id, inbound, outbound, click_depth, computed_at) VALUES " . implode( ',', $rows ) );
			}
		} while ( 1000 === count( $ids ) ); // phpcs:ignore Squiz.PHP.DisallowSizeFunctionsInLoops.Found -- size of the batch just fetched.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$stats} WHERE computed_at < %s", $now ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$broken = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$links} WHERE to_post_id = 0 AND to_url <> ''" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$link_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$links}" );
		update_option(
			self::STATE_OPTION,
			array_merge(
				$count,
				array(
					'computed_at' => gmdate( 'c' ),
					'posts'       => $total,
					'links'       => $link_count,
					'broken'      => $broken,
					'status'      => 'done',
				)
			),
			false
		);
		/**
		 * Fires after the link graph is recomputed.
		 *
		 * @param array $state Summary counts.
		 */
		do_action( 'flseo_graph_computed', $this->state() );
	}

	/**
	 * Click depth for every reachable post (shortest path from the home page).
	 *
	 * Edges: home → navigation targets; home or posts page → post listing; term
	 * archive → its posts; post → posts it links to. Listings cost one extra click
	 * per pagination page.
	 *
	 * @param array<string, mixed> $nav Navigation targets.
	 * @return array<int, int> Post ID => depth.
	 */
	public function depths( array $nav ): array {
		global $wpdb;
		$links = Migrations::table( 'links' );
		$ppp   = max( 1, (int) get_option( 'posts_per_page', 10 ) );
		$adj   = array();
		$last  = 0;
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, from_post_id, to_post_id FROM {$links} WHERE source = 'content' AND to_post_id > 0 AND id > %d ORDER BY id ASC LIMIT 5000", $last ), ARRAY_N );
			foreach ( (array) $rows as $row ) {
				$adj[ (int) $row[1] ][] = (int) $row[2];
				$last                   = (int) $row[0];
			}
		} while ( is_array( $rows ) && 5000 === count( $rows ) ); // phpcs:ignore Squiz.PHP.DisallowSizeFunctionsInLoops.Found -- size of the batch just fetched.

		$dist       = array();
		$buckets    = array();
		$push       = static function ( string $node, int $d ) use ( &$dist, &$buckets ): void {
			$d = min( self::MAX_DEPTH, $d );
			if ( isset( $dist[ $node ] ) && $dist[ $node ] <= $d ) {
				return;
			}
			$dist[ $node ]   = $d;
			$buckets[ $d ][] = $node;
		};
		$front      = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
		$posts_page = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_for_posts' ) : 0;
		$push( 'home', 0 );
		if ( $front ) {
			$push( 'p' . $front, 0 );
		}
		foreach ( array_keys( $nav['posts'] ) as $id ) {
			$push( 'p' . $id, 1 );
		}
		foreach ( array_keys( $nav['terms'] ) as $term_id ) {
			$push( 't' . $term_id, 1 );
		}
		if ( $nav['all_categories'] ) {
			foreach ( (array) get_terms(
				array(
					'taxonomy'   => 'category',
					'hide_empty' => true,
					'fields'     => 'ids',
				)
			) as $term_id ) {
				$push( 't' . (int) $term_id, 1 );
			}
		}
		if ( $nav['all_pages'] ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			foreach ( (array) $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' LIMIT 500" ) as $id ) {
				$push( 'p' . (int) $id, 1 );
			}
		}
		for ( $d = 0; $d < self::MAX_DEPTH; $d++ ) {
			if ( empty( $buckets[ $d ] ) ) {
				continue;
			}
			while ( $buckets[ $d ] ) {
				$node = (string) array_pop( $buckets[ $d ] );
				if ( $dist[ $node ] !== $d ) {
					continue;
				}
				if ( 'home' === $node ) {
					if ( ! $front ) {
						$this->push_listing( $this->listing_ids( 0, $ppp ), $d, $ppp, $push );
					}
					continue;
				}
				$id = (int) substr( $node, 1 );
				if ( 't' === $node[0] ) {
					$this->push_listing( $this->listing_ids( $id, $ppp ), $d, $ppp, $push );
					continue;
				}
				if ( $posts_page && $id === $posts_page ) {
					$this->push_listing( $this->listing_ids( 0, $ppp ), $d, $ppp, $push );
				}
				foreach ( $adj[ $id ] ?? array() as $to ) {
					$push( 'p' . $to, $d + 1 );
				}
			}
		}
		$out = array();
		foreach ( $dist as $node => $d ) {
			if ( 'p' === $node[0] ) {
				$out[ (int) substr( $node, 1 ) ] = $d;
			}
		}
		return $out;
	}

	/**
	 * Push a paginated listing.
	 *
	 * @param array<int, int> $ids   Post IDs in display order.
	 * @param int             $d     Depth of the listing page.
	 * @param int             $ppp   Posts per page.
	 * @param callable        $push  Push callback.
	 */
	private function push_listing( array $ids, int $d, int $ppp, callable $push ): void {
		foreach ( $ids as $index => $id ) {
			$push( 'p' . $id, $d + 1 + intdiv( $index, $ppp ) );
		}
	}

	/**
	 * Post IDs as listed on the blog index (term 0) or a term archive, newest first.
	 *
	 * @param int $term_id Term ID or 0 for the blog index.
	 * @param int $ppp     Posts per page.
	 * @return array<int, int>
	 */
	private function listing_ids( int $term_id, int $ppp ): array {
		global $wpdb;
		$limit = $ppp * ( self::MAX_DEPTH - 1 );
		if ( 0 === $term_id ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'post' AND post_status = 'publish' ORDER BY post_date DESC, ID DESC LIMIT %d", $limit ) ) );
		}
		$term = get_term( $term_id );
		if ( ! $term instanceof \WP_Term ) {
			return array();
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID WHERE tr.term_taxonomy_id = %d AND p.post_status = 'publish' ORDER BY p.post_date DESC, p.ID DESC LIMIT %d", (int) $term->term_taxonomy_id, $limit ) ) );
	}

	/**
	 * Link stats for one post.
	 *
	 * @param int $post_id Post ID.
	 * @return array{inbound: int, outbound: int, click_depth: int, computed_at: string}|null
	 */
	public function stats( int $post_id ): ?array {
		global $wpdb;
		$table = Migrations::table( 'link_stats' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT inbound, outbound, click_depth, computed_at FROM {$table} WHERE post_id = %d", $post_id ), ARRAY_A );
		if ( ! $row ) {
			return null;
		}
		return array(
			'inbound'     => (int) $row['inbound'],
			'outbound'    => (int) $row['outbound'],
			'click_depth' => (int) $row['click_depth'],
			'computed_at' => (string) $row['computed_at'],
		);
	}

	/**
	 * Posts this post already links to.
	 *
	 * @param int $post_id Post ID.
	 * @return array<int, int>
	 */
	public function outbound_targets( int $post_id ): array {
		global $wpdb;
		$table = Migrations::table( 'links' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT to_post_id FROM {$table} WHERE from_post_id = %d AND source = 'content' AND to_post_id > 0", $post_id ) ) );
	}

	/**
	 * Posts that already link to a post.
	 *
	 * @param int $post_id Post ID.
	 * @return array<int, int>
	 */
	public function inbound_sources( int $post_id ): array {
		global $wpdb;
		$table = Migrations::table( 'links' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT from_post_id FROM {$table} WHERE to_post_id = %d AND source = 'content' AND from_post_id > 0", $post_id ) ) );
	}

	/**
	 * Broken internal links.
	 *
	 * @param int $page     Page.
	 * @param int $per_page Per page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function broken( int $page = 1, int $per_page = 50 ): array {
		global $wpdb;
		$table  = Migrations::table( 'links' );
		$offset = ( max( 1, $page ) - 1 ) * $per_page;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE to_post_id = 0 AND to_url <> ''" );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, from_post_id, to_url, anchor, source FROM {$table} WHERE to_post_id = 0 AND to_url <> '' ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ) );
		// phpcs:enable
		$items = array();
		foreach ( (array) $rows as $row ) {
			$from    = (int) $row->from_post_id;
			$items[] = array(
				'id'         => (int) $row->id,
				'from_id'    => $from,
				'from_title' => $from ? get_the_title( $from ) : __( 'Site navigation', 'futurelabs-ai-seo' ),
				'edit_url'   => $from ? (string) get_edit_post_link( $from, 'raw' ) : admin_url( 'nav-menus.php' ),
				'url'        => (string) $row->to_url,
				'anchor'     => (string) $row->anchor,
				'source'     => (string) $row->source,
			);
		}
		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Category coverage (OL-8): is every public category with posts linked from a menu,
	 * footer, navigation block or widget?
	 *
	 * @return array<string, mixed>
	 */
	public function navigation_coverage(): array {
		global $wpdb;
		$nav        = $this->navigation_targets();
		$categories = array();
		$missing    = array();
		$terms      = get_terms(
			array(
				'taxonomy'   => 'category',
				'hide_empty' => true,
			)
		);
		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$via = array_values( array_unique( $nav['terms'][ (int) $term->term_id ] ?? array() ) );
			if ( $nav['all_categories'] ) {
				$via[] = (string) $nav['all_categories'];
			}
			$reachable    = (bool) $via;
			$categories[] = array(
				'id'        => (int) $term->term_id,
				'name'      => $term->name,
				'slug'      => $term->slug,
				'url'       => (string) get_term_link( $term ),
				'count'     => (int) $term->count,
				'reachable' => $reachable,
				'via'       => $via,
			);
			if ( ! $reachable ) {
				$missing[] = $term->name;
			}
		}
		$stats = Migrations::table( 'link_stats' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$beyond = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$stats} WHERE click_depth > 3" );
		return array(
			'locations'             => $nav['locations'],
			'categories'            => $categories,
			'unreachable'           => $missing,
			'unreachable_count'     => count( $missing ),
			'posts_beyond_3_clicks' => $beyond,
			'computed_at'           => (string) $this->state()['computed_at'],
		);
	}
}
