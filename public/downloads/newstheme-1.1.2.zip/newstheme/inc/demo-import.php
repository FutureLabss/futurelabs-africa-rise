<?php
/**
 * Demo content for the One Click Demo Import plugin. The demo files are hosted
 * online (theme directory rules keep them out of the theme): tools/export-demo.mjs
 * builds them, and the folder is uploaded to the URL set below. IDs in theme mods
 * and widgets are remapped after import using id-map.json, since the imported
 * posts and terms get new IDs.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * URL of the hosted demo folder (no trailing slash). Return '' from the
 * `newstheme_demo_url` filter to offer no demo.
 *
 * @return string
 */
function newstheme_demo_url() {
	return untrailingslashit( (string) apply_filters( 'newstheme_demo_url', 'https://futurelabs.africa/downloads/newstheme-demo' ) );
}

/**
 * Registers the demo with One Click Demo Import.
 *
 * @param array $files Demo imports.
 * @return array
 */
function newstheme_demo_import_files( $files ) {
	$url = newstheme_demo_url();
	if ( ! $url ) {
		return $files;
	}
	$files[] = array(
		'import_file_name'           => __( 'NewsTheme Demo', 'newstheme' ),
		'import_file_url'            => $url . '/content.xml',
		'import_widget_file_url'     => $url . '/widgets.wie',
		'import_customizer_file_url' => $url . '/customizer.dat',
		'import_preview_image_url'   => get_template_directory_uri() . '/screenshot.jpg',
		'import_notice'              => __( 'Best imported into a new, empty site. Images are downloaded during the import, which can take a few minutes.', 'newstheme' ),
	);
	return $files;
}
add_filter( 'ocdi/import_files', 'newstheme_demo_import_files' );

/**
 * Downloads one of the hosted demo files.
 *
 * @param string $file File name.
 * @return string Contents, or '' on failure.
 */
function newstheme_demo_fetch( $file ) {
	$response = wp_remote_get( newstheme_demo_url() . '/' . $file, array( 'timeout' => 30 ) );
	return 200 === wp_remote_retrieve_response_code( $response ) ? wp_remote_retrieve_body( $response ) : '';
}

/**
 * Resolves an old demo ID to the ID of the imported copy.
 *
 * @param string $kind 'terms' or 'posts'.
 * @param mixed  $id   Old ID.
 * @param array  $map  Contents of id-map.json.
 * @return int|null New ID, or null when the ID isn't part of the demo.
 */
function newstheme_demo_new_id( $kind, $id, $map ) {
	static $cache = array();
	if ( ! is_numeric( $id ) || ! isset( $map[ $kind ][ (int) $id ] ) ) {
		return null;
	}
	$key = $kind . (int) $id;
	if ( ! array_key_exists( $key, $cache ) ) {
		list( $type, $slug ) = $map[ $kind ][ (int) $id ];
		if ( 'terms' === $kind ) {
			$term          = get_term_by( 'slug', $slug, $type );
			$cache[ $key ] = $term ? (int) $term->term_id : null;
		} else {
			$posts         = get_posts(
				array(
					'name'             => $slug,
					'post_type'        => $type,
					'post_status'      => 'any',
					'posts_per_page'   => 1,
					'orderby'          => 'ID',
					'fields'           => 'ids',
					'suppress_filters' => true,
				)
			);
			$cache[ $key ] = $posts ? (int) $posts[0] : null;
		}
	}
	return $cache[ $key ];
}

/**
 * Replaces demo IDs in a setting value. Which kind of ID a value holds is
 * decided by its key: …categories / …category / nav_menu → terms,
 * …posts → posts, …image / …logo → attachments.
 *
 * @param mixed  $value Setting value.
 * @param string $key   Its key (array key or theme mod name).
 * @param array  $map   ID map.
 * @return mixed
 */
function newstheme_demo_remap( $value, $key, $map ) {
	$key  = (string) $key;
	$kind = null;
	if ( preg_match( '/(^|_)(categories|category|nav_menu)$/', $key ) ) {
		$kind = 'terms';
	} elseif ( preg_match( '/(^|_)(posts|image|logo)$/', $key ) ) {
		$kind = 'posts';
	}

	if ( $kind && is_array( $value ) && array_values( $value ) === $value ) {
		$ids = array();
		foreach ( $value as $id ) {
			$new   = newstheme_demo_new_id( $kind, $id, $map );
			$ids[] = null === $new ? $id : $new;
		}
		return $ids;
	}
	if ( $kind && is_scalar( $value ) && ! is_bool( $value ) ) {
		$new = newstheme_demo_new_id( $kind, $value, $map );
		return null === $new ? $value : ( is_string( $value ) ? (string) $new : $new );
	}
	if ( is_array( $value ) ) {
		foreach ( $value as $k => $v ) {
			$value[ $k ] = newstheme_demo_remap( $v, $k, $map );
		}
	}
	return $value;
}

/**
 * After import: remaps IDs in the demo's theme mods and widgets, and shows the
 * homepage sections.
 */
function newstheme_demo_after_import() {
	$map = json_decode( newstheme_demo_fetch( 'id-map.json' ), true );
	if ( ! is_array( $map ) ) {
		return;
	}

	// Only the mods the demo set, so the site's other settings are left alone.
	$demo = unserialize( newstheme_demo_fetch( 'customizer.dat' ), array( 'allowed_classes' => false ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize -- OCDI's format; objects disallowed.

	// Category colors are keyed by term ID: collect first, so renames can't collide.
	$colors = array();
	foreach ( array_keys( $demo['mods'] ?? array() ) as $name ) {
		$value = get_theme_mod( $name );
		if ( preg_match( '/^newstheme_category_color_(\d+)$/', $name, $m ) ) {
			$colors[ newstheme_demo_new_id( 'terms', $m[1], $map ) ?? (int) $m[1] ] = $value;
			remove_theme_mod( $name );
		} elseif ( 'nav_menu_locations' === $name ) {
			set_theme_mod( $name, array_map( fn( $id ) => newstheme_demo_new_id( 'terms', $id, $map ) ?? $id, (array) $value ) );
		} else {
			set_theme_mod( $name, newstheme_demo_remap( $value, $name, $map ) );
		}
	}
	foreach ( $colors as $term => $value ) {
		set_theme_mod( 'newstheme_category_color_' . $term, $value );
	}

	// Widgets of the types the demo uses.
	$widgets = json_decode( newstheme_demo_fetch( 'widgets.wie' ), true );
	$bases   = array();
	foreach ( (array) $widgets as $instances ) {
		foreach ( array_keys( $instances ) as $id ) {
			$bases[ preg_replace( '/-\d+$/', '', $id ) ] = true;
		}
	}
	foreach ( array_keys( $bases ) as $base ) {
		$option = get_option( 'widget_' . $base );
		if ( is_array( $option ) ) {
			update_option( 'widget_' . $base, newstheme_demo_remap( $option, '', $map ) );
		}
	}

	update_option( 'show_on_front', 'posts' );
}
add_action( 'ocdi/after_import', 'newstheme_demo_after_import' );
