<?php
/**
 * Content refresh alerts: pages whose Search Console clicks or impressions fell sharply.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Reports;

use FutureLabs\AISEO\Core\Container;

defined( 'ABSPATH' ) || exit;

/**
 * Compares the two most recent stored periods (28 days each) per URL.
 */
class RefreshAlerts {

	public const DROP = 0.30;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * The "Refresh" list.
	 *
	 * @return array{current_period: string, previous_period: string, items: array<int, array<string, mixed>>, total: int, message: string}
	 */
	public function alerts(): array {
		$data   = $this->c->get( SearchData::class );
		$ranges = $data->ranges( 2 );
		if ( count( $ranges ) < 2 ) {
			return array(
				'current_period'  => $ranges[0] ?? '',
				'previous_period' => '',
				'items'           => array(),
				'total'           => 0,
				'message'         => __( 'Refresh alerts need two Search Console periods. Sync Search Console analytics to build the comparison.', 'futurelabs-ai-seo' ),
			);
		}
		/**
		 * Minimum previous-period impressions for a page to be compared (avoids noise from tiny numbers).
		 *
		 * @param int $min Impressions.
		 */
		$min      = (int) apply_filters( 'flseo_refresh_min_impressions', 20 );
		$current  = $data->totals( $ranges[0] );
		$previous = $data->totals( $ranges[1] );
		$items    = array();
		foreach ( $previous as $hash => $old ) {
			if ( $old['impressions'] < $min ) {
				continue;
			}
			$now        = $current[ $hash ] ?? array(
				'clicks'      => 0,
				'impressions' => 0,
			);
			$click_drop = $old['clicks'] > 0 ? 1 - $now['clicks'] / $old['clicks'] : 0.0;
			$impr_drop  = $old['impressions'] > 0 ? 1 - $now['impressions'] / $old['impressions'] : 0.0;
			if ( $click_drop < self::DROP - 1e-9 && $impr_drop < self::DROP - 1e-9 ) {
				continue;
			}
			$url     = $data->url( $hash, $old['url'] );
			$post_id = $data->post_id( $url );
			$items[] = array(
				'post_id'                   => $post_id,
				'title'                     => $post_id ? html_entity_decode( get_the_title( $post_id ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) : '',
				'url'                       => $url,
				'clicks_previous'           => $old['clicks'],
				'clicks_current'            => (int) $now['clicks'],
				'impressions_previous'      => $old['impressions'],
				'impressions_current'       => (int) $now['impressions'],
				'click_change_percent'      => $old['clicks'] > 0 ? round( ( $now['clicks'] / $old['clicks'] - 1 ) * 100, 1 ) : null,
				'impression_change_percent' => round( ( $now['impressions'] / $old['impressions'] - 1 ) * 100, 1 ),
				'suggestion'                => $this->suggestion( $post_id ),
			);
		}
		usort( $items, static fn( $a, $b ) => ( $b['clicks_previous'] - $b['clicks_current'] ) <=> ( $a['clicks_previous'] - $a['clicks_current'] ) ?: ( $b['impressions_previous'] - $b['impressions_current'] ) <=> ( $a['impressions_previous'] - $a['impressions_current'] ) );
		return array(
			'current_period'  => $ranges[0],
			'previous_period' => $ranges[1],
			'items'           => $items,
			'total'           => count( $items ),
			'message'         => '',
		);
	}

	/**
	 * Suggestion for a page.
	 *
	 * @param int $post_id Post (0 when unknown).
	 */
	private function suggestion( int $post_id ): string {
		if ( $post_id ) {
			$deadline = (string) get_post_meta( $post_id, '_flseo_opp_deadline', true );
			if ( '' !== $deadline && $deadline < current_time( 'Y-m-d' ) ) {
				return __( 'The deadline on this page has passed. Update it with the current edition and dates from the official source, or mark it closed.', 'futurelabs-ai-seo' );
			}
		}
		return __( 'Refresh this page: check that dates, eligibility and links are still accurate, that it still answers what its title promises, and that related pages link to it.', 'futurelabs-ai-seo' );
	}
}
