<?php
/**
 * Homepage options: section order, and per-section block lists and sidebar
 * position. See inc/customizer/config.php for the setting format; `partial`
 * names a selective-refresh partial (defined under `partials`) so the
 * preview re-renders just that section instead of reloading.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

$newstheme_defs     = newstheme_homepage_section_defs();
$newstheme_sections = array(
	'newstheme_sections_order' => array(
		'title'    => __( 'Sections Order', 'newstheme' ),
		'panel'    => 'newstheme_homepage',
		'priority' => 1,
	),
);
$newstheme_partials = array(
	'homepage' => array(
		'selector' => '.nt-homepage',
		'render'   => 'newstheme_render_homepage',
	),
);

$newstheme_order_choices = array();
foreach ( $newstheme_defs as $newstheme_id => $newstheme_def ) {
	$newstheme_order_choices[ $newstheme_id ] = $newstheme_def['label'];
}

$newstheme_settings = array(
	'homepage_sections'   => array(
		'section'     => 'newstheme_sections_order',
		'control'     => 'sortable',
		'label'       => __( 'Homepage Sections', 'newstheme' ),
		'description' => __( 'Drag to reorder. Untick to hide a section. Edit each section in its own panel.', 'newstheme' ),
		'choices'     => $newstheme_order_choices,
		'partial'     => 'homepage',
		'default'     => array_map(
			static function ( $id ) {
				return array(
					'id'      => $id,
					'enabled' => 'ticker' !== $id,
				);
			},
			array_keys( $newstheme_defs )
		),
	),
	'home_sidebar_sticky' => array(
		'section'    => 'newstheme_sections_order',
		'control'    => 'toggle',
		'label'      => __( 'Sticky sidebars', 'newstheme' ),
		'default'    => true,
		'body_class' => 'nt-sidebar-sticky',
	),
);

foreach ( $newstheme_defs as $newstheme_id => $newstheme_def ) {
	if ( ! $newstheme_def['types'] ) {
		continue;
	}
	$newstheme_section = 'newstheme_home_' . str_replace( '-', '_', $newstheme_id );
	$newstheme_partial = 'section-' . $newstheme_id;

	$newstheme_sections[ $newstheme_section ] = array(
		'title' => $newstheme_def['label'],
		'panel' => 'newstheme_homepage',
	);
	$newstheme_partials[ $newstheme_partial ] = array(
		'selector' => '.nt-section--' . $newstheme_id,
		'render'   => static function () use ( $newstheme_id ) {
			newstheme_render_homepage_section( $newstheme_id );
		},
	);

	$newstheme_settings[ "section_{$newstheme_id}_blocks" ] = array(
		'section'     => $newstheme_section,
		'control'     => 'blocks',
		'label'       => __( 'Blocks', 'newstheme' ),
		'description' => __( 'Add, reorder and edit the blocks in this section.', 'newstheme' ),
		'types'       => $newstheme_def['types'],
		'default'     => $newstheme_def['blocks'],
		'partial'     => $newstheme_partial,
	);

	if ( $newstheme_def['sidebar'] ) {
		$newstheme_settings[ "section_{$newstheme_id}_sidebar" ] = array(
			'section'     => $newstheme_section,
			'control'     => 'buttons',
			'label'       => __( 'Sidebar', 'newstheme' ),
			/* translators: %s: widget area name. */
			'description' => sprintf( __( 'Widgets come from the "%s" widget area.', 'newstheme' ), $GLOBALS['wp_registered_sidebars'][ $newstheme_def['sidebar'] ]['name'] ?? $newstheme_def['sidebar'] ),
			'default'     => $newstheme_def['position'],
			'choices'     => array(
				'left'  => __( 'Left', 'newstheme' ),
				'right' => __( 'Right', 'newstheme' ),
				'none'  => __( 'None', 'newstheme' ),
			),
			'partial'     => $newstheme_partial,
		);
	}
}

return array(
	'sections' => $newstheme_sections,
	'settings' => $newstheme_settings,
	'partials' => $newstheme_partials,
);
