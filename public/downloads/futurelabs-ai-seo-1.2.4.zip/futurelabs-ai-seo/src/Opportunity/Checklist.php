<?php
/**
 * Team publishing checklist (OL-5) with an optional hard publish gate.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Opportunity;

use FutureLabs\AISEO\Content\Template;
use FutureLabs\AISEO\Core\Capabilities;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Links\Crawler;
use FutureLabs\AISEO\Meta\Variables;

defined( 'ABSPATH' ) || exit;

/**
 * Evaluates the publishing checklist for saved posts and unsaved editor data.
 *
 * Soft mode reports only. Hard mode (setting `hard_checklist`) keeps classic-editor
 * posts in draft and rejects block-editor/REST publish requests with HTTP 400.
 */
class Checklist implements Module {

	/**
	 * Set when the classic gate kept a post in draft during this request.
	 *
	 * @var bool
	 */
	private bool $blocked = false;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_filter( 'wp_insert_post_data', array( $this, 'classic_gate' ), 20, 3 );
		add_action( 'init', array( $this, 'register_rest_gates' ), 99 );
		add_filter( 'redirect_post_location', array( $this, 'redirect_location' ) );
		add_action( 'admin_notices', array( $this, 'notice' ) );
	}

	/**
	 * Attach the REST gate to every public post type.
	 */
	public function register_rest_gates(): void {
		foreach ( get_post_types( array( 'public' => true ), 'names' ) as $type ) {
			if ( 'attachment' !== $type ) {
				add_filter( 'rest_pre_insert_' . $type, array( $this, 'rest_gate' ), 10, 2 );
			}
		}
	}

	/**
	 * Whether the hard gate is on.
	 */
	public function is_hard(): bool {
		return (bool) $this->c->get( Settings::class )->get( 'hard_checklist', false );
	}

	/**
	 * Evaluate the checklist.
	 *
	 * @param \WP_Post             $post Post (may be unsaved, ID 0).
	 * @param array<string, mixed> $data Unsaved values that override stored ones:
	 *                                   meta (array of `_flseo_*` => value), featured_media (int),
	 *                                   categories (int[]), content (string), title (string).
	 * @return array<int, array{key: string, label: string, ok: bool}>
	 */
	public function evaluate( \WP_Post $post, array $data = array() ): array {
		$post = clone $post;
		if ( isset( $data['content'] ) ) {
			$post->post_content = (string) $data['content'];
		}
		if ( isset( $data['title'] ) ) {
			$post->post_title = (string) $data['title'];
		}
		$meta = isset( $data['meta'] ) && is_array( $data['meta'] ) ? $data['meta'] : array();
		$get  = static function ( string $key ) use ( $post, $meta ): string {
			if ( array_key_exists( $key, $meta ) ) {
				return is_scalar( $meta[ $key ] ) ? trim( (string) $meta[ $key ] ) : '';
			}
			return $post->ID ? trim( (string) get_post_meta( $post->ID, $key, true ) ) : '';
		};

		$html = (string) $post->post_content;
		if ( '' === trim( $html ) && $post->ID ) {
			$elementor = (string) get_post_meta( $post->ID, '_elementor_data', true );
			$html      = '' !== $elementor ? \FutureLabs\AISEO\Content\Analyzer::elementor_data_html( $elementor ) : '';
		}
		$parsed = Crawler::parse_html( $html );

		$description = $get( '_flseo_description' );
		if ( '' !== $description && str_contains( $description, '%' ) && $post->ID ) {
			$description = $this->c->get( Variables::class )->replace( $description, $post );
		}
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $description ) : strlen( $description );

		$thumb = array_key_exists( 'featured_media', $data ) ? absint( $data['featured_media'] ) : ( $post->ID ? (int) get_post_thumbnail_id( $post->ID ) : 0 );
		$alt   = $thumb ? trim( (string) get_post_meta( $thumb, '_wp_attachment_image_alt', true ) ) : '';

		$cats    = null;
		$has_tax = is_object_in_taxonomy( $post->post_type, 'category' );
		if ( $has_tax ) {
			$cats    = isset( $data['categories'] ) ? array_map( 'absint', (array) $data['categories'] ) : ( $post->ID ? Template::category_ids( $post->ID ) : array() );
			$default = (int) get_option( 'default_category' );
			$cats    = array_values( array_filter( $cats, static fn( $id ) => $id > 0 && $id !== $default ) );
		}

		$internal = 0;
		$external = false;
		$targets  = array();
		foreach ( $parsed['links'] as $link ) {
			if ( Crawler::is_internal( $link['href'] ) ) {
				$key = untrailingslashit( Crawler::absolute( $link['href'] ) );
				if ( untrailingslashit( home_url( '/' ) ) !== $key && ! isset( $targets[ $key ] ) ) {
					$targets[ $key ] = true;
					++$internal;
				}
			} elseif ( Crawler::is_external( $link['href'] ) ) {
				$external = true;
			}
		}

		$is_opp = Template::is_opportunity( $post, \FutureLabs\AISEO\Content\Analyzer::text_without_anchors( $parsed ), $meta, $has_tax ? ( isset( $data['categories'] ) ? array_map( 'absint', (array) $data['categories'] ) : null ) : array() );

		$items = array(
			array(
				'key'   => 'description',
				/* translators: %d: current length in characters. */
				'label' => sprintf( __( 'Meta description is 120–160 characters (now %d)', 'futurelabs-ai-seo' ), $length ),
				'ok'    => $length >= 120 && $length <= 160,
			),
			array(
				'key'   => 'focus_topic',
				'label' => __( 'Focus topic is set', 'futurelabs-ai-seo' ),
				'ok'    => '' !== $get( '_flseo_focus_topic' ),
			),
			array(
				'key'   => 'featured_image',
				'label' => __( 'Featured image has alt text', 'futurelabs-ai-seo' ),
				'ok'    => $thumb > 0 && '' !== $alt,
			),
		);
		if ( $has_tax ) {
			$items[] = array(
				'key'   => 'category',
				'label' => __( 'A category other than the default is chosen', 'futurelabs-ai-seo' ),
				'ok'    => (bool) $cats,
			);
		}
		if ( $is_opp ) {
			$items[] = array(
				'key'   => 'deadline',
				'label' => __( 'Opportunity deadline is set (or status is rolling)', 'futurelabs-ai-seo' ),
				'ok'    => '' !== $get( '_flseo_opp_deadline' ) || 'rolling' === $get( '_flseo_opp_status' ),
			);
			$items[] = array(
				'key'   => 'source_link',
				'label' => __( 'Official source link is present', 'futurelabs-ai-seo' ),
				'ok'    => '' !== $get( '_flseo_opp_source_url' ) || $external,
			);
		}
		$items[] = array(
			'key'   => 'internal_links',
			/* translators: %d: internal links found. */
			'label' => sprintf( __( 'At least 2 internal links to other posts (now %d)', 'futurelabs-ai-seo' ), $internal ),
			'ok'    => $internal >= 2,
		);
		/**
		 * Filter checklist items.
		 *
		 * @param array    $items Items: key, label, ok.
		 * @param \WP_Post $post  Post.
		 * @param array    $data  Unsaved overrides.
		 */
		return (array) apply_filters( 'flseo_checklist_items', $items, $post, $data );
	}

	/**
	 * Failed items.
	 *
	 * @param array<int, array{key: string, label: string, ok: bool}> $items Items.
	 * @return array<int, array{key: string, label: string, ok: bool}>
	 */
	public static function failures( array $items ): array {
		return array_values( array_filter( $items, static fn( $item ) => empty( $item['ok'] ) ) );
	}

	/**
	 * Whether the gate applies to a post being published.
	 *
	 * @param string $new_status Requested status.
	 * @param int    $post_id    Post ID (0 when new).
	 * @param string $type       Post type.
	 */
	private function gate_applies( string $new_status, int $post_id, string $type ): bool {
		if ( ! $this->is_hard() || ! in_array( $new_status, array( 'publish', 'future' ), true ) ) {
			return false;
		}
		if ( 'attachment' === $type || ! in_array( $type, get_post_types( array( 'public' => true ), 'names' ), true ) ) {
			return false;
		}
		if ( $post_id && in_array( get_post_status( $post_id ), array( 'publish', 'future' ), true ) ) {
			return false;
		}
		/**
		 * Whether the hard checklist gate applies to this publish.
		 *
		 * @param bool   $applies Default true.
		 * @param int    $post_id Post ID.
		 * @param string $type    Post type.
		 */
		return (bool) apply_filters( 'flseo_checklist_gate_applies', true, $post_id, $type );
	}

	/**
	 * Classic editor gate: keep the post as a draft when the checklist fails.
	 *
	 * @param array<string, mixed> $data    Slashed post data.
	 * @param array<string, mixed> $postarr Raw post array.
	 * @param array<string, mixed> $raw     Unsanitized post array.
	 * @return array<string, mixed>
	 */
	public function classic_gate( $data, $postarr, $raw = array() ) {
		if ( ! is_array( $data ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ! is_admin() ) {
			return $data;
		}
		$post_id = absint( $postarr['ID'] ?? 0 );
		if ( ! $this->gate_applies( (string) ( $data['post_status'] ?? '' ), $post_id, (string) ( $data['post_type'] ?? 'post' ) ) ) {
			return $data;
		}
		$post               = $post_id ? get_post( $post_id ) : null;
		$post               = $post instanceof \WP_Post ? $post : new \WP_Post(
			(object) array(
				'ID'        => 0,
				'post_type' => (string) ( $data['post_type'] ?? 'post' ),
			)
		);
		$overrides          = array(
			'content' => wp_unslash( (string) ( $data['post_content'] ?? '' ) ),
			'title'   => wp_unslash( (string) ( $data['post_title'] ?? '' ) ),
			'meta'    => array(),
		);
		$source             = wp_unslash( is_array( $raw ) && $raw ? $raw : (array) $postarr );
		$nonce              = isset( $source['flseo_nonce'] ) ? sanitize_text_field( (string) $source['flseo_nonce'] ) : '';
		$fields_are_trusted = '' !== $nonce && wp_verify_nonce( $nonce, 'flseo_save_post' );
		if ( $fields_are_trusted ) {
			foreach ( array( 'description', 'focus_topic', 'opp_deadline', 'opp_source_url', 'opp_status' ) as $key ) {
				if ( isset( $source[ 'flseo_' . $key ] ) ) {
					$overrides['meta'][ '_flseo_' . $key ] = sanitize_text_field( (string) $source[ 'flseo_' . $key ] );
				}
			}
		}
		if ( isset( $source['_thumbnail_id'] ) ) {
			$overrides['featured_media'] = (int) $source['_thumbnail_id'];
		}
		if ( isset( $source['post_category'] ) ) {
			$overrides['categories'] = array_map( 'absint', (array) $source['post_category'] );
		}
		$failed = self::failures( $this->evaluate( $post, $overrides ) );
		if ( $failed ) {
			$data['post_status'] = 'draft';
			$this->blocked       = true;
			set_transient( 'flseo_checklist_blocked_' . get_current_user_id(), array_column( $failed, 'label' ), 5 * MINUTE_IN_SECONDS );
		}
		return $data;
	}

	/**
	 * Show "draft updated" instead of "published" after the classic gate blocked a publish.
	 *
	 * @param string $location Redirect URL.
	 * @return mixed
	 */
	public function redirect_location( $location ) {
		if ( $this->blocked && is_string( $location ) ) {
			return add_query_arg( 'message', 10, $location );
		}
		return $location;
	}

	/**
	 * REST / block editor gate.
	 *
	 * @param \stdClass|\WP_Error $prepared Prepared post.
	 * @param \WP_REST_Request    $request  Request.
	 * @return \stdClass|\WP_Error
	 */
	public function rest_gate( $prepared, $request ) {
		if ( is_wp_error( $prepared ) || ! $request instanceof \WP_REST_Request ) {
			return $prepared;
		}
		$post_id = absint( $prepared->ID ?? $request->get_param( 'id' ) );
		$type    = (string) ( $prepared->post_type ?? ( $post_id ? get_post_type( $post_id ) : 'post' ) );
		$status  = (string) ( $prepared->post_status ?? ( $post_id ? get_post_status( $post_id ) : '' ) );
		if ( ! $this->gate_applies( $status, $post_id, $type ) ) {
			return $prepared;
		}
		$post      = $post_id ? get_post( $post_id ) : null;
		$post      = $post instanceof \WP_Post ? $post : new \WP_Post(
			(object) array(
				'ID'        => 0,
				'post_type' => $type,
			)
		);
		$overrides = array();
		if ( isset( $prepared->post_content ) ) {
			$overrides['content'] = (string) $prepared->post_content;
		}
		if ( isset( $prepared->post_title ) ) {
			$overrides['title'] = (string) $prepared->post_title;
		}
		$meta = $request->get_param( 'meta' );
		if ( is_array( $meta ) ) {
			$overrides['meta'] = $meta;
		}
		if ( null !== $request->get_param( 'featured_media' ) ) {
			$overrides['featured_media'] = absint( $request->get_param( 'featured_media' ) );
		}
		if ( null !== $request->get_param( 'categories' ) ) {
			$overrides['categories'] = array_map( 'absint', (array) $request->get_param( 'categories' ) );
		}
		$failed = self::failures( $this->evaluate( $post, $overrides ) );
		if ( ! $failed ) {
			return $prepared;
		}
		return new \WP_Error(
			'flseo_checklist_incomplete',
			/* translators: %s: list of unmet checklist items. */
			sprintf( __( 'Complete the FutureLabs AI SEO publishing checklist before publishing: %s', 'futurelabs-ai-seo' ), implode( '; ', array_column( $failed, 'label' ) ) ),
			array(
				'status' => 400,
				'items'  => $failed,
			)
		);
	}

	/**
	 * Notice after the classic gate kept a post in draft.
	 */
	public function notice(): void {
		if ( ! Capabilities::can( Capabilities::EDITOR ) ) {
			return;
		}
		$key    = 'flseo_checklist_blocked_' . get_current_user_id();
		$failed = get_transient( $key );
		if ( ! is_array( $failed ) ) {
			return;
		}
		delete_transient( $key );
		echo '<div class="notice notice-error"><p>' . esc_html__( 'FutureLabs AI SEO kept this post as a draft because the publishing checklist is incomplete:', 'futurelabs-ai-seo' ) . '</p><ul>';
		foreach ( $failed as $label ) {
			echo '<li>' . esc_html( (string) $label ) . '</li>';
		}
		echo '</ul></div>';
	}
}
