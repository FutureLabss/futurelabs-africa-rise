<?php
/**
 * Yoast SEO importer.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Importers;

defined( 'ABSPATH' ) || exit;

/**
 * Reads `_yoast_wpseo_*` post meta, the `wpseo_taxonomy_meta` option and Yoast Premium redirects.
 */
class Yoast extends Importer {

	public const POST_KEYS = array(
		'_yoast_wpseo_title',
		'_yoast_wpseo_metadesc',
		'_yoast_wpseo_canonical',
		'_yoast_wpseo_meta-robots-noindex',
		'_yoast_wpseo_opengraph-title',
		'_yoast_wpseo_opengraph-description',
		'_yoast_wpseo_opengraph-image',
		'_yoast_wpseo_twitter-title',
		'_yoast_wpseo_twitter-description',
		'_yoast_wpseo_twitter-image',
		'_yoast_wpseo_focuskw',
		'_yoast_wpseo_schema_article_type',
	);

	public const REDIRECTS_OPTION = 'wpseo-premium-redirects-base';

	/**
	 * Slug.
	 */
	public function slug(): string {
		return 'yoast';
	}

	/**
	 * Label.
	 */
	public function label(): string {
		return 'Yoast SEO';
	}

	/**
	 * Counts.
	 *
	 * @return array{posts: int, terms: int, redirects: int}
	 */
	public function count(): array {
		return array(
			'posts'     => self::meta_post_count( self::POST_KEYS ),
			'terms'     => count( $this->term_index() ),
			'redirects' => count( $this->redirect_option() ),
		);
	}

	/**
	 * Post IDs.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, int>
	 */
	protected function post_ids( int $offset, int $limit ): array {
		return self::meta_post_ids( self::POST_KEYS, $offset, $limit );
	}

	/**
	 * Post fields.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string, string>
	 */
	protected function post_fields( int $post_id ): array {
		$get     = static fn( string $key ): string => (string) get_post_meta( $post_id, '_yoast_wpseo_' . $key, true );
		$robots  = $get( 'meta-robots-noindex' );
		$noindex = '1' === $robots ? '1' : ( '2' === $robots ? 'index' : '' );
		return array(
			'title'          => $get( 'title' ),
			'description'    => $get( 'metadesc' ),
			'canonical'      => $get( 'canonical' ),
			'noindex'        => $noindex,
			'og_title'       => '' !== $get( 'opengraph-title' ) ? $get( 'opengraph-title' ) : $get( 'twitter-title' ),
			'og_description' => '' !== $get( 'opengraph-description' ) ? $get( 'opengraph-description' ) : $get( 'twitter-description' ),
			'og_image'       => '' !== $get( 'opengraph-image' ) ? $get( 'opengraph-image' ) : $get( 'twitter-image' ),
			'focus_topic'    => $get( 'focuskw' ),
			'schema_type'    => self::schema_type( $get( 'schema_article_type' ) ),
		);
	}

	/**
	 * Flattened taxonomy meta: term_id => values.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function term_index(): array {
		$option = get_option( 'wpseo_taxonomy_meta', array() );
		$out    = array();
		foreach ( is_array( $option ) ? $option : array() as $terms ) {
			foreach ( is_array( $terms ) ? $terms : array() as $term_id => $values ) {
				if ( is_array( $values ) && absint( $term_id ) ) {
					$out[ absint( $term_id ) ] = $values;
				}
			}
		}
		ksort( $out );
		return $out;
	}

	/**
	 * Term IDs.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, int>
	 */
	protected function term_ids( int $offset, int $limit ): array {
		return array_slice( array_keys( $this->term_index() ), $offset, $limit );
	}

	/**
	 * Term fields.
	 *
	 * @param int $term_id Term ID.
	 * @return array<string, string>
	 */
	protected function term_fields( int $term_id ): array {
		$values  = $this->term_index()[ $term_id ] ?? array();
		$get     = static fn( string $key ): string => is_scalar( $values[ 'wpseo_' . $key ] ?? null ) ? (string) $values[ 'wpseo_' . $key ] : '';
		$robots  = $get( 'noindex' );
		$noindex = 'noindex' === $robots ? '1' : ( 'index' === $robots ? 'index' : '' );
		return array(
			'title'          => $get( 'title' ),
			'description'    => $get( 'desc' ),
			'canonical'      => $get( 'canonical' ),
			'noindex'        => $noindex,
			'og_title'       => '' !== $get( 'opengraph-title' ) ? $get( 'opengraph-title' ) : $get( 'twitter-title' ),
			'og_description' => '' !== $get( 'opengraph-description' ) ? $get( 'opengraph-description' ) : $get( 'twitter-description' ),
			'og_image'       => '' !== $get( 'opengraph-image' ) ? $get( 'opengraph-image' ) : $get( 'twitter-image' ),
		);
	}

	/**
	 * Yoast Premium redirects option as a list.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function redirect_option(): array {
		$option = get_option( self::REDIRECTS_OPTION, array() );
		return array_values( array_filter( is_array( $option ) ? $option : array(), 'is_array' ) );
	}

	/**
	 * Redirect rows.
	 *
	 * @param int $offset Offset.
	 * @param int $limit  Limit.
	 * @return array<int, array{source: string, target: string, type: int, is_regex: bool}>
	 */
	protected function redirect_rows( int $offset, int $limit ): array {
		$out = array();
		foreach ( array_slice( $this->redirect_option(), $offset, $limit ) as $row ) {
			$regex  = 'regex' === ( $row['format'] ?? 'plain' );
			$source = (string) ( $row['origin'] ?? '' );
			if ( $regex && str_starts_with( $source, '^' ) && ! str_starts_with( $source, '^/' ) ) {
				// Yoast matches regexes against the path without its leading slash; FutureLabs AI SEO includes it.
				$source = '^/' . substr( $source, 1 );
			}
			$out[] = array(
				'source'   => $source,
				'target'   => (string) ( $row['url'] ?? '' ),
				'type'     => absint( $row['type'] ?? 301 ),
				'is_regex' => $regex,
			);
		}
		return $out;
	}

	/**
	 * Variable pattern: %%name%%.
	 */
	protected function variable_pattern(): string {
		return '/%%([a-z0-9_\-]+)%%/i';
	}

	/**
	 * Variable map.
	 *
	 * @return array<string, string>
	 */
	protected function variable_map(): array {
		return array(
			'title'            => '%title%',
			'parent_title'     => '',
			'sitename'         => '%sitename%',
			'sitedesc'         => '%tagline%',
			'sep'              => '%sep%',
			'excerpt'          => '%excerpt%',
			'excerpt_only'     => '%excerpt%',
			'category'         => '%category%',
			'primary_category' => '%category%',
			'term_title'       => '%title%',
			'date'             => '%date%',
			'name'             => '%author%',
			'page'             => '%page%',
			'pagenumber'       => '%page%',
		);
	}
}
