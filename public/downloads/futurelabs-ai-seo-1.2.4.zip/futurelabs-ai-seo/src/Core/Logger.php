<?php
/**
 * Small bounded logger that never records secrets.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Stores the most recent log entries in a non-autoloaded option.
 */
class Logger {

	public const OPTION = 'flseo_log';
	private const LIMIT = 200;

	/**
	 * Context keys whose values are always redacted.
	 */
	private const SENSITIVE = array( 'token', 'access_token', 'refresh_token', 'client_secret', 'api_key', 'key', 'authorization', 'password', 'secret', 'x-api-key', 'code' );

	/**
	 * Log at error level.
	 *
	 * @param string               $message Message.
	 * @param array<string, mixed> $context Context.
	 */
	public function error( string $message, array $context = array() ): void {
		$this->log( 'error', $message, $context );
	}

	/**
	 * Log at warning level.
	 *
	 * @param string               $message Message.
	 * @param array<string, mixed> $context Context.
	 */
	public function warning( string $message, array $context = array() ): void {
		$this->log( 'warning', $message, $context );
	}

	/**
	 * Log at info level.
	 *
	 * @param string               $message Message.
	 * @param array<string, mixed> $context Context.
	 */
	public function info( string $message, array $context = array() ): void {
		$this->log( 'info', $message, $context );
	}

	/**
	 * Write an entry.
	 *
	 * @param string               $level   Level.
	 * @param string               $message Message.
	 * @param array<string, mixed> $context Context.
	 */
	public function log( string $level, string $message, array $context = array() ): void {
		$entries   = $this->entries();
		$entries[] = array(
			'time'    => gmdate( 'c' ),
			'level'   => $level,
			'message' => self::scrub( $message ),
			'context' => $this->redact( $context ),
		);
		update_option( self::OPTION, array_slice( $entries, -self::LIMIT ), false );
		if ( 'error' === $level && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			error_log( 'FutureLabs AI SEO: ' . self::scrub( $message ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}

	/**
	 * Recent entries, oldest first.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function entries(): array {
		$entries = get_option( self::OPTION, array() );
		return is_array( $entries ) ? $entries : array();
	}

	/**
	 * Remove secrets from context recursively.
	 *
	 * @param array<mixed> $context Context.
	 * @return array<mixed>
	 */
	private function redact( array $context ): array {
		foreach ( $context as $key => $value ) {
			if ( is_string( $key ) && in_array( strtolower( $key ), self::SENSITIVE, true ) ) {
				$context[ $key ] = '[redacted]';
			} elseif ( is_array( $value ) ) {
				$context[ $key ] = $this->redact( $value );
			} elseif ( is_string( $value ) ) {
				$context[ $key ] = self::scrub( $value );
			}
		}
		return $context;
	}

	/**
	 * Mask bearer tokens and Anthropic/Google key shapes inside free text.
	 *
	 * @param string $text Text.
	 */
	public static function scrub( string $text ): string {
		$patterns = array(
			'/Bearer\s+[A-Za-z0-9._\-]+/i' => 'Bearer [redacted]',
			'/sk-ant-[A-Za-z0-9_\-]+/'     => '[redacted]',
			'/ya29\.[A-Za-z0-9._\-]+/'     => '[redacted]',
			'/1\/\/[A-Za-z0-9._\-]{20,}/'  => '[redacted]',
			'/AIza[0-9A-Za-z_\-]{35}/'     => '[redacted]',
		);
		return (string) preg_replace( array_keys( $patterns ), array_values( $patterns ), $text );
	}
}
