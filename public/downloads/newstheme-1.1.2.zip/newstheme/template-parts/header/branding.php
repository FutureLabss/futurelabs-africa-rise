<?php
/**
 * Header element: logo or site title, and tagline.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

// The site title (or logo, whose alt text is the site name) is the page's h1
// only on the front page.
$newstheme_title_tag = is_front_page() ? 'h1' : 'p';
?>
<div class="nt-branding">
	<?php if ( has_custom_logo() && 'h1' === $newstheme_title_tag ) : ?>
		<h1 class="nt-site-title nt-site-title--logo"><?php the_custom_logo(); ?></h1>
	<?php elseif ( has_custom_logo() ) : ?>
		<?php the_custom_logo(); ?>
	<?php else : ?>
		<<?php echo tag_escape( $newstheme_title_tag ); ?> class="nt-site-title">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
		</<?php echo tag_escape( $newstheme_title_tag ); ?>>
	<?php endif; ?>
	<?php if ( get_bloginfo( 'description' ) ) : ?>
		<p class="nt-site-tagline"><?php bloginfo( 'description' ); ?></p>
	<?php endif; ?>
</div>
