<?php
/**
 * Image audit (OL-7): generic filenames, missing alt text, heavy files, small featured images.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Images;

use FutureLabs\AISEO\Core\Container;

defined( 'ABSPATH' ) || exit;

/**
 * Scans image attachments in chunks and caches a compact issue index.
 */
class Audit {

	public const TRANSIENT = 'flseo_image_audit';

	public const GENERIC_PATTERN = '/^(images?[-_ ]?\d+|img[-_ ]?\d+|img_|whatsapp[-_ ]image|screenshot|screen[-_ ]shot|dsc[-_ ]?\d+|untitled|photo[-_ ]?\d+)/i';

	public const MAX_BYTES = 307200;

	public const MIN_FEATURED_WIDTH = 1200;

	/**
	 * Issue code => bit.
	 */
	public const ISSUES = array(
		'generic_filename'    => 1,
		'missing_alt'         => 2,
		'over_300kb'          => 4,
		'featured_under_1200' => 8,
	);

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Whether a filename is generic.
	 *
	 * @param string $filename File name or path.
	 */
	public static function is_generic( string $filename ): bool {
		return (bool) preg_match( self::GENERIC_PATTERN, pathinfo( wp_basename( $filename ), PATHINFO_FILENAME ) );
	}

	/**
	 * Attachment IDs used as featured image of a published post.
	 *
	 * @return array<int, true>
	 */
	private function featured_ids(): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ids = (array) $wpdb->get_col( "SELECT DISTINCT pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = '_thumbnail_id' AND p.post_status = 'publish'" );
		return array_fill_keys( array_filter( array_map( 'intval', $ids ) ), true );
	}

	/**
	 * Facts about one attachment from its stored data.
	 *
	 * @param int    $id    Attachment ID.
	 * @param string $file  `_wp_attached_file`.
	 * @param string $alt   Alt text.
	 * @param mixed  $meta  Attachment metadata (serialized or array).
	 * @return array{filename: string, alt: string, bytes: int, width: int, height: int}
	 */
	private static function facts( int $id, string $file, string $alt, $meta ): array {
		$meta  = is_array( $meta ) ? $meta : maybe_unserialize( (string) $meta );
		$meta  = is_array( $meta ) ? $meta : array();
		$bytes = (int) ( $meta['filesize'] ?? 0 );
		if ( ! $bytes && '' !== $file ) {
			$uploads = wp_get_upload_dir();
			$path    = path_join( (string) $uploads['basedir'], $file );
			$bytes   = is_readable( $path ) ? (int) filesize( $path ) : 0;
		}
		return array(
			'filename' => wp_basename( $file ),
			'alt'      => trim( $alt ),
			'bytes'    => $bytes,
			'width'    => (int) ( $meta['width'] ?? 0 ),
			'height'   => (int) ( $meta['height'] ?? 0 ),
		);
	}

	/**
	 * Issue bitmask.
	 *
	 * @param array{filename: string, alt: string, bytes: int, width: int, height: int} $facts    Facts.
	 * @param bool                                                                      $featured Used as a featured image.
	 */
	private static function mask( array $facts, bool $featured ): int {
		$mask = 0;
		if ( '' !== $facts['filename'] && self::is_generic( $facts['filename'] ) ) {
			$mask |= self::ISSUES['generic_filename'];
		}
		if ( '' === $facts['alt'] ) {
			$mask |= self::ISSUES['missing_alt'];
		}
		if ( $facts['bytes'] > self::MAX_BYTES ) {
			$mask |= self::ISSUES['over_300kb'];
		}
		if ( $featured && $facts['width'] > 0 && $facts['width'] < self::MIN_FEATURED_WIDTH ) {
			$mask |= self::ISSUES['featured_under_1200'];
		}
		return $mask;
	}

	/**
	 * Issue index for every image (cached 15 minutes).
	 *
	 * @param bool $refresh Rebuild even when cached.
	 * @return array{flags: array<int, int>, total: int, built_at: string}
	 */
	public function index( bool $refresh = false ): array {
		global $wpdb;
		$cached = $refresh ? false : get_transient( self::TRANSIENT );
		if ( is_array( $cached ) && isset( $cached['flags'] ) ) {
			return $cached;
		}
		$featured = $this->featured_ids();
		$flags    = array();
		$total    = 0;
		$last     = 0;
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, f.meta_value file, a.meta_value alt, m.meta_value meta FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} f ON f.post_id = p.ID AND f.meta_key = '_wp_attached_file' LEFT JOIN {$wpdb->postmeta} a ON a.post_id = p.ID AND a.meta_key = '_wp_attachment_image_alt' LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_wp_attachment_metadata' WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE %s AND p.ID > %d GROUP BY p.ID ORDER BY p.ID ASC LIMIT 500", 'image/%', $last ) );
			foreach ( (array) $rows as $row ) {
				$id   = (int) $row->ID;
				$last = $id;
				++$total;
				$mask = self::mask( self::facts( $id, (string) $row->file, (string) $row->alt, $row->meta ), isset( $featured[ $id ] ) );
				if ( $mask ) {
					$flags[ $id ] = $mask;
				}
			}
		} while ( is_array( $rows ) && 500 === count( $rows ) ); // phpcs:ignore Squiz.PHP.DisallowSizeFunctionsInLoops.Found -- size of the batch just fetched.
		$index = array(
			'flags'    => $flags,
			'total'    => $total,
			'built_at' => gmdate( 'c' ),
		);
		set_transient( self::TRANSIENT, $index, 15 * MINUTE_IN_SECONDS );
		return $index;
	}

	/**
	 * Counts per issue.
	 *
	 * @return array<string, int>
	 */
	public function counts(): array {
		$index = $this->index();
		$out   = array(
			'total_images' => (int) $index['total'],
			'flagged'      => count( $index['flags'] ),
		);
		foreach ( self::ISSUES as $code => $bit ) {
			$out[ $code ] = count( array_filter( $index['flags'], static fn( $mask ) => ( $mask & $bit ) === $bit ) );
		}
		return $out;
	}

	/**
	 * Paginated flagged images.
	 *
	 * @param string $issue    Optional issue code filter.
	 * @param int    $page     Page.
	 * @param int    $per_page Per page.
	 * @param bool   $refresh  Rebuild the cached index first.
	 * @return array{items: array<int, array<string, mixed>>, total: int, counts: array<string, int>}
	 */
	public function audit( string $issue = '', int $page = 1, int $per_page = 50, bool $refresh = false ): array {
		$flags = $this->index( $refresh )['flags'];
		if ( isset( self::ISSUES[ $issue ] ) ) {
			$bit   = self::ISSUES[ $issue ];
			$flags = array_filter( $flags, static fn( $mask ) => ( $mask & $bit ) === $bit );
		}
		krsort( $flags );
		$slice    = array_slice( $flags, ( max( 1, $page ) - 1 ) * $per_page, $per_page, true );
		$featured = $this->featured_ids();
		$items    = array();
		foreach ( $slice as $id => $mask ) {
			$facts  = self::facts( (int) $id, (string) get_post_meta( (int) $id, '_wp_attached_file', true ), (string) get_post_meta( (int) $id, '_wp_attachment_image_alt', true ), wp_get_attachment_metadata( (int) $id ) );
			$issues = array();
			foreach ( self::ISSUES as $code => $bit ) {
				if ( ( $mask & $bit ) === $bit ) {
					$issues[] = $code;
				}
			}
			$items[] = array(
				'id'        => (int) $id,
				'title'     => get_the_title( (int) $id ),
				'filename'  => $facts['filename'],
				'url'       => (string) wp_get_attachment_url( (int) $id ),
				'thumb'     => (string) wp_get_attachment_image_url( (int) $id, 'thumbnail' ),
				'alt'       => $facts['alt'],
				'bytes'     => $facts['bytes'],
				'width'     => $facts['width'],
				'height'    => $facts['height'],
				'featured'  => isset( $featured[ (int) $id ] ),
				'parent_id' => (int) wp_get_post_parent_id( (int) $id ),
				'issues'    => $issues,
				'edit_url'  => (string) get_edit_post_link( (int) $id, 'raw' ),
			);
		}
		return array(
			'items'  => $items,
			'total'  => count( $flags ),
			'counts' => $this->counts(),
		);
	}

	/**
	 * Forget the cached index (after attachment edits).
	 */
	public function flush(): void {
		delete_transient( self::TRANSIENT );
	}
}
