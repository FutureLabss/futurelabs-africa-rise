<?php
/**
 * Header layout and rendering.
 *
 * The layout comes from the header builder (inc/builder.php): one layout for
 * desktop/tablet and one for phones, each rendered from template parts in
 * template-parts/header/{id}.php.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Print the whole <header>: the desktop layout, the phone layout, and any
 * dialogs its elements need. Also the Customizer's selective-refresh render
 * callback for the header.
 */
function newstheme_render_masthead() {
	echo '<header id="nt-masthead" class="nt-header">';
	echo '<div class="nt-header__layout nt-header__layout--desktop">';
	newstheme_render_builder( 'header', 'header' );
	echo '</div>';
	echo '<div class="nt-header__layout nt-header__layout--mobile">';
	newstheme_render_builder( 'header_mobile', 'header', 'm' );
	echo '</div>';

	foreach ( newstheme_dialogs() as $dialog ) {
		call_user_func( 'newstheme_render_' . $dialog . '_dialog' );
	}
	echo '</header>';
}

/**
 * Social links that are enabled and have a URL.
 *
 * @return array[]
 */
function newstheme_active_social_links() {
	return array_values(
		array_filter(
			(array) newstheme_get_mod( 'social_links' ),
			static function ( $link ) {
				return ! empty( $link['enabled'] ) && ! empty( $link['url'] );
			}
		)
	);
}

/**
 * Posts shown in the ticker.
 *
 * @return WP_Post[]
 */
function newstheme_ticker_posts() {
	static $posts = null;
	if ( null !== $posts ) {
		return $posts;
	}

	$args = array(
		'post_type'           => 'post',
		'posts_per_page'      => (int) newstheme_get_mod( 'ticker_count' ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);

	switch ( newstheme_get_mod( 'ticker_source' ) ) {
		case 'categories':
			$args['category__in'] = newstheme_get_mod( 'ticker_categories' );
			break;
		case 'posts':
			$ids                    = newstheme_get_mod( 'ticker_posts' );
			$args['post__in']       = $ids ? $ids : array( 0 );
			$args['orderby']        = 'post__in';
			$args['posts_per_page'] = count( $args['post__in'] );
			break;
	}

	$posts = get_posts( apply_filters( 'newstheme_ticker_query_args', $args ) );
	return $posts;
}

/**
 * Dark mode boot script, printed first in <head> so the right color scheme
 * is applied before the first paint (no flash of the wrong theme).
 */
function newstheme_print_color_scheme_script() {
	$default = newstheme_get_mod( 'default_mode' );
	?>
	<script>
	(function(){var d=document.documentElement,s=null;try{s=localStorage.getItem('nt-color-scheme')}catch(e){}
	var m=s||<?php echo wp_json_encode( $default ); ?>;if(m==='system'){m=window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'}
	if(m==='dark'){d.classList.add('nt-dark')}})();
	</script>
	<?php
}
add_action( 'wp_head', 'newstheme_print_color_scheme_script', 0 );

/**
 * Body classes for header state.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function newstheme_header_body_classes( $classes ) {
	if ( ! has_nav_menu( 'primary' ) ) {
		$classes[] = 'nt-no-menu';
	}
	return $classes;
}
add_filter( 'body_class', 'newstheme_header_body_classes' );
