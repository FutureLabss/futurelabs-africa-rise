<?php
/**
 * NewsTheme Banner Ad Widget.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Banner ad: image with link.
 */
class NewsTheme_Banner_Ad_Widget extends NewsTheme_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->fields = array(
			'title'   => array(
				'type'    => 'text',
				'label'   => __( 'Title (optional)', 'newstheme' ),
				'default' => '',
			),
			'image'   => array(
				'type'    => 'image',
				'label'   => __( 'Image', 'newstheme' ),
				'default' => 0,
			),
			'url'     => array(
				'type'    => 'url',
				'label'   => __( 'Link URL', 'newstheme' ),
				'default' => '',
			),
			'new_tab' => array(
				'type'    => 'checkbox',
				'label'   => __( 'Open in a new tab', 'newstheme' ),
				'default' => true,
			),
			'label'   => array(
				'type'    => 'text',
				'label'   => __( 'Small label above the ad', 'newstheme' ),
				'default' => __( 'Advertisement', 'newstheme' ),
			),
		);
		parent::__construct( 'banner_ad', __( 'NewsTheme: Banner Ad', 'newstheme' ), __( 'An image advert with a link.', 'newstheme' ) );
	}

	/**
	 * Render.
	 *
	 * @param array $values Instance values.
	 */
	protected function render( array $values ) {
		if ( ! $values['image'] ) {
			return;
		}
		newstheme_render_block(
			'ad',
			array(
				'image' => $values['image'],
				'url'   => $values['url'],
				'label' => $values['label'],
			)
		);
	}
}
