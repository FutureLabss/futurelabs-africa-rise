<?php
/**
 * Footer element: social links.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

get_template_part( 'template-parts/social-links', null, array( 'class' => 'nt-social--footer' ) );
