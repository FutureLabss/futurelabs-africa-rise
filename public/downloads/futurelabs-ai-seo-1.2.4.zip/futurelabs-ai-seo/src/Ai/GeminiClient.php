<?php
/**
 * Google Gemini API (generateContent) client over the WordPress HTTP API.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Ai;

use FutureLabs\AISEO\Core\Crypto;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Sends one-shot requests to POST /v1beta/models/{model}:generateContent.
 */
class GeminiClient extends Provider {

	public const BASE_URL   = 'https://generativelanguage.googleapis.com/v1beta';
	public const KEY_OPTION = 'flseo_ai_key_gemini';

	/**
	 * Output budget. Thinking models count their thinking against it.
	 */
	public const MAX_TOKENS = 4000;

	/**
	 * Image types Gemini accepts inline (no GIF).
	 */
	public const IMAGE_TYPES = array( 'image/jpeg', 'image/png', 'image/webp' );

	/**
	 * Finish reasons that mean the content was blocked.
	 */
	private const BLOCKED = array( 'SAFETY', 'RECITATION', 'BLOCKLIST', 'PROHIBITED_CONTENT', 'SPII', 'IMAGE_SAFETY' );

	/**
	 * Provider ID.
	 */
	public function id(): string {
		return 'gemini';
	}

	/**
	 * Service name.
	 */
	public function label(): string {
		return 'Gemini';
	}

	/**
	 * Key option.
	 */
	public function key_option(): string {
		return self::KEY_OPTION;
	}

	/**
	 * Image types.
	 *
	 * @return array<int, string>
	 */
	public function image_types(): array {
		return self::IMAGE_TYPES;
	}

	/**
	 * Configured model ID without the "models/" prefix ('' when none is chosen).
	 */
	public function model(): string {
		$model = (string) $this->c->get( Settings::class )->get( 'ai_model_gemini', '' );
		$model = (string) preg_replace( '#^models/#', '', trim( $model ) );
		return preg_match( '/^[A-Za-z0-9][A-Za-z0-9._\-]{0,127}$/', $model ) ? $model : '';
	}

	/**
	 * Request body.
	 *
	 * @param string                                              $system System prompt.
	 * @param string                                              $text   User text.
	 * @param array<int, array{media_type: string, data: string}> $images Base64 images, placed before the text.
	 * @return array<string, mixed>
	 */
	public function body( string $system, string $text, array $images = array() ): array {
		$parts = array();
		foreach ( $images as $image ) {
			$parts[] = array(
				'inline_data' => array(
					'mime_type' => $image['media_type'],
					'data'      => $image['data'],
				),
			);
		}
		$parts[] = array( 'text' => $text );
		return array(
			'system_instruction' => array( 'parts' => array( array( 'text' => $system ) ) ),
			'contents'           => array(
				array(
					'role'  => 'user',
					'parts' => $parts,
				),
			),
			'generationConfig'   => array( 'maxOutputTokens' => self::MAX_TOKENS ),
		);
	}

	/**
	 * HTTP request (the key goes in a header, never the URL, so it stays out of server logs).
	 *
	 * @param string                                              $system System prompt.
	 * @param string                                              $text   User text.
	 * @param array<int, array{media_type: string, data: string}> $images Images.
	 * @param string                                              $key    API key.
	 * @return array{url: string, args: array<string, mixed>}
	 */
	protected function request( string $system, string $text, array $images, string $key ): array {
		return array(
			'url'  => self::BASE_URL . '/models/' . rawurlencode( $this->model() ) . ':generateContent',
			'args' => array(
				'headers' => array(
					'x-goog-api-key' => $key,
					'content-type'   => 'application/json',
				),
				'body'    => (string) wp_json_encode( $this->body( $system, $text, $images ) ),
			),
		);
	}

	/**
	 * Read a 200 response.
	 *
	 * @param array<string, mixed> $data Decoded body.
	 * @return array{text: string, stop_reason: string, truncated: bool}|\WP_Error
	 */
	protected function parse( array $data ) {
		$blocked = is_array( $data['promptFeedback'] ?? null ) ? (string) ( $data['promptFeedback']['blockReason'] ?? '' ) : '';
		if ( '' !== $blocked ) {
			return $this->refusal( strtolower( $blocked ) );
		}
		$candidate = is_array( $data['candidates'][0] ?? null ) ? $data['candidates'][0] : array();
		$finish    = (string) ( $candidate['finishReason'] ?? '' );
		if ( in_array( $finish, self::BLOCKED, true ) ) {
			return $this->refusal( strtolower( $finish ) );
		}
		$text = '';
		foreach ( (array) ( $candidate['content']['parts'] ?? array() ) as $part ) {
			// Thought summaries are flagged `thought: true`; only the answer is kept.
			if ( is_array( $part ) && empty( $part['thought'] ) && isset( $part['text'] ) ) {
				$text .= (string) $part['text'];
			}
		}
		return array(
			'text'        => trim( $text ),
			'stop_reason' => $finish,
			'truncated'   => 'MAX_TOKENS' === $finish,
		);
	}

	/**
	 * Models that can generate text, from GET /v1beta/models.
	 *
	 * @return array<int, string>|\WP_Error
	 */
	public function list_models() {
		$key  = $this->c->get( Crypto::class )->get_secret( self::KEY_OPTION );
		$data = $this->get_json( self::BASE_URL . '/models?pageSize=1000', array( 'x-goog-api-key' => $key ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$ids = array();
		foreach ( (array) ( $data['models'] ?? array() ) as $model ) {
			if ( ! is_array( $model ) || ! in_array( 'generateContent', (array) ( $model['supportedGenerationMethods'] ?? array() ), true ) ) {
				continue;
			}
			$id = (string) preg_replace( '#^models/#', '', (string) ( $model['name'] ?? '' ) );
			if ( preg_match( '/^gemini-/', $id ) && ! preg_match( '/(embedding|tts|image|live|audio)/', $id ) ) {
				$ids[] = $id;
			}
		}
		sort( $ids );
		return $ids;
	}
}
