<?php
/**
 * Opportunity expiry lifecycle (OL-2).
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Opportunity;

use FutureLabs\AISEO\Bulk\AuditLog;
use FutureLabs\AISEO\Content\Analyzer;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Features;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Meta\NoindexGuard;
use FutureLabs\AISEO\Meta\RobotsResolver;
use FutureLabs\AISEO\Redirects\Rules;

defined( 'ABSPATH' ) || exit;

/**
 * Marks opportunities closing soon or closed and applies the expiry action.
 *
 * Actions: update (move the deadline a year forward and reopen; manual or bulk only),
 * notice (visible "Closed" notice, page stays indexable), noindex, redirect (301 to a
 * newer edition or the category).
 */
class Lifecycle implements Module {

	public const ACTIONS = array( 'update', 'notice', 'noindex', 'redirect' );
	public const MARKER  = 'data-futurelabs-ai-seo="closed-notice"';

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'flseo_daily', array( $this, 'run' ) );
		add_action( 'flseo_expire_opportunities', array( $this, 'run' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'styles' ) );
		add_filter( 'the_content', array( $this, 'render_notice' ), 20 );
	}

	/**
	 * Today in the site timezone (Y-m-d).
	 */
	private static function today(): string {
		return current_time( 'Y-m-d' );
	}

	/**
	 * Date offset from today.
	 *
	 * @param int $days Days (negative for the past).
	 */
	private static function offset( int $days ): string {
		return gmdate( 'Y-m-d', (int) strtotime( self::today() . ' ' . ( $days >= 0 ? '+' : '' ) . $days . ' days' ) );
	}

	/**
	 * Daily job: close expired posts, mark closing-soon, reopen posts whose deadline moved.
	 *
	 * @return array{closed: int, closing: int, reopened: int}
	 */
	public function run(): array {
		global $wpdb;
		if ( ! $this->c->get( Features::class )->enabled( Features::OPPORTUNITIES ) ) {
			return array(
				'closed'   => 0,
				'closing'  => 0,
				'reopened' => 0,
			);
		}
		$settings = $this->c->get( Settings::class );
		$grace    = max( 0, (int) $settings->get( 'expiry_grace', 30 ) );
		$soon     = max( 0, (int) $settings->get( 'closing_soon_days', 7 ) );
		$today    = self::today();
		$cutoff   = self::offset( -$grace );
		$horizon  = self::offset( $soon );
		$result   = array(
			'closed'   => 0,
			'closing'  => 0,
			'reopened' => 0,
		);
		$join     = "FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} d ON d.post_id = p.ID AND d.meta_key = '_flseo_opp_deadline' LEFT JOIN {$wpdb->postmeta} st ON st.post_id = p.ID AND st.meta_key = '_flseo_opp_status' WHERE p.post_status = 'publish' AND d.meta_value <> ''";

		for ( $round = 0; $round < 25; $round++ ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			$ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT p.ID {$join} AND d.meta_value <= %s AND (st.meta_value IS NULL OR st.meta_value NOT IN ('closed', 'rolling')) ORDER BY p.ID ASC LIMIT 200", $cutoff ) ) );
			if ( ! $ids ) {
				break;
			}
			foreach ( $ids as $id ) {
				$this->auto_close( $id );
				++$result['closed'];
			}
			Analyzer::flush_memory();
			if ( 24 === $round ) {
				$this->c->get( Queue::class )->async( 'flseo_expire_opportunities' );
			}
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$closing = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT p.ID {$join} AND d.meta_value >= %s AND d.meta_value <= %s AND (st.meta_value IS NULL OR st.meta_value IN ('', 'open')) LIMIT 2000", $today, $horizon ) ) );
		foreach ( $closing as $id ) {
			update_post_meta( $id, '_flseo_opp_status', 'closing-soon' );
			++$result['closing'];
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$open = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, st.meta_value status, d.meta_value deadline {$join} AND ((d.meta_value > %s AND (st.meta_value IS NULL OR st.meta_value IN ('', 'closing-soon'))) OR (d.meta_value >= %s AND st.meta_value = 'closed')) LIMIT 2000", $horizon, $today ) );
		foreach ( (array) $open as $row ) {
			$id = (int) $row->ID;
			if ( 'closed' === (string) $row->status ) {
				$this->remove_notice( $id, null );
				++$result['reopened'];
			}
			update_post_meta( $id, '_flseo_opp_status', (string) $row->deadline <= $horizon ? 'closing-soon' : 'open' );
		}
		return $result;
	}

	/**
	 * Close one post and apply its automatic expiry action. "update" needs a person,
	 * so it falls back to the notice; a blocked noindex also falls back to the notice.
	 *
	 * @param int $post_id Post ID.
	 */
	private function auto_close( int $post_id ): void {
		update_post_meta( $post_id, '_flseo_opp_status', 'closed' );
		$action = $this->action_for( $post_id );
		if ( 'none' === $action ) {
			return;
		}
		if ( 'update' === $action ) {
			$action = 'notice';
		}
		$result = $this->apply_action( $post_id, $action, '', null, '', false );
		if ( is_wp_error( $result ) && 'notice' !== $action ) {
			$this->c->get( Logger::class )->warning(
				'Opportunity expiry action fell back to a closed notice.',
				array(
					'post_id' => $post_id,
					'action'  => $action,
					'error'   => $result->get_error_code(),
				)
			);
			$this->apply_action( $post_id, 'notice', '', null, '', false );
		}
	}

	/**
	 * Expiry action for a post: per-post override, else the site setting.
	 *
	 * @param int $post_id Post ID.
	 * @return string update, notice, noindex, redirect or none.
	 */
	public function action_for( int $post_id ): string {
		$own = (string) get_post_meta( $post_id, '_flseo_opp_expiry_action', true );
		if ( in_array( $own, self::ACTIONS, true ) ) {
			return $own;
		}
		$default = (string) $this->c->get( Settings::class )->get( 'expiry_action', 'notice' );
		return in_array( $default, array_merge( self::ACTIONS, array( 'none' ) ), true ) ? $default : 'notice';
	}

	/**
	 * Apply an expiry action to one post (used by the daily job, REST and bulk actions).
	 *
	 * Returns the result array (truthy) when something changed, false when the post
	 * was already in the requested state, or WP_Error.
	 *
	 * @param int         $post_id      Post ID.
	 * @param string      $action       update, notice, noindex or redirect.
	 * @param string      $target       Redirect target URL (redirect only; default newer edition or category).
	 * @param string|null $batch_id      Audit batch to write into (bulk actions); a new batch when null.
	 * @param string      $confirmation  Typed noindex confirmation when the noindex guard asks for one.
	 * @param bool        $manual        Whether a person requested the action (required for update).
	 * @param bool        $guard_checked True only when the caller already ran the noindex guard for this post.
	 * @return array<string, mixed>|false|\WP_Error
	 */
	public function apply_action( int $post_id, string $action, string $target = '', ?string $batch_id = null, string $confirmation = '', bool $manual = true, bool $guard_checked = false ) {
		$before = $this->snapshot( $post_id );
		$result = $this->run_action( $post_id, $action, $target, $batch_id, $confirmation, $manual, $guard_checked );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$changed = $before !== $this->snapshot( $post_id ) || ! empty( $result['redirect_created'] );
		if ( ! $changed ) {
			return false;
		}
		$result['changed'] = true;
		return $result;
	}

	/**
	 * State compared before and after an action.
	 *
	 * @param int $post_id Post ID.
	 * @return array<int, string>
	 */
	private function snapshot( int $post_id ): array {
		clean_post_cache( $post_id );
		return array(
			(string) get_post_meta( $post_id, '_flseo_opp_status', true ),
			(string) get_post_meta( $post_id, '_flseo_opp_deadline', true ),
			(string) get_post_meta( $post_id, '_flseo_noindex', true ),
			(string) get_post_meta( $post_id, '_flseo_closed_notice', true ),
			md5( (string) get_post_field( 'post_content', $post_id ) ),
		);
	}

	/**
	 * Perform an action (see apply_action()).
	 *
	 * @param int         $post_id      Post ID.
	 * @param string      $action       Action.
	 * @param string      $target       Redirect target.
	 * @param string|null $batch_id     Audit batch.
	 * @param string      $confirmation Noindex confirmation.
	 * @param bool        $manual       Requested by a person.
	 * @param bool        $guard_checked Caller already ran the noindex guard.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function run_action( int $post_id, string $action, string $target, ?string $batch_id, string $confirmation, bool $manual, bool $guard_checked ) {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status ) {
			return new \WP_Error( 'flseo_opportunity_post', __( 'Choose a published post.', 'futurelabs-ai-seo' ), array( 'status' => 404 ) );
		}
		if ( ! in_array( $action, self::ACTIONS, true ) ) {
			return new \WP_Error( 'flseo_opportunity_action', __( 'Choose update, notice, noindex or redirect.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$audit = $this->c->get( AuditLog::class );
		$bulk  = null !== $batch_id && '' !== $batch_id;
		$batch = $bulk ? (string) $batch_id : $audit->new_batch();
		$out   = array(
			'post_id' => $post_id,
			'action'  => $action,
			'batch'   => $batch,
		);
		switch ( $action ) {
			case 'update':
				if ( ! $manual ) {
					return new \WP_Error( 'flseo_opportunity_manual', __( 'Updating for the next cycle must be requested by an editor.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
				}
				$old = (string) get_post_meta( $post_id, '_flseo_opp_deadline', true );
				if ( '' === $old ) {
					return new \WP_Error( 'flseo_opportunity_deadline', __( 'Set a deadline before updating for the next cycle.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
				}
				$new   = $old;
				$today = self::today();
				for ( $i = 0; $i < 5 && ( $new === $old || $new < $today ); $i++ ) {
					$new = gmdate( 'Y-m-d', (int) strtotime( $new . ' +1 year' ) );
				}
				$audit->record_single( 'opportunity_update', $post_id, '_flseo_opp_deadline', $old, $new, $batch );
				update_post_meta( $post_id, '_flseo_opp_deadline', $new );
				$status = $new <= self::offset( max( 0, (int) $this->c->get( Settings::class )->get( 'closing_soon_days', 7 ) ) ) ? 'closing-soon' : 'open';
				$audit->record_single( 'opportunity_update', $post_id, '_flseo_opp_status', (string) get_post_meta( $post_id, '_flseo_opp_status', true ), $status, $batch );
				update_post_meta( $post_id, '_flseo_opp_status', $status );
				$this->remove_notice( $post_id, $batch );
				if ( 'noindex' === get_post_meta( $post_id, '_flseo_opp_expiry_applied', true ) && '1' === (string) get_post_meta( $post_id, '_flseo_noindex', true ) ) {
					$audit->record_single( 'index', $post_id, '_flseo_noindex', '1', '', $batch );
					delete_post_meta( $post_id, '_flseo_noindex' );
				}
				delete_post_meta( $post_id, '_flseo_opp_expiry_applied' );
				$out['deadline'] = $new;
				$out['status']   = $status;
				return $out;

			case 'notice':
				$this->close( $post_id, $manual ? $batch : null );
				$out['notice'] = $this->insert_notice( $post_id, $batch );
				$out['status'] = 'closed';
				update_post_meta( $post_id, '_flseo_opp_expiry_applied', 'notice' );
				return $out;

			case 'noindex':
				$verdict = $guard_checked ? array( 'allowed' => true ) : $this->c->get( NoindexGuard::class )->check_posts( array( $post_id ), $confirmation );
				if ( ! $verdict['allowed'] ) {
					return new \WP_Error(
						'flseo_noindex_confirm',
						/* translators: %s: confirmation phrase. */
						sprintf( __( 'This would leave more than half of published pages noindexed. Type %s to confirm.', 'futurelabs-ai-seo' ), $verdict['phrase'] ),
						array(
							'status'  => 409,
							'verdict' => $verdict,
						)
					);
				}
				$this->close( $post_id, $manual ? $batch : null );
				$this->insert_notice( $post_id, $batch );
				$old = (string) get_post_meta( $post_id, '_flseo_noindex', true );
				if ( '1' !== $old ) {
					$audit->record_single( 'noindex', $post_id, '_flseo_noindex', $old, '1', $batch );
					update_post_meta( $post_id, '_flseo_noindex', '1' );
				}
				update_post_meta( $post_id, '_flseo_opp_expiry_applied', 'noindex' );
				$out['status'] = 'closed';
				return $out;

			case 'redirect':
				if ( '' !== $target ) {
					// A target supplied by a person must stay on this site; defaults are internal by design.
					$target = esc_url_raw( str_starts_with( $target, '/' ) && ! str_starts_with( $target, '//' ) ? home_url( $target ) : $target );
					if ( ! self::is_internal( $target ) ) {
						return new \WP_Error( 'flseo_opportunity_target', __( 'Opportunity redirects must point to a page on this site.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
					}
				} else {
					$target = $this->default_target( $post_id );
				}
				if ( '' === $target ) {
					return new \WP_Error( 'flseo_opportunity_target', __( 'No newer edition or category was found. Enter a redirect target.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
				}
				if ( '/' === Rules::normalize_path( (string) get_permalink( $post_id ) ) ) {
					return new \WP_Error( 'flseo_opportunity_permalinks', __( 'Redirects need pretty permalinks (Settings > Permalinks); this post URL has no path to redirect.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
				}
				$rules    = $this->c->get( Rules::class );
				$existing = $rules->match( (string) get_permalink( $post_id ) );
				$id       = $rules->save(
					array(
						'source' => (string) get_permalink( $post_id ),
						'target' => $target,
						'type'   => 301,
					),
					0,
					'expiry'
				);
				if ( is_wp_error( $id ) ) {
					return $id;
				}
				$audit->write(
					$batch,
					'expiry_redirect',
					'redirect',
					(int) $id,
					array(
						'kind' => 'redirect',
						'id'   => (int) $id,
						'row'  => null,
					),
					array(
						'kind' => 'redirect',
						'id'   => (int) $id,
						'row'  => $rules->get( (int) $id ),
					)
				);
				$this->close( $post_id, $manual ? $batch : null );
				update_post_meta( $post_id, '_flseo_opp_expiry_applied', 'redirect' );
				$out['redirect_id']      = (int) $id;
				$out['redirect_created'] = ! $existing || (string) $existing->target !== $target;
				$out['target']           = $target;
				$out['status']           = 'closed';
				return $out;
		}
	}

	/**
	 * Whether a URL is on this site (same host as home_url()).
	 *
	 * @param string $url URL.
	 */
	public static function is_internal( string $url ): bool {
		$host   = wp_parse_url( $url, PHP_URL_HOST );
		$home   = wp_parse_url( home_url(), PHP_URL_HOST );
		$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
		return is_string( $host ) && is_string( $home ) && in_array( strtolower( (string) $scheme ), array( 'http', 'https' ), true ) && strtolower( $host ) === strtolower( $home );
	}

	/**
	 * Set status closed (audited when a person asked).
	 *
	 * @param int         $post_id Post ID.
	 * @param string|null $batch   Audit batch.
	 */
	private function close( int $post_id, ?string $batch ): void {
		$old = (string) get_post_meta( $post_id, '_flseo_opp_status', true );
		if ( 'closed' === $old ) {
			return;
		}
		if ( null !== $batch ) {
			$this->c->get( AuditLog::class )->record_single( 'opportunity_close', $post_id, '_flseo_opp_status', $old, 'closed', $batch );
		}
		update_post_meta( $post_id, '_flseo_opp_status', 'closed' );
	}

	/**
	 * Redirect target when none is given: the newest later edition, else the primary category.
	 *
	 * @param int $post_id Post ID.
	 */
	public function default_target( int $post_id ): string {
		$newer = $this->c->get( Editions::class )->newer_edition( $post_id );
		if ( $newer ) {
			return (string) get_permalink( $newer );
		}
		$default = (int) get_option( 'default_category' );
		foreach ( \FutureLabs\AISEO\Content\Template::category_ids( $post_id ) as $cat ) {
			if ( (int) $cat !== $default ) {
				$link = get_category_link( (int) $cat );
				return is_string( $link ) ? $link : '';
			}
		}
		return '';
	}

	/**
	 * Notice HTML.
	 *
	 * @param int $post_id Post ID.
	 */
	public function notice_html( int $post_id ): string {
		$deadline = (string) get_post_meta( $post_id, '_flseo_opp_deadline', true );
		$source   = (string) get_post_meta( $post_id, '_flseo_opp_source_url', true );
		$when     = '' !== $deadline ? date_i18n( (string) get_option( 'date_format' ), (int) strtotime( $deadline ) ) : '';
		$text     = '' !== $when
			/* translators: %s: deadline date. */
			? sprintf( __( 'The application deadline (%s) has passed. Check the official source for future rounds.', 'futurelabs-ai-seo' ), $when )
			: __( 'The application deadline has passed. Check the official source for future rounds.', 'futurelabs-ai-seo' );
		$link = '' !== $source ? ' <a href="' . esc_url( $source ) . '" rel="noopener">' . esc_html__( 'Official source', 'futurelabs-ai-seo' ) . '</a>' : '';
		return '<div class="flseo-closed-notice" role="note" ' . self::MARKER . '><strong>' . esc_html__( 'This opportunity has closed', 'futurelabs-ai-seo' ) . '</strong> <span>' . esc_html( $text ) . '</span>' . $link . '</div>';
	}

	/**
	 * Remove every FutureLabs AI SEO closed-notice block from content.
	 *
	 * @param string $content Content.
	 */
	public static function strip_notices( string $content ): string {
		$content = (string) preg_replace( '~<!-- wp:html -->\s*<div class="flseo-closed-notice"[^>]*' . preg_quote( self::MARKER, '~' ) . '.*?</div>\s*<!-- /wp:html -->\s*~s', '', $content );
		return (string) preg_replace( '~<div class="flseo-closed-notice"[^>]*' . preg_quote( self::MARKER, '~' ) . '.*?</div>\s*~s', '', $content );
	}

	/**
	 * Insert one closed notice at the top of the post (idempotent).
	 *
	 * @param int    $post_id Post ID.
	 * @param string $batch   Audit batch.
	 * @return bool Whether a notice is present after the call.
	 */
	public function insert_notice( int $post_id, string $batch ): bool {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}
		if ( 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true ) || ( '' === trim( (string) $post->post_content ) && '' !== (string) get_post_meta( $post_id, '_elementor_data', true ) ) ) {
			// Builder pages ignore post_content; the notice is added when the content renders.
			update_post_meta( $post_id, '_flseo_closed_notice', 'render' );
			return true;
		}
		$old = (string) $post->post_content;
		$new = "<!-- wp:html -->\n" . $this->notice_html( $post_id ) . "\n<!-- /wp:html -->\n\n" . ltrim( self::strip_notices( $old ) );
		if ( $new !== $old ) {
			$this->write_content( $post, $old, $new, $batch );
		}
		update_post_meta( $post_id, '_flseo_closed_notice', 'content' );
		return true;
	}

	/**
	 * Remove the closed notice.
	 *
	 * @param int         $post_id Post ID.
	 * @param string|null $batch   Audit batch (a new one when null).
	 */
	public function remove_notice( int $post_id, ?string $batch ): void {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return;
		}
		delete_post_meta( $post_id, '_flseo_closed_notice' );
		$old = (string) $post->post_content;
		$new = self::strip_notices( $old );
		if ( $new !== $old ) {
			$this->write_content( $post, $old, $new, $batch ?? $this->c->get( AuditLog::class )->new_batch() );
		}
	}

	/**
	 * Write post content directly (no revision, kses or save_post loop) and audit it.
	 *
	 * @param \WP_Post $post  Post.
	 * @param string   $old   Old content.
	 * @param string   $updated New content.
	 * @param string   $batch Audit batch.
	 */
	private function write_content( \WP_Post $post, string $old, string $updated, string $batch ): void {
		global $wpdb;
		$this->c->get( AuditLog::class )->write(
			$batch,
			'closed_notice',
			'post',
			$post->ID,
			array(
				'kind'  => 'post_content',
				'value' => $old,
			),
			array(
				'kind'  => 'post_content',
				'value' => $updated,
			)
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update(
			$wpdb->posts,
			array(
				'post_content'      => $updated,
				'post_modified'     => current_time( 'mysql' ),
				'post_modified_gmt' => current_time( 'mysql', true ),
			),
			array( 'ID' => $post->ID ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
		clean_post_cache( $post->ID );
		$this->c->get( Queue::class )->async( 'flseo_scan_post', array( $post->ID ) );
	}

	/**
	 * Prepend the notice for builder pages whose content is not stored in post_content.
	 *
	 * @param string $content Rendered content.
	 * @return mixed
	 */
	public function render_notice( $content ) {
		if ( ! is_string( $content ) || ! is_singular() || ! in_the_loop() || ! is_main_query() || ! $this->c->get( Features::class )->enabled( Features::OPPORTUNITIES ) ) {
			return $content;
		}
		$post = get_post();
		if ( ! $post instanceof \WP_Post || 'render' !== get_post_meta( $post->ID, '_flseo_closed_notice', true ) || 'closed' !== get_post_meta( $post->ID, '_flseo_opp_status', true ) || str_contains( $content, self::MARKER ) ) {
			return $content;
		}
		return $this->notice_html( $post->ID ) . $content;
	}

	/**
	 * Notice styles on closed opportunity pages only.
	 */
	public function styles(): void {
		if ( ! is_singular() || ! $this->c->get( Features::class )->enabled( Features::OPPORTUNITIES ) ) {
			return;
		}
		$id = (int) get_queried_object_id();
		if ( ! $id || 'closed' !== get_post_meta( $id, '_flseo_opp_status', true ) ) {
			return;
		}
		wp_register_style( 'flseo-closed-notice', false, array(), defined( 'FLSEO_VERSION' ) ? FLSEO_VERSION : null );
		wp_enqueue_style( 'flseo-closed-notice' );
		wp_add_inline_style( 'flseo-closed-notice', '.flseo-closed-notice{padding:16px 20px;border-left:4px solid #b45309;background:#fff7ed;color:#1f2937;margin:0 0 1.5em}.flseo-closed-notice strong{display:block;margin-bottom:4px}' );
	}

	/**
	 * Shape a post for list responses.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string, mixed>
	 */
	private function item( int $post_id ): array {
		$deadline = (string) get_post_meta( $post_id, '_flseo_opp_deadline', true );
		$post     = get_post( $post_id );
		$author   = $post ? get_userdata( (int) $post->post_author ) : false;
		$days     = '' !== $deadline ? (int) floor( ( strtotime( $deadline ) - strtotime( self::today() ) ) / DAY_IN_SECONDS ) : null;
		return array(
			'id'            => $post_id,
			'title'         => html_entity_decode( get_the_title( $post_id ), ENT_QUOTES ),
			'url'           => (string) get_permalink( $post_id ),
			'edit_url'      => (string) get_edit_post_link( $post_id, 'raw' ),
			'deadline'      => $deadline,
			'days_left'     => $days,
			'status'        => (string) get_post_meta( $post_id, '_flseo_opp_status', true ),
			'indexable'     => $post instanceof \WP_Post && $this->c->get( RobotsResolver::class )->is_indexable( $post ),
			'expiry_action' => $this->action_for( $post_id ),
			'author'        => $author ? array(
				'id'   => (int) $author->ID,
				'name' => $author->display_name,
			) : null,
		);
	}

	/**
	 * Opportunities with a deadline in the next N days.
	 *
	 * @param int $days     Window.
	 * @param int $page     Page.
	 * @param int $per_page Per page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function closing( int $days = 7, int $page = 1, int $per_page = 50 ): array {
		global $wpdb;
		$base = "FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} d ON d.post_id = p.ID AND d.meta_key = '_flseo_opp_deadline' WHERE p.post_status = 'publish' AND d.meta_value >= %s AND d.meta_value <= %s";
		$from = self::today();
		$to   = self::offset( max( 0, $days ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT p.ID) {$base}", $from, $to ) );
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT p.ID {$base} ORDER BY d.meta_value ASC, p.ID ASC LIMIT %d OFFSET %d", $from, $to, $per_page, ( max( 1, $page ) - 1 ) * $per_page ) );
		// phpcs:enable
		return array(
			'items' => array_map( array( $this, 'item' ), array_map( 'intval', (array) $ids ) ),
			'total' => $total,
		);
	}

	/**
	 * Closed opportunities that are still indexable and not redirected.
	 *
	 * @param int $page     Page.
	 * @param int $per_page Per page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function closed_indexed( int $page = 1, int $per_page = 50 ): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ids    = array_map( 'intval', (array) $wpdb->get_col( "SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} st ON st.post_id = p.ID AND st.meta_key = '_flseo_opp_status' AND st.meta_value = 'closed' LEFT JOIN {$wpdb->postmeta} ni ON ni.post_id = p.ID AND ni.meta_key = '_flseo_noindex' AND ni.meta_value = '1' WHERE p.post_status = 'publish' AND ni.meta_id IS NULL ORDER BY p.post_date DESC LIMIT 5000" ) );
		$robots = $this->c->get( RobotsResolver::class );
		$rules  = $this->c->get( Rules::class );
		$keep   = array();
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post instanceof \WP_Post || ! $robots->is_indexable( $post ) ) {
				continue;
			}
			if ( $rules->match( (string) get_permalink( $id ) ) ) {
				continue;
			}
			$keep[] = $id;
		}
		return array(
			'items' => array_map( array( $this, 'item' ), array_slice( $keep, ( max( 1, $page ) - 1 ) * $per_page, $per_page ) ),
			'total' => count( $keep ),
		);
	}

	/**
	 * Opportunity posts without a deadline (rolling opportunities excluded).
	 *
	 * @param int $page     Page.
	 * @param int $per_page Per page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function missing_deadline( int $page = 1, int $per_page = 50 ): array {
		global $wpdb;
		$scan = \FutureLabs\AISEO\Core\Migrations::table( 'content_scan' );
		$base = "FROM {$scan} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id LEFT JOIN {$wpdb->postmeta} d ON d.post_id = p.ID AND d.meta_key = '_flseo_opp_deadline' LEFT JOIN {$wpdb->postmeta} st ON st.post_id = p.ID AND st.meta_key = '_flseo_opp_status' WHERE p.post_status = 'publish' AND s.is_opportunity = 1 AND (d.meta_value IS NULL OR d.meta_value = '') AND (st.meta_value IS NULL OR st.meta_value <> 'rolling')";
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) {$base}" );
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT p.ID {$base} ORDER BY p.post_date DESC LIMIT %d OFFSET %d", $per_page, ( max( 1, $page ) - 1 ) * $per_page ) );
		// phpcs:enable
		return array(
			'items' => array_map( array( $this, 'item' ), array_map( 'intval', (array) $ids ) ),
			'total' => $total,
		);
	}
}
