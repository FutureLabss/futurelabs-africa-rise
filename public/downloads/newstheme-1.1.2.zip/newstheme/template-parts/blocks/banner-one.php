<?php
/**
 * Block: main banner — slider + 2×2 grid of overlay cards.
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args (see newstheme_block_types()).
 */

defined( 'ABSPATH' ) || exit;

$newstheme_slides = new WP_Query( newstheme_block_wp_query_args( $args['query'] ) );
$newstheme_side   = new WP_Query( newstheme_block_wp_query_args( $args['side'] ) );
if ( ! $newstheme_slides->have_posts() ) {
	return;
}
?>
<section class="nt-banner nt-banner--<?php echo esc_attr( $args['variant'] ?? 'one' ); ?>" aria-label="<?php esc_attr_e( 'Featured stories', 'newstheme' ); ?>">
	<div class="nt-banner__slider nt-carousel" data-nt-carousel data-autoplay="<?php echo esc_attr( $args['autoplay'] * 1000 ); ?>" data-loop role="region" aria-roledescription="<?php esc_attr_e( 'carousel', 'newstheme' ); ?>" aria-label="<?php esc_attr_e( 'Top stories', 'newstheme' ); ?>">
		<div class="nt-carousel__track">
			<?php
			while ( $newstheme_slides->have_posts() ) :
				$newstheme_slides->the_post();
				?>
				<article <?php post_class( 'nt-carousel__slide nt-overlay-card nt-overlay-card--large' ); ?> aria-roledescription="<?php esc_attr_e( 'slide', 'newstheme' ); ?>">
					<?php newstheme_post_thumb( 'newstheme-large', array( 'eager' => 0 === $newstheme_slides->current_post ) ); ?>
					<div class="nt-overlay-card__body">
						<div class="nt-overlay-card__top">
							<?php
							newstheme_post_categories();
							newstheme_posted_on( null, true );
							?>
						</div>
						<?php newstheme_post_title( 'h3' ); ?>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
		<?php get_template_part( 'template-parts/blocks/carousel-controls' ); ?>
	</div>
	<?php if ( $newstheme_side->have_posts() ) : ?>
		<div class="nt-banner__side">
			<?php
			while ( $newstheme_side->have_posts() ) :
				$newstheme_side->the_post();
				?>
				<article <?php post_class( 'nt-overlay-card' ); ?>>
					<?php newstheme_post_thumb( 'newstheme-medium' ); ?>
					<div class="nt-overlay-card__body">
						<?php
						newstheme_post_categories();
						newstheme_post_title( 'h3' );
						?>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
	<?php endif; ?>
</section>
<?php
wp_reset_postdata();
