<?php
/**
 * Footer element: widget area "Footer - Column 1".
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

echo '<div class="nt-footer__widgets">';
dynamic_sidebar( 'footer-1' );
echo '</div>';
