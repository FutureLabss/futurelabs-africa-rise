<?php
/**
 * Debounced sitemap submission to Search Console.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Gsc;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Logger;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Sitemap\Router;

defined( 'ABSPATH' ) || exit;

/**
 * Submits the sitemap index 10 minutes after the published set last changed.
 */
class Sitemaps implements Module {

	public const HOOK     = 'flseo_submit_sitemap';
	public const OPTION   = 'flseo_gsc_sitemap_submitted';
	public const DEBOUNCE = 10 * MINUTE_IN_SECONDS;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'flseo_sitemap_changed', array( $this, 'schedule' ), 20, 0 );
		add_action( self::HOOK, array( $this, 'run' ) );
	}

	/**
	 * Queue a submission at +10 minutes unless one is already pending.
	 */
	public function schedule(): bool {
		if ( ! $this->c->get( Settings::class )->get( 'sitemap_ping', true ) || ! $this->c->get( OAuth::class )->ready() || '0' === (string) get_option( 'blog_public' ) ) {
			return false;
		}
		$queue = $this->c->get( Queue::class );
		if ( $queue->is_pending( self::HOOK ) ) {
			return false;
		}
		$queue->at( time() + self::DEBOUNCE, self::HOOK );
		return true;
	}

	/**
	 * Background job handler.
	 */
	public function run(): void {
		$this->submit();
	}

	/**
	 * Submit the sitemap index now and record the outcome.
	 *
	 * @return array{at: string, ok: bool, error: string, url: string}|\WP_Error
	 */
	public function submit() {
		$oauth = $this->c->get( OAuth::class );
		if ( ! $oauth->ready() ) {
			return new \WP_Error( 'flseo_gsc_not_ready', __( 'Connect Search Console and choose a property first.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$url    = Router::index_url();
		$result = $this->c->get( Client::class )->submit_sitemap( $oauth->property(), $url );
		$record = array(
			'at'    => gmdate( 'c' ),
			'ok'    => ! is_wp_error( $result ),
			'error' => is_wp_error( $result ) ? $result->get_error_message() : '',
			'url'   => $url,
		);
		update_option( self::OPTION, $record, false );
		if ( is_wp_error( $result ) ) {
			$this->c->get( Logger::class )->warning( 'Sitemap submission to Search Console failed.', array( 'error' => $result->get_error_message() ) );
		}
		return $record;
	}

	/**
	 * Last submission record.
	 *
	 * @return array<string, mixed>
	 */
	public function last(): array {
		$value = get_option( self::OPTION, array() );
		return is_array( $value ) ? $value : array();
	}
}
