<?php
/**
 * Purges page caches after changes that alter front-end output.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Admin;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Supports WP Rocket, LiteSpeed Cache, W3 Total Cache, WP Super Cache, WP Fastest Cache,
 * SiteGround Optimizer, Breeze, Cache Enabler and Autoptimize.
 */
class CachePurge implements Module {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Whether a purge already ran in this request.
	 *
	 * @var bool
	 */
	private bool $done = false;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'flseo_settings_updated', array( $this, 'purge_all' ) );
		add_action( 'flseo_redirects_changed', array( $this, 'purge_all' ) );
		add_action( 'flseo_bulk_applied', array( $this, 'purge_all' ) );
	}

	/**
	 * Purge every supported cache once per request.
	 *
	 * @return array<int, string> Names of caches purged.
	 */
	public function purge_all(): array {
		if ( $this->done ) {
			return array();
		}
		$this->done = true;
		$purged     = array();
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
			$purged[] = 'WP Rocket';
		}
		if ( defined( 'LSCWP_V' ) || has_action( 'litespeed_purge_all' ) ) {
			do_action( 'litespeed_purge_all' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed Cache API.
			$purged[] = 'LiteSpeed Cache';
		}
		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
			$purged[] = 'W3 Total Cache';
		}
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			wp_cache_clear_cache();
			$purged[] = 'WP Super Cache';
		}
		if ( isset( $GLOBALS['wp_fastest_cache'] ) && is_object( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'deleteCache' ) ) {
			$GLOBALS['wp_fastest_cache']->deleteCache( true );
			$purged[] = 'WP Fastest Cache';
		}
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			sg_cachepress_purge_cache();
			$purged[] = 'SiteGround Optimizer';
		}
		if ( has_action( 'breeze_clear_all_cache' ) ) {
			do_action( 'breeze_clear_all_cache' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Breeze API.
			$purged[] = 'Breeze';
		}
		if ( has_action( 'cache_enabler_clear_complete_cache' ) ) {
			do_action( 'cache_enabler_clear_complete_cache' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Cache Enabler API.
			$purged[] = 'Cache Enabler';
		}
		if ( is_callable( array( '\autoptimizeCache', 'clearall' ) ) ) {
			call_user_func( array( '\autoptimizeCache', 'clearall' ) );
			$purged[] = 'Autoptimize';
		}
		/**
		 * Fires after FutureLabs AI SEO purged page caches, for hosts with custom caching.
		 *
		 * @param array $purged Names of caches purged.
		 */
		do_action( 'flseo_cache_purged', $purged );
		return $purged;
	}

	/**
	 * Allow another purge later in the same request (used by tests and long jobs).
	 */
	public function reset(): void {
		$this->done = false;
	}
}
