<?php
/**
 * Header element: secondary menu (e.g. in the top bar).
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<nav class="nt-secondary-nav" aria-label="<?php esc_attr_e( 'Secondary', 'newstheme' ); ?>">
	<?php
	wp_nav_menu(
		array(
			'theme_location' => 'secondary',
			'menu_class'     => 'nt-secondary-menu',
			'container'      => false,
			'depth'          => 1,
		)
	);
	?>
</nav>
