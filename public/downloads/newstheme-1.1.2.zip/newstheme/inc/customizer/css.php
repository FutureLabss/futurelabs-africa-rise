<?php
/**
 * Dynamic CSS generated from theme options.
 *
 * Only values that differ from the defaults are output (the defaults already
 * live in main.css). The same algorithm runs in the Customizer preview
 * (src/customizer/css-generator.js) — keep the two in sync; the parity test
 * in tools/test-customizer.mjs compares their output.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Build the dynamic stylesheet.
 *
 * @param array $settings Setting configs keyed by setting key.
 * @param array $values   Current values keyed by setting key.
 * @param array $fonts    Font families (see newstheme_font_families()).
 * @return string
 */
function newstheme_build_css( array $settings, array $values, array $fonts ) {
	$root      = array();
	$tablet    = array();
	$mobile    = array();
	$dark      = array();
	$selectors = array();

	foreach ( $settings as $key => $setting ) {
		if ( empty( $setting['css'] ) ) {
			continue;
		}
		$css     = $setting['css'];
		$default = $setting['default'] ?? null;
		$value   = array_key_exists( $key, $values ) ? $values[ $key ] : $default;
		$unit    = $css['unit'] ?? '';

		switch ( $setting['control'] ) {
			case 'color':
				if ( '' === $value || newstheme_css_same( $value, $default ) ) {
					break;
				}
				if ( isset( $css['selector'] ) ) {
					$selectors[ $css['selector'] ][] = array( $css['var'], $value );
					// Readable text color (black/white) for text on this background.
					if ( isset( $css['contrast_var'] ) && sanitize_hex_color( $value ) ) {
						$selectors[ $css['selector'] ][] = array( $css['contrast_var'], newstheme_contrast_color( $value ) );
					}
				} elseif ( 'dark' === ( $css['scope'] ?? '' ) ) {
					$dark[] = array( $css['var'], $value );
				} else {
					$root[] = array( $css['var'], $value );
				}
				break;

			case 'palette':
				// Always output: colors may reference var(--nt-preset-N).
				foreach ( array_values( (array) $value ) as $i => $color ) {
					$root[] = array( $css['var'] . ( $i + 1 ), $color );
				}
				break;

			case 'number':
				if ( ! newstheme_css_same( $value, $default ) ) {
					$root[] = array( $css['var'], $value . $unit );
				}
				break;

			case 'responsive':
				if ( ! newstheme_css_same( $value, $default ) ) {
					$root[]   = array( $css['var'], $value['desktop'] . $unit );
					$tablet[] = array( $css['var'], $value['tablet'] . $unit );
					$mobile[] = array( $css['var'], $value['mobile'] . $unit );
				}
				break;

			case 'typography':
				$prefix = $css['prefix'];
				foreach ( array( 'family', 'weight', 'transform', 'decoration' ) as $prop ) {
					if ( newstheme_css_same( $value[ $prop ], $default[ $prop ] ) ) {
						continue;
					}
					$output = $value[ $prop ];
					if ( 'family' === $prop ) {
						$output = $fonts[ $value['family'] ]['stack'] ?? $fonts[ $default['family'] ]['stack'];
					}
					$root[] = array( $prefix . '-' . $prop, $output );
				}
				foreach ( array(
					'size'       => '-size',
					'lineHeight' => '-lh',
					'spacing'    => '-ls',
				) as $prop => $suffix ) {
					// A responsive value is output for all devices if any device changed,
					// so a new desktop value can't leak over the stylesheet's tablet value.
					if ( newstheme_css_same( $value[ $prop ], $default[ $prop ] ) ) {
						continue;
					}
					$root[]   = array( $prefix . $suffix, $value[ $prop ]['desktop'] . 'px' );
					$tablet[] = array( $prefix . $suffix, $value[ $prop ]['tablet'] . 'px' );
					$mobile[] = array( $prefix . $suffix, $value[ $prop ]['mobile'] . 'px' );
				}
				break;
		}
	}

	$out = newstheme_css_block( ':root', $root );
	if ( $tablet ) {
		$out .= '@media (max-width:940px){' . newstheme_css_block( ':root', $tablet ) . '}';
	}
	if ( $mobile ) {
		$out .= '@media (max-width:610px){' . newstheme_css_block( ':root', $mobile ) . '}';
	}
	$out .= newstheme_css_block( ':root.nt-dark', $dark );
	foreach ( $selectors as $selector => $declarations ) {
		$out .= newstheme_css_block( $selector, $declarations );
	}

	return $out;
}

/**
 * Black or white, whichever has more contrast against a hex color (WCAG
 * relative luminance). Mirrored in css-generator.js.
 *
 * @param string $hex Hex color (#rgb or #rrggbb).
 * @return string '#000' or '#fff'.
 */
function newstheme_contrast_color( $hex ) {
	$hex = ltrim( $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	$lum = 0;
	foreach ( array( 0.2126, 0.7152, 0.0722 ) as $i => $weight ) {
		$c    = hexdec( substr( $hex, $i * 2, 2 ) ) / 255;
		$c    = $c <= 0.03928 ? $c / 12.92 : pow( ( $c + 0.055 ) / 1.055, 2.4 );
		$lum += $weight * $c;
	}
	// Contrast with white: 1.05 / (L + 0.05); with black: (L + 0.05) / 0.05.
	return ( 1.05 / ( $lum + 0.05 ) ) >= ( ( $lum + 0.05 ) / 0.05 ) ? '#fff' : '#000';
}

/**
 * Compare two option values for equality (by their string forms).
 *
 * @param mixed $a First value.
 * @param mixed $b Second value.
 * @return bool
 */
function newstheme_css_same( $a, $b ) {
	if ( is_array( $a ) || is_array( $b ) ) {
		if ( ! is_array( $a ) || ! is_array( $b ) ) {
			return false;
		}
		foreach ( $b as $k => $v ) {
			if ( ! array_key_exists( $k, $a ) || ! newstheme_css_same( $a[ $k ], $v ) ) {
				return false;
			}
		}
		return true;
	}
	if ( is_bool( $a ) || is_bool( $b ) ) {
		return (bool) $a === (bool) $b;
	}
	return (string) $a === (string) $b;
}

/**
 * Render one CSS rule block, or nothing if there are no declarations.
 *
 * @param string $selector     Selector.
 * @param array  $declarations List of [ property, value ].
 * @return string
 */
function newstheme_css_block( $selector, array $declarations ) {
	if ( ! $declarations ) {
		return '';
	}
	$body = array();
	foreach ( $declarations as list( $property, $value ) ) {
		$body[] = $property . ':' . $value;
	}
	return $selector . '{' . implode( ';', $body ) . '}';
}

/**
 * Current values of all CSS-producing settings.
 *
 * @return array
 */
function newstheme_current_css_values() {
	$values = array();
	foreach ( newstheme_all_settings() as $key => $setting ) {
		if ( ! empty( $setting['css'] ) ) {
			$values[ $key ] = newstheme_get_mod( $key );
		}
	}
	return $values;
}

/**
 * Print the dynamic CSS after the main stylesheet.
 */
function newstheme_enqueue_dynamic_css() {
	$css = newstheme_build_css( newstheme_all_settings(), newstheme_current_css_values(), newstheme_font_families() );

	// Strip anything that could close the style tag; values are already sanitized.
	$css = str_replace( array( '<', '>' ), '', $css );

	wp_add_inline_style( 'newstheme-main', $css );
}
add_action( 'wp_enqueue_scripts', 'newstheme_enqueue_dynamic_css', 20 );

/**
 * Body classes driven by options (layout, hover effects, animations).
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function newstheme_option_body_classes( $classes ) {
	foreach ( newstheme_customizer_config()['settings'] as $key => $setting ) {
		if ( empty( $setting['body_class'] ) ) {
			continue;
		}
		$value = newstheme_get_mod( $key );
		if ( 'toggle' === $setting['control'] ) {
			if ( $value ) {
				$classes[] = $setting['body_class'];
			}
		} else {
			$classes[] = sprintf( $setting['body_class'], sanitize_html_class( $value ) );
		}
	}
	return $classes;
}
add_filter( 'body_class', 'newstheme_option_body_classes' );
