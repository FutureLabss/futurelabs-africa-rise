<?php
/**
 * Header element: ad banner image.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

newstheme_render_block(
	'ad',
	array(
		'image' => (int) newstheme_get_mod( 'header_ad_image' ),
		'url'   => newstheme_get_mod( 'header_ad_url' ),
		'label' => '',
	)
);
