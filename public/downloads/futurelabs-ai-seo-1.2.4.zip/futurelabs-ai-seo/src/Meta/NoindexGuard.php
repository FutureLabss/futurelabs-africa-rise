<?php
/**
 * Safeguard against accidentally noindexing most of a site.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Meta;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Requires a typed confirmation when a change would noindex more than half of published URLs.
 */
class NoindexGuard {

	public const THRESHOLD = 0.5;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Evaluate noindexing additional posts.
	 *
	 * @param array<int, int> $post_ids     Posts that would become noindex.
	 * @param string          $confirmation Phrase supplied by the user.
	 * @return array{allowed: bool, projected: int, published: int, phrase: string}
	 */
	public function check_posts( array $post_ids, string $confirmation = '' ): array {
		$current   = $this->noindexed_ids();
		$published = $this->published_count();
		$public    = array_filter( array_map( 'absint', $post_ids ), fn( $id ) => $this->is_published_public( $id ) );
		$projected = count( array_unique( array_merge( $current, $public ) ) ) + $this->type_noindexed_count( (array) $this->c->get( Settings::class )->get( 'post_types' ) );
		return $this->verdict( $projected, $published, $confirmation );
	}

	/**
	 * Evaluate a post type settings change.
	 *
	 * @param array<string, array<string, mixed>> $post_types   Proposed per-type settings.
	 * @param string                              $confirmation Phrase supplied by the user.
	 * @return array{allowed: bool, projected: int, published: int, phrase: string}
	 */
	public function check_settings( array $post_types, string $confirmation = '' ): array {
		$projected = $this->type_noindexed_count( $post_types ) + count( $this->noindexed_ids( $post_types ) );
		return $this->verdict( $projected, $this->published_count(), $confirmation );
	}

	/**
	 * The phrase a user must type.
	 *
	 * @param int $projected Projected noindexed count.
	 */
	public static function phrase( int $projected ): string {
		return sprintf( 'NOINDEX %d PAGES', $projected );
	}

	/**
	 * Build the verdict.
	 *
	 * @param int    $projected    Projected noindexed URLs.
	 * @param int    $published    Published URLs.
	 * @param string $confirmation Supplied phrase.
	 * @return array{allowed: bool, projected: int, published: int, phrase: string}
	 */
	private function verdict( int $projected, int $published, string $confirmation ): array {
		$phrase  = self::phrase( $projected );
		$risky   = $published > 0 && $projected > (int) floor( $published * self::THRESHOLD );
		$allowed = ! $risky || trim( $confirmation ) === $phrase;
		return array(
			'allowed'   => $allowed,
			'projected' => $projected,
			'published' => $published,
			'phrase'    => $phrase,
		);
	}

	/**
	 * Published posts in public types (the sitemap universe).
	 */
	public function published_count(): int {
		global $wpdb;
		$types = $this->public_types();
		if ( ! $types ) {
			return 0;
		}
		$in = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ($in)", $types ) );
	}

	/**
	 * Published, per-post noindexed IDs in types that are otherwise indexable.
	 *
	 * @param array<string, array<string, mixed>>|null $post_types Proposed type settings, or current.
	 * @return array<int, int>
	 */
	private function noindexed_ids( ?array $post_types = null ): array {
		global $wpdb;
		$types = array_values(
			array_filter(
				$this->public_types(),
				function ( $type ) use ( $post_types ) {
					return $this->type_index( $type, $post_types );
				}
			)
		);
		if ( ! $types ) {
			return array();
		}
		$in   = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$args = array_merge( array( '_flseo_noindex' ), $types );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} m ON m.post_id=p.ID WHERE m.meta_key=%s AND m.meta_value='1' AND p.post_status='publish' AND p.post_type IN ($in)", $args ) );
		return array_map( 'absint', (array) $ids );
	}

	/**
	 * Published posts in types configured as noindex.
	 *
	 * @param array<string, array<string, mixed>> $post_types Type settings.
	 */
	private function type_noindexed_count( array $post_types ): int {
		$count = 0;
		foreach ( $this->public_types() as $type ) {
			if ( ! $this->type_index( $type, $post_types ) ) {
				$count += (int) ( wp_count_posts( $type )->publish ?? 0 );
			}
		}
		return $count;
	}

	/**
	 * Whether a type is indexable under proposed (or current) settings.
	 *
	 * @param string                                   $type       Post type.
	 * @param array<string, array<string, mixed>>|null $post_types Proposed settings.
	 */
	private function type_index( string $type, ?array $post_types ): bool {
		if ( null !== $post_types && isset( $post_types[ $type ]['index'] ) ) {
			return Settings::to_bool( $post_types[ $type ]['index'] );
		}
		return (bool) $this->c->get( Settings::class )->post_type( $type )['index'];
	}

	/**
	 * Whether a post is published in a public type.
	 *
	 * @param int $id Post ID.
	 */
	private function is_published_public( int $id ): bool {
		$post = get_post( $id );
		return $post && 'publish' === $post->post_status && in_array( $post->post_type, $this->public_types(), true );
	}

	/**
	 * Public post types except attachments.
	 *
	 * @return array<int, string>
	 */
	public function public_types(): array {
		return array_values( array_diff( get_post_types( array( 'public' => true ), 'names' ), array( 'attachment' ) ) );
	}
}
