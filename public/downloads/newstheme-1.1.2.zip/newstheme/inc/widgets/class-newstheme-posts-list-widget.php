<?php
/**
 * NewsTheme Posts List Widget.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Posts list: small thumbnails (or rank numbers) beside titles.
 */
class NewsTheme_Posts_List_Widget extends NewsTheme_Widget {

	/**
	 * Default list style.
	 *
	 * @var string
	 */
	protected $default_style = 'thumb';

	/**
	 * Default order.
	 *
	 * @var string
	 */
	protected $default_orderby = 'date';

	/**
	 * Constructor.
	 *
	 * @param string $id          Base ID.
	 * @param string $name        Name.
	 * @param string $description Description.
	 */
	public function __construct( $id = 'posts_list', $name = '', $description = '' ) {
		$this->fields                       = array_merge(
			array(
				'title' => array(
					'type'    => 'text',
					'label'   => __( 'Title', 'newstheme' ),
					'default' => __( 'Trending News', 'newstheme' ),
				),
				'style' => array(
					'type'    => 'select',
					'label'   => __( 'Style', 'newstheme' ),
					'default' => $this->default_style,
					'choices' => array(
						'thumb'    => __( 'Thumbnail + title', 'newstheme' ),
						'numbered' => __( 'Numbered thumbnails', 'newstheme' ),
						'text'     => __( 'Titles only', 'newstheme' ),
					),
				),
			),
			self::post_fields( 4 ),
			array(
				'show_date'     => array(
					'type'    => 'checkbox',
					'label'   => __( 'Show date', 'newstheme' ),
					'default' => true,
				),
				'show_category' => array(
					'type'    => 'checkbox',
					'label'   => __( 'Show category', 'newstheme' ),
					'default' => true,
				),
			)
		);
		$this->fields['orderby']['default'] = $this->default_orderby;

		parent::__construct(
			$id,
			$name ? $name : __( 'NewsTheme: Posts List', 'newstheme' ),
			$description ? $description : __( 'Recent or popular posts with small thumbnails.', 'newstheme' )
		);
	}

	/**
	 * Render.
	 *
	 * @param array $values Instance values.
	 */
	protected function render( array $values ) {
		$query = $this->posts_query( $values );
		if ( ! $query->have_posts() ) {
			return;
		}
		printf( '<ol class="nt-wposts nt-wposts--%s">', esc_attr( $values['style'] ) );
		while ( $query->have_posts() ) {
			$query->the_post();
			echo '<li class="nt-wposts__item">';
			if ( 'text' !== $values['style'] ) {
				echo '<div class="nt-wposts__thumb">';
				if ( 'numbered' === $values['style'] ) {
					printf( '<span class="nt-wposts__rank" aria-hidden="true">%d</span>', (int) $query->current_post + 1 );
				}
				newstheme_post_thumb( 'newstheme-list' );
				echo '</div>';
			}
			echo '<div class="nt-wposts__body">';
			if ( $values['show_category'] ) {
				newstheme_post_categories( null, 1, 'text' );
			}
			newstheme_post_title( 'h3' );
			if ( $values['show_date'] ) {
				newstheme_post_meta( array( 'date' ) );
			}
			echo '</div></li>';
		}
		echo '</ol>';
		wp_reset_postdata();
	}
}
