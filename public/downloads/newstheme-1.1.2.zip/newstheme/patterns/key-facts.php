<?php
/**
 * Title: Key facts box
 * Slug: newstheme/key-facts
 * Categories: newstheme, text
 * Description: A short "key facts" summary to place at the top of a story.
 *
 * @package NewsTheme
 */

?>
<!-- wp:group {"style":{"border":{"left":{"color":"var:preset|color|accent","width":"4px"}},"spacing":{"padding":{"top":"18px","bottom":"18px","left":"22px","right":"22px"}}},"backgroundColor":"background","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background-background-color has-background" style="border-left-color:var(--wp--preset--color--accent);border-left-width:4px;padding-top:18px;padding-right:22px;padding-bottom:18px;padding-left:22px"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading"><?php esc_html_e( 'Key facts', 'newstheme' ); ?></h4>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><?php esc_html_e( 'What happened, in one line.', 'newstheme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'Who it affects.', 'newstheme' ); ?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e( 'What happens next.', 'newstheme' ); ?></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->
