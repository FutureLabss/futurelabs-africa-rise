<?php
/**
 * Thin-content scoring against the configured word threshold.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Content;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * A thin score is 0 at or above the threshold and rises to 100 for an empty page.
 */
class Thin {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Configured word threshold (setting `thin_words`, default 300).
	 */
	public function threshold(): int {
		return max( 1, (int) $this->c->get( Settings::class )->get( 'thin_words', 300 ) );
	}

	/**
	 * Score for a word count.
	 *
	 * @param int $words Word count.
	 */
	public function score( int $words ): int {
		$threshold = $this->threshold();
		if ( $words >= $threshold ) {
			return 0;
		}
		return (int) max( 1, min( 100, round( ( $threshold - max( 0, $words ) ) * 100 / $threshold ) ) );
	}

	/**
	 * Whether a word count is below the threshold.
	 *
	 * @param int $words Word count.
	 */
	public function is_thin( int $words ): bool {
		return $words < $this->threshold();
	}

	/**
	 * Whether a page is so short that keeping it out of the index until it is
	 * expanded is a reasonable option (under a third of the threshold).
	 *
	 * @param int $words Word count.
	 */
	public function is_very_thin( int $words ): bool {
		return $words < (int) ceil( $this->threshold() / 3 );
	}
}
