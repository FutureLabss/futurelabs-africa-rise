<?php
/**
 * Header element: link to a random post.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<a class="nt-header-btn" href="<?php echo esc_url( newstheme_random_post_url() ); ?>" rel="nofollow"><?php newstheme_icon( 'shuffle' ); ?><span><?php echo esc_html( newstheme_get_mod( 'random_label' ) ); ?></span></a>
