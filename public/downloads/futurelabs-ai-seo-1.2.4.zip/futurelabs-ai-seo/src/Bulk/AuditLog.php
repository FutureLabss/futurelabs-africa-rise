<?php
/**
 * Audit log for every FutureLabs AI SEO change that can be undone.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Bulk;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Writes and reads `flseo_audit_log` rows.
 *
 * Row value format: old_value/new_value are JSON objects such as
 * {"kind":"post_meta","key":"_flseo_noindex","value":"1"} or
 * {"kind":"redirect","id":12,"row":{...}} so Undo can restore any change type.
 */
class AuditLog implements Module {

	public const RETENTION_DAYS = 30;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'flseo_daily', array( $this, 'purge' ) );
	}

	/**
	 * New batch id.
	 */
	public function new_batch(): string {
		return wp_generate_uuid4();
	}

	/**
	 * Write one audit row.
	 *
	 * @param string               $batch       Batch id.
	 * @param string               $action      Action name.
	 * @param string               $object_type Object type (post, term, redirect, attachment, settings).
	 * @param int                  $object_id   Object id.
	 * @param array<string, mixed> $old         Previous state.
	 * @param array<string, mixed> $new         New state.
	 */
	public function write( string $batch, string $action, string $object_type, int $object_id, array $old, array $new ): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			Migrations::table( 'audit_log' ),
			array(
				'user_id'     => get_current_user_id(),
				'action'      => sanitize_key( $action ),
				'object_type' => sanitize_key( $object_type ),
				'object_id'   => $object_id,
				'old_value'   => wp_json_encode( $old ),
				'new_value'   => wp_json_encode( $new ),
				'batch_id'    => $batch,
				'undone'      => 0,
				'created_at'  => current_time( 'mysql', true ),
			),
			array( '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * Record a post meta change, optionally in a batch.
	 *
	 * @param string      $action  Action name.
	 * @param int         $post_id Post ID.
	 * @param string      $key     Meta key.
	 * @param mixed       $old     Old value ('' when absent).
	 * @param mixed       $new     New value ('' when deleted).
	 * @param string|null $batch   Batch id; a new one is generated when null.
	 * @return string Batch id.
	 */
	public function record_single( string $action, int $post_id, string $key, $old, $new, ?string $batch = null ): string {
		$batch = $batch ?? $this->new_batch();
		$this->write(
			$batch,
			$action,
			'post',
			$post_id,
			array(
				'kind'  => 'post_meta',
				'key'   => $key,
				'value' => $old,
			),
			array(
				'kind'  => 'post_meta',
				'key'   => $key,
				'value' => $new,
			)
		);
		return $batch;
	}

	/**
	 * Rows for a batch within the undo window, newest first.
	 *
	 * @param string $batch Batch id.
	 * @return array<int, object>
	 */
	public function batch_rows( string $batch ): array {
		global $wpdb;
		$table = Migrations::table( 'audit_log' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE batch_id=%s AND undone=0 AND created_at >= %s ORDER BY id DESC", $batch, gmdate( 'Y-m-d H:i:s', time() - self::RETENTION_DAYS * DAY_IN_SECONDS ) ) );
	}

	/**
	 * Mark rows undone.
	 *
	 * @param array<int, int> $ids Row ids.
	 */
	public function mark_undone( array $ids ): void {
		global $wpdb;
		$ids = array_filter( array_map( 'absint', $ids ) );
		if ( ! $ids ) {
			return;
		}
		$table = Migrations::table( 'audit_log' );
		$in    = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET undone=1 WHERE id IN ($in)", $ids ) );
	}

	/**
	 * List recent batches (one row per batch) for the audit screen.
	 *
	 * @param int $page     Page.
	 * @param int $per_page Per page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function batches( int $page = 1, int $per_page = 50 ): array {
		global $wpdb;
		$table  = Migrations::table( 'audit_log' );
		$offset = ( max( 1, $page ) - 1 ) * $per_page;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT batch_id, MIN(action) action, MIN(user_id) user_id, COUNT(*) items, MAX(undone) undone, MIN(created_at) created_at FROM {$table} GROUP BY batch_id ORDER BY created_at DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A );
		$total = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT batch_id) FROM {$table}" );
		// phpcs:enable
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - self::RETENTION_DAYS * DAY_IN_SECONDS );
		$items  = array();
		foreach ( (array) $rows as $row ) {
			$user    = get_userdata( (int) $row['user_id'] );
			$items[] = array(
				'batch_id'   => $row['batch_id'],
				'action'     => $row['action'],
				'user'       => $user ? $user->display_name : '',
				'items'      => (int) $row['items'],
				'undone'     => (bool) $row['undone'],
				'undoable'   => ! $row['undone'] && $row['created_at'] >= $cutoff,
				'created_at' => $row['created_at'],
			);
		}
		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Delete rows older than the undo window.
	 */
	public function purge(): void {
		global $wpdb;
		$table = Migrations::table( 'audit_log' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", gmdate( 'Y-m-d H:i:s', time() - 90 * DAY_IN_SECONDS ) ) );
	}
}
