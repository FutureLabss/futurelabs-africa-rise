<?php
/**
 * Social profile links (header, footer, widget).
 *
 * @package NewsTheme
 *
 * @var array $args { @type string $class Extra list class. }
 */

defined( 'ABSPATH' ) || exit;

$newstheme_links = newstheme_active_social_links();
if ( ! $newstheme_links ) {
	return;
}
$newstheme_networks = newstheme_social_networks();
$newstheme_new_tab  = newstheme_get_mod( 'social_new_tab' );
?>
<ul class="nt-social <?php echo esc_attr( $args['class'] ?? '' ); ?>">
	<?php foreach ( $newstheme_links as $newstheme_link ) : ?>
		<li>
			<a href="<?php echo esc_url( $newstheme_link['url'] ); ?>"<?php echo $newstheme_new_tab ? ' target="_blank" rel="noopener me"' : ' rel="me"'; ?> aria-label="<?php echo esc_attr( $newstheme_networks[ $newstheme_link['network'] ] ?? $newstheme_link['network'] ); ?>">
				<?php newstheme_icon( $newstheme_link['network'] ); ?>
			</a>
		</li>
	<?php endforeach; ?>
</ul>
