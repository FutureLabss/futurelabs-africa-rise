<?php
/**
 * Resolves SEO titles, descriptions and social fields from overrides and templates.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Meta;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Title/description resolution: object override → type template → sensible default.
 */
class Templates {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Document title for a context; empty string defers to WordPress.
	 *
	 * @param Context $context Context.
	 */
	public function title( Context $context ): string {
		$settings = $this->c->get( Settings::class );
		$vars     = $this->c->get( Variables::class );
		switch ( $context->kind ) {
			case 'singular':
			case 'front':
			case 'home':
				if ( $context->object instanceof \WP_Post ) {
					return $this->post_title( $context->object );
				}
				$home = (string) $settings->get( 'home_title' );
				return $vars->replace( '' !== $home ? $home : '%sitename% %sep% %tagline% %sep% %page%' );
			case 'term':
				if ( $context->object instanceof \WP_Term ) {
					return $this->term_title( $context->object );
				}
				break;
			case 'author':
				return $vars->replace( '%title% %sep% %page% %sep% %sitename%', $context->object );
			case 'post_type_archive':
				if ( $context->object instanceof \WP_Post_Type ) {
					return $vars->replace( '%title% %sep% %page% %sep% %sitename%', null, $context->object->labels->name );
				}
				break;
			case 'search':
				/* translators: %s: search query. */
				return $vars->replace( sprintf( __( 'Search results for "%s"', 'futurelabs-ai-seo' ), get_search_query() ) . ' %sep% %sitename%' );
			case '404':
				return $vars->replace( __( 'Page not found', 'futurelabs-ai-seo' ) . ' %sep% %sitename%' );
		}
		return '';
	}

	/**
	 * SEO title for a post.
	 *
	 * @param \WP_Post $post Post.
	 */
	public function post_title( \WP_Post $post ): string {
		$vars     = $this->c->get( Variables::class );
		$override = (string) get_post_meta( $post->ID, '_flseo_title', true );
		if ( '' !== $override ) {
			return $vars->replace( $override, $post );
		}
		$template = (string) $this->c->get( Settings::class )->post_type( $post->post_type )['title'];
		return $vars->replace( '' !== $template ? $template : '%title% %sep% %sitename%', $post );
	}

	/**
	 * SEO title for a term archive.
	 *
	 * @param \WP_Term $term Term.
	 */
	public function term_title( \WP_Term $term ): string {
		$vars     = $this->c->get( Variables::class );
		$override = (string) get_term_meta( $term->term_id, '_flseo_title', true );
		if ( '' !== $override ) {
			return $vars->replace( $override, $term );
		}
		$template = (string) $this->c->get( Settings::class )->taxonomy( $term->taxonomy )['title'];
		return $vars->replace( ( '' !== $template ? $template : '%title% %sep% %sitename%' ) . ' %sep% %page%', $term );
	}

	/**
	 * Meta description for a context.
	 *
	 * @param Context $context Context.
	 */
	public function description( Context $context ): string {
		$settings = $this->c->get( Settings::class );
		$vars     = $this->c->get( Variables::class );
		switch ( $context->kind ) {
			case 'singular':
			case 'front':
			case 'home':
				if ( $context->object instanceof \WP_Post ) {
					return $this->post_description( $context->object );
				}
				$home = (string) $settings->get( 'home_description' );
				return $vars->replace( '' !== $home ? $home : '%tagline%' );
			case 'term':
				if ( $context->object instanceof \WP_Term ) {
					return $this->term_description( $context->object );
				}
				break;
			case 'author':
				if ( $context->object instanceof \WP_User ) {
					return wp_trim_words( wp_strip_all_tags( (string) get_the_author_meta( 'description', $context->object->ID ) ), 30, '' );
				}
				break;
			case 'post_type_archive':
				if ( $context->object instanceof \WP_Post_Type ) {
					$template = (string) $settings->post_type( $context->object->name )['description'];
					return '' !== $template ? $vars->replace( $template, null, $context->object->labels->name ) : wp_strip_all_tags( (string) $context->object->description );
				}
				break;
		}
		return '';
	}

	/**
	 * Meta description for a post.
	 *
	 * @param \WP_Post $post Post.
	 */
	public function post_description( \WP_Post $post ): string {
		$vars     = $this->c->get( Variables::class );
		$override = (string) get_post_meta( $post->ID, '_flseo_description', true );
		if ( '' !== $override ) {
			return $vars->replace( $override, $post );
		}
		if ( '' !== (string) $post->post_password ) {
			// Protected posts get no automatic description, so none of their text leaks.
			return '';
		}
		$template = (string) $this->c->get( Settings::class )->post_type( $post->post_type )['description'];
		if ( '' !== $template ) {
			return $vars->replace( $template, $post );
		}
		return Variables::excerpt( $post );
	}

	/**
	 * Meta description for a term.
	 *
	 * @param \WP_Term $term Term.
	 */
	public function term_description( \WP_Term $term ): string {
		$vars     = $this->c->get( Variables::class );
		$override = (string) get_term_meta( $term->term_id, '_flseo_description', true );
		if ( '' !== $override ) {
			return $vars->replace( $override, $term );
		}
		$template = (string) $this->c->get( Settings::class )->taxonomy( $term->taxonomy )['description'];
		if ( '' !== $template ) {
			return $vars->replace( $template, $term );
		}
		return wp_trim_words( wp_strip_all_tags( $term->description ), 30, '' );
	}

	/**
	 * Open Graph fields for a context.
	 *
	 * @param Context $context     Context.
	 * @param string  $title       Resolved SEO title.
	 * @param string  $description Resolved description.
	 * @param string  $url         Canonical URL.
	 * @return array{type: string, title: string, description: string, url: string, image: string, image_width: int, image_height: int, published: string, modified: string}
	 */
	public function social( Context $context, string $title, string $description, string $url ): array {
		$out      = array(
			'type'         => 'website',
			'title'        => $title,
			'description'  => $description,
			'url'          => $url,
			'image'        => '',
			'image_width'  => 0,
			'image_height' => 0,
			'published'    => '',
			'modified'     => '',
		);
		$image_id = 0;
		if ( $context->object instanceof \WP_Post ) {
			$post = $context->object;
			if ( 'singular' === $context->kind && 'page' !== $post->post_type ) {
				$out['type']      = 'article';
				$out['published'] = (string) get_post_time( 'c', true, $post );
				$out['modified']  = (string) get_post_modified_time( 'c', true, $post );
			}
			$out['title']       = (string) get_post_meta( $post->ID, '_flseo_og_title', true ) ?: $title;
			$out['description'] = (string) get_post_meta( $post->ID, '_flseo_og_description', true ) ?: $description;
			$out['image']       = (string) get_post_meta( $post->ID, '_flseo_og_image', true );
			if ( '' === $out['image'] ) {
				$image_id = (int) get_post_thumbnail_id( $post );
			}
		} elseif ( $context->object instanceof \WP_Term ) {
			$term               = $context->object;
			$out['title']       = (string) get_term_meta( $term->term_id, '_flseo_og_title', true ) ?: $title;
			$out['description'] = (string) get_term_meta( $term->term_id, '_flseo_og_description', true ) ?: $description;
			$out['image']       = (string) get_term_meta( $term->term_id, '_flseo_og_image', true );
		}
		if ( $image_id ) {
			$src = wp_get_attachment_image_src( $image_id, 'full' );
			if ( $src ) {
				$out['image']        = (string) $src[0];
				$out['image_width']  = (int) $src[1];
				$out['image_height'] = (int) $src[2];
			}
		}
		if ( '' === $out['image'] ) {
			$out['image'] = (string) $this->c->get( Settings::class )->get( 'default_og_image' );
		}
		return $out;
	}
}
