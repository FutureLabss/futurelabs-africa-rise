<?php
/**
 * Registers every REST controller.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Rest;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Attaches controllers on rest_api_init.
 */
final class Routes implements Module {

	/**
	 * Controller classes.
	 *
	 * @var array<int, string>
	 */
	public const CONTROLLERS = array(
		SettingsController::class,
		ConflictsController::class,
		SitemapController::class,
		RedirectsController::class,
		NotFoundController::class,
		GscController::class,
		IndexingController::class,
		ContentController::class,
		LinksController::class,
		OpportunityController::class,
		ImagesController::class,
		BulkController::class,
		AuditController::class,
		ImportController::class,
		SchemaController::class,
		AiController::class,
		CannibalizationController::class,
		PerformanceController::class,
		ReportsController::class,
	);

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_filter( 'rest_post_dispatch', array( $this, 'proxy_safe_status' ), 10, 3 );
	}

	/**
	 * Send upstream failures as 424 instead of 502/504.
	 *
	 * Cloudflare and other proxies replace a 502 or 504 from the origin with their own
	 * error page, so the editor would see "error code: 502" instead of our message.
	 * The original status stays available in the X-FLSEO-Upstream-Status header.
	 *
	 * @param mixed $response Response.
	 * @param mixed $server   Server.
	 * @param mixed $request  Request.
	 * @return mixed
	 */
	public function proxy_safe_status( $response, $server, $request ) {
		if ( ! $response instanceof \WP_HTTP_Response || ! $request instanceof \WP_REST_Request ) {
			return $response;
		}
		$status = $response->get_status();
		if ( ( 502 === $status || 504 === $status ) && str_starts_with( $request->get_route(), '/' . Controller::NAMESPACE . '/' ) ) {
			$response->set_status( 424 );
			$response->header( 'X-FLSEO-Upstream-Status', (string) $status );
		}
		return $response;
	}

	/**
	 * Register every controller's routes.
	 */
	public function register_routes(): void {
		foreach ( self::CONTROLLERS as $class ) {
			if ( class_exists( $class ) ) {
				$this->c->get( $class )->register_routes();
			}
		}
	}
}
