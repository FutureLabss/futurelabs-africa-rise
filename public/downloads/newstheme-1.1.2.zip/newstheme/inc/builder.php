<?php
/**
 * Header/footer builder: element registry, default layouts, sanitizing and
 * rendering. Layouts are stored as
 *
 *     [ rowId => [ 'columns' => n, 'zones' => [ [ elementId, … ], … ] ], … ]
 *
 * and edited in the Customizer by the `builder` control. Each element is a
 * template part: template-parts/header/{id}.php or template-parts/footer/{id}.php.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Builder definitions: rows and available elements per builder.
 *
 * @return array<string, array{rows: array, elements: array}>
 */
function newstheme_builders() {
	$header_elements = array(
		'date-time'        => __( 'Date & Time', 'newstheme' ),
		'ticker'           => __( 'Ticker News', 'newstheme' ),
		'social'           => __( 'Social Icons', 'newstheme' ),
		'branding'         => __( 'Logo / Site Title', 'newstheme' ),
		'newsletter'       => __( 'Newsletter Button', 'newstheme' ),
		'random-news'      => __( 'Random News Button', 'newstheme' ),
		'custom-button'    => __( 'Custom Button', 'newstheme' ),
		'offcanvas-toggle' => __( 'Sidebar Toggle', 'newstheme' ),
		'menu'             => __( 'Primary Menu', 'newstheme' ),
		'secondary-menu'   => __( 'Secondary Menu', 'newstheme' ),
		'search'           => __( 'Search', 'newstheme' ),
		'theme-mode'       => __( 'Dark Mode Toggle', 'newstheme' ),
		'ad-banner'        => __( 'Ad Banner', 'newstheme' ),
		'header-widgets'   => __( 'Widget Area', 'newstheme' ),
	);
	$header_rows     = array(
		'top'  => __( 'Top Row', 'newstheme' ),
		'main' => __( 'Main Row', 'newstheme' ),
		'nav'  => __( 'Bottom Row', 'newstheme' ),
	);

	return apply_filters(
		'newstheme_builders',
		array(
			'header'        => array(
				'rows'        => $header_rows,
				'elements'    => $header_elements,
				'columns'     => 3,
				'max_columns' => 3,
				'zone_labels' => array( __( 'Left', 'newstheme' ), __( 'Center', 'newstheme' ), __( 'Right', 'newstheme' ) ),
			),
			'header_mobile' => array(
				'rows'        => $header_rows,
				'elements'    => array( 'menu-toggle' => __( 'Mobile Menu Toggle', 'newstheme' ) ) + $header_elements,
				'columns'     => 3,
				'max_columns' => 3,
				'zone_labels' => array( __( 'Left', 'newstheme' ), __( 'Center', 'newstheme' ), __( 'Right', 'newstheme' ) ),
			),
			'footer'        => array(
				'rows'        => array(
					'widgets' => __( 'Widgets Row', 'newstheme' ),
					'bottom'  => __( 'Bottom Bar', 'newstheme' ),
				),
				'elements'    => array(
					'footer-1'    => __( 'Footer Widgets 1', 'newstheme' ),
					'footer-2'    => __( 'Footer Widgets 2', 'newstheme' ),
					'footer-3'    => __( 'Footer Widgets 3', 'newstheme' ),
					'footer-4'    => __( 'Footer Widgets 4', 'newstheme' ),
					'copyright'   => __( 'Copyright', 'newstheme' ),
					'footer-menu' => __( 'Footer Menu', 'newstheme' ),
					'social'      => __( 'Social Icons', 'newstheme' ),
					'footer-logo' => __( 'Logo / Site Title', 'newstheme' ),
				),
				'columns'     => null, // Per row, 1–4.
				'max_columns' => 4,
				'zone_labels' => array( __( 'Col 1', 'newstheme' ), __( 'Col 2', 'newstheme' ), __( 'Col 3', 'newstheme' ), __( 'Col 4', 'newstheme' ) ),
			),
		)
	);
}

/**
 * Default layouts (the reference design).
 *
 * @param string $builder Builder ID.
 * @return array
 */
function newstheme_builder_default( $builder ) {
	$row = static function ( array $zones, $columns = null ) {
		return array(
			'columns' => $columns ?? count( $zones ),
			'zones'   => $zones,
		);
	};

	switch ( $builder ) {
		case 'header':
			return array(
				'top'  => $row( array( array( 'date-time' ), array(), array( 'ticker' ) ) ),
				'main' => $row( array( array( 'social' ), array( 'branding' ), array( 'newsletter', 'random-news' ) ) ),
				'nav'  => $row( array( array( 'offcanvas-toggle' ), array( 'menu' ), array( 'search', 'theme-mode' ) ) ),
			);
		case 'header_mobile':
			return array(
				'top'  => $row( array( array(), array( 'ticker' ), array() ) ),
				'main' => $row( array( array( 'social' ), array( 'branding' ), array( 'newsletter', 'random-news' ) ) ),
				'nav'  => $row( array( array( 'menu-toggle' ), array( 'menu' ), array( 'search', 'theme-mode' ) ) ),
			);
		case 'footer':
			return array(
				'widgets' => $row( array( array( 'footer-1' ), array( 'footer-2' ), array( 'footer-3' ) ) ),
				'bottom'  => $row( array( array( 'copyright' ), array( 'footer-menu' ) ) ),
			);
	}
	return array();
}

/**
 * Sanitize a builder layout: known rows, 1..max columns, known elements,
 * each element placed at most once.
 *
 * @param mixed  $value   Raw value.
 * @param string $builder Builder ID.
 * @return array
 */
function newstheme_sanitize_builder( $value, $builder ) {
	$def   = newstheme_builders()[ $builder ];
	$value = is_array( $value ) ? $value : array();
	$seen  = array();
	$clean = array();

	foreach ( array_keys( $def['rows'] ) as $row_id ) {
		$row     = isset( $value[ $row_id ] ) && is_array( $value[ $row_id ] ) ? $value[ $row_id ] : array();
		$columns = $def['columns'] ?? max( 1, min( $def['max_columns'], (int) ( $row['columns'] ?? 1 ) ) );
		$zones   = array();
		for ( $i = 0; $i < $columns; $i++ ) {
			$zones[ $i ] = array();
			foreach ( (array) ( $row['zones'][ $i ] ?? array() ) as $element ) {
				$element = (string) $element;
				if ( isset( $def['elements'][ $element ] ) && ! isset( $seen[ $element ] ) ) {
					$seen[ $element ] = true;
					$zones[ $i ][]    = $element;
				}
			}
		}
		$clean[ $row_id ] = array(
			'columns' => $columns,
			'zones'   => $zones,
		);
	}
	return $clean;
}

/**
 * Current layout of a builder.
 *
 * @param string $builder Builder ID.
 * @return array
 */
function newstheme_builder_layout( $builder ) {
	return apply_filters(
		'newstheme_builder_layout',
		newstheme_sanitize_builder( newstheme_get_mod( $builder . '_layout' ), $builder ),
		$builder
	);
}

/**
 * Whether an element has anything to show (e.g. social needs profiles).
 *
 * @param string $id Element ID.
 * @return bool
 */
function newstheme_builder_element_visible( $id ) {
	switch ( $id ) {
		case 'date-time':
			return newstheme_get_mod( 'show_date' ) || newstheme_get_mod( 'show_time' );
		case 'social':
			return (bool) newstheme_active_social_links();
		case 'offcanvas-toggle':
			return is_active_sidebar( 'offcanvas-sidebar' );
		case 'menu':
		case 'menu-toggle':
			return has_nav_menu( 'primary' );
		case 'secondary-menu':
			return has_nav_menu( 'secondary' );
		case 'footer-menu':
			return has_nav_menu( 'footer' );
		case 'header-widgets':
			return is_active_sidebar( 'header-builder' );
		case 'footer-1':
		case 'footer-2':
		case 'footer-3':
		case 'footer-4':
			return is_active_sidebar( $id );
		case 'ad-banner':
			return (bool) newstheme_get_mod( 'header_ad_image' );
		case 'custom-button':
			return '' !== trim( (string) newstheme_get_mod( 'custom_button_label' ) );
		default:
			return true;
	}
}

/**
 * Render a builder's rows. Rows with nothing visible are skipped.
 *
 * @param string $builder Builder ID.
 * @param string $part    Template part directory ('header' or 'footer').
 * @param string $context Suffix for element IDs (unique per rendered copy).
 */
function newstheme_render_builder( $builder, $part, $context = '' ) {
	foreach ( newstheme_builder_layout( $builder ) as $row_id => $row ) {
		$zones = array_map(
			static function ( $zone ) {
				return array_values( array_filter( $zone, 'newstheme_builder_element_visible' ) );
			},
			$row['zones']
		);
		if ( ! array_filter( $zones ) ) {
			continue;
		}

		printf(
			'<div class="nt-%1$s__row nt-%1$s__row--%2$s"><div class="nt-container nt-%1$s__inner" style="--nt-cols: %3$d">',
			esc_attr( $part ),
			esc_attr( $row_id ),
			(int) $row['columns']
		);
		foreach ( $zones as $i => $elements ) {
			printf(
				'<div class="nt-%1$s__col nt-%1$s__col--%2$d%3$s">',
				esc_attr( $part ),
				(int) $i + 1,
				$elements ? '' : ' is-empty'
			);
			foreach ( $elements as $element ) {
				get_template_part( "template-parts/{$part}/{$element}", null, array( 'context' => $context ) );
			}
			echo '</div>';
		}
		echo '</div></div>';
	}
}

/**
 * ID suffix for an element template part ('' for the first copy, '-m' for the
 * mobile header), so duplicated elements keep unique IDs.
 *
 * @param array $args Template part args.
 * @return string
 */
function newstheme_element_suffix( $args ) {
	return isset( $args['context'] ) && '' !== $args['context'] ? '-' . sanitize_key( $args['context'] ) : '';
}

/**
 * Dialogs requested by elements (newsletter, off-canvas). Printed once, at the
 * end of the header, so they survive Customizer selective refresh.
 *
 * @param string|null $add Dialog to request.
 * @return string[] Requested dialogs.
 */
function newstheme_dialogs( $add = null ) {
	static $dialogs = array();
	if ( $add ) {
		$dialogs[ $add ] = true;
	}
	return array_keys( $dialogs );
}
