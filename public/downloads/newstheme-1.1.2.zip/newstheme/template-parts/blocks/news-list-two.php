<?php
/**
 * Block: news list — compact rows (small thumbnail, title, meta).
 *
 * @package NewsTheme
 *
 * @var array $args Sanitized block args (see newstheme_block_types()).
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="nt-block nt-block--list nt-block--list-two" <?php echo $args['title'] ? 'aria-labelledby="' . esc_attr( $args['id'] ) . '-title"' : ''; ?>>
	<?php newstheme_block_heading( $args['title'], $args['id'] ); ?>
	<div class="nt-grid nt-grid--<?php echo (int) $args['columns']; ?>">
		<?php
		while ( $args['loop']->have_posts() ) :
			$args['loop']->the_post();
			?>
			<article <?php post_class( 'nt-post nt-post--row nt-post--compact' ); ?> data-nt-animate>
				<?php newstheme_post_thumb( 'newstheme-list', array( 'badge' => true ) ); ?>
				<div class="nt-post__body">
					<?php
					newstheme_post_title( 'h3' );
					newstheme_post_meta( $args['meta'] );
					?>
				</div>
			</article>
		<?php endwhile; ?>
	</div>
</section>
