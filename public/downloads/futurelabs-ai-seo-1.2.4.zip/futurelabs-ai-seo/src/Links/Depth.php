<?php
/**
 * Click depth reports.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Links;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;

defined( 'ABSPATH' ) || exit;

/**
 * Depth distribution and deep or unreachable posts.
 */
class Depth {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Count of indexable published posts per click depth ("unreachable" for no path).
	 *
	 * @return array<string, int>
	 */
	public function distribution(): array {
		global $wpdb;
		$stats = Migrations::table( 'link_stats' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( "SELECT s.click_depth d, COUNT(*) n FROM {$stats} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' GROUP BY s.click_depth ORDER BY s.click_depth ASC" );
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$key         = (int) $row->d >= Graph::MAX_DEPTH ? 'unreachable' : (string) (int) $row->d;
			$out[ $key ] = (int) $row->n;
		}
		return $out;
	}

	/**
	 * Posts deeper than a minimum depth (unreachable posts included last).
	 *
	 * @param int $min_depth Lowest depth to list (default: deeper than 4 clicks).
	 * @param int $page      Page.
	 * @param int $per_page  Per page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function deep( int $min_depth = Graph::DEEP + 1, int $page = 1, int $per_page = 50 ): array {
		global $wpdb;
		$stats  = Migrations::table( 'link_stats' );
		$offset = ( max( 1, $page ) - 1 ) * $per_page;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$stats} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.click_depth >= %d", $min_depth ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT s.post_id, s.inbound, s.outbound, s.click_depth, p.post_title, p.post_type FROM {$stats} s INNER JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE p.post_status = 'publish' AND s.click_depth >= %d ORDER BY s.click_depth ASC, s.inbound ASC LIMIT %d OFFSET %d", $min_depth, $per_page, $offset ) );
		// phpcs:enable
		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = Orphans::item( $row );
		}
		return array(
			'items' => $items,
			'total' => $total,
		);
	}
}
