<?php
/**
 * AI suggestions: generation, pending storage, approval and rate limiting.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Ai;

use FutureLabs\AISEO\Bulk\AuditLog;
use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Queue;
use FutureLabs\AISEO\Core\Settings;
use FutureLabs\AISEO\Meta\PostMeta;

defined( 'ABSPATH' ) || exit;

/**
 * Every AI output is stored in `flseo_ai_suggestions` as `pending`. Nothing is written
 * to post, term or attachment data until an editor approves it.
 */
class Approvals implements Module {

	public const ALT_HOOK        = 'flseo_ai_alt_batch';
	public const ALT_QUEUE       = 'flseo_ai_alt_queue';
	public const ALT_PROGRESS    = 'flseo_ai_alt_progress';
	private const ALT_PER_RUN    = 5;
	private const MAX_IMAGE_SIZE = 3145728;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( self::ALT_HOOK, array( $this, 'run_alt_batch' ) );
		$embeddings = $this->c->get( Embeddings::class );
		add_filter( 'flseo_similarity_provider', array( $embeddings, 'filter_provider' ), 20 );
		add_action( Embeddings::HOOK, array( $embeddings, 'run_batch' ) );
		add_action( 'flseo_settings_updated', array( $embeddings, 'on_settings_updated' ) );
		add_action( 'save_post', array( $embeddings, 'on_save_post' ), 30, 2 );
		add_action( 'deleted_post', array( $embeddings, 'forget' ) );
	}

	/**
	 * Generate a suggestion and store it as pending.
	 *
	 * @param int    $object_id   Post or attachment ID.
	 * @param string $field       Field (see Prompts::FIELDS).
	 * @param int    $user_id     Requesting user.
	 * @param bool   $interactive Whether an editor is waiting (allows one retry).
	 * @return array<string, mixed>|\WP_Error Stored suggestion.
	 */
	public function suggest( int $object_id, string $field, int $user_id, bool $interactive = true ) {
		$client = $this->c->get( AiClient::class );
		if ( ! $client->enabled() ) {
			return new \WP_Error( 'flseo_ai_disabled', __( 'AI assist is turned off. An administrator can enable it in FutureLabs AI SEO settings.', 'futurelabs-ai-seo' ), array( 'status' => 403 ) );
		}
		if ( ! in_array( $field, Prompts::FIELDS, true ) ) {
			return new \WP_Error( 'flseo_ai_field', __( 'Unsupported suggestion type.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$post = get_post( $object_id );
		if ( ! $post instanceof \WP_Post ) {
			return new \WP_Error( 'flseo_ai_not_found', __( 'Post or image not found.', 'futurelabs-ai-seo' ), array( 'status' => 404 ) );
		}
		$is_image = 'attachment' === $post->post_type && wp_attachment_is_image( $post->ID );
		if ( ( 'alt' === $field ) !== $is_image ) {
			return new \WP_Error( 'flseo_ai_field', __( 'Alt text suggestions are only available for images, and images only support alt text.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}

		$images = array();
		if ( 'alt' === $field ) {
			$image = $this->image_payload( $post->ID );
			if ( is_wp_error( $image ) ) {
				return $image;
			}
			$images[] = $image;
			$prompt   = Prompts::alt( $post );
		} else {
			$prompt = Prompts::for_post( $field, $post, 'merge_brief' === $field ? $this->related_posts( $post->ID ) : array(), $this->finding( $post->ID ) );
		}

		$limit = $this->consume_rate_limit( $user_id );
		if ( is_wp_error( $limit ) ) {
			return $limit;
		}

		$result = $client->send( Prompts::system(), $prompt, $images, $interactive );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( $result['truncated'] && in_array( $field, Prompts::APPLIED_FIELDS, true ) ) {
			return new \WP_Error( 'flseo_ai_truncated', __( 'The suggestion was cut off before it was complete, so it was not saved. Try again.', 'futurelabs-ai-seo' ), array( 'status' => 502 ) );
		}
		$value = Prompts::clean( $field, $result['text'], $post );
		if ( is_wp_error( $value ) ) {
			return $value;
		}
		$id = $this->insert( $post->ID, $field, $value, $user_id );
		if ( ! $id ) {
			return new \WP_Error( 'flseo_ai_store', __( 'The suggestion could not be saved.', 'futurelabs-ai-seo' ), array( 'status' => 500 ) );
		}
		$row              = (array) $this->get( $id );
		$row['truncated'] = (bool) $result['truncated'];
		return $row;
	}

	/**
	 * Image as base64 for the API.
	 *
	 * @param int $attachment_id Attachment.
	 * @return array{media_type: string, data: string}|\WP_Error
	 */
	private function image_payload( int $attachment_id ) {
		$file  = get_attached_file( $attachment_id );
		$size  = $file && is_readable( $file ) ? (int) filesize( $file ) : 0;
		$mime  = $size ? wp_get_image_mime( $file ) : false;
		$types = $this->c->get( AiClient::class )->image_types();
		if ( ! $types ) {
			return new \WP_Error( 'flseo_ai_no_images', __( 'The selected AI provider or model cannot read images, so alt text suggestions are not available.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		if ( ! $file || ! $mime || ! in_array( $mime, $types, true ) || $size < 1 || $size > self::MAX_IMAGE_SIZE ) {
			$names = implode( ', ', array_map( static fn( $t ) => strtoupper( str_replace( array( 'image/', 'jpeg' ), array( '', 'jpg' ), $t ) ), $types ) );
			/* translators: %s: accepted formats, e.g. "JPG, PNG, WEBP". */
			return new \WP_Error( 'flseo_ai_image', sprintf( __( 'The image must be a %s file no larger than 3 MB.', 'futurelabs-ai-seo' ), $names ), array( 'status' => 400 ) );
		}
		$binary = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local upload.
		if ( ! is_string( $binary ) ) {
			return new \WP_Error( 'flseo_ai_image', __( 'The image file could not be read.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		return array(
			'media_type' => $mime,
			'data'       => base64_encode( $binary ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- API requires base64.
		);
	}

	/**
	 * Duplicate-group or same-edition posts for a merge brief (max 4).
	 *
	 * @param int $post_id Post.
	 * @return array<int, \WP_Post>
	 */
	private function related_posts( int $post_id ): array {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT dup_group_id, edition_key FROM {$table} WHERE post_id=%d", $post_id ) );
		$ids = array();
		if ( $row && (int) $row->dup_group_id > 0 ) {
			$ids = $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$table} WHERE dup_group_id=%d AND post_id<>%d LIMIT 4", (int) $row->dup_group_id, $post_id ) );
		}
		if ( ! $ids && $row && '' !== (string) $row->edition_key ) {
			$ids = $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$table} WHERE edition_key=%s AND post_id<>%d ORDER BY edition_year DESC LIMIT 4", (string) $row->edition_key, $post_id ) );
		}
		// phpcs:enable
		if ( ! $ids ) {
			$ids = array_keys( $this->c->get( Embeddings::class )->similar( $post_id, 3 ) );
		}
		$posts = array();
		foreach ( $ids as $id ) {
			$post = get_post( (int) $id );
			if ( $post instanceof \WP_Post && 'publish' === $post->post_status ) {
				$posts[] = $post;
			}
		}
		return $posts;
	}

	/**
	 * Stored content finding for a post, used as context for rewrite briefs.
	 *
	 * @param int $post_id Post.
	 */
	private function finding( int $post_id ): string {
		global $wpdb;
		$table = Migrations::table( 'content_scan' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (string) $wpdb->get_var( $wpdb->prepare( "SELECT reason FROM {$table} WHERE post_id=%d", $post_id ) );
	}

	/**
	 * Count a request against the per-user hourly limit.
	 *
	 * @param int $user_id User.
	 * @return true|\WP_Error
	 */
	public function consume_rate_limit( int $user_id ) {
		$limit = (int) $this->c->get( Settings::class )->get( 'ai_rate_limit', 30 );
		if ( $limit <= 0 ) {
			return true;
		}
		$key  = $this->rate_key( $user_id );
		$used = (int) get_transient( $key );
		if ( $used >= $limit ) {
			return new \WP_Error(
				'flseo_ai_user_limit',
				/* translators: %d: requests per hour. */
				sprintf( __( 'You have reached the limit of %d AI requests per hour. Try again later.', 'futurelabs-ai-seo' ), $limit ),
				array(
					'status'      => 429,
					'retry_after' => $this->seconds_to_next_hour(),
				)
			);
		}
		set_transient( $key, $used + 1, $this->seconds_to_next_hour() + 60 );
		return true;
	}

	/**
	 * Rate limit usage for a user.
	 *
	 * @param int $user_id User.
	 * @return array{limit: int, used: int, remaining: int|null}
	 */
	public function rate_usage( int $user_id ): array {
		$limit = (int) $this->c->get( Settings::class )->get( 'ai_rate_limit', 30 );
		$used  = (int) get_transient( $this->rate_key( $user_id ) );
		return array(
			'limit'     => $limit,
			'used'      => $used,
			'remaining' => $limit > 0 ? max( 0, $limit - $used ) : null,
		);
	}

	/**
	 * Transient key for the current hour window.
	 *
	 * @param int $user_id User.
	 */
	private function rate_key( int $user_id ): string {
		return 'flseo_ai_rate_' . $user_id . '_' . gmdate( 'YmdH' );
	}

	/**
	 * Seconds until the hourly window resets.
	 */
	private function seconds_to_next_hour(): int {
		return max( 1, HOUR_IN_SECONDS - ( time() % HOUR_IN_SECONDS ) );
	}

	/**
	 * Insert a pending suggestion.
	 *
	 * @param int    $post_id Post or attachment.
	 * @param string $field   Field.
	 * @param string $value   Suggestion.
	 * @param int    $user_id Creator.
	 */
	public function insert( int $post_id, string $field, string $value, int $user_id ): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			Migrations::table( 'ai_suggestions' ),
			array(
				'post_id'    => $post_id,
				'field'      => $field,
				'suggestion' => $value,
				'status'     => 'pending',
				'created_by' => $user_id,
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%d', '%s', '%s', '%s', '%d', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * One suggestion formatted for the API.
	 *
	 * @param int $id Suggestion ID.
	 * @return array<string, mixed>|null
	 */
	public function get( int $id ): ?array {
		global $wpdb;
		$table = Migrations::table( 'ai_suggestions' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d", $id ), ARRAY_A );
		return $row ? $this->format( $row ) : null;
	}

	/**
	 * List suggestions.
	 *
	 * @param int    $post_id  Filter by post (0 = all).
	 * @param string $status   Filter by status ('' = all).
	 * @param int    $page     Page.
	 * @param int    $per_page Per page.
	 * @return array{items: array<int, array<string, mixed>>, total: int}
	 */
	public function list( int $post_id = 0, string $status = '', int $page = 1, int $per_page = 50 ): array {
		global $wpdb;
		$table  = Migrations::table( 'ai_suggestions' );
		$where  = array( '1=%d' );
		$params = array( 1 );
		if ( $post_id ) {
			$where[]  = 'post_id=%d';
			$params[] = $post_id;
		}
		if ( in_array( $status, array( 'pending', 'approved', 'rejected' ), true ) ) {
			$where[]  = 'status=%s';
			$params[] = $status;
		}
		$sql = implode( ' AND ', $where );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$sql}", $params ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$sql} ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $params, array( $per_page, ( max( 1, $page ) - 1 ) * $per_page ) ) ), ARRAY_A );
		// phpcs:enable
		return array(
			'items' => array_map( array( $this, 'format' ), (array) $rows ),
			'total' => $total,
		);
	}

	/**
	 * Format a DB row.
	 *
	 * @param array<string, mixed> $row Row.
	 * @return array<string, mixed>
	 */
	private function format( array $row ): array {
		$user = get_userdata( (int) $row['created_by'] );
		$out  = array(
			'id'              => (int) $row['id'],
			'post_id'         => (int) $row['post_id'],
			'post_title'      => html_entity_decode( get_the_title( (int) $row['post_id'] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
			'field'           => (string) $row['field'],
			'suggestion'      => (string) $row['suggestion'],
			'fields'          => null,
			'applies'         => in_array( $row['field'], Prompts::APPLIED_FIELDS, true ),
			'status'          => (string) $row['status'],
			'created_by'      => (int) $row['created_by'],
			'created_by_name' => $user ? $user->display_name : '',
			'created_at'      => (string) $row['created_at'],
			'decided_at'      => $row['decided_at'] ? (string) $row['decided_at'] : null,
		);
		if ( 'opportunity_fields' === $row['field'] ) {
			$decoded       = json_decode( (string) $row['suggestion'], true );
			$out['fields'] = is_array( $decoded ) ? $decoded : array();
		}
		return $out;
	}

	/**
	 * Approve (apply) or reject a pending suggestion. Applied changes go to the audit log so they can be undone.
	 *
	 * @param int    $id       Suggestion ID.
	 * @param string $decision approve|reject.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function decide( int $id, string $decision ) {
		if ( ! in_array( $decision, array( 'approve', 'reject' ), true ) ) {
			return new \WP_Error( 'flseo_ai_decision', __( 'Choose approve or reject.', 'futurelabs-ai-seo' ), array( 'status' => 400 ) );
		}
		$row = $this->get( $id );
		if ( ! $row ) {
			return new \WP_Error( 'flseo_ai_not_found', __( 'Suggestion not found.', 'futurelabs-ai-seo' ), array( 'status' => 404 ) );
		}
		if ( 'pending' !== $row['status'] ) {
			return new \WP_Error( 'flseo_ai_decided', __( 'This suggestion was already decided.', 'futurelabs-ai-seo' ), array( 'status' => 409 ) );
		}
		$applied = array();
		$batch   = null;
		if ( 'approve' === $decision ) {
			$result = $this->apply( $row );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			list( $applied, $batch ) = $result;
		}
		$status = 'approve' === $decision ? 'approved' : 'rejected';
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->update(
			Migrations::table( 'ai_suggestions' ),
			array(
				'status'     => $status,
				'decided_at' => current_time( 'mysql', true ),
			),
			array( 'id' => $id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
		return array(
			'id'       => $id,
			'status'   => $status,
			'applied'  => $applied,
			'batch_id' => $batch,
		);
	}

	/**
	 * Write an approved suggestion to the site.
	 *
	 * @param array<string, mixed> $row Formatted suggestion.
	 * @return array{0: array<int, string>, 1: string|null}|\WP_Error Applied meta keys and audit batch.
	 */
	private function apply( array $row ) {
		$post_id = (int) $row['post_id'];
		$post    = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return new \WP_Error( 'flseo_ai_not_found', __( 'The page or image for this suggestion no longer exists.', 'futurelabs-ai-seo' ), array( 'status' => 404 ) );
		}
		$audit = $this->c->get( AuditLog::class );
		$batch = $audit->new_batch();
		switch ( $row['field'] ) {
			case 'title':
			case 'description':
				$key   = '_flseo_' . $row['field'];
				$value = PostMeta::sanitize_template( (string) $row['suggestion'] );
				$audit->record_single( 'ai_approve', $post_id, $key, (string) get_post_meta( $post_id, $key, true ), $value, $batch );
				update_post_meta( $post_id, $key, $value );
				return array( array( $key ), $batch );
			case 'alt':
				$key   = '_wp_attachment_image_alt';
				$value = sanitize_text_field( (string) $row['suggestion'] );
				$old   = (string) get_post_meta( $post_id, $key, true );
				$audit->write(
					$batch,
					'ai_approve',
					'attachment',
					$post_id,
					array(
						'kind'  => 'attachment_meta',
						'key'   => $key,
						'value' => $old,
					),
					array(
						'kind'  => 'attachment_meta',
						'key'   => $key,
						'value' => $value,
					)
				);
				update_post_meta( $post_id, $key, $value );
				return array( array( $key ), $batch );
			case 'opportunity_fields':
				$keys = array();
				foreach ( (array) $row['fields'] as $name => $raw ) {
					if ( ! isset( Prompts::OPPORTUNITY_KEYS[ $name ] ) ) {
						continue;
					}
					$value = PostMeta::sanitize( Prompts::OPPORTUNITY_KEYS[ $name ], $raw );
					if ( '' === $value ) {
						continue;
					}
					$key = '_flseo_opp_' . $name;
					$audit->record_single( 'ai_approve', $post_id, $key, (string) get_post_meta( $post_id, $key, true ), $value, $batch );
					update_post_meta( $post_id, $key, $value );
					$keys[] = $key;
				}
				return array( $keys, $keys ? $batch : null );
		}
		// Notes and briefs are kept for the editor and never written to the page.
		return array( array(), null );
	}

	/**
	 * Queue alt text suggestions for many images.
	 *
	 * @param array<int, int> $attachment_ids Attachments the user may edit.
	 * @param int             $user_id        Requesting user (rate limit owner).
	 * @return array{queued: int, skipped: int}
	 */
	public function queue_alt_batch( array $attachment_ids, int $user_id ): array {
		$queue   = (array) get_option( self::ALT_QUEUE, array() );
		$known   = array_column( $queue, 'id' );
		$pending = $this->pending_alt_ids();
		$queued  = 0;
		$skipped = 0;
		foreach ( array_unique( array_map( 'absint', $attachment_ids ) ) as $id ) {
			if ( ! $id || ! wp_attachment_is_image( $id ) || in_array( $id, $known, true ) || in_array( $id, $pending, true ) ) {
				++$skipped;
				continue;
			}
			$queue[] = array(
				'id'   => $id,
				'user' => $user_id,
			);
			++$queued;
		}
		update_option( self::ALT_QUEUE, array_values( $queue ), false );
		if ( $queued ) {
			$progress          = $this->alt_progress();
			$progress['total'] = ( $progress['remaining'] ? $progress['total'] : 0 ) + $queued;
			if ( ! $progress['remaining'] ) {
				$progress['done']   = 0;
				$progress['failed'] = 0;
				$progress['errors'] = array();
			}
			update_option( self::ALT_PROGRESS, $progress, false );
			$this->c->get( Queue::class )->async( self::ALT_HOOK );
		}
		return array(
			'queued'  => $queued,
			'skipped' => $skipped,
		);
	}

	/**
	 * Attachments with a pending alt suggestion.
	 *
	 * @return array<int, int>
	 */
	private function pending_alt_ids(): array {
		global $wpdb;
		$table = Migrations::table( 'ai_suggestions' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array_map( 'intval', (array) $wpdb->get_col( "SELECT post_id FROM {$table} WHERE field='alt' AND status='pending'" ) );
	}

	/**
	 * Progress of the alt batch.
	 *
	 * @return array{total: int, done: int, failed: int, remaining: int, errors: array<int, array<string, mixed>>}
	 */
	public function alt_progress(): array {
		$stored = (array) get_option( self::ALT_PROGRESS, array() );
		return array(
			'total'     => (int) ( $stored['total'] ?? 0 ),
			'done'      => (int) ( $stored['done'] ?? 0 ),
			'failed'    => (int) ( $stored['failed'] ?? 0 ),
			'remaining' => count( (array) get_option( self::ALT_QUEUE, array() ) ),
			'errors'    => array_slice( (array) ( $stored['errors'] ?? array() ), -20 ),
		);
	}

	/**
	 * Job: create pending alt suggestions for the next few queued images.
	 */
	public function run_alt_batch(): void {
		$queue    = (array) get_option( self::ALT_QUEUE, array() );
		$progress = $this->alt_progress();
		$jobs     = $this->c->get( Queue::class );
		$pending  = $this->pending_alt_ids();
		$handled  = 0;
		while ( $queue && $handled < self::ALT_PER_RUN ) {
			$item = $queue[0];
			$id   = (int) ( $item['id'] ?? 0 );
			if ( in_array( $id, $pending, true ) ) {
				array_shift( $queue );
				++$progress['done'];
				continue;
			}
			$result = $this->suggest( $id, 'alt', (int) ( $item['user'] ?? 0 ), false );
			if ( is_wp_error( $result ) ) {
				$data = (array) $result->get_error_data();
				if ( in_array( $result->get_error_code(), array( 'flseo_ai_user_limit', 'flseo_ai_rate_limited', 'flseo_ai_overloaded' ), true ) ) {
					// Keep the item and resume once the limit resets.
					update_option( self::ALT_QUEUE, array_values( $queue ), false );
					update_option( self::ALT_PROGRESS, $progress, false );
					$wait = max( 60, (int) ( $data['retry_after'] ?? 0 ) );
					$jobs->at( time() + $wait, self::ALT_HOOK );
					return;
				}
				if ( 'flseo_ai_disabled' === $result->get_error_code() || 'flseo_ai_no_key' === $result->get_error_code() || 'flseo_ai_bad_key' === $result->get_error_code() ) {
					// Stop: nothing can succeed until an administrator fixes the configuration.
					$progress['errors'][] = array(
						'attachment_id' => $id,
						'message'       => $result->get_error_message(),
					);
					update_option( self::ALT_PROGRESS, $progress, false );
					return;
				}
				++$progress['failed'];
				$progress['errors'][] = array(
					'attachment_id' => $id,
					'message'       => $result->get_error_message(),
				);
			} else {
				++$progress['done'];
			}
			array_shift( $queue );
			++$handled;
		}
		update_option( self::ALT_QUEUE, array_values( $queue ), false );
		unset( $progress['remaining'] );
		$progress['errors'] = array_slice( $progress['errors'], -20 );
		update_option( self::ALT_PROGRESS, $progress, false );
		if ( $queue ) {
			$jobs->async( self::ALT_HOOK );
		}
	}
}
