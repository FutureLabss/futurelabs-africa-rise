<?php
/**
 * Footer element: logo or site title.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="nt-footer-logo">
	<?php if ( has_custom_logo() ) : ?>
		<?php the_custom_logo(); ?>
	<?php else : ?>
		<a class="nt-footer-logo__title" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
	<?php endif; ?>
</div>
