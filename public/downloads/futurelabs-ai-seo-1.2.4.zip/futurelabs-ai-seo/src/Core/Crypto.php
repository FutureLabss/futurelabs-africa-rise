<?php
/**
 * Secret storage using libsodium with a key derived from WordPress salts.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Encrypts and decrypts secrets stored in options.
 */
class Crypto {

	private const PREFIX = 'il1:';

	/**
	 * Encrypt a plaintext secret. Returns an empty string when encryption is unavailable,
	 * so a secret is never stored in plaintext.
	 *
	 * @param string $plain Secret.
	 */
	public function encrypt( string $plain ): string {
		if ( '' === $plain || ! function_exists( 'sodium_crypto_secretbox' ) ) {
			return '';
		}
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		return self::PREFIX . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, $this->key() ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Decrypt a value produced by encrypt(). Also accepts the pre-1.1 format without prefix.
	 *
	 * @param string $cipher Stored value.
	 */
	public function decrypt( string $cipher ): string {
		if ( '' === $cipher || ! function_exists( 'sodium_crypto_secretbox_open' ) ) {
			return '';
		}
		if ( str_starts_with( $cipher, self::PREFIX ) ) {
			$cipher = substr( $cipher, strlen( self::PREFIX ) );
		}
		$raw = base64_decode( $cipher, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
			return '';
		}
		$nonce = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$box   = substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$plain = sodium_crypto_secretbox_open( $box, $nonce, $this->key() );
		if ( ! is_string( $plain ) ) {
			// Values written by 1.0.0 used the unprefixed salt hash as key.
			$plain = sodium_crypto_secretbox_open( $box, $nonce, hash( 'sha256', wp_salt( 'auth' ), true ) );
		}
		return is_string( $plain ) ? $plain : '';
	}

	/**
	 * Read and decrypt a secret option.
	 *
	 * @param string $option Option name.
	 */
	public function get_secret( string $option ): string {
		return $this->decrypt( (string) get_option( $option, '' ) );
	}

	/**
	 * Encrypt and store a secret option. An empty value deletes it.
	 *
	 * @param string $option Option name.
	 * @param string $plain  Secret.
	 */
	public function set_secret( string $option, string $plain ): bool {
		if ( '' === $plain ) {
			return delete_option( $option );
		}
		$cipher = $this->encrypt( $plain );
		if ( '' === $cipher ) {
			return false;
		}
		return update_option( $option, $cipher, false );
	}

	/**
	 * Whether a secret option currently holds a value.
	 *
	 * @param string $option Option name.
	 */
	public function has_secret( string $option ): bool {
		return '' !== $this->get_secret( $option );
	}

	/**
	 * 32-byte key derived from the site's auth salt.
	 */
	private function key(): string {
		return hash( 'sha256', 'futurelabs-ai-seo|' . wp_salt( 'auth' ), true );
	}
}
