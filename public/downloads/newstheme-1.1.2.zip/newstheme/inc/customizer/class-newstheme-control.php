<?php
/**
 * Generic Customizer control. The UI for each kind (color, typography,
 * repeater, …) is rendered client-side by src/customizer/controls.js.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;

/**
 * NewsTheme Customizer control.
 */
class NewsTheme_Control extends WP_Customize_Control {

	/**
	 * Control type; maps to the `newstheme` JS control constructor.
	 *
	 * @var string
	 */
	public $type = 'newstheme';

	/**
	 * Setting config from newstheme_customizer_config().
	 *
	 * @var array
	 */
	public $nf = array();

	/**
	 * Pass the config to JS.
	 */
	public function to_json() {
		parent::to_json();

		$nf = $this->nf;
		unset( $nf['section'], $nf['label'], $nf['description'], $nf['css'], $nf['body_class'] );

		if ( 'multiselect' === $nf['control'] ) {
			$nf['options'] = $this->multiselect_options( $nf['source'] );
		}

		if ( 'builder' === $nf['control'] ) {
			$nf['def'] = newstheme_builders()[ $nf['builder'] ];
		}

		if ( 'blocks' === $nf['control'] ) {
			$all              = newstheme_block_types();
			$nf['blockTypes'] = array();
			foreach ( $nf['types'] as $type ) {
				$nf['blockTypes'][ $type ] = array(
					'label'    => $all[ $type ]['label'],
					'defaults' => $all[ $type ]['defaults'],
					'fields'   => newstheme_block_fields( $type ),
				);
			}
			$nf['postTitles'] = $this->block_post_titles();
		}

		$this->json['nf'] = $nf;
	}

	/**
	 * Options for multi-select controls: all categories, or the titles of the
	 * currently selected posts (other posts are searched via REST).
	 *
	 * @param string $source 'categories' or 'posts'.
	 * @return array<int, array{id: int, label: string}>
	 */
	private function multiselect_options( $source ) {
		$options = array();

		if ( 'categories' === $source ) {
			foreach ( get_categories( array( 'hide_empty' => false ) ) as $term ) {
				$options[] = array(
					'id'    => (int) $term->term_id,
					'label' => $term->name,
				);
			}
			return $options;
		}

		$selected = $this->setting ? (array) $this->setting->value() : array();
		foreach ( array_filter( array_map( 'absint', $selected ) ) as $post_id ) {
			$options[] = array(
				'id'    => $post_id,
				'label' => get_the_title( $post_id ),
			);
		}
		return $options;
	}

	/**
	 * Titles of hand-picked posts used in a block list, so the control can
	 * label them without a request.
	 *
	 * @return array<int, string>
	 */
	private function block_post_titles() {
		$ids = array();
		foreach ( (array) ( $this->setting ? $this->setting->value() : array() ) as $block ) {
			foreach ( array( 'query', 'side' ) as $key ) {
				$ids = array_merge( $ids, (array) ( $block[ $key ]['posts'] ?? array() ) );
			}
		}
		$titles = array();
		foreach ( array_unique( array_map( 'absint', $ids ) ) as $id ) {
			if ( $id ) {
				$titles[ $id ] = get_the_title( $id );
			}
		}
		return $titles;
	}

	/**
	 * Static markup; the body is filled in by JS.
	 */
	protected function render_content() {
		$kind = $this->nf['control'];

		if ( 'heading' === $kind ) {
			printf( '<h3 class="nt-heading">%s</h3>', esc_html( $this->label ) );
			if ( $this->description ) {
				printf( '<p class="description customize-control-description">%s</p>', esc_html( $this->description ) );
			}
			return;
		}
		?>
		<div class="nt-control nt-control--<?php echo esc_attr( $kind ); ?>">
			<?php if ( $this->label ) : ?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php endif; ?>
			<?php if ( $this->description ) : ?>
				<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php endif; ?>
			<div class="nt-control__body"></div>
		</div>
		<?php
	}
}
