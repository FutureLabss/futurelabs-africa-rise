<?php
/**
 * Executes redirects early on template_redirect, and attachment-to-parent redirects.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Redirects;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Module;
use FutureLabs\AISEO\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * One indexed lookup per front-end request; regex rules only when no exact rule matches.
 */
class Router implements Module {

	/**
	 * Whether this request was answered with 410 Gone.
	 *
	 * @var bool
	 */
	public static bool $gone = false;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Hook registration.
	 */
	public function register(): void {
		add_action( 'template_redirect', array( $this, 'handle' ), 1 );
	}

	/**
	 * Current request path.
	 */
	public static function request_path(): string {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only the path is used after parsing.
		return Rules::normalize_path( (string) wp_parse_url( (string) $uri, PHP_URL_PATH ) );
	}

	/**
	 * Redirect when a rule matches.
	 */
	public function handle(): void {
		if ( is_admin() || wp_doing_cron() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		if ( is_attachment() && $this->c->get( Settings::class )->get( 'redirect_attachments' ) ) {
			$parent = wp_get_post_parent_id( get_queried_object_id() );
			if ( $parent && 'publish' === get_post_status( $parent ) ) {
				$this->redirect( (string) get_permalink( $parent ), 301 );
				return;
			}
		}
		$path = self::request_path();
		if ( '/' === $path ) {
			return;
		}
		$rule = $this->c->get( Rules::class )->match( $path );
		if ( ! $rule ) {
			return;
		}
		$this->c->get( Rules::class )->hit( (int) $rule->id );
		if ( 410 === (int) $rule->type ) {
			self::$gone = true;
			global $wp_query;
			if ( $wp_query instanceof \WP_Query ) {
				$wp_query->set_404();
			}
			status_header( 410 );
			nocache_headers();
			return;
		}
		$target = (string) $rule->resolved_target;
		if ( '' === $target || ( Rules::normalize_path( $target ) === $path && $this->same_host( $target ) ) ) {
			return;
		}
		$query = isset( $_SERVER['QUERY_STRING'] ) ? sanitize_text_field( wp_unslash( $_SERVER['QUERY_STRING'] ) ) : '';
		if ( '' !== $query && ! str_contains( $target, '?' ) ) {
			$target .= '?' . $query;
		}
		$this->redirect( $target, (int) $rule->type );
	}

	/**
	 * Whether a URL is on this site.
	 *
	 * @param string $url URL.
	 */
	private function same_host( string $url ): bool {
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		return '' === $host || strtolower( $host ) === strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	}

	/**
	 * Send the redirect. External targets are allowed because an administrator created them.
	 *
	 * @param string $url    Target.
	 * @param int    $status Status.
	 */
	protected function redirect( string $url, int $status ): void {
		// phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- targets are admin-defined, including external domains.
		if ( wp_redirect( esc_url_raw( $url ), $status, 'FutureLabs AI SEO' ) ) {
			exit;
		}
	}
}
