<?php
/**
 * Footer element: footer menu.
 *
 * @package NewsTheme
 */

defined( 'ABSPATH' ) || exit;
?>
<nav class="nt-footer__nav" aria-label="<?php esc_attr_e( 'Footer', 'newstheme' ); ?>">
	<?php
	wp_nav_menu(
		array(
			'theme_location' => 'footer',
			'menu_class'     => 'nt-footer-menu',
			'container'      => false,
			'depth'          => 1,
		)
	);
	?>
</nav>
