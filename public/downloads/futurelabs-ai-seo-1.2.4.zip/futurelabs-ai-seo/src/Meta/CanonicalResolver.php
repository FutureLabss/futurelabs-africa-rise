<?php
/**
 * Decides the canonical URL for a request or a post.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Meta;

use FutureLabs\AISEO\Core\Container;

defined( 'ABSPATH' ) || exit;

/**
 * Canonical rules: object override → WordPress canonical → archive link.
 */
class CanonicalResolver {

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Canonical for a context; empty string when none should be output.
	 *
	 * @param Context $context Context.
	 */
	public function resolve( Context $context ): string {
		$url = '';
		switch ( $context->kind ) {
			case 'singular':
			case 'front':
			case 'home':
				if ( $context->object instanceof \WP_Post ) {
					$url = $this->for_post( $context->object );
					if ( 'home' === $context->kind && $context->page > 1 ) {
						$url = $this->paged( $url, $context->page );
					}
				} else {
					$url = $this->paged( home_url( '/' ), $context->page );
				}
				break;
			case 'term':
				if ( $context->object instanceof \WP_Term ) {
					$override = (string) get_term_meta( $context->object->term_id, '_flseo_canonical', true );
					if ( '' !== $override ) {
						$url = $override;
					} else {
						$link = get_term_link( $context->object );
						$url  = is_wp_error( $link ) ? '' : $this->paged( $link, $context->page );
					}
				}
				break;
			case 'author':
				if ( $context->object instanceof \WP_User ) {
					$url = $this->paged( get_author_posts_url( $context->object->ID ), $context->page );
				}
				break;
			case 'post_type_archive':
				if ( $context->object instanceof \WP_Post_Type ) {
					$link = get_post_type_archive_link( $context->object->name );
					$url  = $link ? $this->paged( $link, $context->page ) : '';
				}
				break;
		}
		/**
		 * Filter the canonical URL. Return an empty string to suppress output.
		 *
		 * @param string  $url     Canonical URL.
		 * @param Context $context Context.
		 */
		return (string) apply_filters( 'flseo_canonical', $url, $context );
	}

	/**
	 * Canonical URL for a post regardless of query.
	 *
	 * @param \WP_Post $post Post.
	 */
	public function for_post( \WP_Post $post ): string {
		$override = (string) get_post_meta( $post->ID, '_flseo_canonical', true );
		if ( '' !== $override && \FutureLabs\AISEO\Core\Url::is_valid( $override ) ) {
			return $override;
		}
		$url = wp_get_canonical_url( $post );
		return $url ? (string) $url : (string) get_permalink( $post );
	}

	/**
	 * Whether a post declares itself as canonical (no cross-URL canonical).
	 *
	 * @param \WP_Post $post Post.
	 */
	public function is_self_canonical( \WP_Post $post ): bool {
		$permalink = (string) get_permalink( $post );
		return self::same_url( $this->for_post( $post ), $permalink );
	}

	/**
	 * Compare two URLs ignoring trailing slash, scheme and host case.
	 *
	 * @param string $a URL.
	 * @param string $b URL.
	 */
	public static function same_url( string $a, string $b ): bool {
		$norm = static function ( string $url ): string {
			$parts = wp_parse_url( $url );
			if ( ! $parts ) {
				return $url;
			}
			$host  = strtolower( (string) ( $parts['host'] ?? '' ) );
			$path  = untrailingslashit( (string) ( $parts['path'] ?? '' ) );
			$query = isset( $parts['query'] ) ? '?' . $parts['query'] : '';
			return $host . $path . $query;
		};
		return $norm( $a ) === $norm( $b );
	}

	/**
	 * Add a page number to an archive URL.
	 *
	 * @param string $url  Base URL.
	 * @param int    $page Page.
	 */
	private function paged( string $url, int $page ): string {
		if ( $page <= 1 ) {
			return $url;
		}
		global $wp_rewrite;
		if ( $wp_rewrite instanceof \WP_Rewrite && $wp_rewrite->using_permalinks() ) {
			return user_trailingslashit( trailingslashit( $url ) . $wp_rewrite->pagination_base . '/' . $page );
		}
		return add_query_arg( 'paged', $page, $url );
	}
}
