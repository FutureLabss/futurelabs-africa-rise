<?php
/**
 * Keyword suggestions: high-impression, low-CTR queries at positions 8–20, per page.
 *
 * @package FutureLabs AI SEO
 */

namespace FutureLabs\AISEO\Reports;

use FutureLabs\AISEO\Core\Container;
use FutureLabs\AISEO\Core\Migrations;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the latest Search Console period.
 */
class Keywords {

	public const MIN_IMPRESSIONS = 50;
	public const MAX_CTR         = 0.02;
	public const MIN_POSITION    = 8;
	public const MAX_POSITION    = 20;

	/**
	 * Container.
	 *
	 * @var Container
	 */
	private Container $c;

	/**
	 * Constructor.
	 *
	 * @param Container $c Container.
	 */
	public function __construct( Container $c ) {
		$this->c = $c;
	}

	/**
	 * Suggestions grouped by page.
	 *
	 * @param int $limit Max pages.
	 * @return array{range: string, items: array<int, array<string, mixed>>, total: int}
	 */
	public function suggestions( int $limit = 100 ): array {
		$data  = $this->c->get( SearchData::class );
		$range = $data->latest_range();
		if ( '' === $range ) {
			return array(
				'range' => '',
				'items' => array(),
				'total' => 0,
			);
		}
		/**
		 * Minimum impressions for a query to be suggested.
		 *
		 * @param int $min Impressions.
		 */
		$min = (int) apply_filters( 'flseo_keyword_min_impressions', self::MIN_IMPRESSIONS );
		global $wpdb;
		$table = Migrations::table( 'gsc_queries' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT url_hash, MAX(url) url, query, SUM(clicks) clicks, SUM(impressions) impressions, AVG(position) position FROM {$table} WHERE date_range=%s GROUP BY url_hash, query HAVING impressions>=%d AND position BETWEEN %d AND %d ORDER BY impressions DESC LIMIT 2000", $range, $min, self::MIN_POSITION, self::MAX_POSITION ) );
		/**
		 * Suggestions keyed by URL hash.
		 *
		 * @var array<string, array<string, mixed>> $pages
		 */
		$pages = array();
		foreach ( (array) $rows as $row ) {
			$ctr = (int) $row->impressions > 0 ? (int) $row->clicks / (int) $row->impressions : 0;
			if ( $ctr >= self::MAX_CTR ) {
				continue;
			}
			$hash = (string) $row->url_hash;
			if ( ! isset( $pages[ $hash ] ) ) {
				$url            = $data->url( $hash, (string) $row->url );
				$post_id        = $data->post_id( $url );
				$pages[ $hash ] = array(
					'url'         => $url,
					'post_id'     => $post_id,
					'title'       => $post_id ? html_entity_decode( get_the_title( $post_id ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) : '',
					'impressions' => 0,
					'queries'     => array(),
					'suggestion'  => __( 'These queries already show this page on page one or two but rarely get clicks. Check that the title and description match what searchers ask, and answer each query clearly on the page.', 'futurelabs-ai-seo' ),
				);
			}
			$pages[ $hash ]['impressions'] = (int) $pages[ $hash ]['impressions'] + (int) $row->impressions;
			$queries                       = (array) $pages[ $hash ]['queries'];
			$queries[]                     = array(
				'query'       => (string) $row->query,
				'clicks'      => (int) $row->clicks,
				'impressions' => (int) $row->impressions,
				'ctr_percent' => round( $ctr * 100, 2 ),
				'position'    => round( (float) $row->position, 1 ),
			);
			$pages[ $hash ]['queries']     = $queries;
		}
		$items = array();
		foreach ( $pages as $page ) {
			$items[] = $page;
		}
		usort( $items, static fn( $a, $b ) => (int) $b['impressions'] <=> (int) $a['impressions'] );
		return array(
			'range' => $range,
			'items' => array_slice( $items, 0, max( 1, $limit ) ),
			'total' => count( $items ),
		);
	}
}
